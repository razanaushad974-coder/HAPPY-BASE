import {
  createClient,
  type SupabaseClient,
} from "@supabase/supabase-js";

import type {
  ModulePersistenceAdapter,
} from "./module-persistence";
import type {
  ModuleDataValue,
  ModuleRecord,
} from "./module-data-store";
import {
  getSupabaseServerConfig,
} from "../../database/supabase-server-config";
import {
  bootstrapHappyModuleRuntimeBridge,
} from "../runtime/happy-module-runtime-bridge";

const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isUuid(value: string): boolean {
  return UUID_PATTERN.test(value);
}
export interface SupabaseModulePersistenceContext {
  organizationId: string;
  workspaceId: string;
  userId?: string;
  accessToken?: string;
}

interface HappyModuleRecordRow {
  id: string;
  organization_id: string;
  workspace_id: string;
  user_id: string | null;
  module_number: number;
  module_id: string;
  module_name: string;
  version: number;
  data: ModuleDataValue;
  created_at: string;
  updated_at: string;
}

export class RealSupabaseModulePersistenceAdapter
  implements ModulePersistenceAdapter
{
  readonly kind = "SUPABASE" as const;

  private readonly url: string;
  private readonly publishableKey?: string;
  private readonly moduleMetadata =
    bootstrapHappyModuleRuntimeBridge().registry;

  constructor(
    private readonly context: SupabaseModulePersistenceContext,
    private readonly clientFactory: (
      url: string,
      key: string,
      accessToken: string,
    ) => SupabaseClient = (
      url,
      key,
      accessToken,
    ) =>
      createClient(url, key, {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
        global: {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      }),
  ) {
    const config = getSupabaseServerConfig();

    this.url = config.url;
    this.publishableKey =
      config.publishableKey;
  }

  get connected(): boolean {
    return Boolean(
      this.url &&
        this.publishableKey &&
        isUuid(this.context.organizationId) &&
        isUuid(this.context.workspaceId) &&
        this.context.accessToken,
    );
  }

  status(): "AVAILABLE" | "NOT_YET_CONNECTED" {
    return this.connected
      ? "AVAILABLE"
      : "NOT_YET_CONNECTED";
  }

  private client(): SupabaseClient {
    if (!this.url) {
      throw new Error(
        "Supabase URL is not configured.",
      );
    }

    if (!this.publishableKey) {
      throw new Error(
        "Supabase publishable key is not configured.",
      );
    }

    if (!this.context.organizationId) {
      throw new Error(
        "Supabase module persistence requires organizationId.",
      );
    }

    if (!isUuid(this.context.organizationId)) {
      throw new Error(
        "Supabase module persistence requires a valid organization UUID; canonical tenant setup is required.",
      );
    }

    if (!this.context.workspaceId) {
      throw new Error(
        "Supabase module persistence requires workspaceId.",
      );
    }

    if (!isUuid(this.context.workspaceId)) {
      throw new Error(
        "Supabase module persistence requires a valid workspace UUID; canonical tenant setup is required.",
      );
    }

    if (!this.context.accessToken) {
      throw new Error(
        "Authenticated Supabase access token is required for module persistence.",
      );
    }

    return this.clientFactory(
      this.url,
      this.publishableKey,
      this.context.accessToken,
    );
  }

  private requireCanonicalModule(
    moduleNumber: number,
  ) {
    const runtime =
      this.moduleMetadata.get(moduleNumber);

    if (!runtime) {
      throw new Error(
        `HAPPY canonical module ${moduleNumber} is not registered`,
      );
    }

    return runtime.module;
  }

  private mapRow<T extends ModuleDataValue>(
    row: HappyModuleRecordRow,
  ): ModuleRecord<T> {
    return {
      id: row.id,
      tenantId: row.workspace_id,
      moduleNumber: row.module_number,
      data: structuredClone(
        row.data,
      ) as T,
      version: row.version,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  async create<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    const { data, error } = await this.client()
      .from("happy_module_records")
      .insert({
        id: record.id,
        organization_id:
          this.context.organizationId,
        workspace_id:
          this.context.workspaceId,
        user_id:
          this.context.userId ?? null,
        module_number:
          record.moduleNumber,
        module_id:
          this.requireCanonicalModule(record.moduleNumber).id,
        module_name:
          this.requireCanonicalModule(record.moduleNumber).name,
        version:
          record.version,
        data:
          record.data,
        created_at:
          record.createdAt,
        updated_at:
          record.updatedAt,
      })
      .select("*")
      .single();

    if (error) {
      throw new Error(
        `Supabase module INSERT failed: ${error.message}`,
      );
    }

    return this.mapRow<T>(
      data as HappyModuleRecordRow,
    );
  }

  async get<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): Promise<ModuleRecord<T> | null> {
    if (tenantId !== this.context.workspaceId) {
      throw new Error(
        "Supabase module tenant scope mismatch.",
      );
    }

    const { data, error } = await this.client()
      .from("happy_module_records")
      .select("*")
      .eq(
        "organization_id",
        this.context.organizationId,
      )
      .eq(
        "workspace_id",
        this.context.workspaceId,
      )
      .eq(
        "module_number",
        moduleNumber,
      )
      .eq("id", recordId)
      .maybeSingle();

    if (error) {
      throw new Error(
        `Supabase module SELECT failed: ${error.message}`,
      );
    }

    if (!data) {
      return null;
    }

    return this.mapRow<T>(
      data as HappyModuleRecordRow,
    );
  }

  async list<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
  ): Promise<ModuleRecord<T>[]> {
    if (tenantId !== this.context.workspaceId) {
      throw new Error(
        "Supabase module tenant scope mismatch.",
      );
    }

    const { data, error } = await this.client()
      .from("happy_module_records")
      .select("*")
      .eq(
        "organization_id",
        this.context.organizationId,
      )
      .eq(
        "workspace_id",
        this.context.workspaceId,
      )
      .eq(
        "module_number",
        moduleNumber,
      )
      .order(
        "updated_at",
        { ascending: false },
      );

    if (error) {
      throw new Error(
        `Supabase module LIST failed: ${error.message}`,
      );
    }

    return (data ?? []).map(
      (row) =>
        this.mapRow<T>(
          row as HappyModuleRecordRow,
        ),
    );
  }

  async update<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    if (
      this.context.workspaceId !==
      record.tenantId
    ) {
      throw new Error(
        "Supabase module tenant scope mismatch.",
      );
    }

    const expectedVersion =
      record.version - 1;

    if (expectedVersion < 1) {
      throw new Error(
        "Supabase module update requires a next version greater than 1.",
      );
    }

    const { data, error } = await this.client()
      .from("happy_module_records")
      .update({
        version:
          record.version,
        data:
          record.data,
        updated_at:
          record.updatedAt,
      })
      .eq(
        "organization_id",
        this.context.organizationId,
      )
      .eq(
        "workspace_id",
        this.context.workspaceId,
      )
      .eq(
        "module_number",
        record.moduleNumber,
      )
      .eq(
        "id",
        record.id,
      )
      .eq(
        "version",
        expectedVersion,
      )
      .select("*")
      .maybeSingle();

    if (error) {
      throw new Error(
        `Supabase module UPDATE failed: ${error.message}`,
      );
    }

    if (!data) {
      throw new Error(
        "Supabase module update conflict or record not found.",
      );
    }

    return this.mapRow<T>(
      data as HappyModuleRecordRow,
    );
  }

  async delete(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
    expectedVersion: number,
  ): Promise<void> {
    if (tenantId !== this.context.workspaceId) {
      throw new Error(
        "Supabase module tenant scope mismatch.",
      );
    }

    const { error } = await this.client()
      .from("happy_module_records")
      .delete()
      .eq(
        "organization_id",
        this.context.organizationId,
      )
      .eq(
        "workspace_id",
        this.context.workspaceId,
      )
      .eq(
        "module_number",
        moduleNumber,
      )
      .eq("id", recordId)
      .eq("version", expectedVersion);

    if (error) {
      throw new Error(
        `Supabase module DELETE failed: ${error.message}`,
      );
    }
  }
}
