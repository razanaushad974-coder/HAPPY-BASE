import { describe, it } from "vitest";

import {
  InMemoryModulePersistenceAdapter,
  SupabaseModulePersistenceAdapter,
} from "../../../core/modules/data/module-persistence";
import {
  ModuleRecord,
} from "../../../core/modules/data/module-data-store";

const assert: (
  condition: unknown,
  message: string,
) => asserts condition = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

const record: ModuleRecord = {
  id: "customer-001",
  tenantId: "tenant-a",
  moduleNumber: 282,
  data: {
    name: "Customer One",
  },
  version: 1,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

describe("HAPPY Command 20 — Module Persistence Boundary", () => {
  it("verifies the canonical module persistence boundary", async () => {
    const memory = new InMemoryModulePersistenceAdapter();

assert(
  memory.kind === "IN_MEMORY",
  "memory adapter kind incorrect",
);

assert(
  memory.connected === true,
  "memory adapter must be connected",
);

await memory.create(record);

const fetched = await memory.get(
  "tenant-a",
  282,
  "customer-001",
);

assert(
  fetched?.data.name === "Customer One",
  "memory get failed",
);

const list = await memory.list(
  "tenant-a",
  282,
);

assert(
  list.length === 1,
  "memory list failed",
);

const otherTenant = await memory.get(
  "tenant-b",
  282,
  "customer-001",
);

assert(
  otherTenant === null,
  "persistent cross-tenant read leaked",
);

const supabase =
  new SupabaseModulePersistenceAdapter();

assert(
  supabase.kind === "SUPABASE",
  "Supabase adapter kind incorrect",
);

assert(
  supabase.connected === false,
  "Supabase must remain disconnected",
);

let disconnectedBlocked = false;

try {
  await supabase.get(
    "tenant-a",
    282,
    "customer-001",
  );
} catch (error) {
  disconnectedBlocked =
    error instanceof Error &&
    error.message.includes(
      "NOT_YET_CONNECTED",
    );
}

assert(
  disconnectedBlocked,
  "Supabase disconnected boundary was not enforced",
);

console.log(
  "HAPPY COMMAND 20 MODULE PERSISTENCE BOUNDARY: PASS",
);

console.log({
  inMemory: "READY",
  tenantIsolation: true,
  supabase: "NOT_YET_CONNECTED",
  disconnectedBoundary: true,
  moduleLayerUnchanged: true,
});

  });
});
