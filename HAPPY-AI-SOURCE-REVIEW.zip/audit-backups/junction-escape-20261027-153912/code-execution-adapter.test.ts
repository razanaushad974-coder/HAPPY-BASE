import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

import { CodeExecutionAdapter } from "../../../core/execution/code-execution-adapter";
import { WorkspaceCodeExecutor } from "../../../core/execution/workspace-code-executor";
import type { ExecutionRequest } from "../../../core/execution/types";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

function makeRequest(
  overrides: Partial<ExecutionRequest> = {},
): ExecutionRequest {
  return {
    id: "code-exec-test",
    taskId: "code-task-test",
    missionId: "code-mission-test",
    capability: "CODE",
    action: "MODIFY",
    input: {
      command:
        "modify HAPPY source safely",
      changes: [
        {
          action: "CREATE",
          path: "adapter-contract-test.txt",
          content: "HAPPY CODE adapter contract",
        },
      ],
    },
    requiresApproval: false,
    approved: true,
    risk: "LOW",
    createdAt:
      new Date().toISOString(),
    ...overrides,
  };
}

async function main(): Promise<void> {
  const workspaceRoot =
    mkdtempSync(
      join(
        tmpdir(),
        "happy-code-adapter-",
      ),
    );

  try {
    const adapter =
      new CodeExecutionAdapter(
        new WorkspaceCodeExecutor(
          workspaceRoot,
        ),
      );

    assert(
      adapter.status() ===
        "AVAILABLE",
      "CODE adapter must be AVAILABLE when the workspace executor is connected.",
    );

    assert(
      adapter.canExecute(
        makeRequest({
          action: "CREATE",
        }),
      ),
      "CREATE should route to CODE.",
    );

    assert(
      adapter.canExecute(
        makeRequest({
          action: "MODIFY",
        }),
      ),
      "MODIFY should route to CODE.",
    );

    assert(
      adapter.canExecute(
        makeRequest({
          action: "BUILD",
        }),
      ),
      "BUILD should route to CODE.",
    );

    assert(
      adapter.canExecute(
        makeRequest({
          action: "TEST",
        }),
      ),
      "TEST should route to CODE.",
    );

    const approval =
      await adapter.execute(
        makeRequest({
          requiresApproval: true,
          approved: false,
        }),
      );

    assert(
      approval.status ===
        "WAITING_APPROVAL",
      "Approval gate failed.",
    );

    const result =
      await adapter.execute(
        makeRequest(),
      );

    assert(
      result.status ===
        "COMPLETED",
      "Connected CODE workspace execution should complete approved file changes.",
    );

    assert(
      result.output !== undefined,
      "CODE adapter contract output missing.",
    );

    const changedFiles =
      (
        result.output as {
          changedFiles?: unknown;
        }
      ).changedFiles;

    assert(
      Array.isArray(changedFiles) &&
        changedFiles.includes(
          "adapter-contract-test.txt",
        ),
      "Expected workspace file change was not reported.",
    );

    console.log(
      "STEP 39 CODE execution adapter test: PASS",
    );

    console.log({
      actionRouting: true,
      approvalGate: true,
      workspaceExecutionContract: true,
      realWorkspaceMutationIsolated: true,
      notYetConnectedNotClaimedWithoutConnection: true,
    });
  } finally {
    rmSync(
      workspaceRoot,
      {
        recursive: true,
        force: true,
      },
    );
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
