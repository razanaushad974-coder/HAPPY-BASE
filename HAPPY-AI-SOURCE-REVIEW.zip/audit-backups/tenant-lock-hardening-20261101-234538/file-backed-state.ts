import {
    randomUUID,
} from "node:crypto";

import {
    closeSync,
    existsSync,
    fstatSync,
    lstatSync,
    mkdirSync,
    openSync,
    readFileSync,
    renameSync,
    unlinkSync,
    writeFileSync,
} from "node:fs";

import {
    dirname,
    join,
    resolve,
} from "node:path";

import {
    JsonFileStateAdapter,
} from "../persistence/adapters/json-file-adapter";

import {
    PersistenceService,
} from "../persistence/service";

import {
    createHappyStateStore,
} from "../state/factory";

import type {
    HappyState,
} from "../persistence/state";

import type {
    HappyStateStore,
} from "../state/happy-state-store";

export interface ResolvedWorkspaceTenant {
    organizationId: string;
    workspaceId: string;
    userId: string;
}

interface PersistedWorkspaceTenant {
    organizationId: string;
    workspaceId: string;
    userId: string;
    createdAt: string;
    source:
        | "LEGACY_STATE"
        | "BOOTSTRAPPED";
}

interface WorkspaceTenantRegistry {
    version: 1;
    tenants: PersistedWorkspaceTenant[];
}

const TENANT_COLLECTIONS:
    Array<keyof HappyState> = [
        "commands",
        "missions",
        "tasks",
        "executions",
        "verifications",
        "evidence",
        "memories",
        "approvals",
        "auditEvents",
    ];

export function getWorkspacePersistenceFile(): string {
    return join(
        process.cwd(),
        ".happy-state",
        "orchestration-state.json",
    );
}

export function getWorkspaceTenantRegistryFile(): string {
    return join(
        process.cwd(),
        ".happy-state",
        "workspace-tenants.json",
    );
}

export function createWorkspacePersistence(): PersistenceService {
    return new PersistenceService(
        new JsonFileStateAdapter(
            getWorkspacePersistenceFile(),
        ),
    );
}

function asRecord(
    value: unknown,
): Record<string, unknown> | undefined {
    if (
        typeof value !== "object" ||
        value === null
    ) {
        return undefined;
    }

    return value as Record<string, unknown>;
}

function collectTenantMatches(
    state: HappyState,
    userId: string,
): Map<string, ResolvedWorkspaceTenant> {
    const matches =
        new Map<
            string,
            ResolvedWorkspaceTenant
        >();

    for (
        const collectionName
        of TENANT_COLLECTIONS
    ) {
        const collection =
            state[collectionName];

        for (
            const record
            of collection
        ) {
            const wrapper =
                asRecord(
                    record.data,
                );

            if (!wrapper) {
                continue;
            }

            if (
                wrapper.userId !==
                userId
            ) {
                continue;
            }

            const organizationId =
                typeof wrapper.organizationId ===
                "string"
                    ? wrapper.organizationId.trim()
                    : "";

            const workspaceId =
                typeof wrapper.workspaceId ===
                "string"
                    ? wrapper.workspaceId.trim()
                    : "";

            if (
                !organizationId ||
                !workspaceId
            ) {
                continue;
            }

            const key =
                `${organizationId}::${workspaceId}`;

            matches.set(
                key,
                {
                    organizationId,
                    workspaceId,
                    userId,
                },
            );
        }
    }

    return matches;
}

export function resolveFileBackedWorkspaceTenant(
    persistence: PersistenceService,
    userId: string,
): ResolvedWorkspaceTenant {
    const normalizedUserId =
        userId.trim();

    if (!normalizedUserId) {
        throw new Error(
            "AUTHENTICATED_USER_ID_REQUIRED",
        );
    }

    const matches =
        collectTenantMatches(
            persistence.snapshot(),
            normalizedUserId,
        );

    if (matches.size === 0) {
        throw new Error(
            "WORKSPACE_TENANT_NOT_FOUND",
        );
    }

    if (matches.size > 1) {
        throw new Error(
            "AMBIGUOUS_WORKSPACE_TENANT",
        );
    }

    return Array.from(
        matches.values(),
    )[0];
}

function emptyRegistry(): WorkspaceTenantRegistry {
    return {
        version: 1,
        tenants: [],
    };
}

function readRegistry(
    registryFile: string,
): WorkspaceTenantRegistry {
    if (!existsSync(registryFile)) {
        return emptyRegistry();
    }

    let parsed: unknown;

    try {
        parsed = JSON.parse(
            readFileSync(registryFile, "utf8"),
        );
    } catch {
        throw new Error(
            "WORKSPACE_TENANT_REGISTRY_INVALID_JSON",
        );
    }

    const record = asRecord(parsed);

    if (!record || record.version !== 1) {
        throw new Error(
            "WORKSPACE_TENANT_REGISTRY_UNSUPPORTED_VERSION",
        );
    }

    if (!Array.isArray(record.tenants)) {
        throw new Error(
            "WORKSPACE_TENANT_REGISTRY_INVALID_STRUCTURE",
        );
    }

    const tenants: PersistedWorkspaceTenant[] = [];

    for (const value of record.tenants) {
        const tenant = asRecord(value);

        if (
            !tenant ||
            typeof tenant.organizationId !== "string" ||
            !tenant.organizationId.trim() ||
            typeof tenant.workspaceId !== "string" ||
            !tenant.workspaceId.trim() ||
            typeof tenant.userId !== "string" ||
            !tenant.userId.trim() ||
            typeof tenant.createdAt !== "string" ||
            !tenant.createdAt.trim() ||
            !Number.isFinite(Date.parse(tenant.createdAt)) ||
            (
                tenant.source !== "LEGACY_STATE" &&
                tenant.source !== "BOOTSTRAPPED"
            )
        ) {
            throw new Error(
                "WORKSPACE_TENANT_REGISTRY_INVALID_TENANT",
            );
        }

        tenants.push({
            organizationId: tenant.organizationId,
            workspaceId: tenant.workspaceId,
            userId: tenant.userId,
            createdAt: tenant.createdAt,
            source: tenant.source,
        });
    }

    return { version: 1, tenants };
}

function withRegistryLock<T>(
    registryFile: string,
    operation: () => T,
): T {
    const target = resolve(registryFile);
    mkdirSync(dirname(target), { recursive: true });

    const lockPath = `${target}.lock`;
    const deadline = Date.now() + 10_000;
    const waitCell = new Int32Array(new SharedArrayBuffer(4));
    const lockToken = randomUUID();

    let lockFd: number | undefined;
    let lockIdentity: { dev: number; ino: number } | undefined;

    const cleanupOwnLock = (requireToken: boolean): void => {
        if (!lockIdentity) return;

        try {
            const pathIdentity = lstatSync(lockPath);

            if (
                pathIdentity.dev !== lockIdentity.dev ||
                pathIdentity.ino !== lockIdentity.ino
            ) return;

            if (requireToken) {
                let metadata: { token?: unknown };

                try {
                    metadata = JSON.parse(
                        readFileSync(lockPath, "utf8"),
                    ) as { token?: unknown };
                } catch {
                    return;
                }

                if (metadata.token !== lockToken) return;
            }

            unlinkSync(lockPath);
        } catch {
            // Preserve an unverified lock; operator recovery may be required.
        }
    };

    while (lockFd === undefined) {
        try {
            lockFd = openSync(lockPath, "wx");
            const identity = fstatSync(lockFd);
            lockIdentity = {
                dev: identity.dev,
                ino: identity.ino,
            };

            writeFileSync(
                lockFd,
                JSON.stringify({
                    token: lockToken,
                    pid: process.pid,
                    hostname:
                        process.env.COMPUTERNAME ??
                        process.env.HOSTNAME ??
                        "unknown",
                    createdAt: new Date().toISOString(),
                }),
                "utf8",
            );
        } catch (error) {
            if (lockFd !== undefined) {
                cleanupOwnLock(false);
                try {
                    closeSync(lockFd);
                } finally {
                    lockFd = undefined;
                    lockIdentity = undefined;
                }
            }

            const code = (error as NodeJS.ErrnoException).code;
            if (code !== "EEXIST") throw error;

            if (Date.now() >= deadline) {
                let owner = "owner metadata unavailable";
                try {
                    owner = readFileSync(lockPath, "utf8");
                } catch {}

                throw new Error(
                    `WORKSPACE_TENANT_REGISTRY_LOCK_TIMEOUT: ${lockPath}; refusing unsafe registration. Owner: ${owner}`,
                );
            }

            Atomics.wait(waitCell, 0, 0, 10);
        }
    }

    try {
        return operation();
    } finally {
        try {
            closeSync(lockFd);
        } finally {
            cleanupOwnLock(true);
        }
    }
}

function writeRegistry(
    registryFile: string,
    registry: WorkspaceTenantRegistry,
): void {
    const target = resolve(registryFile);
    mkdirSync(dirname(target), { recursive: true });

    const temporary =
        `${target}.${process.pid}.${randomUUID()}.tmp`;

    try {
        writeFileSync(
            temporary,
            JSON.stringify(registry, null, 2),
            { encoding: "utf8", flag: "wx" },
        );
        renameSync(temporary, target);
    } finally {
        if (existsSync(temporary)) {
            unlinkSync(temporary);
        }
    }
}

function collectRegisteredTenantsForUser(
    registry: WorkspaceTenantRegistry,
    userId: string,
): ResolvedWorkspaceTenant[] {
    const unique =
        new Map<
            string,
            ResolvedWorkspaceTenant
        >();

    for (
        const tenant
        of registry.tenants
    ) {
        if (
            tenant.userId !==
            userId
        ) {
            continue;
        }

        unique.set(
            `${tenant.organizationId}::${tenant.workspaceId}`,
            {
                organizationId:
                    tenant.organizationId,
                workspaceId:
                    tenant.workspaceId,
                userId:
                    tenant.userId,
            },
        );
    }

    return Array.from(
        unique.values(),
    );
}

function registerTenant(
    registryFile: string,
    tenant: ResolvedWorkspaceTenant,
    source:
        PersistedWorkspaceTenant["source"],
): ResolvedWorkspaceTenant {
    const registry =
        readRegistry(
            registryFile,
        );

    const existing =
        collectRegisteredTenantsForUser(
            registry,
            tenant.userId,
        );

    if (
        existing.length > 1
    ) {
        throw new Error(
            "AMBIGUOUS_WORKSPACE_TENANT",
        );
    }

    if (
        existing.length === 1
    ) {
        const registered =
            existing[0];

        if (
            registered.organizationId !==
                tenant.organizationId ||
            registered.workspaceId !==
                tenant.workspaceId
        ) {
            throw new Error(
                "AMBIGUOUS_WORKSPACE_TENANT",
            );
        }

        return registered;
    }

    registry.tenants.push(
        {
            organizationId:
                tenant.organizationId,
            workspaceId:
                tenant.workspaceId,
            userId:
                tenant.userId,
            createdAt:
                new Date().toISOString(),
            source,
        },
    );

    writeRegistry(
        registryFile,
        registry,
    );

    return tenant;
}

export function ensureFileBackedWorkspaceTenant(
    persistence: PersistenceService,
    userId: string,
    registryFile: string =
        getWorkspaceTenantRegistryFile(),
): ResolvedWorkspaceTenant {
    const normalizedUserId =
        userId.trim();

    if (!normalizedUserId) {
        throw new Error(
            "AUTHENTICATED_USER_ID_REQUIRED",
        );
    }

    return withRegistryLock(
        registryFile,
        () => {
            const registry = readRegistry(registryFile);

            const registered =
                collectRegisteredTenantsForUser(
                    registry,
                    normalizedUserId,
                );

            if (registered.length > 1) {
                throw new Error(
                    "AMBIGUOUS_WORKSPACE_TENANT",
                );
            }

            if (registered.length === 1) {
                return registered[0];
            }

            try {
                const legacyTenant =
                    resolveFileBackedWorkspaceTenant(
                        persistence,
                        normalizedUserId,
                    );

                return registerTenant(
                    registryFile,
                    legacyTenant,
                    "LEGACY_STATE",
                );
            } catch (error: unknown) {
                const message =
                    error instanceof Error
                        ? error.message
                        : "";

                if (
                    message ===
                    "AMBIGUOUS_WORKSPACE_TENANT"
                ) {
                    throw error;
                }

                if (
                    message !==
                    "WORKSPACE_TENANT_NOT_FOUND"
                ) {
                    throw error;
                }
            }

            const bootstrappedTenant:
                ResolvedWorkspaceTenant = {
                organizationId: `org-${randomUUID()}`,
                workspaceId: `workspace-${randomUUID()}`,
                userId: normalizedUserId,
            };

            return registerTenant(
                registryFile,
                bootstrappedTenant,
                "BOOTSTRAPPED",
            );
        },
    );
}

export function createAuthenticatedWorkspaceState(
    userId: string,
): {
    persistence: PersistenceService;
    tenant: ResolvedWorkspaceTenant;
    store: HappyStateStore;
} {
    const persistence =
        createWorkspacePersistence();

    const tenant =
        ensureFileBackedWorkspaceTenant(
            persistence,
            userId,
        );

    const store =
        createHappyStateStore(
            persistence,
            tenant.organizationId,
            tenant.workspaceId,
            tenant.userId,
        );

    return {
        persistence,
        tenant,
        store,
    };
}
