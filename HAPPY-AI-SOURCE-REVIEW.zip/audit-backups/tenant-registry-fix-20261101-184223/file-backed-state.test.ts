import {
    existsSync,
    mkdirSync,
    readFileSync,
    rmSync,
} from "node:fs";

import {
    join,
} from "node:path";

import type {
    PersistenceService,
} from "../../../core/persistence/service";

import type {
    HappyState,
} from "../../../core/persistence/state";

import {
    ensureFileBackedWorkspaceTenant,
    resolveFileBackedWorkspaceTenant,
} from "../../../core/workspace/file-backed-state";

const testRoot =
    join(
        process.cwd(),
        ".happy-state",
        "#19e-bootstrap-test",
    );

const registryFile =
    join(
        testRoot,
        "workspace-tenants.json",
    );

function createEmptyState(): HappyState {
    return {
        users: [],
        workspaces: [],
        projects: [],
        commands: [],
        missions: [],
        tasks: [],
        executions: [],
        verifications: [],
        evidence: [],
        memories: [],
        approvals: [],
        auditEvents: [],
    };
}

function createPersistence(
    state: HappyState,
): PersistenceService {
    return {
        snapshot: () =>
            structuredClone(
                state,
            ),
    } as unknown as PersistenceService;
}

function expectError(
    operation: () => unknown,
    expected:
        string,
): boolean {
    try {
        operation();
        return false;
    }
    catch (error: unknown) {
        return (
            error instanceof Error &&
            error.message ===
                expected
        );
    }
}

function main(): void {
    rmSync(
        testRoot,
        {
            recursive: true,
            force: true,
        },
    );

    mkdirSync(
        testRoot,
        {
            recursive: true,
        },
    );

    // =========================================================
    // FRESH USER BOOTSTRAP
    // =========================================================

    const emptyState =
        createEmptyState();

    const persistence =
        createPersistence(
            emptyState,
        );

    const userA =
        "bootstrap-user-19e-a";

    const tenantA1 =
        ensureFileBackedWorkspaceTenant(
            persistence,
            userA,
            registryFile,
        );

    const tenantA2 =
        ensureFileBackedWorkspaceTenant(
            persistence,
            userA,
            registryFile,
        );

    const sameTenant =
        tenantA1.userId ===
            tenantA2.userId &&
        tenantA1.organizationId ===
            tenantA2.organizationId &&
        tenantA1.workspaceId ===
            tenantA2.workspaceId;

    const tenantIdsValid =
        tenantA1.userId ===
            userA &&
        tenantA1.organizationId.startsWith(
            "org-",
        ) &&
        tenantA1.workspaceId.startsWith(
            "workspace-",
        );

    // =========================================================
    // SECOND USER ISOLATION
    // =========================================================

    const userB =
        "bootstrap-user-19e-b";

    const tenantB =
        ensureFileBackedWorkspaceTenant(
            persistence,
            userB,
            registryFile,
        );

    const isolated =
        tenantB.userId ===
            userB &&
        tenantA1.organizationId !==
            tenantB.organizationId &&
        tenantA1.workspaceId !==
            tenantB.workspaceId;

    // =========================================================
    // REGISTRY PERSISTENCE
    // =========================================================

    const registryExists =
        existsSync(
            registryFile,
        );

    const registry =
        JSON.parse(
            readFileSync(
                registryFile,
                "utf8",
            ),
        ) as {
            version: number;
            tenants: Array<{
                organizationId:
                    string;
                workspaceId:
                    string;
                userId:
                    string;
                createdAt:
                    string;
                source:
                    string;
            }>;
        };

    const registryPersistent =
        registry.version === 1 &&
        registry.tenants.filter(
            (tenant) =>
                tenant.userId ===
                userA,
        ).length === 1 &&
        registry.tenants.some(
            (tenant) =>
                tenant.userId ===
                    userA &&
                tenant.organizationId ===
                    tenantA1.organizationId &&
                tenant.workspaceId ===
                    tenantA1.workspaceId &&
                tenant.source ===
                    "BOOTSTRAPPED",
        );

    // =========================================================
    // LEGACY STATE PRESERVATION
    // =========================================================

    const legacyState =
        createEmptyState();

    const legacyNow =
        new Date().toISOString();

    legacyState.commands.push(
        {
            id:
                "legacy-command-19e",
            entityType:
                "COMMAND",
            version:
                1,
            createdAt:
                legacyNow,
            updatedAt:
                legacyNow,
            data: {
                organizationId:
                    "demo-org",
                workspaceId:
                    "demo-workspace",
                userId:
                    "legacy-user-19e",
                command:
                    "legacy compatibility",
            },
        },
    );

    const legacyPersistence =
        createPersistence(
            legacyState,
        );

    const legacyRegistry =
        join(
            testRoot,
            "legacy-workspace-tenants.json",
        );

    const legacyTenant =
        ensureFileBackedWorkspaceTenant(
            legacyPersistence,
            "legacy-user-19e",
            legacyRegistry,
        );

    const legacyPreserved =
        legacyTenant.userId ===
            "legacy-user-19e" &&
        legacyTenant.organizationId ===
            "demo-org" &&
        legacyTenant.workspaceId ===
            "demo-workspace";

    const legacyResolved =
        resolveFileBackedWorkspaceTenant(
            legacyPersistence,
            "legacy-user-19e",
        );

    const legacyResolverPass =
        legacyResolved.organizationId ===
            "demo-org" &&
        legacyResolved.workspaceId ===
            "demo-workspace";

    // =========================================================
    // AMBIGUITY PROTECTION
    // =========================================================

    const ambiguousState =
        createEmptyState();

    ambiguousState.commands.push(
        {
            id:
                "ambiguous-a",
            entityType:
                "COMMAND",
            version:
                1,
            createdAt:
                legacyNow,
            updatedAt:
                legacyNow,
            data: {
                organizationId:
                    "org-a",
                workspaceId:
                    "workspace-a",
                userId:
                    "ambiguous-user-19e",
            },
        },
    );

    ambiguousState.commands.push(
        {
            id:
                "ambiguous-b",
            entityType:
                "COMMAND",
            version:
                1,
            createdAt:
                legacyNow,
            updatedAt:
                legacyNow,
            data: {
                organizationId:
                    "org-b",
                workspaceId:
                    "workspace-b",
                userId:
                    "ambiguous-user-19e",
            },
        },
    );

    const ambiguousPersistence =
        createPersistence(
            ambiguousState,
        );

    const ambiguousBlocked =
        expectError(
            () =>
                ensureFileBackedWorkspaceTenant(
                    ambiguousPersistence,
                    "ambiguous-user-19e",
                    join(
                        testRoot,
                        "ambiguous-workspace-tenants.json",
                    ),
                ),
            "AMBIGUOUS_WORKSPACE_TENANT",
        );

    // =========================================================
    // BLANK USER PROTECTION
    // =========================================================

    const blankUserBlocked =
        expectError(
            () =>
                ensureFileBackedWorkspaceTenant(
                    persistence,
                    "   ",
                    join(
                        testRoot,
                        "blank-workspace-tenants.json",
                    ),
                ),
            "AUTHENTICATED_USER_ID_REQUIRED",
        );

    // =========================================================
    // RESULTS
    // =========================================================

    const passed =
        sameTenant &&
        tenantIdsValid &&
        isolated &&
        registryExists &&
        registryPersistent &&
        legacyPreserved &&
        legacyResolverPass &&
        ambiguousBlocked &&
        blankUserBlocked;

    console.log(
        "tenantIdsValid:",
        tenantIdsValid,
    );

    console.log(
        "sameTenant:",
        sameTenant,
    );

    console.log(
        "isolated:",
        isolated,
    );

    console.log(
        "registryExists:",
        registryExists,
    );

    console.log(
        "registryPersistent:",
        registryPersistent,
    );

    console.log(
        "legacyPreserved:",
        legacyPreserved,
    );

    console.log(
        "legacyResolverPass:",
        legacyResolverPass,
    );

    console.log(
        "ambiguousBlocked:",
        ambiguousBlocked,
    );

    console.log(
        "blankUserBlocked:",
        blankUserBlocked,
    );

    console.log(
        `RESULT: ${passed ? "PASS" : "FAIL"}`,
    );

    rmSync(
        testRoot,
        {
            recursive: true,
            force: true,
        },
    );

    if (!passed) {
        throw new Error(
            "AUTHENTICATED_TENANT_BOOTSTRAP_REGRESSION_FAILED",
        );
    }
}

main();
