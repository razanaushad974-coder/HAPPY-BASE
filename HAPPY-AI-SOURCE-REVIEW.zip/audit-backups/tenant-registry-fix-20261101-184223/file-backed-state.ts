import {
    randomUUID,
} from "node:crypto";

import {
    existsSync,
    mkdirSync,
    readFileSync,
    writeFileSync,
} from "node:fs";

import {
    dirname,
    join,
} from "node:path";

import {
    JsonFileStateAdapter,
} from "../persistence/adapters/json-file-adapter";

import {
    PersistenceService,
} from "../persistence/service";

import {
    createHappyStateStore,
} from "../state/factory";

import type {
    HappyState,
} from "../persistence/state";

import type {
    HappyStateStore,
} from "../state/happy-state-store";

export interface ResolvedWorkspaceTenant {
    organizationId: string;
    workspaceId: string;
    userId: string;
}

interface PersistedWorkspaceTenant {
    organizationId: string;
    workspaceId: string;
    userId: string;
    createdAt: string;
    source:
        | "LEGACY_STATE"
        | "BOOTSTRAPPED";
}

interface WorkspaceTenantRegistry {
    version: 1;
    tenants: PersistedWorkspaceTenant[];
}

const TENANT_COLLECTIONS:
    Array<keyof HappyState> = [
        "commands",
        "missions",
        "tasks",
        "executions",
        "verifications",
        "evidence",
        "memories",
        "approvals",
        "auditEvents",
    ];

export function getWorkspacePersistenceFile(): string {
    return join(
        process.cwd(),
        ".happy-state",
        "orchestration-state.json",
    );
}

export function getWorkspaceTenantRegistryFile(): string {
    return join(
        process.cwd(),
        ".happy-state",
        "workspace-tenants.json",
    );
}

export function createWorkspacePersistence(): PersistenceService {
    return new PersistenceService(
        new JsonFileStateAdapter(
            getWorkspacePersistenceFile(),
        ),
    );
}

function asRecord(
    value: unknown,
): Record<string, unknown> | undefined {
    if (
        typeof value !== "object" ||
        value === null
    ) {
        return undefined;
    }

    return value as Record<string, unknown>;
}

function collectTenantMatches(
    state: HappyState,
    userId: string,
): Map<string, ResolvedWorkspaceTenant> {
    const matches =
        new Map<
            string,
            ResolvedWorkspaceTenant
        >();

    for (
        const collectionName
        of TENANT_COLLECTIONS
    ) {
        const collection =
            state[collectionName];

        for (
            const record
            of collection
        ) {
            const wrapper =
                asRecord(
                    record.data,
                );

            if (!wrapper) {
                continue;
            }

            if (
                wrapper.userId !==
                userId
            ) {
                continue;
            }

            const organizationId =
                typeof wrapper.organizationId ===
                "string"
                    ? wrapper.organizationId.trim()
                    : "";

            const workspaceId =
                typeof wrapper.workspaceId ===
                "string"
                    ? wrapper.workspaceId.trim()
                    : "";

            if (
                !organizationId ||
                !workspaceId
            ) {
                continue;
            }

            const key =
                `${organizationId}::${workspaceId}`;

            matches.set(
                key,
                {
                    organizationId,
                    workspaceId,
                    userId,
                },
            );
        }
    }

    return matches;
}

export function resolveFileBackedWorkspaceTenant(
    persistence: PersistenceService,
    userId: string,
): ResolvedWorkspaceTenant {
    const normalizedUserId =
        userId.trim();

    if (!normalizedUserId) {
        throw new Error(
            "AUTHENTICATED_USER_ID_REQUIRED",
        );
    }

    const matches =
        collectTenantMatches(
            persistence.snapshot(),
            normalizedUserId,
        );

    if (matches.size === 0) {
        throw new Error(
            "WORKSPACE_TENANT_NOT_FOUND",
        );
    }

    if (matches.size > 1) {
        throw new Error(
            "AMBIGUOUS_WORKSPACE_TENANT",
        );
    }

    return Array.from(
        matches.values(),
    )[0];
}

function emptyRegistry(): WorkspaceTenantRegistry {
    return {
        version: 1,
        tenants: [],
    };
}

function readRegistry(
    registryFile: string,
): WorkspaceTenantRegistry {
    if (!existsSync(registryFile)) {
        return emptyRegistry();
    }

    try {
        const parsed =
            JSON.parse(
                readFileSync(
                    registryFile,
                    "utf8",
                ),
            ) as Partial<
                WorkspaceTenantRegistry
            >;

        if (
            parsed.version !==
            1
        ) {
            return emptyRegistry();
        }

        const tenants =
            Array.isArray(
                parsed.tenants,
            )
                ? parsed.tenants.filter(
                    (
                        tenant,
                    ): tenant is PersistedWorkspaceTenant =>
                        typeof tenant ===
                            "object" &&
                        tenant !== null &&
                        typeof tenant.organizationId ===
                            "string" &&
                        typeof tenant.workspaceId ===
                            "string" &&
                        typeof tenant.userId ===
                            "string" &&
                        typeof tenant.createdAt ===
                            "string" &&
                        (
                            tenant.source ===
                                "LEGACY_STATE" ||
                            tenant.source ===
                                "BOOTSTRAPPED"
                        ),
                )
                : [];

        return {
            version: 1,
            tenants,
        };
    }
    catch {
        return emptyRegistry();
    }
}

function writeRegistry(
    registryFile: string,
    registry: WorkspaceTenantRegistry,
): void {
    mkdirSync(
        dirname(
            registryFile,
        ),
        {
            recursive: true,
        },
    );

    writeFileSync(
        registryFile,
        JSON.stringify(
            registry,
            null,
            2,
        ),
        "utf8",
    );
}

function collectRegisteredTenantsForUser(
    registry: WorkspaceTenantRegistry,
    userId: string,
): ResolvedWorkspaceTenant[] {
    const unique =
        new Map<
            string,
            ResolvedWorkspaceTenant
        >();

    for (
        const tenant
        of registry.tenants
    ) {
        if (
            tenant.userId !==
            userId
        ) {
            continue;
        }

        unique.set(
            `${tenant.organizationId}::${tenant.workspaceId}`,
            {
                organizationId:
                    tenant.organizationId,
                workspaceId:
                    tenant.workspaceId,
                userId:
                    tenant.userId,
            },
        );
    }

    return Array.from(
        unique.values(),
    );
}

function registerTenant(
    registryFile: string,
    tenant: ResolvedWorkspaceTenant,
    source:
        PersistedWorkspaceTenant["source"],
): ResolvedWorkspaceTenant {
    const registry =
        readRegistry(
            registryFile,
        );

    const existing =
        collectRegisteredTenantsForUser(
            registry,
            tenant.userId,
        );

    if (
        existing.length > 1
    ) {
        throw new Error(
            "AMBIGUOUS_WORKSPACE_TENANT",
        );
    }

    if (
        existing.length === 1
    ) {
        const registered =
            existing[0];

        if (
            registered.organizationId !==
                tenant.organizationId ||
            registered.workspaceId !==
                tenant.workspaceId
        ) {
            throw new Error(
                "AMBIGUOUS_WORKSPACE_TENANT",
            );
        }

        return registered;
    }

    registry.tenants.push(
        {
            organizationId:
                tenant.organizationId,
            workspaceId:
                tenant.workspaceId,
            userId:
                tenant.userId,
            createdAt:
                new Date().toISOString(),
            source,
        },
    );

    writeRegistry(
        registryFile,
        registry,
    );

    return tenant;
}

export function ensureFileBackedWorkspaceTenant(
    persistence: PersistenceService,
    userId: string,
    registryFile: string =
        getWorkspaceTenantRegistryFile(),
): ResolvedWorkspaceTenant {
    const normalizedUserId =
        userId.trim();

    if (!normalizedUserId) {
        throw new Error(
            "AUTHENTICATED_USER_ID_REQUIRED",
        );
    }

    const registry =
        readRegistry(
            registryFile,
        );

    const registered =
        collectRegisteredTenantsForUser(
            registry,
            normalizedUserId,
        );

    if (
        registered.length > 1
    ) {
        throw new Error(
            "AMBIGUOUS_WORKSPACE_TENANT",
        );
    }

    if (
        registered.length === 1
    ) {
        return registered[0];
    }

    try {
        const legacyTenant =
            resolveFileBackedWorkspaceTenant(
                persistence,
                normalizedUserId,
            );

        return registerTenant(
            registryFile,
            legacyTenant,
            "LEGACY_STATE",
        );
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "";

        if (
            message ===
            "AMBIGUOUS_WORKSPACE_TENANT"
        ) {
            throw error;
        }

        if (
            message !==
            "WORKSPACE_TENANT_NOT_FOUND"
        ) {
            throw error;
        }
    }

    const bootstrappedTenant:
        ResolvedWorkspaceTenant = {
        organizationId:
            `org-${randomUUID()}`,
        workspaceId:
            `workspace-${randomUUID()}`,
        userId:
            normalizedUserId,
    };

    return registerTenant(
        registryFile,
        bootstrappedTenant,
        "BOOTSTRAPPED",
    );
}

export function createAuthenticatedWorkspaceState(
    userId: string,
): {
    persistence: PersistenceService;
    tenant: ResolvedWorkspaceTenant;
    store: HappyStateStore;
} {
    const persistence =
        createWorkspacePersistence();

    const tenant =
        ensureFileBackedWorkspaceTenant(
            persistence,
            userId,
        );

    const store =
        createHappyStateStore(
            persistence,
            tenant.organizationId,
            tenant.workspaceId,
            tenant.userId,
        );

    return {
        persistence,
        tenant,
        store,
    };
}
