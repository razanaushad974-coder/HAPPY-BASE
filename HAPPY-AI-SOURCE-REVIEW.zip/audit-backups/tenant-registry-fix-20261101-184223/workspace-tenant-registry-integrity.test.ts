import {
    mkdtempSync,
    writeFileSync,
    readFileSync,
    rmSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
    ensureFileBackedWorkspaceTenant,
} from "../../../core/workspace/file-backed-state";

const root = mkdtempSync(
    join(tmpdir(), "happy-tenant-integrity-"),
);

const state = {
    users: [],
    workspaces: [],
    projects: [],
    commands: [],
    missions: [],
    tasks: [],
    executions: [],
    verifications: [],
    evidence: [],
    memories: [],
    approvals: [],
    auditEvents: [],
};

const persistence = {
    snapshot: () => structuredClone(state),
} as any;

function mustRejectAndPreserve(
    registryFile: string,
    originalBytes: string,
    userId: string,
): boolean {
    writeFileSync(registryFile, originalBytes, "utf8");

    let rejected = false;

    try {
        ensureFileBackedWorkspaceTenant(
            persistence,
            userId,
            registryFile,
        );
    } catch {
        rejected = true;
    }

    const preserved =
        readFileSync(registryFile, "utf8") === originalBytes;

    return rejected && preserved;
}

let malformedRegistryProtected = false;
let unsupportedVersionProtected = false;

try {
    malformedRegistryProtected = mustRejectAndPreserve(
        join(root, "malformed.json"),
        "{ deliberately-corrupt-json",
        "malformed-registry-user",
    );

    unsupportedVersionProtected = mustRejectAndPreserve(
        join(root, "unsupported-version.json"),
        JSON.stringify({
            version: 99,
            tenants: [{
                organizationId: "existing-org",
                workspaceId: "existing-workspace",
                userId: "existing-user",
                createdAt: new Date().toISOString(),
                source: "BOOTSTRAPPED",
            }],
        }),
        "unsupported-version-user",
    );

    console.log(JSON.stringify({
        test: "workspace-tenant-registry-integrity",
        malformedRegistryProtected,
        unsupportedVersionProtected,
        status:
            malformedRegistryProtected &&
            unsupportedVersionProtected
                ? "PASS"
                : "FAIL",
    }, null, 2));

    if (
        !malformedRegistryProtected ||
        !unsupportedVersionProtected
    ) {
        throw new Error(
            "WORKSPACE_TENANT_REGISTRY_INTEGRITY_REGRESSION",
        );
    }
} finally {
    rmSync(root, {
        recursive: true,
        force: true,
    });
}
