import {
    NextRequest,
    NextResponse,
} from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

import {
    SupabaseRuntimeSnapshotStore,
} from "../../../../core/persistence/adapters/supabase-runtime-snapshot";

import {
    applyApprovalDecision,
} from "../../../../core/approval/persist-decision";

import {
    HappyOrchestrationEngine,
} from "../../../../core/orchestration/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function isNonEmptyString(
    value: unknown,
): value is string {
    return (
        typeof value === "string" &&
        value.trim().length > 0
    );
}

type Decision =
    | "APPROVED"
    | "REJECTED";

function isDecision(
    value: unknown,
): value is Decision {
    return (
        value === "APPROVED" ||
        value === "REJECTED"
    );
}

async function getAuthenticatedContext() {
    const runtimeContext =
        await getAuthenticatedExecutionRuntimeContext();

    const authenticatedUserId =
        runtimeContext.authenticatedUserId;

    if (
        !authenticatedUserId ||
        !runtimeContext.supabaseAccessToken
    ) {
        return {
            ok: false as const,
            response:
                NextResponse.json(
                    {
                        status:
                            "UNAUTHENTICATED",
                        error:
                            "Authenticated Supabase session is required.",
                    },
                    {
                        status: 401,
                    },
                ),
        };
    }

    const workspace =
        createAuthenticatedWorkspaceState(
            authenticatedUserId,
        );

    const tenant =
        workspace.tenant;

    const supabase =
        await createSupabaseServerClient();

    const store =
        new SupabaseRuntimeSnapshotStore(
            supabase,
        );

    const snapshot =
        await store.load({
            organizationId:
                tenant.organizationId,
            workspaceId:
                tenant.workspaceId,
            userId:
                tenant.userId,
        });

    return {
        ok: true as const,
        runtimeContext,
        authenticatedUserId,
        workspace,
        tenant,
        store,
        snapshot,
    };
}

export async function GET(): Promise<Response> {
    try {
        const context =
            await getAuthenticatedContext();

        if (!context.ok) {
            return context.response;
        }

        if (!context.snapshot) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    approvals: [],
                    count: 0,
                },
                {
                    status: 404,
                },
            );
        }

        const pendingApprovals =
            context.snapshot.state.approvals
                .filter((approval) => {
                    const status =
                        (
                            approval.data as Record<
                                string,
                                unknown
                            >
                        )?.status;

                    return (
                        status ===
                            "WAITING_APPROVAL" ||
                        status === "PENDING"
                    );
                })
                .map((approval) => {
                    const data =
                        approval.data as Record<
                            string,
                            unknown
                        >;

                    return {
                        id:
                            approval.id,
                        requestId:
                            typeof data.requestId ===
                            "string"
                                ? data.requestId
                                : null,
                        planId:
                            typeof data.planId ===
                            "string"
                                ? data.planId
                                : null,
                        status:
                            typeof data.status ===
                            "string"
                                ? data.status
                                : null,
                        createdAt:
                            approval.createdAt,
                        updatedAt:
                            approval.updatedAt,
                    };
                });

        return NextResponse.json(
            {
                status:
                    "AVAILABLE",
                scopeKey:
                    context.snapshot.scopeKey,
                count:
                    pendingApprovals.length,
                approvals:
                    pendingApprovals,
            },
            {
                status: 200,
            },
        );
    } catch (error) {
        return NextResponse.json(
            {
                status:
                    "ERROR",
                error:
                    error instanceof Error
                        ? error.message
                        : "Unknown approval query error.",
            },
            {
                status: 500,
            },
        );
    }
}

export async function POST(
    request: NextRequest,
): Promise<Response> {
    try {
        const context =
            await getAuthenticatedContext();

        if (!context.ok) {
            return context.response;
        }

        if (!context.snapshot) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    error:
                        "Authenticated runtime snapshot was not found.",
                },
                {
                    status: 404,
                },
            );
        }

        let body: unknown;

        try {
            body =
                await request.json();
        } catch {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "Request body must be valid JSON.",
                },
                {
                    status: 400,
                },
            );
        }

        if (
            !body ||
            typeof body !== "object"
        ) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "Request body must be an object.",
                },
                {
                    status: 400,
                },
            );
        }

        const payload =
            body as Record<
                string,
                unknown
            >;

        const approvalId =
            isNonEmptyString(
                payload.approvalId,
            )
                ? payload.approvalId.trim()
                : "";

        const decision =
            isDecision(
                payload.decision,
            )
                ? payload.decision
                : null;

        const reason =
            isNonEmptyString(
                payload.reason,
            )
                ? payload.reason.trim()
                : undefined;

        if (!approvalId) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "approvalId is required.",
                },
                {
                    status: 400,
                },
            );
        }

        if (!decision) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "decision must be APPROVED or REJECTED.",
                },
                {
                    status: 400,
                },
            );
        }

        const result =
            applyApprovalDecision(
                context.snapshot.state,
                approvalId,
                decision,
                context.runtimeContext
                    .authenticatedUserId ?? "",
                reason,
            );

        const saved =
            await context.store.save(
                {
                    organizationId:
                        context.tenant.organizationId,
                    workspaceId:
                        context.tenant.workspaceId,
                    userId:
                        context.tenant.userId,
                },
                result.state,
                context.snapshot.version,
            );

        // The approval decision is persisted to the authenticated
        // Supabase runtime snapshot above. The continuation engine,
        // however, operates on the workspace PersistenceService.
        // Hydrate that local continuation state from the same
        // authoritative approved snapshot before resuming.
        context.workspace.persistence.replaceScopedSnapshot(
            result.state,
            {
                organizationId:
                    context.tenant.organizationId,
                workspaceId:
                    context.tenant.workspaceId,
                userId:
                    context.tenant.userId,
            },
        );

        if (
            result.decision ===
                "APPROVED"
        ) {
            if (
                !result.requestId ||
                !result.planId
            ) {
                return NextResponse.json(
                    {
                        status:
                            "APPROVAL_LINKAGE_INCOMPLETE",
                        error:
                            "Approved decision is missing requestId or planId.",
                        approvalId:
                            result.approvalId,
                    },
                    {
                        status: 500,
                    },
                );
            }

            const executionRuntimeContext = {
                ...context.runtimeContext,
                organizationId:
                    context.tenant.organizationId,
                workspaceId:
                    context.tenant.workspaceId,
            };

            const engine =
                new HappyOrchestrationEngine(
                    undefined,
                    context.workspace.persistence,
                );

            const resumed =
                await engine.resumeAfterApproval(
                    result.requestId,
                    result.approvalId,
                    result.planId,
                    context.tenant.organizationId,
                    context.tenant.workspaceId,
                    context.authenticatedUserId,
                    executionRuntimeContext,
                );

            return NextResponse.json(
                {
                    status:
                        "APPROVAL_RESUMED",
                    verified:
                        true,
                    scopeKey:
                        saved.scopeKey,
                    approvalId:
                        result.approvalId,
                    requestId:
                        result.requestId,
                    planId:
                        result.planId,
                    decisionId:
                        result.decisionId,
                    auditEventId:
                        result.auditEventId,
                    decision:
                        result.decision,
                    approverId:
                        result.approverId,
                    reason:
                        result.reason,
                    decidedAt:
                        result.decidedAt,
                    version:
                        saved.version,
                    updatedAt:
                        saved.updatedAt,
                    remotePersistence:
                        "AVAILABLE",
                    resume:
                        resumed,
                },
                {
                    status: 200,
                },
            );
        }

        return NextResponse.json(
            {
                status:
                    "APPROVAL_DECISION_PERSISTED",
                verified:
                    true,
                scopeKey:
                    saved.scopeKey,
                approvalId:
                    result.approvalId,
                requestId:
                    result.requestId ?? null,
                planId:
                    result.planId ?? null,
                decisionId:
                    result.decisionId,
                auditEventId:
                    result.auditEventId,
                decision:
                    result.decision,
                approverId:
                    result.approverId,
                reason:
                    result.reason,
                decidedAt:
                    result.decidedAt,
                version:
                    saved.version,
                updatedAt:
                    saved.updatedAt,
                remotePersistence:
                    "AVAILABLE",
            },
            {
                status: 200,
            },
        );
    } catch (error) {
        const message =
            error instanceof Error
                ? error.message
                : "Unknown approval decision error.";

        if (
            message ===
            "APPROVAL_NOT_FOUND"
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    error: message,
                },
                {
                    status: 404,
                },
            );
        }

        if (
            message ===
            "APPROVAL_NOT_PENDING"
        ) {
            return NextResponse.json(
                {
                    status:
                        "ALREADY_DECIDED",
                    error: message,
                },
                {
                    status: 409,
                },
            );
        }

        return NextResponse.json(
            {
                status:
                    "ERROR",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}
