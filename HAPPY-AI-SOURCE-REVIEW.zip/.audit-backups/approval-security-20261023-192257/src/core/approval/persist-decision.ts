export type PersistedApprovalDecisionStatus =
    | "APPROVED"
    | "REJECTED";

export interface PersistedApprovalDecisionResult<TState> {
    state: TState;
    approvalId: string;
    requestId?: string;
    planId?: string;
    decisionId: string;
    auditEventId: string;
    decision:
        PersistedApprovalDecisionStatus;
    approverId: string;
    decidedAt: string;
    reason: string;
}

interface MutableApprovalRecord {
    id: string;
    data: unknown;
    version: number;
    createdAt: string;
    updatedAt: string;
    entityType: string;
}

interface MutableAuditRecord {
    id: string;
    data: unknown;
    version: number;
    createdAt: string;
    updatedAt: string;
    entityType: string;
}

type ApprovalStateShape = {
    approvals: MutableApprovalRecord[];
    auditEvents: MutableAuditRecord[];
};

function requireNonEmpty(
    value: string,
    field: string,
): void {
    if (!value.trim()) {
        throw new Error(
            `${field} is required.`,
        );
    }
}

function isPendingApprovalStatus(
    value: unknown,
): boolean {
    return (
        value === "WAITING_APPROVAL" ||
        value === "PENDING"
    );
}

function asRecord(
    value: unknown,
): Record<string, unknown> {
    if (
        value !== null &&
        typeof value === "object" &&
        !Array.isArray(value)
    ) {
        return value as Record<
            string,
            unknown
        >;
    }

    return {};
}

export function applyApprovalDecision<
    TState extends ApprovalStateShape,
>(
    state: TState,
    approvalId: string,
    decision:
        PersistedApprovalDecisionStatus,
    approverId: string,
    reason?: string,
    decidedAt:
        string = new Date().toISOString(),
): PersistedApprovalDecisionResult<TState> {
    requireNonEmpty(
        approvalId,
        "approvalId",
    );

    requireNonEmpty(
        approverId,
        "approverId",
    );

    if (
        decision !== "APPROVED" &&
        decision !== "REJECTED"
    ) {
        throw new Error(
            "Approval decision must be APPROVED or REJECTED.",
        );
    }

    const nextState =
        structuredClone(state);

    const approval =
        nextState.approvals.find(
            (item) =>
                item.id === approvalId,
        );

    if (!approval) {
        throw new Error(
            "APPROVAL_NOT_FOUND",
        );
    }

    const currentApprovalData =
        asRecord(
            approval.data,
        );

    const currentStatus =
        currentApprovalData.status;

    if (
        !isPendingApprovalStatus(
            currentStatus,
        )
    ) {
        throw new Error(
            "APPROVAL_NOT_PENDING",
        );
    }

    const decisionId =
        `approval-decision-${crypto.randomUUID()}`;

    const auditEventId =
        `audit-approval-decision-${crypto.randomUUID()}`;

    const finalReason =
        reason?.trim() ||
        (
            decision === "APPROVED"
                ? "Approved by authenticated approver."
                : "Rejected by authenticated approver."
        );

    approval.data = {
        ...currentApprovalData,
        status: decision,
        decision,
        decisionId,
        approverId,
        decidedAt,
        decisionReason:
            finalReason,
    };

    approval.version =
        Number.isFinite(
            Number(approval.version),
        )
            ? Number(approval.version) + 1
            : 2;

    approval.updatedAt =
        decidedAt;

    const requestId =
        typeof currentApprovalData
            .requestId === "string"
            ? currentApprovalData.requestId
            : undefined;

    const planId =
        typeof currentApprovalData
            .planId === "string"
            ? currentApprovalData.planId
            : undefined;

    const auditEvent:
        MutableAuditRecord = {
        id: auditEventId,
        data: {
            event:
                "APPROVAL_DECISION",
            approvalId,
            requestId,
            planId,
            decision,
            approverId,
            reason: finalReason,
            stage: "APPROVAL",
            createdAt:
                decidedAt,
        },
        version: 1,
        createdAt: decidedAt,
        updatedAt: decidedAt,
        entityType:
            "AUDIT_EVENT",
    };

    nextState.auditEvents.push(
        auditEvent,
    );

    return {
        state: nextState,
        approvalId,
        requestId,
        planId,
        decisionId,
        auditEventId,
        decision,
        approverId,
        decidedAt,
        reason: finalReason,
    };
}
