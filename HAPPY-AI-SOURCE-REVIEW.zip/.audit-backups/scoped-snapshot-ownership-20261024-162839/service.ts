import type { EntityType, PersistedRecord } from "./types";
import type { HappyState } from "./state";
import {
  ENTITY_STATE_KEYS,
  createEmptyState,
} from "./state";
import type { PersistentStateAdapter } from "./adapters/json-file-adapter";

export class PersistenceService {
  private state: HappyState;

  constructor(private readonly adapter: PersistentStateAdapter) {
    this.state = this.adapter.load();
  }

  create<T>(entityType: EntityType, id: string, data: T): PersistedRecord<T> {
    return this.transact((state) => {
      const collection = state[ENTITY_STATE_KEYS[entityType]] as PersistedRecord<T>[];
      if (collection.some((record) => record.id === id)) {
        throw new Error(`Record already exists: ${id}`);
      }
      const now = new Date().toISOString();
      const record: PersistedRecord<T> = {
        id, entityType, version: 1, createdAt: now, updatedAt: now, data,
      };
      collection.push(record);
      return record;
    });
  }

  get<T>(entityType: EntityType, id: string): PersistedRecord<T> | undefined {
    this.refresh();
    const collection = this.state[ENTITY_STATE_KEYS[entityType]] as PersistedRecord<T>[];
    return collection.find((record) => record.id === id);
  }

  list<T>(entityType: EntityType): PersistedRecord<T>[] {
    this.refresh();
    return [...(this.state[ENTITY_STATE_KEYS[entityType]] as PersistedRecord<T>[])];
  }

  update<T>(entityType: EntityType, id: string, data: T): PersistedRecord<T> {
    return this.transact((state) => {
      const collection = state[ENTITY_STATE_KEYS[entityType]] as PersistedRecord<T>[];
      const index = collection.findIndex((record) => record.id === id);
      if (index === -1) throw new Error(`Record not found: ${id}`);

      const existing = collection[index];
      const updated: PersistedRecord<T> = {
        ...existing,
        version: existing.version + 1,
        updatedAt: new Date().toISOString(),
        data,
      };
      collection[index] = updated;
      return updated;
    });
  }

  delete(entityType: EntityType, id: string): boolean {
    return this.transact((state) => {
      const collection = state[ENTITY_STATE_KEYS[entityType]] as PersistedRecord<unknown>[];
      const index = collection.findIndex((record) => record.id === id);
      if (index === -1) return false;
      collection.splice(index, 1);
      return true;
    });
  }

  count(entityType?: EntityType): number {
    this.refresh();
    if (!entityType) {
      return Object.values(this.state).reduce((total, collection) => total + collection.length, 0);
    }
    return this.state[ENTITY_STATE_KEYS[entityType]].length;
  }

  snapshot(): HappyState {
    this.refresh();
    return structuredClone(this.state);
  }

  replaceSnapshot(state: HappyState): void {
    this.transact((current) => {
      Object.assign(current, structuredClone(state));
    });
  }

  replaceScopedSnapshot(
    state: HappyState,
    scope: { organizationId: string; workspaceId: string; userId?: string },
  ): void {
    this.transact((current) => {
      const collectionKeys: (keyof HappyState)[] = [
        "users",
        "workspaces",
        "projects",
        "commands",
        "missions",
        "tasks",
        "executions",
        "verifications",
        "evidence",
        "memories",
        "approvals",
        "auditEvents",
      ];

      const belongsToScope = (
        record: PersistedRecord<unknown>,
      ): boolean => {
        if (typeof record.data !== "object" || record.data === null) {
          return false;
        }

        const metadata = record.data as {
          organizationId?: unknown;
          workspaceId?: unknown;
          userId?: unknown;
        };

        if (
          metadata.organizationId !== scope.organizationId ||
          metadata.workspaceId !== scope.workspaceId
        ) {
          return false;
        }

        return (
          scope.userId === undefined ||
          metadata.userId === undefined ||
          metadata.userId === scope.userId
        );
      };

      // Validate every collection before applying any replacements.
      const replacements: Partial<HappyState> = {};

      for (const key of collectionKeys) {
        const existingRecords =
          current[key] as PersistedRecord<unknown>[];
        const incomingRecords =
          state[key] as PersistedRecord<unknown>[];
        const incomingIds = new Set<string>();

        for (const record of incomingRecords) {
          if (incomingIds.has(record.id)) {
            throw new Error(
              `SCOPED_SNAPSHOT_DUPLICATE_ID:${key}:${record.id}`,
            );
          }
          incomingIds.add(record.id);

          const collision = existingRecords.find(
            (existing) => existing.id === record.id,
          );

          if (collision && !belongsToScope(collision)) {
            throw new Error(
              `SCOPED_SNAPSHOT_ID_COLLISION:${key}:${record.id}`,
            );
          }
        }

        const preservedRecords = existingRecords.filter(
          (record) => !belongsToScope(record),
        );

        const wrappedRecords = incomingRecords.map((record) => ({
          ...structuredClone(record),
          data: {
            data: structuredClone(record.data),
            organizationId: scope.organizationId,
            workspaceId: scope.workspaceId,
            userId: scope.userId,
          },
        }));

        Object.assign(replacements, {
          [key]: [...preservedRecords, ...wrappedRecords],
        });
      }

      Object.assign(current, replacements);
    });
  }
  reset(): void {
    this.transact((current) => {
      Object.assign(current, createEmptyState());
    });
  }

  private refresh(): void {
    this.state = this.adapter.load();
  }

  private transact<T>(mutator: (state: HappyState) => T): T {
    if (this.adapter.transact) {
      const outcome = this.adapter.transact(mutator);
      this.state = outcome.state;
      return outcome.result;
    }

    // Compatibility for adapters without transaction support.
    const next = structuredClone(this.state);
    const result = mutator(next);
    this.adapter.save(next);
    this.state = next;
    return result;
  }
}
