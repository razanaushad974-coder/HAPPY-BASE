import { strict as assert } from "node:assert";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";

async function main(): Promise<void> {
    const stateFile =
        `.happy-state/test-scoped-runtime-snapshot-${Date.now()}-${Math.random()
            .toString(36)
            .slice(2)}.json`;

    const persistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile
            )
        );

    const storeA =
        createHappyStateStore(
            persistence,
            "org-a",
            "workspace-a",
            "user-a"
        );

    const storeB =
        createHappyStateStore(
            persistence,
            "org-b",
            "workspace-b",
            "user-b"
        );

    await storeA.command().create(
        "command-a",
        {
            command: "A"
        },
        "user-a"
    );

    await storeB.command().create(
        "command-b",
        {
            command: "B"
        },
        "user-b"
    );

    const snapshotA =
        await storeA.snapshot();

    const snapshotB =
        await storeB.snapshot();

    assert.equal(
        snapshotA.commands.length,
        1
    );

    assert.equal(
        snapshotA.commands[0]?.id,
        "command-a"
    );

    assert.equal(
        snapshotB.commands.length,
        1
    );

    assert.equal(
        snapshotB.commands[0]?.id,
        "command-b"
    );

    assert.equal(
        snapshotA.commands.some(
            (record) =>
                record.id === "command-b"
        ),
        false
    );

    assert.equal(
        snapshotB.commands.some(
            (record) =>
                record.id === "command-a"
        ),
        false
    );

    console.log(
        "Scoped runtime snapshot isolation: PASS"
    );
}

main().catch(
    (error: unknown) => {
        console.error(
            "Scoped snapshot test: FAIL",
            error
        );

        process.exitCode = 1;
    }
);