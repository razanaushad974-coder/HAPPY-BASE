import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const routeFile =
    "src/app/api/approvals/decision/route.ts";

const text =
    readFileSync(
        routeFile,
        "utf8",
    );

assert.match(
    text,
    /getAuthenticatedExecutionRuntimeContext/,
);

assert.match(
    text,
    /createAuthenticatedWorkspaceState/,
);

assert.match(
    text,
    /SupabaseRuntimeSnapshotStore/,
);

assert.match(
    text,
    /export async function GET/,
);

assert.match(
    text,
    /export async function POST/,
);

assert.match(
    text,
    /applyApprovalDecision/,
);

assert.match(
    text,
    /\.load\(/,
);

assert.match(
    text,
    /\.save\(/,
);

assert.match(
    text,
    /APPROVAL_DECISION_PERSISTED/,
);

assert.match(
    text,
    /APPROVAL_NOT_PENDING/,
);

assert.doesNotMatch(
    text,
    /service_role|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_SERVICE_KEY/i,
);

console.log(
    "Authenticated approval API boundary: PASS",
);

console.log(
    "Approval GET contract: PASS",
);

console.log(
    "Approval POST contract: PASS",
);

console.log(
    "Remote snapshot load binding: PASS",
);

console.log(
    "Remote snapshot save binding: PASS",
);

console.log(
    "Persisted decision response contract: PASS",
);

console.log(
    "Duplicate decision protection: PASS",
);

console.log(
    "No service-role bypass: PASS",
);

console.log(
    "#36F approval API contract test: PASS",
);
