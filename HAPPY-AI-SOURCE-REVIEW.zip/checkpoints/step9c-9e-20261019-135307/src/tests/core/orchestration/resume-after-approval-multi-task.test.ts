import { join } from "node:path";
import { rm } from "node:fs/promises";

import {
    HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import {
    JsonFileStateAdapter,
} from "../../../core/persistence/adapters/json-file-adapter";

import {
    PersistenceService,
} from "../../../core/persistence/service";

import {
    createHappyStateStore,
} from "../../../core/state/factory";

import type {
    ExecutionRequest,
    ExecutionResult,
} from "../../../core/execution/types";

import type {
    ExecutionPlan,
} from "../../../core/reasoning/types";

class RecordingExecutionEngine {
    public readonly calls: ExecutionRequest[] = [];

    async execute(
        request: ExecutionRequest,
    ): Promise<ExecutionResult> {
        this.calls.push(request);

        const now = new Date().toISOString();

        return {
            id: `recorded-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: {
                recorded: true,
                action: request.action,
                taskId: request.taskId,
            },
            startedAt: now,
            completedAt: now,
        };
    }
}

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

async function main(): Promise<void> {
    const stateDir =
        join(
            process.cwd(),
            ".happy-step9b-resume-test",
        );

    await rm(
        stateDir,
        {
            recursive: true,
            force: true,
        },
    );

    const stateFile =
        join(
            stateDir,
            "orchestration-state.json",
        );

    const persistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile,
            ),
        );

    const store =
        createHappyStateStore(
            persistence,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );

    const requestId =
        "resume-9b-request";

    const approvalId =
        "approval-resume-9b";

    const planId =
        "plan-resume-9b";

    const actions = [
        "UNDERSTAND",
        "BUILD",
        "TEST",
        "VERIFY",
        "CONTROL",
    ] as const;

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId:
            "reasoning-resume-9b",
        goal:
            "Resume a five-task mission after approval",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps:
            actions.map(
                (action, index) => ({
                    id:
                        `plan-step-resume-9b-${index + 1}`,
                    order:
                        index + 1,
                    action,
                    title:
                        `${action} task`,
                    description:
                        `Deterministic ${action} task for resume testing.`,
                    dependencies:
                        index === 0
                            ? []
                            : [
                                `plan-step-resume-9b-${index}`,
                            ],
                    requiresApproval:
                        false,
                    risk:
                        "LOW",
                    verificationRequired:
                        true,
                }),
            ),
        expectedOutputs: [
            "Five completed tasks",
            "Five verification results",
            "Five evidence records",
        ],
        failureConditions: [
            "Any task fails.",
            "Any task is skipped.",
            "Any task executes more than once.",
        ],
        verificationRequirements: [
            "Every task execution must complete.",
            "Evidence must be persisted for every task.",
        ],
        createdAt:
            new Date().toISOString(),
    };

    await store.mission().create(
        planId,
        plan,
        "user-9b",
    );

    await store.approval().create(
        approvalId,
        {
            requestId,
            planId,
            status:
                "APPROVED",
            createdAt:
                new Date().toISOString(),
            approvedAt:
                new Date().toISOString(),
            decision:
                "APPROVED",
            decisionId:
                "decision-resume-9b",
            approverId:
                "user-9b",
            decidedAt:
                new Date().toISOString(),
            decisionReason:
                "Deterministic multi-task resume regression test.",
        },
        "user-9b",
    );

    const engine =
        new HappyOrchestrationEngine(
            stateFile,
        );

    const recorder =
        new RecordingExecutionEngine();

    (
        engine as unknown as {
            execution:
                RecordingExecutionEngine;
        }
    ).execution =
        recorder;

    const [result, concurrentResult] = await Promise.all([
        engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-9b",
            "workspace-9b",
            "user-9b",
        ),
        engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-9b",
            "workspace-9b",
            "user-9b",
        ),
    ]);

    assert(
        concurrentResult.status === result.status,
        "Concurrent callers returned different statuses.",
    );
    assert(
        concurrentResult.missionId === result.missionId,
        "Concurrent callers returned different missions.",
    );

    // Retry-safety regression: completed resume must not execute tasks twice.
    let retryResult: Awaited<ReturnType<typeof engine.resumeAfterApproval>> | undefined;
    let retryError = "";

    try {
        retryResult = await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );
    } catch (error) {
        retryError = error instanceof Error ? error.message : String(error);
    }

    assert(
        retryError === "",
        `Completed resume retry should recover safely, got: ${retryError}`,
    );
    assert(
        retryResult?.status === "COMPLETED",
        "Completed resume retry did not return the completed result.",
    );
    assert(
        retryResult?.missionId === result.missionId,
        "Completed resume retry created or returned a different mission.",
    );
    assert(
        recorder.calls.length === 5,
        `Retry duplicated execution; expected 5 calls, got ${recorder.calls.length}.`,
    );

    /*
     * Fresh persistence instance:
     * proves data survived runtime reload.
     */
    const freshPersistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile,
            ),
        );

    const freshStore =
        createHappyStateStore(
            freshPersistence,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );

    const tasks =
        await freshStore.task().list();

    const executions =
        await freshStore.execution().list();

    const verifications =
        await freshStore.verification().list();

    const evidence =
        await freshStore.evidence().list();

    const mission =
        result.missionId
            ? await freshStore
                .mission()
                .get(result.missionId)
            : undefined;

    const executedActions =
        recorder.calls.map(
            (request) =>
                request.action,
        );

    const uniqueTaskIds =
        new Set(
            recorder.calls.map(
                (request) =>
                    request.taskId,
            ),
        );

    const completedTasks =
        tasks.filter(
            (record) =>
                (record.data as { status?: string }).status ===
                "COMPLETED",
        );

    console.log("");
    console.log(
        "================ STEP 9C RESULT ================",
    );

    console.log(
        JSON.stringify(
            {
                status:
                    result.status,
                currentStage:
                    result.currentStage,
                planId:
                    result.planId,
                executionCalls:
                    recorder.calls.length,
                executedActions,
                uniqueTaskIds:
                    uniqueTaskIds.size,
                persistedTasks:
                    tasks.length,
                completedTasks:
                    completedTasks.length,
                persistedExecutions:
                    executions.length,
                persistedVerifications:
                    verifications.length,
                persistedEvidence:
                    evidence.length,
                missionStatus:
                    (mission?.data as { status?: string } | undefined)?.status,
            },
            null,
            2,
        ),
    );

    assert(
        result.status ===
            "COMPLETED",
        "Resume pipeline did not complete.",
    );

    assert(
        result.currentStage ===
            "COMPLETE",
        "Resume pipeline did not reach COMPLETE.",
    );

    assert(
        recorder.calls.length === 5,
        `Expected 5 executions, got ${recorder.calls.length}.`,
    );

    assert(
        JSON.stringify(executedActions) ===
            JSON.stringify(actions),
        "Execution order is incorrect.",
    );

    assert(
        uniqueTaskIds.size === 5,
        "Task duplication detected.",
    );

    assert(
        tasks.length === 5,
        `Expected 5 persisted tasks, got ${tasks.length}.`,
    );

    assert(
        completedTasks.length === 5,
        "Not all persisted tasks are COMPLETED.",
    );

    assert(
        executions.length === 5,
        `Expected 5 persisted executions, got ${executions.length}.`,
    );

    assert(
        verifications.length === 5,
        `Expected 5 persisted verifications, got ${verifications.length}.`,
    );

    assert(
        evidence.length === 5,
        `Expected 5 persisted evidence records, got ${evidence.length}.`,
    );

    assert(
        (mission?.data as { status?: string } | undefined)?.status ===
            "COMPLETED",
        "Persisted mission is not COMPLETED.",
    );

    console.log("");
    console.log(
        "=== STEP 9C: VERIFIED PASS ===",
    );
}

main().catch(
    (error) => {
        console.error(error);
        process.exit(1);
    },
);


