import { join } from "node:path";
import { evaluateHappyFeatureAccess } from "../authorization/happy-feature-access";
import { getHappyExecutionFeatureContract, isHappyExecutionFeatureReady } from "../happy/kernel/runtime/happy-execution-route";
import type { CapabilityAction } from "../capabilities/types";

import { parseCommand } from "../command/parser";
import {
    buildContext,
    resolveContext,
} from "../context/resolver";
import { PersistentMemoryService } from "../memory/persistent-service";
import { ReasoningOrchestrator } from "../reasoning/orchestrator";
import type { ExecutionPlan } from "../reasoning/types";
import { MissionOrchestrator } from "../mission/orchestrator";
import { TaskGraphEngine } from "../mission/task-graph";

import {
    ExecutionEngine,
} from "../execution/engine";

import {
    createDefaultExecutionRegistry,
} from "../execution/default-registry";

import {
    resolveExecutionCapability,
} from "../execution/capability-resolver";

import {
    resolveHappyModuleExecutionRoute,
} from "../happy/kernel/runtime/happy-execution-route";

import {
    requireExecutionCapabilityDefinition,
} from "../capabilities/registry";

import type {
    ExecutionRuntimeContext,
} from "../execution/runtime-context";

import {
    VerificationEngine,
} from "../verification/engine";

import {
    InMemoryEvidenceRepository,
} from "../evidence/repository";

import {
    EvidenceService,
} from "../evidence/service";

import {
    JsonFileStateAdapter,
} from "../persistence/adapters/json-file-adapter";

import {
    PersistenceService,
} from "../persistence/service";

import {
    createHappyStateStore,
} from "../state/factory";

import type {
    HappyPipelineRequest,
    HappyPipelineResult,
    HappyPipelineStageResult,
} from "./types";

function buildWorkspaceFileChanges(outputs: unknown[], missionId: string, taskOrder: number) {
    for (let i = outputs.length - 1; i >= 0; i--) {
        const value = outputs[i];
        if (typeof value !== "object" || value === null) continue;
        const content = (value as { content?: unknown }).content;
        if (typeof content !== "string" || !content.trim()) continue;
        const fenced = content.match(/```(?:html|tsx?|jsx?|css|javascript|js)?\s*([\s\S]*?)```/i);
        return [{
            action: "CREATE" as const,
            path: `.happy-workspaces/${missionId}/task-${taskOrder}/index.html`,
            content: (fenced?.[1] ?? content).trim(),
        }];
    }
    return [];
}
export class HappyOrchestrationEngine {

    private readonly reasoning: ReasoningOrchestrator;
    private readonly mission: MissionOrchestrator;
    private readonly execution: ExecutionEngine;

    private readonly persistence: PersistenceService;
    private readonly persistenceFile: string;
    private readonly resumeInFlight = new Map<string, Promise<HappyPipelineResult>>();

    constructor(
        persistenceFile?: string,
        persistence?: PersistenceService,
    ) {
        this.reasoning = new ReasoningOrchestrator();
        this.mission = new MissionOrchestrator();

        const registry =
            createDefaultExecutionRegistry();

        this.execution =
            new ExecutionEngine(registry);

        this.persistenceFile =
            persistenceFile ??
            join(
                process.cwd(),
                ".happy-state",
                "orchestration-state.json",
            );

        this.persistence =
            persistence ??
            new PersistenceService(
                new JsonFileStateAdapter(
                    this.persistenceFile,
                ),
            );
    }

    async resumeAfterApproval(
        requestId: string,
        approvalId: string,
        planId: string,
        organizationId: string,
        workspaceId: string,
        userId: string,
        runtimeContext?: ExecutionRuntimeContext,
    ): Promise<HappyPipelineResult> {
        const key = JSON.stringify([
            organizationId,
            workspaceId,
            userId,
            requestId,
            approvalId,
            planId,
        ]);

        const existing = this.resumeInFlight.get(key);
        if (existing) {
            return existing;
        }

        const operation = this.resumeAfterApprovalInternal(
            requestId,
            approvalId,
            planId,
            organizationId,
            workspaceId,
            userId,
            runtimeContext,
        );

        this.resumeInFlight.set(key, operation);

        try {
            return await operation;
        } finally {
            if (this.resumeInFlight.get(key) === operation) {
                this.resumeInFlight.delete(key);
            }
        }
    }
    private async resumeAfterApprovalInternal(
        requestId: string,
        approvalId: string,
        planId: string,
        organizationId: string,
        workspaceId: string,
        userId: string,
        runtimeContext?: ExecutionRuntimeContext,
    ): Promise<HappyPipelineResult> {
        const startedAt =
            new Date().toISOString();

        const state =
            createHappyStateStore(
                this.persistence,
                organizationId,
                workspaceId,
                userId,
            );

        // ==================================================
        // APPROVAL VALIDATION
        // ==================================================

        const approval =
            await state.approval<{
                requestId: string;
                planId: string;
                status: string;
                createdAt?: string;
                approvedAt?: string;
                decision?: string;
                decisionId?: string;
                approverId?: string;
                decidedAt?: string;
                decisionReason?: string;
            }>().get(approvalId);

        if (!approval) {
            throw new Error(
                "APPROVAL_NOT_FOUND",
            );
        }

        const approvalData =
            approval.data;

        if (
            approvalData.requestId !== requestId ||
            approvalData.planId !== planId
        ) {
            throw new Error(
                "APPROVAL_LINKAGE_MISMATCH",
            );
        }

        if (
            approvalData.status !==
            "APPROVED"
        ) {
            throw new Error(
                "APPROVAL_NOT_APPROVED",
            );
        }

        // ==================================================
        // LOAD PLAN
        // ==================================================

        const planRecord =
            await state
                .mission<ExecutionPlan>()
                .get(planId);

        if (!planRecord) {
            throw new Error(
                "EXECUTION_PLAN_NOT_FOUND",
            );
        }

        const plan =
            planRecord.data;

        // Retry safety: never replay a resume that already has a durable audit marker.
        const resumeAuditId = `audit-resume-${requestId}`;
        const priorResumeAudit =
            await state.audit<Record<string, unknown>>().get(resumeAuditId);

        if (priorResumeAudit) {
            const auditData = priorResumeAudit.data;

            if (
                auditData["requestId"] !== requestId ||
                auditData["approvalId"] !== approvalId ||
                auditData["planId"] !== planId
            ) {
                throw new Error("RESUME_AUDIT_LINKAGE_MISMATCH");
            }

            const priorResult = auditData["result"];
            if (
                auditData["event"] === "PIPELINE_RESUMED_AFTER_APPROVAL_COMPLETED" &&
                auditData["finalStatus"] === "COMPLETED" &&
                priorResult !== null &&
                typeof priorResult === "object" &&
                (priorResult as Record<string, unknown>)["requestId"] === requestId &&
                (priorResult as Record<string, unknown>)["planId"] === planId &&
                (priorResult as Record<string, unknown>)["status"] === "COMPLETED" &&
                (priorResult as Record<string, unknown>)["persisted"] === true &&
                typeof (priorResult as Record<string, unknown>)["missionId"] === "string" &&
                Array.isArray((priorResult as Record<string, unknown>)["evidenceIds"])
            ) {
                return priorResult as HappyPipelineResult;
            }

            throw new Error("RESUME_RECOVERY_RECONCILIATION_REQUIRED");
        }

        await state.audit().create(
            resumeAuditId,
            {
                event: "PIPELINE_RESUME_STARTED",
                requestId,
                approvalId,
                planId: plan.id,
                finalStatus: "RUNNING",
                startedAt: new Date().toISOString(),
            },
            userId,
        );


        // ==================================================
        // CREATE MISSION + TASK GRAPH
        // ==================================================

        let currentMissionSnapshot =
            this.mission.create(plan);

        await state.mission().create(
            currentMissionSnapshot.mission.id,
            currentMissionSnapshot.mission,
            userId,
        );

        const taskGraphEngine =
            new TaskGraphEngine();

        const initialReadyTasks =
            taskGraphEngine
                .getReadyTasks(
                    currentMissionSnapshot.graph,
                )
                .sort(
                    (a, b) =>
                        a.order - b.order,
                );

        if (
            initialReadyTasks.length === 0
        ) {
            throw new Error(
                "MISSION_HAS_NO_TASKS",
            );
        }

        const persistedProjectTarget =
            plan.steps.find(
                (step) =>
                    step.targetReference?.entityType ===
                    "PROJECT",
            )?.targetReference;

        for (
            const task of
            currentMissionSnapshot.graph.tasks
        ) {
            await state.task().create(
                task.id,
                task,
                userId,
            );
        }

        // ==================================================
        // TRACE / EVIDENCE
        // ==================================================

        const stages:
            HappyPipelineStageResult[] = [
                {
                    stage: "APPROVAL",
                    status: "COMPLETED",
                    summary:
                        "Authenticated approval decision confirmed.",
                    referenceId:
                        approvalId,
                },
                {
                    stage: "MISSION",
                    status: "PROCESSING",
                    summary:
                        "Mission resumed from the persisted execution plan.",
                    referenceId:
                        currentMissionSnapshot.mission.id,
                },
            ];

        const evidenceRepository =
            new InMemoryEvidenceRepository();

        const evidenceService =
            new EvidenceService(
                evidenceRepository,
            );

        const verificationEngine =
            new VerificationEngine(
                evidenceService,
            );

        const allEvidenceIds:
            string[] = [];

        const executionOutputs:
            unknown[] = [];

        let lastExecutionRequestId:
            string | undefined;

        let lastVerificationRequestId:
            string | undefined;

        let terminalStatus:
            HappyPipelineResult["status"] =
            "RUNNING";

        let executionCycles =
            0;

        const maxExecutionCycles =
            Math.max(
                1,
                currentMissionSnapshot.graph.tasks.length,
            );

        // ==================================================
        // TRUE MULTI-TASK RESUME LOOP
        // ==================================================

        while (true) {
            executionCycles += 1;

            if (
                executionCycles >
                maxExecutionCycles
            ) {
                throw new Error(
                    "MULTI_TASK_RESUME_EXECUTION_GUARD_EXCEEDED",
                );
            }

            const readyTasks =
                taskGraphEngine
                    .getReadyTasks(
                        currentMissionSnapshot.graph,
                    )
                    .sort(
                        (a, b) =>
                            a.order - b.order,
                    );

            const executionTargetTask =
                readyTasks[0];

            if (!executionTargetTask) {
                const remainingTasks =
                    currentMissionSnapshot.graph.tasks
                        .filter(
                            (task) =>
                                task.status !==
                                "COMPLETED",
                        );

                if (
                    remainingTasks.length > 0
                ) {
                    terminalStatus =
                        "BLOCKED";

                    stages.push({
                        stage: "MISSION",
                        status: "BLOCKED",
                        summary:
                            "Mission graph stalled because no executable task is ready.",
                    });
                }

                break;
            }

            // ----------------------------------------------
            // TASK -> RUNNING
            // ----------------------------------------------

            currentMissionSnapshot =
                this.mission.updateTaskStatus(
                    currentMissionSnapshot,
                    executionTargetTask.id,
                    "RUNNING",
                );

            const runningTask =
                currentMissionSnapshot.graph.tasks.find(
                    (task) =>
                        task.id ===
                        executionTargetTask.id,
                );

            if (!runningTask) {
                throw new Error(
                    "Running task was not found after status transition.",
                );
            }

            await state.task().update(
                runningTask.id,
                runningTask,
            );

            await state.mission().update(
                currentMissionSnapshot.mission.id,
                currentMissionSnapshot.mission,
            );

            // ----------------------------------------------
            // HAPPY MODULE -> EXECUTION CAPABILITY
            // ----------------------------------------------

            const happyExecutionRoute =
                resolveHappyModuleExecutionRoute(
                    plan.goal,
                    runningTask.action,
                    runningTask.targetReference,
                    runningTask.moduleCrud,
                );

            // ----------------------------------------------
            // EXECUTION REQUEST
            // ----------------------------------------------

            const executionRequest = {
                id:
                    `exec-${requestId}-${runningTask.id}`,
                taskId:
                    runningTask.id,
                missionId:
                    currentMissionSnapshot.mission.id,
                capability:
                    happyExecutionRoute.executionCapability,
                action:
                    runningTask.action,
                input: {
                    command:
                        plan.goal,
                    taskTitle:
                        runningTask.title,
                    taskDescription:
                        runningTask.description,
                    taskOrder:
                        runningTask.order,
                    resumedAfterApproval:
                        true,
                    approvalId,
            moduleCrud: runningTask.moduleCrud,
                    happyModuleRoute: {
                        source:
                            happyExecutionRoute.source,
                        status:
                            happyExecutionRoute.status,
                        moduleId:
                            happyExecutionRoute.moduleId,
                        moduleNumber:
                            happyExecutionRoute.moduleNumber,
                        moduleName:
                            happyExecutionRoute.moduleName,
                        moduleCategory:
                            happyExecutionRoute.moduleCategory,
                        moduleAction:
                            happyExecutionRoute.moduleAction,
                        bindingStatus:
                            happyExecutionRoute.binding?.status,
                        bindingCapability:
                            happyExecutionRoute.binding?.capability,
                        reason:
                            happyExecutionRoute.reason,
                    },
                },
                targetReference:
                    runningTask.targetReference ??
                    persistedProjectTarget,
                requiresApproval:
                    runningTask.requiresApproval,
                approved:
                    true,
                risk:
                    runningTask.requiresApproval
                        ? "HIGH" as const
                        : "LOW" as const,
                createdAt:
                    new Date().toISOString(),
            };

            await state.execution().create(
                executionRequest.id,
                executionRequest,
                userId,
            );

            lastExecutionRequestId =
                executionRequest.id;

            // ----------------------------------------------
            // EXECUTION
            // ----------------------------------------------

            let executionResult: Awaited<
                ReturnType<typeof this.execution.execute>
            >;

            try {
                executionResult = await this.execution.execute(
                    executionRequest,
                    runtimeContext,
                );
            } catch (executionError) {
                const failureMessage =
                    executionError instanceof Error
                        ? executionError.message
                        : String(executionError);

                try {
                    const existingAudit = await state
                        .audit<Record<string, unknown>>()
                        .get(resumeAuditId);

                    if (existingAudit) {
                        await state.audit().update(
                            resumeAuditId,
                            {
                                ...existingAudit.data,
                                event: "PIPELINE_RESUME_OUTCOME_UNKNOWN",
                                finalStatus: "RECONCILIATION_REQUIRED",
                                reconciliationRequired: true,
                                outcomeUnknown: true,
                                failedTaskId: runningTask.id,
                                executionRequestId: executionRequest.id,
                                failureMessage,
                                failureRecordedAt: new Date().toISOString(),
                            },
                        );
                    }
                } catch {
                    // Preserve the original execution error.
                    // The start audit still blocks an unsafe retry.
                }

                throw executionError;
            }

            executionOutputs.push(
                executionResult.output,
            );

            await state.execution().update(
                executionRequest.id,
                {
                    ...executionRequest,
                    ...executionResult,
                    targetReference:
                        executionRequest.targetReference,
                },
            );

            let executionStageStatus:
                HappyPipelineStageResult["status"];

            if (
                executionResult.status ===
                "NOT_YET_CONNECTED"
            ) {
                executionStageStatus =
                    "NOT_YET_CONNECTED";
            } else if (
                executionResult.status ===
                "WAITING_APPROVAL"
            ) {
                executionStageStatus =
                    "WAITING_APPROVAL";
            } else if (
                executionResult.status ===
                "COMPLETED"
            ) {
                executionStageStatus =
                    "COMPLETED";
            } else if (
                executionResult.status ===
                "BLOCKED"
            ) {
                executionStageStatus =
                    "BLOCKED";
            } else {
                executionStageStatus =
                    "FAILED";
            }

            stages.push({
                stage: "EXECUTION",
                status:
                    executionStageStatus,
                summary:
                    executionResult.error
                        ? `Resumed task ${runningTask.order} ${executionResult.status}: ${executionResult.error}`
                        : `Resumed task ${runningTask.order} execution evaluated (${executionResult.status}).`,
                referenceId:
                    executionResult.id,
            });

            // ----------------------------------------------
            // WAITING APPROVAL = HARD STOP
            // ----------------------------------------------

            if (
                executionResult.status ===
                "WAITING_APPROVAL"
            ) {
                terminalStatus =
                    "WAITING_APPROVAL";

                currentMissionSnapshot =
                    this.mission.updateTaskStatus(
                        currentMissionSnapshot,
                        runningTask.id,
                        "PENDING",
                    );

                const pendingTask =
                    currentMissionSnapshot.graph.tasks.find(
                        (task) =>
                            task.id ===
                            runningTask.id,
                    );

                if (pendingTask) {
                    await state.task().update(
                        pendingTask.id,
                        pendingTask,
                    );
                }

                await state.mission().update(
                    currentMissionSnapshot.mission.id,
                    currentMissionSnapshot.mission,
                );

                break;
            }

            // ----------------------------------------------
            // VERIFICATION
            // ----------------------------------------------

            const verificationRequest = {
                id:
                    `verification-${requestId}-${runningTask.id}`,
                missionId:
                    currentMissionSnapshot.mission.id,
                taskId:
                    runningTask.id,
                executionRequestId:
                    executionResult.requestId,
                description:
                    `Verify resumed execution of mission task ${runningTask.order}.`,
                criteria: [
    {
        id:
            "execution-status",
        description:
            "Execution must have a connected successful result.",
        expected:
            "COMPLETED",
        required:
            true,
    },
    ...(
        typeof happyExecutionRoute.moduleNumber === "number" &&
        Number.isInteger(
            happyExecutionRoute.moduleNumber,
        ) &&
        typeof happyExecutionRoute.moduleAction === "string"
    )
        ? [
            {
                id:
                    "module-route-match",
                description:
                    "Execution evidence must preserve the resolved HAPPY module route.",
                expected:
                    JSON.stringify({
                        moduleNumber:
                            happyExecutionRoute.moduleNumber,
                        moduleAction:
                            happyExecutionRoute.moduleAction,
                    }),
                required:
                    true,
            },
        ]
        : [],
],
                preferredMethods: [
                    "TEST" as const,
                    "COMMAND" as const,
                    "LOG" as const,
                ],
                requiresEvidence:
                    true,
                createdAt:
                    new Date().toISOString(),
            };

            await state.verification().create(
                verificationRequest.id,
                verificationRequest,
                userId,
            );

            lastVerificationRequestId =
                verificationRequest.id;

            // ----------------------------------------------
            // EVIDENCE
            // ----------------------------------------------

            const executionEvidence =
                evidenceService.capture({
                    verificationRequestId:
                        verificationRequest.id,
                    executionRequestId:
                        executionResult.requestId,
                    missionId:
                        currentMissionSnapshot.mission.id,
                    taskId:
                        runningTask.id,
                    type:
                        "COMMAND_OUTPUT" as const,
                    source:
                        "EXECUTION" as const,
                    title:
                        `Resumed execution evidence ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â task ${runningTask.order}`,
                    content:
                        JSON.stringify({
                            taskId:
                                runningTask.id,
                            taskOrder:
                                runningTask.order,
                            action:
                                runningTask.action,
                            status:
                                executionResult.status,
                            output:
                                executionResult.output,
                            error:
                                executionResult.error,
                            happyModuleRoute:
                                executionRequest.input
                                    .happyModuleRoute,
                            approvalId,
                            resumedAfterApproval:
                                true,
                        }),
                    metadata: {
                        capability:
                            executionResult.capability,
                        executionResultId:
                            executionResult.id,
                        taskOrder:
                            runningTask.order,
                        retryCount:
                            runningTask.retryCount,
                        approvalId,
                        resumedAfterApproval:
                            true,
                    },
                    isPrimary:
                        true,
                });

            await state.evidence().create(
                executionEvidence.id,
                executionEvidence,
                userId,
            );

            allEvidenceIds.push(
                executionEvidence.id,
            );

            // ----------------------------------------------
            // VERIFY
            // ----------------------------------------------

            const verificationResult =
                verificationEngine.verify(
                    verificationRequest,
                    [
                        executionEvidence.id,
                    ],
                );

            await state.verification().update(
                verificationRequest.id,
                verificationResult,
            );

            stages.push({
                stage: "VERIFICATION",
                status:
                    verificationResult.status ===
                    "PASSED"
                        ? "COMPLETED"
                        : verificationResult.status ===
                          "PARTIAL"
                            ? "PARTIAL"
                            : "FAILED",
                summary:
                    verificationResult.summary,
                referenceId:
                    verificationResult.id,
            });

            stages.push({
                stage: "EVIDENCE",
                status:
                    verificationResult.evidenceIds.length >
                    0
                        ? "COMPLETED"
                        : "BLOCKED",
                summary:
                    verificationResult.evidenceIds.length >
                    0
                        ? `Evidence captured for resumed task ${runningTask.order}.`
                        : `No evidence captured for resumed task ${runningTask.order}.`,
                referenceId:
                    executionEvidence.id,
            });

            // ----------------------------------------------
            // TASK STATE TRANSITION
            // ----------------------------------------------

            let nextTaskStatus:
                import("../mission/types").TaskStatus;

            if (
                executionResult.status ===
                    "COMPLETED" &&
                verificationResult.status ===
                    "PASSED"
            ) {
                nextTaskStatus =
                    "COMPLETED";
            } else if (
                executionResult.status ===
                    "COMPLETED" &&
                verificationResult.status ===
                    "PARTIAL"
            ) {
                nextTaskStatus =
                    "VERIFYING";
            } else if (
                executionResult.status ===
                "BLOCKED"
            ) {
                nextTaskStatus =
                    "BLOCKED";
            } else {
                nextTaskStatus =
                    "FAILED";
            }

            currentMissionSnapshot =
                this.mission.updateTaskStatus(
                    currentMissionSnapshot,
                    runningTask.id,
                    nextTaskStatus,
                );

            const updatedTask =
                currentMissionSnapshot.graph.tasks.find(
                    (task) =>
                        task.id ===
                        runningTask.id,
                );

            if (!updatedTask) {
                throw new Error(
                    "Updated mission task was not found.",
                );
            }

            await state.task().update(
                updatedTask.id,
                updatedTask,
            );

            await state.mission().update(
                currentMissionSnapshot.mission.id,
                currentMissionSnapshot.mission,
            );

            // ----------------------------------------------
            // TERMINAL TASK OUTCOME
            // ----------------------------------------------

            if (
                nextTaskStatus !==
                "COMPLETED"
            ) {
                terminalStatus =
                    executionResult.status ===
                    "NOT_YET_CONNECTED"
                        ? "NOT_YET_CONNECTED"
                        : executionResult.status ===
                          "BLOCKED"
                            ? "BLOCKED"
                            : verificationResult.status ===
                              "PARTIAL"
                                ? "PARTIAL"
                                : "FAILED";

                break;
            }

            terminalStatus =
                "RUNNING";

            // ----------------------------------------------
            // ALL TASKS COMPLETE?
            // ----------------------------------------------

            const allTasksCompleted =
                currentMissionSnapshot.graph.tasks.every(
                    (task) =>
                        task.status ===
                        "COMPLETED",
                );

            if (allTasksCompleted) {
                terminalStatus =
                    "COMPLETED";
                break;
            }
        }

        // ==================================================
        // FINAL STATUS
        // ==================================================

        const allTasksCompleted =
            currentMissionSnapshot.graph.tasks.length >
                0 &&
            currentMissionSnapshot.graph.tasks.every(
                (task) =>
                    task.status ===
                    "COMPLETED",
            );

        const hasBlockedTasks =
            currentMissionSnapshot.graph.tasks.some(
                (task) =>
                    task.status ===
                    "BLOCKED",
            );

        const hasFailedTasks =
            currentMissionSnapshot.graph.tasks.some(
                (task) =>
                    task.status ===
                    "FAILED",
            );

        let finalStatus:
            HappyPipelineResult["status"];

        if (allTasksCompleted) {
            finalStatus =
                "COMPLETED";
        } else if (
            terminalStatus ===
            "WAITING_APPROVAL"
        ) {
            finalStatus =
                "WAITING_APPROVAL";
        } else if (
            terminalStatus ===
            "NOT_YET_CONNECTED"
        ) {
            finalStatus =
                "NOT_YET_CONNECTED";
        } else if (
            hasFailedTasks ||
            terminalStatus ===
            "FAILED"
        ) {
            finalStatus =
                "FAILED";
        } else if (
            hasBlockedTasks ||
            terminalStatus ===
            "BLOCKED"
        ) {
            finalStatus =
                "BLOCKED";
        } else {
            finalStatus =
                "PARTIAL";
        }

        const finalStage:
            HappyPipelineResult["currentStage"] =
            finalStatus ===
            "COMPLETED"
                ? "COMPLETE"
                : finalStatus ===
                  "WAITING_APPROVAL"
                    ? "APPROVAL"
                    : finalStatus ===
                      "NOT_YET_CONNECTED"
                        ? "NOT_YET_CONNECTED"
                        : "BLOCKED";

        stages.push({
            stage: "PERSIST",
            status: "COMPLETED",
            summary:
                `Resumed multi-task mission state persisted after ${executionCycles} execution cycle(s).`,
        });

        const finalOutput =
            executionOutputs.length === 1
                ? executionOutputs[0]
                : executionOutputs;

        const finalResult:
            HappyPipelineResult = {
            requestId,
            status:
                finalStatus,
            currentStage:
                finalStage,
            trace: {
                requestId,
                stages,
                currentStage:
                    finalStage,
                status:
                    finalStatus,
                startedAt,
                completedAt:
                    new Date().toISOString(),
            },
            missionId:
                currentMissionSnapshot.mission.id,
            planId:
                plan.id,
            executionRequestId:
                lastExecutionRequestId,
            verificationRequestId:
                lastVerificationRequestId,
            evidenceIds:
                allEvidenceIds,
            output:
                finalOutput,
            persisted:
                true,
        };

        await state.audit().update(
            resumeAuditId,
            {
                event:
                    finalStatus ===
                    "COMPLETED"
                        ? "PIPELINE_RESUMED_AFTER_APPROVAL_COMPLETED"
                        : "PIPELINE_RESUMED_AFTER_APPROVAL_TERMINAL",
                requestId,
                approvalId,
                planId:
                    plan.id,
                missionId:
                    currentMissionSnapshot.mission.id,
                executionCycles,
                executionRequestId:
                    lastExecutionRequestId,
                verificationRequestId:
                    lastVerificationRequestId,
                finalStatus,
                evidenceIds:
                    allEvidenceIds,
                trace:
                    finalResult.trace,
                result: finalResult,
                createdAt:
                    new Date().toISOString(),
            },
        );

        return finalResult;
    }
    async run(
        request: HappyPipelineRequest,
        runtimeContext?: ExecutionRuntimeContext,
    ): Promise<HappyPipelineResult> {
        const startedAt =
            new Date().toISOString();

        const stages: HappyPipelineStageResult[] = [];

        const addStage = (
            stage: HappyPipelineStageResult,
        ): void => {
            stages.push(stage);
        };

        const state =
            createHappyStateStore(
                this.persistence,
                request.organizationId,
                request.workspaceId,
                request.userId,
            );

        // ==================================================
        // COMMAND
        // ==================================================

        const commandResult =
            parseCommand(
                request.command,
                request.source,
            );

        addStage({
            stage: "COMMAND",
            status: "PROCESSING",
            summary:
                "Command normalized and classified.",
            referenceId:
                commandResult.command.id,
        });

        await state.repository("COMMAND").create(
            commandResult.command.id,
            commandResult.command,
            request.userId,
        );

        // ==================================================
        // MEMORY
        // ==================================================

        const persistentMemory =
            new PersistentMemoryService(
                request.organizationId,
                request.workspaceId,
                request.userId,
                this.persistenceFile,
                this.persistence,
            );

        const memoryKey =
            `pipeline:${request.id}`;

        const existingMemory =
            await persistentMemory.search({
                userId:
                    request.userId,
                workspaceId:
                    request.workspaceId,
                key:
                    memoryKey,
                limit:
                    1,
            });

        const commandMemory =
            existingMemory[0] ??
            await persistentMemory.remember({
                type:
                    "EPISODIC",
                scope:
                    "SESSION",
                userId:
                    request.userId,
                workspaceId:
                    request.workspaceId,
                key:
                    memoryKey,
                value:
                    request.command,
                confidence:
                    "HIGH",
                source:
                    "PIPELINE_COMMAND",
            });

        const memoryContext =
            await persistentMemory.search({
                userId:
                    request.userId,
                workspaceId:
                    request.workspaceId,
                limit:
                    20,
            });

        const memorySummary =
            memoryContext
                .map(
                    (memory) =>
                        `${memory.key}: ${memory.value}`,
                )
                .join("\n");

        const memoryCount =
            await persistentMemory.count();

        addStage({
            stage: "MEMORY",
            status: "COMPLETED",
            summary:
                "Persistent memory loaded and pipeline command retained.",
            referenceId:
                commandMemory.id,
        });

        // ==================================================
        // CONTEXT
        // ==================================================

        const contextResolution =
            resolveContext(
                {
                    userId:
                        request.userId,
                    workspaceId:
                        request.workspaceId,
                    activeProjectId:
                        request.activeProjectId,
                    activeMissionId:
                        request.activeMissionId,
                    activeTaskId:
                        request.activeTaskId,
                    memorySummary:
                        memorySummary,
                    recentCommand:
                        request.command,
                },
                request.command,
            );

        addStage({
            stage: "CONTEXT",
            status:
                contextResolution.requiresClarification
                    ? "BLOCKED"
                    : "COMPLETED",
            summary:
                contextResolution.requiresClarification
                    ? "Context contains unresolved references and requires clarification."
                    : "Context resolved with persistent memory.",
        });

        if (
            contextResolution.requiresClarification
        ) {
            return {
                requestId:
                    request.id,
                status:
                    "BLOCKED",
                currentStage:
                    "CONTEXT",
                trace: {
                    requestId:
                        request.id,
                    stages,
                    currentStage:
                        "CONTEXT",
                    status:
                        "BLOCKED",
                    startedAt,
                    completedAt:
                        new Date().toISOString(),
                },
                evidenceIds: [],
                persisted: false,
            };
        }
        // ==================================================
        // REASONING + PLAN
        // ==================================================


        const plan =
            await this.reasoning.createAIExecutionPlan({
                goal:
                    request.command,
                resolvedReferences:
                    contextResolution.resolvedReferences,
contextSummary:
                    JSON.stringify({
                        context:
                            contextResolution,
                        resolvedReferences:
                            contextResolution.resolvedReferences,
                        unresolvedReferences:
                            contextResolution.unresolvedReferences,
                        requiresClarification:
                            contextResolution.requiresClarification,
                        persistentMemory:
                            memorySummary,
                    }),
            });

        addStage({
            stage: "REASON",
            status: "PROCESSING",
            summary:
                "Reasoning engine evaluated the command.",
            referenceId:
                plan.reasoningRequestId,
        });

        addStage({
            stage: "PLAN",
            status:
                plan.steps.some(
                    (step) =>
                        step.requiresApproval,
                )
                    ? "WAITING_APPROVAL"
                    : "PROCESSING",
            summary:
                "Execution plan created.",
            referenceId:
                plan.id,
        });

        await state.mission().create(
            plan.id,
            plan,
            request.userId,
        );

        // ==================================================
        // APPROVAL
        // ==================================================

        const approvalRequired =
            plan.steps.some(
                (step) =>
                    step.requiresApproval,
            );

        if (
            approvalRequired &&
            request.approved !== true
        ) {
            const approvalRecord = {
                requestId:
                    request.id,
                planId:
                    plan.id,
                status:
                    "WAITING_APPROVAL",
                createdAt:
                    new Date().toISOString(),
            };

            addStage({
                stage: "APPROVAL",
                status: "WAITING_APPROVAL",
                summary:
                    "Founder approval required before execution.",
            });

            await state.approval().create(
                `approval-${request.id}`,
                approvalRecord,
                request.userId,
            );

            await state.audit().create(
                `audit-${request.id}`,
                {
                    event:
                        "PIPELINE_WAITING_APPROVAL",
                    requestId:
                        request.id,
                    planId:
                        plan.id,
                    stage:
                        "APPROVAL",
                    createdAt:
                        new Date().toISOString(),
                },
                request.userId,
            );

            addStage({
                stage: "PERSIST",
                status: "COMPLETED",
                summary:
                    "Waiting-approval state persisted.",
            });

            return {
                requestId:
                    request.id,
                status:
                    "WAITING_APPROVAL",
                currentStage:
                    "APPROVAL",
                trace: {
                    requestId:
                        request.id,
                    stages,
                    currentStage:
                        "APPROVAL",
                    status:
                        "WAITING_APPROVAL",
                    startedAt,
                    completedAt:
                        new Date().toISOString(),
                },
                planId:
                    plan.id,
                evidenceIds: [],
                persisted: true,
            };
        }

        addStage({
            stage: "APPROVAL",
            status: "COMPLETED",
            summary:
                approvalRequired
                    ? "Approval supplied by caller."
                    : "Approval gate not required.",
        });

        if (approvalRequired) {
            await state.approval().create(
                `approval-${request.id}`,
                {
                    requestId:
                        request.id,
                    planId:
                        plan.id,
                    status:
                        "APPROVED",
                    approvedAt:
                        new Date().toISOString(),
                },
                request.userId,
            );
        }

        // ==================================================
        // MISSION
        // ==================================================

        const missionSnapshot =
            this.mission.create(plan);

        await state.mission().create(
            missionSnapshot.mission.id,
            missionSnapshot.mission,
            request.userId,
        );

        addStage({
            stage: "MISSION",
            status: "PROCESSING",
            summary:
                "Mission created from execution plan.",
            referenceId:
                missionSnapshot.mission.id,
        });

        // ==================================================
        // TASK GRAPH
        // ==================================================

        const taskGraphEngine =
            new TaskGraphEngine();

        const readyTasks =
            taskGraphEngine
                .getReadyTasks(
                    missionSnapshot.graph,
                )
                .sort(
                    (a, b) =>
                        a.order - b.order,
                );

        const firstTask =
            readyTasks[0];

        for (
            const task of
            missionSnapshot.graph.tasks
        ) {
            await state.task().create(
                task.id,
                task,
                request.userId,
            );
        }

        if (!firstTask) {
            addStage({
                stage: "TASK_GRAPH",
                status: "BLOCKED",
                summary:
                    "Mission has no executable tasks.",
                referenceId:
                    missionSnapshot.mission.id,
            });

            await state.audit().create(
                `audit-${request.id}-blocked`,
                {
                    event:
                        "TASK_GRAPH_BLOCKED",
                    requestId:
                        request.id,
                    missionId:
                        missionSnapshot.mission.id,
                    createdAt:
                        new Date().toISOString(),
                },
                request.userId,
            );

            return {
                requestId:
                    request.id,
                status:
                    "BLOCKED",
                currentStage:
                    "TASK_GRAPH",
                trace: {
                    requestId:
                        request.id,
                    stages,
                    currentStage:
                        "TASK_GRAPH",
                    status:
                        "BLOCKED",
                    startedAt,
                    completedAt:
                        new Date().toISOString(),
                },
                planId:
                    plan.id,
                missionId:
                    missionSnapshot.mission.id,
                evidenceIds: [],
                persisted: true,
            };
        }

        addStage({
            stage: "TASK_GRAPH",
            status: "PROCESSING",
            summary:
                "Mission task graph created.",
            referenceId:
                missionSnapshot.mission.id,
        });

        // ==================================================
        // ==================================================
        // EXECUTION
        // ==================================================

        const persistedProjectTarget =
            plan.steps.find(
                (step) =>
                    step.targetReference?.entityType ===
                    "PROJECT",
            )?.targetReference;

        const evidenceRepository =
            new InMemoryEvidenceRepository();

        const evidenceService =
            new EvidenceService(
                evidenceRepository,
            );

        const verificationEngine =
            new VerificationEngine(
                evidenceService,
            );

        let currentMissionSnapshot =
            missionSnapshot;

        const allEvidenceIds:
            string[] = [];

        const executionOutputs:
            unknown[] = [];

        let lastExecutionRequestId:
            string | undefined;

        let lastVerificationRequestId:
            string | undefined;

        let terminalStatus:
            HappyPipelineResult["status"] =
            "RUNNING";

        let executionCycles =
            0;

        const maxExecutionCycles =
            Math.max(
                1,
                currentMissionSnapshot.graph.tasks.length,
            );

        while (true) {
            executionCycles += 1;

            if (
                executionCycles >
                maxExecutionCycles
            ) {
                throw new Error(
                    "MULTI_TASK_EXECUTION_GUARD_EXCEEDED",
                );
            }

            const readyTasks =
                taskGraphEngine
                    .getReadyTasks(
                        currentMissionSnapshot.graph,
                    )
                    .sort(
                        (a, b) =>
                            a.order - b.order,
                    );

            const executionTargetTask =
                readyTasks[0];

            if (!executionTargetTask) {
                break;
            }

            // ----------------------------------------------
            // TASK -> RUNNING
            // ----------------------------------------------

            currentMissionSnapshot =
                this.mission.updateTaskStatus(
                    currentMissionSnapshot,
                    executionTargetTask.id,
                    "RUNNING",
                );

            const runningTask =
                currentMissionSnapshot.graph.tasks.find(
                    (task) =>
                        task.id ===
                        executionTargetTask.id,
                );

            if (!runningTask) {
                throw new Error(
                    "Running task was not found after status transition.",
                );
            }

            await state.task().update(
                runningTask.id,
                runningTask,
            );

            await state.mission().update(
                currentMissionSnapshot.mission.id,
                currentMissionSnapshot.mission,
            );

            // ----------------------------------------------
            // HAPPY MODULE -> EXECUTION CAPABILITY
            // ----------------------------------------------

            const happyExecutionRoute =
                resolveHappyModuleExecutionRoute(
                    request.command,
                    runningTask.action,
                    runningTask.targetReference,
                    runningTask.moduleCrud,
                );

            // ----------------------------------------------
            // SERVER-SIDE FEATURE ACCESS GATE

            const authorization =
                request.authorization;

            const featureAccess =
                evaluateHappyFeatureAccess({
                    userId:
                        request.userId ?? "",
                    role:
                        authorization?.role ?? "USER",
                    scope:
                        authorization?.scope ?? "WORKSPACE",
                    action:
                        runningTask.action as CapabilityAction,
                    capabilityId:
                        happyExecutionRoute.executionCapability ?? undefined,
                    capabilityStatus:
                        happyExecutionRoute.binding?.status ?? undefined,
                    riskLevel:
                        runningTask.requiresApproval
                            ? "HIGH"
                            : "LOW",
                    requiresApproval:
                        runningTask.requiresApproval,
                    approved:
                        request.approved === true,
                    verificationRequired: false,
                });

            if (!authorization ||
                authorization.roleSource !== "TRUSTED_SERVER" ||
                authorization.authenticated !== true) {
                throw new Error(
                    "TRUSTED_SERVER_AUTHORIZATION_REQUIRED",
                );
            }

            
            if (!featureAccess.allowed) {
                const blockedStatus =
                    featureAccess.decision === "APPROVAL_REQUIRED"
                        ? "WAITING_APPROVAL"
                        : featureAccess.decision === "NOT_YET_CONNECTED"
                            ? "NOT_YET_CONNECTED"
                            : "BLOCKED";

                addStage({
                    stage: "EXECUTION",
                    status: blockedStatus,
                    summary:
                        featureAccess.reason,
                    referenceId:
                        runningTask.id,
                });

                return {
                    requestId: request.id,
                    status: blockedStatus,
                    currentStage: "EXECUTION",
                    trace: {
                        requestId: request.id,
                        stages,
                        currentStage: "EXECUTION",
                        status: blockedStatus,
                        startedAt,
                        completedAt:
                            new Date().toISOString(),
                    },
                    planId: plan.id,
                    missionId:
                        currentMissionSnapshot.mission.id,
                    evidenceIds:
                        allEvidenceIds,
                    persisted: true,
                };
            }

            // ----------------------------------------------
            // BUILD EXECUTION REQUEST

            const executionRequest = {
                id:
                    `exec-${request.id}-${runningTask.id}`,
                taskId:
                    runningTask.id,
                missionId:
                    currentMissionSnapshot.mission.id,
                capability:
                    happyExecutionRoute.executionCapability,
                action:
                    runningTask.action,
                input: {
                    command:
                        request.command,
                    taskTitle:
                        runningTask.title,
                    taskDescription:
                        runningTask.description,
                    taskOrder:
                        runningTask.order,
                    changes:
                        runningTask.action === "CREATE" && request.approved === true
                            ? buildWorkspaceFileChanges(executionOutputs, currentMissionSnapshot.mission.id, runningTask.order)
                            : [],
                    moduleCrud:
                        runningTask.moduleCrud,
                    happyModuleRoute: {
                        source:
                            happyExecutionRoute.source,
                        status:
                            happyExecutionRoute.status,
                        moduleId:
                            happyExecutionRoute.moduleId,
                        moduleNumber:
                            happyExecutionRoute.moduleNumber,
                        moduleName:
                            happyExecutionRoute.moduleName,
                        moduleCategory:
                            happyExecutionRoute.moduleCategory,
                        moduleAction:
                            happyExecutionRoute.moduleAction,
                        bindingStatus:
                            happyExecutionRoute.binding?.status,
                        bindingCapability:
                            happyExecutionRoute.binding?.capability,
                        reason:
                            happyExecutionRoute.reason,
                    },
                },
                targetReference:
                    runningTask.targetReference ??
                    persistedProjectTarget,
                requiresApproval:
                    runningTask.requiresApproval,
                approved:
                    request.approved === true,
                risk:
                    runningTask.requiresApproval
                        ? "HIGH" as const
                        : "LOW" as const,
                createdAt:
                    new Date().toISOString(),
            };

            await state.execution().create(
                executionRequest.id,
                executionRequest,
                request.userId,
            );

            lastExecutionRequestId =
                executionRequest.id;

            // ----------------------------------------------
            // EXECUTION
            // ----------------------------------------------

            const executionResult =
                await this.execution.execute(
                    executionRequest,
                    runtimeContext,
                );

            executionOutputs.push(
                executionResult.output,
            );

            await state.execution().update(
                executionRequest.id,
                {
                    ...executionRequest,
                    ...executionResult,
                    targetReference:
                        executionRequest.targetReference,
                },
            );

            let executionStageStatus:
                HappyPipelineStageResult["status"];

            if (
                executionResult.status ===
                "NOT_YET_CONNECTED"
            ) {
                executionStageStatus =
                    "NOT_YET_CONNECTED";
            } else if (
                executionResult.status ===
                "WAITING_APPROVAL"
            ) {
                executionStageStatus =
                    "WAITING_APPROVAL";
            } else if (
                executionResult.status ===
                "COMPLETED"
            ) {
                executionStageStatus =
                    "COMPLETED";
            } else if (
                executionResult.status ===
                "BLOCKED"
            ) {
                executionStageStatus =
                    "BLOCKED";
            } else {
                executionStageStatus =
                    "FAILED";
            }

            addStage({
                stage: "EXECUTION",
                status:
                    executionStageStatus,
                summary:
                    executionResult.error
                        ? `Task ${runningTask.order} ${executionResult.status}: ${executionResult.error}`
                        : `Task ${runningTask.order} execution evaluated (${executionResult.status}).`,
                referenceId:
                    executionResult.id,
            });

            // ----------------------------------------------
            // WAITING APPROVAL = HARD STOP
            // ----------------------------------------------

            if (
                executionResult.status ===
                "WAITING_APPROVAL"
            ) {
                terminalStatus =
                    "WAITING_APPROVAL";

                currentMissionSnapshot =
                    this.mission.updateTaskStatus(
                        currentMissionSnapshot,
                        runningTask.id,
                        "PENDING",
                    );

                const pendingTask =
                    currentMissionSnapshot.graph.tasks.find(
                        (task) =>
                            task.id ===
                            runningTask.id,
                    );

                if (pendingTask) {
                    await state.task().update(
                        pendingTask.id,
                        pendingTask,
                    );
                }

                await state.mission().update(
                    currentMissionSnapshot.mission.id,
                    currentMissionSnapshot.mission,
                );

                break;
            }

            // ----------------------------------------------
            // VERIFICATION + EVIDENCE
            // ----------------------------------------------

            const verificationRequest = {
                id:
                    `verification-${request.id}-${runningTask.id}`,
                missionId:
                    currentMissionSnapshot.mission.id,
                taskId:
                    runningTask.id,
                executionRequestId:
                    executionResult.requestId,
                description:
                    `Verify execution of mission task ${runningTask.order}.`,
                criteria: [
    {
        id:
            "execution-status",
        description:
            "Execution must have a connected successful result.",
        expected:
            "COMPLETED",
        required:
            true,
    },
    ...(
        typeof happyExecutionRoute.moduleNumber === "number" &&
        Number.isInteger(
            happyExecutionRoute.moduleNumber,
        ) &&
        typeof happyExecutionRoute.moduleAction === "string"
    )
        ? [
            {
                id:
                    "module-route-match",
                description:
                    "Execution evidence must preserve the resolved HAPPY module route.",
                expected:
                    JSON.stringify({
                        moduleNumber:
                            happyExecutionRoute.moduleNumber,
                        moduleAction:
                            happyExecutionRoute.moduleAction,
                    }),
                required:
                    true,
            },
        ]
        : [],
],
                preferredMethods: [
                    "TEST" as const,
                    "COMMAND" as const,
                    "LOG" as const,
                ],
                requiresEvidence:
                    true,
                createdAt:
                    new Date().toISOString(),
            };

            await state.verification().create(
                verificationRequest.id,
                verificationRequest,
                request.userId,
            );

            lastVerificationRequestId =
                verificationRequest.id;

            const executionEvidence =
                evidenceService.capture({
                    verificationRequestId:
                        verificationRequest.id,
                    executionRequestId:
                        executionResult.requestId,
                    missionId:
                        currentMissionSnapshot.mission.id,
                    taskId:
                        runningTask.id,
                    type:
                        "COMMAND_OUTPUT" as const,
                    source:
                        "EXECUTION" as const,
                    title:
                        `Execution evidence ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â task ${runningTask.order}`,
                    content:
                        JSON.stringify({
                            taskId:
                                runningTask.id,
                            taskOrder:
                                runningTask.order,
                            action:
                                runningTask.action,
                            status:
                                executionResult.status,
                            output:
                                executionResult.output,
                            error:
                                executionResult.error,
                            happyModuleRoute:
                                executionRequest.input
                                    .happyModuleRoute,
                        }),
                    metadata: {
                        capability:
                            executionResult.capability,
                        executionResultId:
                            executionResult.id,
                        taskOrder:
                            runningTask.order,
                        retryCount:
                            runningTask.retryCount,
                    },
                    isPrimary:
                        true,
                });

            await state.evidence().create(
                executionEvidence.id,
                executionEvidence,
                request.userId,
            );

            allEvidenceIds.push(
                executionEvidence.id,
            );

            const verificationResult =
                verificationEngine.verify(
                    verificationRequest,
                    [
                        executionEvidence.id,
                    ],
                );

            await state.verification().update(
                verificationRequest.id,
                verificationResult,
            );

            addStage({
                stage: "VERIFICATION",
                status:
                    verificationResult.status ===
                    "PASSED"
                        ? "COMPLETED"
                        : verificationResult.status ===
                          "PARTIAL"
                            ? "PARTIAL"
                            : "FAILED",
                summary:
                    verificationResult.summary,
                referenceId:
                    verificationResult.id,
            });

            addStage({
                stage: "EVIDENCE",
                status:
                    verificationResult.evidenceIds.length >
                    0
                        ? "COMPLETED"
                        : "BLOCKED",
                summary:
                    verificationResult.evidenceIds.length >
                    0
                        ? `Evidence captured for task ${runningTask.order}.`
                        : `No evidence captured for task ${runningTask.order}.`,
                referenceId:
                    executionEvidence.id,
            });

            // ----------------------------------------------
            // TASK STATE TRANSITION
            // ----------------------------------------------

            let nextTaskStatus:
                import("../mission/types").TaskStatus;

            if (
                executionResult.status ===
                    "COMPLETED" &&
                verificationResult.status ===
                    "PASSED"
            ) {
                nextTaskStatus =
                    "COMPLETED";
            } else if (
                executionResult.status ===
                    "COMPLETED" &&
                verificationResult.status ===
                    "PARTIAL"
            ) {
                nextTaskStatus =
                    "VERIFYING";
            } else if (
                executionResult.status ===
                "BLOCKED"
            ) {
                nextTaskStatus =
                    "BLOCKED";
            } else {
                nextTaskStatus =
                    "FAILED";
            }

            currentMissionSnapshot =
                this.mission.updateTaskStatus(
                    currentMissionSnapshot,
                    runningTask.id,
                    nextTaskStatus,
                );

            const updatedTask =
                currentMissionSnapshot.graph.tasks.find(
                    (task) =>
                        task.id ===
                        runningTask.id,
                );

            if (!updatedTask) {
                throw new Error(
                    "Updated mission task was not found.",
                );
            }

            await state.task().update(
                updatedTask.id,
                updatedTask,
            );

            await state.mission().update(
                currentMissionSnapshot.mission.id,
                currentMissionSnapshot.mission,
            );

            // ----------------------------------------------
            // TERMINAL TASK OUTCOME
            // ----------------------------------------------

            if (
                nextTaskStatus !==
                "COMPLETED"
            ) {
                terminalStatus =
                    executionResult.status ===
                    "NOT_YET_CONNECTED"
                        ? "NOT_YET_CONNECTED"
                        : executionResult.status ===
                          "BLOCKED"
                            ? "BLOCKED"
                            : verificationResult.status ===
                              "PARTIAL"
                                ? "PARTIAL"
                                : "FAILED";

                break;
            }

            terminalStatus =
                "RUNNING";

            // ----------------------------------------------
            // ALL TASKS COMPLETE?
            // Otherwise graph recalculates automatically
            // on the next while-loop iteration.
            // ----------------------------------------------

            const allTasksCompleted =
                currentMissionSnapshot.graph.tasks.every(
                    (task) =>
                        task.status ===
                        "COMPLETED",
                );

            if (allTasksCompleted) {
                terminalStatus =
                    "COMPLETED";
                break;
            }
        }

        // ==================================================
        // FINAL MULTI-TASK STATUS
        // ==================================================

        const allTasksCompleted =
            currentMissionSnapshot.graph.tasks.length > 0 &&
            currentMissionSnapshot.graph.tasks.every(
                (task) =>
                    task.status ===
                    "COMPLETED",
            );

        const hasBlockedTasks =
            currentMissionSnapshot.graph.tasks.some(
                (task) =>
                    task.status ===
                    "BLOCKED",
            );

        const hasFailedTasks =
            currentMissionSnapshot.graph.tasks.some(
                (task) =>
                    task.status ===
                    "FAILED",
            );

        let finalStatus:
            HappyPipelineResult["status"];

        if (allTasksCompleted) {
            finalStatus =
                "COMPLETED";
        } else if (
            terminalStatus ===
            "WAITING_APPROVAL"
        ) {
            finalStatus =
                "WAITING_APPROVAL";
        } else if (
            terminalStatus ===
            "NOT_YET_CONNECTED"
        ) {
            finalStatus =
                "NOT_YET_CONNECTED";
        } else if (
            hasFailedTasks ||
            terminalStatus ===
            "FAILED"
        ) {
            finalStatus =
                "FAILED";
        } else if (
            hasBlockedTasks ||
            terminalStatus ===
            "BLOCKED"
        ) {
            finalStatus =
                "BLOCKED";
        } else {
            finalStatus =
                "PARTIAL";
        }

        const finalStage:
            HappyPipelineResult["currentStage"] =
            finalStatus ===
            "COMPLETED"
                ? "COMPLETE"
                : finalStatus ===
                  "WAITING_APPROVAL"
                    ? "APPROVAL"
                    : finalStatus ===
                      "NOT_YET_CONNECTED"
                        ? "NOT_YET_CONNECTED"
                        : "BLOCKED";

        addStage({
            stage: "PERSIST",
            status: "COMPLETED",
            summary:
                `Multi-task mission state persisted after ${executionCycles} execution cycle(s).`,
        });

        const finalOutput =
            executionOutputs.length === 1
                ? executionOutputs[0]
                : executionOutputs;

        const finalResult:
            HappyPipelineResult = {
            requestId:
                request.id,
            status:
                finalStatus,
            currentStage:
                finalStage,
            trace: {
                requestId:
                    request.id,
                stages,
                currentStage:
                    finalStage,
                status:
                    finalStatus,
                startedAt,
                completedAt:
                    new Date().toISOString(),
            },
            missionId:
                currentMissionSnapshot.mission.id,
            planId:
                plan.id,
            executionRequestId:
                lastExecutionRequestId,
            verificationRequestId:
                lastVerificationRequestId,
            evidenceIds:
                allEvidenceIds,
            output:
                finalOutput,
            persisted:
                true,
        };

        await state.audit().create(
            `audit-final-${request.id}`,
            {
                event:
                    finalStatus ===
                    "COMPLETED"
                        ? "PIPELINE_COMPLETED"
                        : "PIPELINE_TERMINAL_STATE",
                requestId:
                    request.id,
                finalStatus,
                executionCycles,
                missionId:
                    currentMissionSnapshot.mission.id,
                planId:
                    plan.id,
                executionRequestId:
                    lastExecutionRequestId,
                verificationRequestId:
                    lastVerificationRequestId,
                evidenceIds:
                    allEvidenceIds,
                trace:
                    finalResult.trace,
                createdAt:
                    new Date().toISOString(),
            },
            request.userId,
        );

        return finalResult;
    }
}






































