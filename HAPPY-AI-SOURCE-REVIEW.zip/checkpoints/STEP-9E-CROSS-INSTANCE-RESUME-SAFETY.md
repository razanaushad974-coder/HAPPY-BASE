# Step 9E — Cross-Instance Resume Safety

Status: ROOT CAUSE CONFIRMED; IMPLEMENTATION PENDING

## Reproduced failure
Two HappyOrchestrationEngine instances resumed the same approval concurrently.
Both returned COMPLETED with different mission IDs. The shared recorder observed
10 action calls instead of the expected 5.

## Confirmed causes
- resumeInFlight is scoped to an engine instance.
- PersistenceService loads a state snapshot into memory at construction.
- JsonFileStateAdapter.save overwrites the complete JSON snapshot.
- The adapter interface has synchronous load/save only; it has no atomic
  claim, compare-and-swap, transaction, or coordinated refresh operation.
- FILE is available; POSTGRES and SUPABASE remain NOT_YET_CONNECTED.

## Required implementation
1. Add durable idempotency/claim coordination for the composite identity:
   organizationId, workspaceId, requestId, approvalId, planId.
2. Ensure competing engine instances cannot both claim and execute the resume.
3. Coordinate every relevant file-state writer, or use a transactional backend;
   a resume-only lock is insufficient if unrelated writers can overwrite stale
   snapshots.
4. Preserve approval validation, tenant isolation, audit linkage checks, and
   default-deny behavior.
5. Preserve fail-closed recovery: an ambiguous/crashed execution must require
   reconciliation and must not be blindly replayed.
6. Never report cross-process safety until a separate-process concurrency test
   proves it.

## Acceptance tests
- Two engine instances, same approval: one mission ID.
- Exactly five execution/action calls, not ten.
- Retry after completed resume returns the original valid result.
- Crash/unknown outcome fails closed with
  RESUME_RECOVERY_RECONCILIATION_REQUIRED.
- Tenant/request/approval/plan linkage mismatch is rejected.
- Existing persistence, state, scoped repository, memory, and workspace tests
  remain passing.

## Safety
Do not reset or overwrite existing working-tree changes.
Do not enable or claim an unconfigured database connection.
Do not weaken approval gates, tenant isolation, or recovery checks.
