import type {
    ScopedRecord,
} from "../../../core/state/types";

import {
    buildLiveWorkspaceDashboard,
} from "../../../core/workspace/live-dashboard";

function record(
    id: string,
    entityType: ScopedRecord["entityType"],
    data: Record<string, unknown>,
): ScopedRecord {
    return {
        id,
        entityType,
        version: 1,
        createdAt:
            "2026-09-18T00:00:00.000Z",
        updatedAt:
            "2026-09-18T00:01:00.000Z",
        data,
        organizationId: "org-test",
        workspaceId: "workspace-test",
        userId: "user-test",
    };
}

const dashboard =
    buildLiveWorkspaceDashboard(
        {
            organizationId:
                "org-test",
            workspaceId:
                "workspace-test",
            userId:
                "user-test",
        },
        {
            commands: [
                record(
                    "command-1",
                    "COMMAND",
                    {
                        command:
                            "test command",
                        status:
                            "COMPLETED",
                    },
                ),
            ],
            missions: [
                record(
                    "mission-1",
                    "MISSION",
                    {
                        goal:
                            "Build live workspace",
                        status:
                            "RUNNING",
                        progressPercent:
                            50,
                    },
                ),
            ],
            tasks: [
                record(
                    "task-1",
                    "TASK",
                    {
                        missionId:
                            "mission-1",
                        title:
                            "Test task",
                        status:
                            "COMPLETED",
                        order: 1,
                    },
                ),
                record(
                    "task-2",
                    "TASK",
                    {
                        missionId:
                            "mission-1",
                        title:
                            "Second task",
                        status:
                            "READY",
                        order: 2,
                    },
                ),
            ],
            executions: [
                record(
                    "execution-1",
                    "EXECUTION",
                    {
                        status:
                            "COMPLETED",
                    },
                ),
            ],
            verifications: [
                record(
                    "verification-1",
                    "VERIFICATION",
                    {
                        missionId:
                            "mission-1",
                        status:
                            "PASSED",
                        confidence:
                            "HIGH",
                        evidenceIds: [
                            "evidence-1",
                        ],
                    },
                ),
            ],
            evidence: [
                record(
                    "evidence-1",
                    "EVIDENCE",
                    {
                        status:
                            "VERIFIED",
                    },
                ),
            ],
            memories: [
                record(
                    "memory-1",
                    "MEMORY",
                    {
                        scope:
                            "USER",
                    },
                ),
            ],
            approvals: [],
            auditEvents: [
                record(
                    "audit-1",
                    "AUDIT_EVENT",
                    {
                        eventType:
                            "SYSTEM_CHECK",
                        status:
                            "COMPLETED",
                    },
                ),
            ],
        },
    );

if (
    dashboard.metrics.commandCount !== 1
) {
    throw new Error(
        "COMMAND_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.missionCount !== 1
) {
    throw new Error(
        "MISSION_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.activeMissionCount !== 1
) {
    throw new Error(
        "ACTIVE_MISSION_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.taskCount !== 2
) {
    throw new Error(
        "TASK_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.completedTaskCount !== 1
) {
    throw new Error(
        "COMPLETED_TASK_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.readyTaskCount !== 1
) {
    throw new Error(
        "READY_TASK_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.executionCount !== 1
) {
    throw new Error(
        "EXECUTION_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.verificationCount !== 1
) {
    throw new Error(
        "VERIFICATION_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.passedVerificationCount !== 1
) {
    throw new Error(
        "PASSED_VERIFICATION_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.evidenceCount !== 1
) {
    throw new Error(
        "EVIDENCE_COUNT_FAILED",
    );
}

if (
    dashboard.metrics.memoryCount !== 1
) {
    throw new Error(
        "MEMORY_COUNT_FAILED",
    );
}

if (
    dashboard.currentMission?.missionId !==
    "mission-1"
) {
    throw new Error(
        "CURRENT_MISSION_FAILED",
    );
}

if (
    dashboard.readyTasks.length !== 1 ||
    dashboard.readyTasks[0].taskId !==
        "task-2"
) {
    throw new Error(
        "READY_TASKS_FAILED",
    );
}

if (
    dashboard.verifications.length !== 1 ||
    dashboard.verifications[0]
        .evidenceCount !== 1
) {
    throw new Error(
        "VERIFICATION_SUMMARY_FAILED",
    );
}

console.log(
    "RESULT: PASS",
);

console.log(
    "metrics:",
    dashboard.metrics,
);

console.log(
    "currentMission:",
    dashboard.currentMission,
);
