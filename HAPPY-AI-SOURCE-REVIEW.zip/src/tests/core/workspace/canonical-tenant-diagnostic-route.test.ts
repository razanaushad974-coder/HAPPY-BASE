import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
    getAuthenticatedExecutionRuntimeContext: vi.fn(),
    resolveTrustedFounderIdentity: vi.fn(),
    resolveCanonicalSupabaseTenant: vi.fn(),
}));

vi.mock("@/core/auth/supabase-runtime-context", () => ({
    getAuthenticatedExecutionRuntimeContext:
        mocks.getAuthenticatedExecutionRuntimeContext,
}));

vi.mock("@/core/founder/identity", () => ({
    resolveTrustedFounderIdentity:
        mocks.resolveTrustedFounderIdentity,
}));

vi.mock("@/core/workspace/supabase-tenant-resolver", () => ({
    resolveCanonicalSupabaseTenant:
        mocks.resolveCanonicalSupabaseTenant,
}));

import { GET } from "@/app/api/system/canonical-tenant-diagnostic/route";

describe("GET /api/system/canonical-tenant-diagnostic", () => {
    beforeEach(() => {
        vi.resetAllMocks();

        mocks.getAuthenticatedExecutionRuntimeContext.mockResolvedValue({
            authenticatedUserId: "founder-user",
            supabaseAccessToken: "test-access-token",
        });

        mocks.resolveTrustedFounderIdentity.mockReturnValue({
            status: "ALLOW",
            identity: {
                userId: "founder-user",
                role: "FOUNDER",
                roleSource: "TRUSTED_SERVER",
                configuredFounderUserId: "founder-user",
            },
            access: {
                userId: "founder-user",
                role: "FOUNDER",
                roleSource: "TRUSTED_SERVER",
                authenticated: true,
                configuredFounderUserId: "founder-user",
                action: "CONTROL_HAPPY",
            },
        });

        mocks.resolveCanonicalSupabaseTenant.mockResolvedValue({
            organizationId: "org-id",
            organizationName: "Test Organization",
            organizationSlug: "test-org",
            workspaceId: "workspace-id",
            workspaceName: "Test Workspace",
            workspaceSlug: "test-workspace",
            userId: "founder-user",
        });
    });

    it("returns 401 without an authenticated user", async () => {
        mocks.getAuthenticatedExecutionRuntimeContext.mockResolvedValue({});

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(401);
        expect(body.status).toBe("UNAUTHENTICATED");
        expect(mocks.resolveTrustedFounderIdentity).not.toHaveBeenCalled();
        expect(mocks.resolveCanonicalSupabaseTenant).not.toHaveBeenCalled();
    });

    it("does not resolve tenant details when Founder authorization fails", async () => {
        mocks.resolveTrustedFounderIdentity.mockReturnValue({
            status: "NOT_YET_CONNECTED",
            reason: "Founder registry is not configured.",
        });

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(503);
        expect(body.verified).toBe(false);
        expect(body).not.toHaveProperty("organizationId");
        expect(body).not.toHaveProperty("workspaceId");
        expect(mocks.resolveCanonicalSupabaseTenant).not.toHaveBeenCalled();
    });

    it("fails closed when the access token is missing", async () => {
        mocks.getAuthenticatedExecutionRuntimeContext.mockResolvedValue({
            authenticatedUserId: "founder-user",
        });

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(503);
        expect(body.status).toBe("NOT_YET_CONNECTED");
        expect(mocks.resolveCanonicalSupabaseTenant).not.toHaveBeenCalled();
    });

    it("resolves tenant without provisioning after Founder authorization", async () => {
        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body.status).toBe("LIVE_CANONICAL_TENANT_RESOLVED");
        expect(body.verified).toBe(true);
        expect(mocks.resolveTrustedFounderIdentity).toHaveBeenCalledWith("founder-user");
        expect(mocks.resolveCanonicalSupabaseTenant).toHaveBeenCalledWith(
            "test-access-token",
            { allowProvisioning: false },
        );
    });

    it("returns a safe error when the canonical tenant is not provisioned", async () => {
        mocks.resolveCanonicalSupabaseTenant.mockRejectedValue(
            new Error("CANONICAL_TENANT_NOT_PROVISIONED"),
        );

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(500);
        expect(body.error).toBe("Canonical tenant is not provisioned.");
        expect(body).not.toHaveProperty("organizationId");
    });

    it("sanitizes unexpected resolver errors", async () => {
        mocks.resolveCanonicalSupabaseTenant.mockRejectedValue(
            new Error("sensitive database detail"),
        );

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(500);
        expect(body.error).toBe("Canonical tenant resolution failed.");
        expect(JSON.stringify(body)).not.toContain("sensitive database detail");
    });
});
