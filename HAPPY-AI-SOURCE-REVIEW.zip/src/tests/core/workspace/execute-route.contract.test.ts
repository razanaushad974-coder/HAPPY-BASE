import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getRuntimeContext: vi.fn(),
  createWorkspace: vi.fn(),
  createServerClient: vi.fn(),
  run: vi.fn(),
  persistSnapshot: vi.fn(),
  resolveFounder: vi.fn(),
}));

vi.mock("../../../core/auth/supabase-runtime-context", () => ({
  getAuthenticatedExecutionRuntimeContext: mocks.getRuntimeContext,
}));

vi.mock("../../../core/workspace/file-backed-state", () => ({
  createAuthenticatedWorkspaceState: mocks.createWorkspace,
}));

vi.mock("../../../lib/supabase/server", () => ({
  createSupabaseServerClient: mocks.createServerClient,
}));

vi.mock("../../../core/orchestration/engine", () => ({
  HappyOrchestrationEngine: class {
    run(...args: unknown[]) {
      return mocks.run(...args);
    }
  },
}));

vi.mock("../../../core/integration/runtime-persistence", () => ({
  persistAuthenticatedRuntimeSnapshot: mocks.persistSnapshot,
}));

vi.mock("../../../core/founder/identity", () => ({
  resolveTrustedFounderIdentity: mocks.resolveFounder,
}));

import { POST } from "../../../app/api/execute/route";

const tenant = {
  organizationId: "server-org",
  workspaceId: "server-workspace",
  userId: "authenticated-user",
};

function request(body: unknown) {
  return new Request("http://localhost/api/execute", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });
}

async function bodyOf(response: Response): Promise<Record<string, unknown>> {
  return response.json() as Promise<Record<string, unknown>>;
}

const validBody = {
  command: "test HAPPY command",
  source: "TEXT",
};

beforeEach(() => {
  vi.clearAllMocks();

  mocks.getRuntimeContext.mockResolvedValue({
    authenticatedUserId: tenant.userId,
    supabaseAccessToken: "mock-access-token",
  });

  mocks.createWorkspace.mockReturnValue({
    tenant,
    persistence: {},
    store: {},
  });

  mocks.createServerClient.mockResolvedValue({});

  mocks.run.mockResolvedValue({
    status: "COMPLETED",
    requestId: "mock-request",
  });

  mocks.persistSnapshot.mockResolvedValue({
    status: "PERSISTED",
    scopeKey: "server-org|server-workspace|authenticated-user",
    version: 2,
  });

  mocks.resolveFounder.mockReturnValue({
    status: "DENY",
  });
});

describe("/api/execute POST contract", () => {
  it("returns 401 without authentication and does not create workspace state", async () => {
    mocks.getRuntimeContext.mockResolvedValue({
      authenticatedUserId: undefined,
      supabaseAccessToken: undefined,
    });

    const response = await POST(request(validBody));

    expect(response.status).toBe(401);
    expect(await bodyOf(response)).toMatchObject({
      status: "UNAUTHENTICATED",
    });
    expect(mocks.createWorkspace).not.toHaveBeenCalled();
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("returns 400 for invalid JSON", async () => {
    const response = await POST(request("{ invalid json"));

    expect(response.status).toBe(400);
    expect(mocks.createWorkspace).not.toHaveBeenCalled();
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("returns 400 for an invalid source without executing", async () => {
    const response = await POST(request({
      command: "test command",
      source: "UNTRUSTED_SOURCE",
    }));

    expect(response.status).toBe(400);
    expect(mocks.createWorkspace).not.toHaveBeenCalled();
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("fails closed when the authenticated user has no provisioned tenant", async () => {
    mocks.createWorkspace.mockImplementation(() => {
      throw new Error("WORKSPACE_TENANT_NOT_FOUND");
    });

    const response = await POST(request(validBody));

    expect(response.status).toBe(404);
    expect(await bodyOf(response)).toMatchObject({
      status: "WORKSPACE_NOT_INITIALIZED",
    });
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("returns 409 when the user's workspace tenant is ambiguous", async () => {
    mocks.createWorkspace.mockImplementation(() => {
      throw new Error("AMBIGUOUS_WORKSPACE_TENANT");
    });

    const response = await POST(request(validBody));

    expect(response.status).toBe(409);
    expect(await bodyOf(response)).toMatchObject({
      status: "AMBIGUOUS_WORKSPACE_TENANT",
    });
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("returns 503 when the Supabase server client is not configured", async () => {
    mocks.createWorkspace.mockImplementation(() => {
      throw new Error("Supabase server client is not configured.");
    });

    const response = await POST(request(validBody));

    expect(response.status).toBe(503);
    expect(await bodyOf(response)).toMatchObject({
      status: "NOT_YET_CONNECTED",
    });
    expect(mocks.run).not.toHaveBeenCalled();
  });

  it("uses server-derived tenant IDs rather than client-supplied tenant IDs", async () => {
    const response = await POST(request({
      ...validBody,
      organizationId: "attacker-org",
      workspaceId: "attacker-workspace",
      userId: "attacker-user",
    }));

    const result = await bodyOf(response);

    expect(response.status).toBe(200);
    expect(mocks.run).toHaveBeenCalledTimes(1);

    const [pipelineRequest, runtimeContext] =
      mocks.run.mock.calls[0] as [Record<string, unknown>, Record<string, unknown>];

    expect(pipelineRequest).toMatchObject({
      organizationId: tenant.organizationId,
      workspaceId: tenant.workspaceId,
      userId: tenant.userId,
      source: "TEXT",
      approved: false,
      authorization: {
        roleSource: "TRUSTED_SERVER",
        authenticated: true,
      },
    });

    expect(runtimeContext).toMatchObject({
      authenticatedUserId: tenant.userId,
      organizationId: tenant.organizationId,
      workspaceId: tenant.workspaceId,
    });

    expect(pipelineRequest.organizationId).not.toBe("attacker-org");
    expect(pipelineRequest.workspaceId).not.toBe("attacker-workspace");
    expect(pipelineRequest.userId).not.toBe("attacker-user");

    expect(result.runtimePersistence).toMatchObject({
      status: "PERSISTED",
      scopeKey: "server-org|server-workspace|authenticated-user",
      version: 2,
    });
  });

  it("reports snapshot persistence failure without misreporting it as persisted", async () => {
    mocks.persistSnapshot.mockRejectedValue(
      new Error("INJECTED_SNAPSHOT_FAILURE"),
    );

    const response = await POST(request(validBody));
    const result = await bodyOf(response);

    expect(response.status).toBe(200);
    expect(result.runtimePersistence).toMatchObject({
      status: "ERROR",
      error: "INJECTED_SNAPSHOT_FAILURE",
    });
    expect(mocks.run).toHaveBeenCalledTimes(1);
  });
});

