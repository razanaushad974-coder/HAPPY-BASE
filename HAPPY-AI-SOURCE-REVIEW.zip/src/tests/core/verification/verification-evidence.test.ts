import { InMemoryEvidenceRepository } from "../../../core/evidence/repository";
import { EvidenceService } from "../../../core/evidence/service";
import { VerificationEngine } from "../../../core/verification/engine";
import { VerificationOrchestrator } from "../../../core/verification/orchestrator";
import type { VerificationRequest } from "../../../core/verification/types";

async function main(): Promise<void> {
  const repository = new InMemoryEvidenceRepository();
  const evidenceService = new EvidenceService(repository);
  const engine = new VerificationEngine(evidenceService);
  const orchestrator = new VerificationOrchestrator(engine);

  const request: VerificationRequest = {
    id: "verification-1",
    missionId: "mission-1",
    taskId: "task-1",
    executionRequestId: "execution-1",
    description: "Verify generated application result.",
    criteria: [
      {
        id: "criterion-1",
        description: "Expected application output exists.",
        expected: "Application output exists.",
        required: true,
      },
      {
        id: "criterion-2",
        description: "Verification evidence is attached.",
        expected: "At least one evidence item exists.",
        required: true,
      },
    ],
    preferredMethods: ["TEST", "FILE", "SCREENSHOT"],
    requiresEvidence: true,
    createdAt: new Date().toISOString(),
  };

  const missingEvidence = orchestrator.verify(request, []);

  if (missingEvidence.status !== "FAILED") {
    throw new Error("Missing evidence was not rejected.");
  }

  if (missingEvidence.failureReason !== "REQUIRED_EVIDENCE_MISSING") {
    throw new Error("Missing-evidence failure reason is incorrect.");
  }

  const evidence = evidenceService.capture({
    verificationRequestId: request.id,
    executionRequestId: request.executionRequestId,
    missionId: request.missionId,
    taskId: request.taskId,
    type: "TEST_RESULT",
    source: "TEST",
    title: "Foundation verification test result",
    content: "Synthetic evidence captured by the Step 17 foundation test.",
    metadata: {
      synthetic: true,
      realWorldClaim: false,
    },
    isPrimary: true,
  });

  const result = orchestrator.verify(request, [evidence.id]);

  if (result.status !== "PARTIAL") {
    throw new Error("Unconnected semantic verification was not marked PARTIAL.");
  }

  if (result.confidence !== "LOW") {
    throw new Error("Unconnected semantic verification confidence is incorrect.");
  }

  if (!result.evidenceIds.includes(evidence.id)) {
    throw new Error("Evidence was not linked to verification result.");
  }

  if (result.failureReason !== "SEMANTIC_VERIFIER_NOT_CONNECTED") {
    throw new Error("Semantic-verifier NOT_YET_CONNECTED state is incorrect.");
  }

  const semanticRequest: VerificationRequest = {
    ...request,
    id: "verification-changed-files",
    criteria: [
      {
        id: "execution-status",
        description: "Execution must complete successfully.",
        expected: "COMPLETED",
        required: true,
      },
      {
        id: "changed-files-contains",
        description: "Expected workspace file must be changed.",
        expected: "src/tests/semantic-proof.txt",
        required: true,
      },
    ],
  };

  const semanticEvidence = evidenceService.capture({
    verificationRequestId: semanticRequest.id,
    executionRequestId: semanticRequest.executionRequestId,
    missionId: semanticRequest.missionId,
    taskId: semanticRequest.taskId,
    type: "COMMAND_OUTPUT",
    source: "EXECUTION",
    title: "Deterministic semantic execution evidence",
    content: JSON.stringify({
      status: "COMPLETED",
      output: {
        mode: "SAFE_CODE_EXECUTION",
        changedFiles: [
          "src/tests/semantic-proof.txt",
        ],
      },
    }),
    metadata: {
      synthetic: true,
      realWorldClaim: false,
    },
    isPrimary: true,
  });

  const semanticResult = orchestrator.verify(
    semanticRequest,
    [semanticEvidence.id],
  );

  if (semanticResult.status !== "PASSED") {
    throw new Error(
      "Deterministic changed-files semantic verification did not pass.",
    );
  }

  if (
    !semanticResult.passedCriteria.includes(
      "changed-files-contains",
    )
  ) {
    throw new Error(
      "changed-files-contains criterion was not marked passed.",
    );
  }

  const negativeSemanticRequest: VerificationRequest = {
    ...semanticRequest,
    id: "verification-changed-files-negative",
    criteria: [
      {
        id: "changed-files-contains",
        description:
          "Missing workspace file must not be treated as changed.",
        expected: "src/tests/not-present.txt",
        required: true,
      },
    ],
  };

  const negativeSemanticResult = orchestrator.verify(
    negativeSemanticRequest,
    [semanticEvidence.id],
  );

  if (negativeSemanticResult.status !== "FAILED") {
    throw new Error(
      "Negative changed-files semantic verification did not fail.",
    );
  }

  if (
    negativeSemanticResult.failureReason !==
    "SEMANTIC_CRITERION_MISMATCH"
  ) {
    throw new Error(
      "Negative semantic criterion failure reason is incorrect.",
    );
  }
  const invalidRequest: VerificationRequest = {
    ...request,
    id: "verification-no-criteria",
    criteria: [],
  };

  const blocked = orchestrator.verify(invalidRequest, [evidence.id]);

  if (blocked.status !== "BLOCKED") {
    throw new Error("Empty verification criteria were not blocked.");
  }

  if (repository.count() !== 2) {
    throw new Error("Unexpected evidence repository count.");
  }

  console.log("Verification + Evidence test: PASS");
  console.log({
    verificationStatus: result.status,
    missingEvidenceRejected: missingEvidence.status === "FAILED",
    evidenceCaptured: repository.count(),
    evidenceLinked: result.evidenceIds.length,
    semanticVerifierNotConnected:
      result.failureReason === "SEMANTIC_VERIFIER_NOT_CONNECTED",
    emptyCriteriaBlocked: blocked.status === "BLOCKED",
    fakePassPrevented: result.status === "PARTIAL",
  });
}

main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});

