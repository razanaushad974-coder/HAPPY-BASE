import { InMemoryEvidenceRepository } from "../../../core/evidence/repository";
import { EvidenceService } from "../../../core/evidence/service";
import { VerificationEngine } from "../../../core/verification/engine";
import { VerificationOrchestrator } from "../../../core/verification/orchestrator";
import type { VerificationRequest } from "../../../core/verification/types";

async function main(): Promise<void> {
  const repository = new InMemoryEvidenceRepository();
  const evidenceService = new EvidenceService(repository);
  const engine = new VerificationEngine(evidenceService);
  const orchestrator = new VerificationOrchestrator(engine);

  const expectedRoute = {
    moduleNumber: 322,
    moduleAction: "GENERATE",
  };

  const request: VerificationRequest = {
    id: "verification-module-route",
    missionId: "mission-module-route",
    taskId: "task-module-route",
    executionRequestId: "execution-module-route",
    description: "Verify canonical HAPPY module routing survived execution.",
    criteria: [
      {
        id: "execution-status",
        description: "Execution must complete successfully.",
        expected: "COMPLETED",
        required: true,
      },
      {
        id: "module-route-match",
        description:
          "Execution evidence must preserve the resolved HAPPY module route.",
        expected: JSON.stringify(expectedRoute),
        required: true,
      },
    ],
    preferredMethods: ["TEST", "LOG"],
    requiresEvidence: true,
    createdAt: new Date().toISOString(),
  };

  const evidence = evidenceService.capture({
    verificationRequestId: request.id,
    executionRequestId: request.executionRequestId,
    missionId: request.missionId,
    taskId: request.taskId,
    type: "COMMAND_OUTPUT",
    source: "EXECUTION",
    title: "Canonical HAPPY module route evidence",
    content: JSON.stringify({
      taskId: request.taskId,
      taskOrder: 1,
      action: "GENERATE",
      status: "COMPLETED",
      output: {
        mode: "SAFE_CODE_EXECUTION",
        changedFiles: ["src/test-output.ts"],
      },
      happyModuleRoute: {
        source: "ROUTER",
        status: "RESOLVED",
        moduleId: "m322-ai-website-generator",
        moduleNumber: 322,
        moduleName: "AI Website Generator",
        moduleCategory: "AI WEBSITE BUILDER",
        moduleAction: "GENERATE",
        bindingStatus: "AVAILABLE",
        bindingCapability: "CODE",
      },
    }),
    metadata: {
      synthetic: true,
      realWorldClaim: false,
    },
    isPrimary: true,
  });

  const passed = orchestrator.verify(
    request,
    [evidence.id],
  );

  if (passed.status !== "PASSED") {
    throw new Error(
      "module-route-match positive verification did not pass.",
    );
  }

  if (!passed.passedCriteria.includes("module-route-match")) {
    throw new Error(
      "module-route-match was not marked as passed.",
    );
  }

  const negativeRequest: VerificationRequest = {
    ...request,
    id: "verification-module-route-negative",
    criteria: [
      {
        id: "execution-status",
        description: "Execution must complete successfully.",
        expected: "COMPLETED",
        required: true,
      },
      {
        id: "module-route-match",
        description:
          "Incorrect module route must not pass verification.",
        expected: JSON.stringify({
          moduleNumber: 345,
          moduleAction: "BUILD",
        }),
        required: true,
      },
    ],
  };

  const failed = orchestrator.verify(
    negativeRequest,
    [evidence.id],
  );

  if (failed.status !== "FAILED") {
    throw new Error(
      "module-route-match negative verification did not fail.",
    );
  }

  if (failed.failureReason !== "SEMANTIC_CRITERION_MISMATCH") {
    throw new Error(
      "Incorrect semantic-route failure reason.",
    );
  }

  console.log(
    "Module-route semantic verification test: PASS",
  );
  console.log({
    positivePassed:
      passed.status === "PASSED" &&
      passed.passedCriteria.includes(
        "module-route-match",
      ),
    negativeRejected:
      failed.status === "FAILED" &&
      failed.failureReason ===
        "SEMANTIC_CRITERION_MISMATCH",
    observedModuleNumber:
      expectedRoute.moduleNumber,
    observedModuleAction:
      expectedRoute.moduleAction,
  });
}

main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});