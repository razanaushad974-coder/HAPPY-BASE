import { InMemoryEvidenceRepository } from "../../../core/evidence/repository";
import { EvidenceService } from "../../../core/evidence/service";
import { VerificationEngine } from "../../../core/verification/engine";
import type { VerificationRequest } from "../../../core/verification/types";

function createRequest(id: string): VerificationRequest {
  return {
    id,
    missionId: "mission-verification-test",
    taskId: "task-verification-test",
    executionRequestId: "execution-verification-test",
    description: "Verify deterministic execution status.",
    criteria: [
      {
        id: "execution-status",
        description: "Execution must have a connected successful result.",
        expected: "COMPLETED",
        required: true,
      },
    ],
    preferredMethods: ["COMMAND"],
    requiresEvidence: true,
    createdAt: new Date().toISOString(),
  };
}

const repository = new InMemoryEvidenceRepository();
const evidenceService = new EvidenceService(repository);
const engine = new VerificationEngine(evidenceService);

const completedRequest = createRequest("verification-execution-completed");

const completedEvidence = evidenceService.capture({
  verificationRequestId: completedRequest.id,
  executionRequestId: completedRequest.executionRequestId,
  missionId: completedRequest.missionId,
  taskId: completedRequest.taskId,
  type: "COMMAND_OUTPUT",
  source: "EXECUTION",
  title: "Completed execution evidence",
  content: JSON.stringify({
    status: "COMPLETED",
    output: "Execution completed successfully.",
  }),
  metadata: {},
  isPrimary: true,
});

const completedResult = engine.verify(
  completedRequest,
  [completedEvidence.id],
);

if (completedResult.status !== "PASSED") {
  throw new Error(
    `Expected COMPLETED evidence to verify as PASSED, got ${completedResult.status}.`,
  );
}

if (completedResult.confidence !== "HIGH") {
  throw new Error(
    `Expected completed execution verification confidence HIGH, got ${completedResult.confidence}.`,
  );
}

if (!completedResult.passedCriteria.includes("execution-status")) {
  throw new Error("execution-status criterion was not marked as passed.");
}

const failedRequest = createRequest("verification-execution-failed");

const failedEvidence = evidenceService.capture({
  verificationRequestId: failedRequest.id,
  executionRequestId: failedRequest.executionRequestId,
  missionId: failedRequest.missionId,
  taskId: failedRequest.taskId,
  type: "COMMAND_OUTPUT",
  source: "EXECUTION",
  title: "Failed execution evidence",
  content: JSON.stringify({
    status: "FAILED",
    error: "Execution failed.",
  }),
  metadata: {},
  isPrimary: true,
});

const failedResult = engine.verify(
  failedRequest,
  [failedEvidence.id],
);

if (failedResult.status !== "FAILED") {
  throw new Error(
    `Expected FAILED execution evidence to verify as FAILED, got ${failedResult.status}.`,
  );
}

if (!failedResult.failedCriteria.includes("execution-status")) {
  throw new Error("execution-status criterion was not marked as failed.");
}

if (failedResult.failureReason !== "EXECUTION_STATUS_MISMATCH") {
  throw new Error(
    `Expected EXECUTION_STATUS_MISMATCH, got ${failedResult.failureReason}.`,
  );
}

console.log("Execution-status verification test: PASS");
console.log({
  completedStatus: completedResult.status,
  completedConfidence: completedResult.confidence,
  failedStatus: failedResult.status,
  failedReason: failedResult.failureReason,
});
