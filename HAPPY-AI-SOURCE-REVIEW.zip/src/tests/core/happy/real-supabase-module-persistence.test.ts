import { describe, it } from "vitest";
import type { SupabaseClient } from "@supabase/supabase-js";
import {
  RealSupabaseModulePersistenceAdapter,
} from "../../../core/modules/data/real-supabase-module-persistence";
import { happyModuleRegistry } from "../../../core/happy/kernel/registry/happy-module-runtime";

const assert: (
  condition: unknown,
  message: string,
) => asserts condition = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

type QueryResult = {
  data: unknown;
  error: null;
  single?: boolean;
};

type FakeQuery = {
  select(columns: string): FakeQuery;
  insert(values: Record<string, unknown>): FakeQuery;
  update(values: Record<string, unknown>): FakeQuery;
  delete(): FakeQuery;
  eq(column: string, value: unknown): FakeQuery;
  order(column: string, options: unknown): FakeQuery;
  single: () => Promise<QueryResult>;
  maybeSingle: () => Promise<QueryResult>;
  then(resolve: (value: QueryResult) => unknown): Promise<unknown>;
};

function createFakeClient(
  calls: Array<Record<string, unknown>>,
  deleteResult: unknown = { id: "customer-001" },
): SupabaseClient {
  const chain = {
    from(resource: string) {
      calls.push({ op: "from", resource });

      const query: FakeQuery = {
        select(columns: string) {
          calls.push({
            op: "select",
            columns,
          });
          return query;
        },

        insert(values: Record<string, unknown>) {
          calls.push({
            op: "insert",
            values,
          });
          return query;
        },

        update(values: Record<string, unknown>) {
          calls.push({
            op: "update",
            values,
          });
          return query;
        },

        delete() {
          calls.push({
            op: "delete",
          });
          return query;
        },

        eq(column: string, value: unknown) {
          calls.push({
            op: "eq",
            column,
            value,
          });
          return query;
        },

        order(column: string, options: unknown) {
          calls.push({
            op: "order",
            column,
            options,
          });
          return query;
        },

        single: async (): Promise<QueryResult> => ({
          data: {
            id: "customer-001",
            organization_id:
              "00000000-0000-0000-0000-000000000001",
            workspace_id:
              "00000000-0000-0000-0000-000000000002",
            user_id: null,
            module_number: 282,
            module_id:
              happyModuleRegistry.get("customer-registration")?.id ??
              "customer-registration",
            module_name:
              happyModuleRegistry.get("customer-registration")?.name ??
              "Customer Registration",
            version: 1,
            data: {
              name: "Customer One",
            },
            created_at:
              "2026-09-25T00:00:00.000Z",
            updated_at:
              "2026-09-25T00:00:00.000Z",
          },
          error: null,
          single: true,
        }),

        maybeSingle: async (): Promise<QueryResult> => ({

          data: calls.some((call) => call.op === "delete")
            ? deleteResult
            : {
            id: "customer-001",
            organization_id:
              "00000000-0000-0000-0000-000000000001",
            workspace_id:
              "00000000-0000-0000-0000-000000000002",
            user_id: null,
            module_number: 282,
            module_id:
              happyModuleRegistry.get("customer-registration")?.id ??
              "customer-registration",
            module_name:
              happyModuleRegistry.get("customer-registration")?.name ??
              "Customer Registration",
            version: 1,
            data: {
              name: "Customer One",
            },
            created_at:
              "2026-09-25T00:00:00.000Z",
            updated_at:
              "2026-09-25T00:00:00.000Z",
          },
          error: null,
        }),

        then(
          resolve: (
            value: QueryResult,
          ) => unknown,
        ) {
          return Promise.resolve({
            data: [],
            error: null,
          }).then(resolve);
        },
      };

      return query;
    },
  };

  return chain as unknown as SupabaseClient;
}

export async function main(): Promise<void> {
  process.env.SUPABASE_URL =
    "https://example.supabase.co";
  process.env.SUPABASE_PUBLISHABLE_KEY =
    "test-publishable-key";

  const calls: Array<Record<string, unknown>> = [];

  const adapter =
    new RealSupabaseModulePersistenceAdapter(
      {
        organizationId:
          "00000000-0000-0000-0000-000000000001",
        workspaceId:
          "00000000-0000-0000-0000-000000000002",
        accessToken:
          "test-access-token",
      },
      (
        url,
        key,
        accessToken,
      ) => {
        assert(
          url === "https://example.supabase.co",
          "Supabase URL not passed correctly",
        );

        assert(
          key === "test-publishable-key",
          "publishable key not passed correctly",
        );

        assert(
          accessToken === "test-access-token",
          "access token not passed correctly",
        );

        return createFakeClient(calls);
      },
    );

  assert(
    adapter.connected === true,
    "configured adapter should be connected",
  );

  const created =
    await adapter.create({
      id: "customer-001",
      tenantId:
        "00000000-0000-0000-0000-000000000002",
      moduleNumber: 282,
      data: {
        name: "Customer One",
      },
      version: 1,
      createdAt:
        "2026-09-25T00:00:00.000Z",
      updatedAt:
        "2026-09-25T00:00:00.000Z",
    });

  assert(
    created.id === "customer-001",
    "created record mapping failed",
  );

  const insertCall =
    calls.find(
      (call) => call.op === "insert",
    );

  assert(
    insertCall !== undefined,
    "Supabase INSERT was not issued",
  );

  const inserted =
    insertCall?.values as Record<string, unknown>;

  const canonical =
    happyModuleRegistry.list().find(
      (module) => module.number === 282,
    );

  assert(
    canonical !== undefined,
    "canonical module 282 missing",
  );

  assert(
    inserted.module_id === canonical?.id,
    "canonical module id was not preserved",
  );

  assert(
    inserted.module_name === canonical?.name,
    "canonical module name was not preserved",
  );

  calls.length = 0;

  const fetched =
    await adapter.get(
      "00000000-0000-0000-0000-000000000002",
      282,
      "customer-001",
    );

  assert(
    fetched?.id === "customer-001",
    "SELECT mapping failed",
  );

  assert(
    calls.some(
      (call) =>
        call.op === "eq" &&
        call.column === "organization_id" &&
        call.value ===
          "00000000-0000-0000-0000-000000000001",
    ),
    "organization scope filter missing",
  );

  assert(
    calls.some(
      (call) =>
        call.op === "eq" &&
        call.column === "workspace_id" &&
        call.value ===
          "00000000-0000-0000-0000-000000000002",
    ),
    "workspace scope filter missing",
  );

  calls.length = 0;

  const updated =
    await adapter.update({
      id: "customer-001",
      tenantId:
        "00000000-0000-0000-0000-000000000002",
      moduleNumber: 282,
      data: {
        name: "Customer Updated",
      },
      version: 2,
      createdAt:
        "2026-09-25T00:00:00.000Z",
      updatedAt:
        "2026-09-25T00:01:00.000Z",
    });

  assert(
    updated.version === 1,
    "fake UPDATE response mapping failed",
  );

  assert(
    calls.some(
      (call) =>
        call.op === "eq" &&
        call.column === "version" &&
        call.value === 1,
    ),
    "optimistic version filter missing",
  );

  calls.length = 0;

  await adapter.delete(
    "00000000-0000-0000-0000-000000000002",
    282,
    "customer-001",
    1,
  );

  assert(
    calls.some((call) => call.op === "delete"),
    "Supabase DELETE was not issued",
  );

  assert(
    calls.some(
      (call) => call.op === "select" && call.columns === "id",
    ),
    "Supabase DELETE must return the affected record id",
  );

  const staleDeleteCalls: Array<Record<string, unknown>> = [];
  const staleDeleteAdapter =
    new RealSupabaseModulePersistenceAdapter(
      {
        organizationId: "00000000-0000-0000-0000-000000000001",
        workspaceId: "00000000-0000-0000-0000-000000000002",
        accessToken: "test-access-token",
      },
      () => createFakeClient(staleDeleteCalls, null),
    );

  let zeroRowDeleteRejected = false;

  try {
    await staleDeleteAdapter.delete(
      "00000000-0000-0000-0000-000000000002",
      282,
      "customer-001",
      1,
    );
  } catch (error) {
    zeroRowDeleteRejected =
      error instanceof Error &&
      error.message.includes("conflict or record not found");
  }

  assert(
    zeroRowDeleteRejected,
    "Supabase DELETE must reject when no expected-version row was deleted",
  );

  console.log(
    "HAPPY COMMAND 28 CANONICAL SUPABASE CONTRACT: PASS",
  );

  console.log({
    canonicalModuleMetadata:
      true,
    authenticatedClient:
      true,
    organizationScope:
      true,
    workspaceScope:
      true,
    optimisticVersionFilter:
      true,
    insertContract:
      true,
    selectContract:
      true,
    updateContract:
      true,
    deleteContract:
      true,
    liveDatabaseConnection:
      false,
  });

  delete process.env.SUPABASE_URL;
  delete process.env.SUPABASE_PUBLISHABLE_KEY;
}

describe("HAPPY Command 32 � Supabase Adapter Contract", () => {
  it("verifies the canonical Supabase module persistence contract", async () => {
    await main();
  });
});
