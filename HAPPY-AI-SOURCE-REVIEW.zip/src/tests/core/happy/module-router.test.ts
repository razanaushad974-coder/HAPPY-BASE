﻿import {
    happyModuleRouter,
} from "../../../core/happy/kernel/runtime/happy-module-router";

import {
    happyModuleRegistry,
} from "../../../core/happy/kernel/registry/happy-module-runtime";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

async function main(): Promise<void> {

    assert(
        happyModuleRegistry.list().length === 502,
        "Runtime registry must contain 502 modules.",
    );

    const byId =
        happyModuleRouter.resolve(
            "m041-founder-dashboard",
        );

    assert(
        byId.status === "RESOLVED",
        "Founder Dashboard ID resolution failed.",
    );

    assert(
        byId.module?.number === 41,
        "Founder Dashboard number mismatch.",
    );

    const byNumber =
        happyModuleRouter.resolve(
            "322",
        );

    assert(
        byNumber.status === "RESOLVED",
        "Module 322 resolution failed.",
    );

    assert(
        byNumber.module?.name ===
            "AI Website Generator",
        "Module 322 name mismatch.",
    );

    const byName =
        happyModuleRouter.resolve(
            "Founder Dashboard",
        );

    assert(
        byName.status === "RESOLVED",
        "Founder Dashboard name resolution failed.",
    );

    const generated =
        happyModuleRouter.resolve(
            "generate AI Website",
        );

    assert(
        generated.module?.number === 322,
        "AI Website Generator keyword resolution failed.",
    );

    assert(
        generated.action === "GENERATE",
        "Generate action inference failed.",
    );

    const dashboard =
        happyModuleRouter.resolve(
            "open Founder Dashboard",
        );

    assert(
        dashboard.action === "OPEN",
        "Open action inference failed.",
    );

    const builder =
        happyModuleRouter.resolve(
            "build mobile application",
        );

    assert(
        builder.module?.category ===
            "AI Mobile App Builder",
        "Mobile builder category resolution failed.",
    );

    assert(
        builder.module?.name ===
            "Cross Platform Builder",
        "Build query should resolve to the substantive builder module.",
    );

    assert(
        builder.action === "BUILD",
        "Build action inference failed.",
    );

    const plugin =
        happyModuleRouter.resolve(
            "Plugin Marketplace",
        );

    assert(
        plugin.module?.number === 500,
        "Plugin Marketplace resolution failed.",
    );

    const systemAdmin =
        happyModuleRouter.resolve(
            "502",
        );

    assert(
        systemAdmin.module?.name ===
            "System Administration",
        "System Administration resolution failed.",
    );

    const unknown =
        happyModuleRouter.resolve(
            "this module does not exist in HAPPY",
        );

    assert(
        unknown.status === "NOT_FOUND",
        "Unknown module must remain NOT_FOUND.",
    );

    const digitalHuman =
        happyModuleRouter.resolve(
            "Digital Human Dashboard",
        );

    assert(
        digitalHuman.status ===
            "RESOLVED",
        "Digital Human Dashboard must resolve from the source catalog.",
    );

    assert(
        digitalHuman.module?.status ===
            "PLANNED",
        "Digital Human Dashboard must retain its source catalog status.",
    );

    console.log(
        "STEP 6 HAPPY UNIVERSAL MODULE ROUTER: PASS",
    );

    console.log({
        runtimeModules:
            happyModuleRegistry.list().length,
        founderById:
            byId.module?.number === 41,
        websiteGeneratorByNumber:
            byNumber.module?.number === 322,
        founderByName:
            byName.module?.name ===
            "Founder Dashboard",
        generateAction:
            generated.action ===
            "GENERATE",
        openAction:
            dashboard.action ===
            "OPEN",
        mobileBuilder:
            builder.module?.category ===
            "AI Mobile App Builder",
        pluginMarketplace:
            plugin.module?.number === 500,
        systemAdministration:
            systemAdmin.module?.number === 502,
        unknownProtected:
            unknown.status ===
            "NOT_FOUND",
        digitalHumanResolved:
            digitalHuman.status ===
            "RESOLVED",
    });
}

main().catch((error) => {
    console.error(error);
    process.exit(1);
});


