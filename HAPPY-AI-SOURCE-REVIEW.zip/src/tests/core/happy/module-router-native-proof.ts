﻿import {
    happyModuleRouter,
} from "../../../core/happy/kernel/runtime/happy-module-router";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

const broad =
    happyModuleRouter.resolve(
        "build mobile application",
    );

console.log(
    JSON.stringify({
        input: "build mobile application",
        moduleNumber:
            broad.module?.number ?? null,
        module:
            broad.module?.name ?? null,
        action: broad.action,
        status: broad.status,
    }),
);

assert(
    broad.status === "RESOLVED",
    "Broad mobile build must resolve.",
);

assert(
    broad.module?.number === 345,
    "Broad mobile build must resolve to module 345.",
);

assert(
    broad.module?.name ===
        "Cross Platform Builder",
    "Broad mobile build must resolve to Cross Platform Builder.",
);

const android =
    happyModuleRouter.resolve(
        "build Android application",
    );

console.log(
    JSON.stringify({
        input: "build Android application",
        moduleNumber:
            android.module?.number ?? null,
        module:
            android.module?.name ?? null,
        action: android.action,
        status: android.status,
    }),
);

assert(
    android.status === "RESOLVED",
    "Android build must resolve.",
);

assert(
    android.module?.number === 343,
    "Explicit Android build must remain platform-specific.",
);

const ios =
    happyModuleRouter.resolve(
        "build iOS application",
    );

console.log(
    JSON.stringify({
        input: "build iOS application",
        moduleNumber:
            ios.module?.number ?? null,
        module:
            ios.module?.name ?? null,
        action: ios.action,
        status: ios.status,
    }),
);

assert(
    ios.status === "RESOLVED",
    "iOS build must resolve.",
);

assert(
    ios.module?.number !== 345,
    "Explicit iOS build must not be forced to Cross Platform Builder.",
);

console.log(
    "STEP 6 NATIVE ROUTING SAFETY PROOF: PASS",
);
