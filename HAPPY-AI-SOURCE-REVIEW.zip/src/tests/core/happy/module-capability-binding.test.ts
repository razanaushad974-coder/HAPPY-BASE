﻿import {
    happyModuleCapabilityBindingRegistry,
} from "../../../core/happy/kernel/registry/happy-module-capability-binding";

import {
    happyModuleRouter,
} from "../../../core/happy/kernel/runtime/happy-module-router";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

function assertEqual(
    actual: unknown,
    expected: unknown,
    message: string,
): void {
    assert(
        actual === expected,
        `${message} Actual=${String(actual)} Expected=${String(expected)}`,
    );
}

async function main(): Promise<void> {
    const catalogModule =
        await import(
            "../../../core/happy/kernel/registry/happy-major-module-catalog"
        );

    const catalogValue =
        Object.values(catalogModule).find(
            (value) =>
                Array.isArray(value) &&
                value.length === 502,
        );

    assert(
        Array.isArray(catalogValue),
        "Could not locate the 502-module catalog export.",
    );

    const catalog =
        catalogValue as unknown as ReadonlyArray<{
            readonly id: string;
            readonly number?: number;
            readonly name: string;
            readonly category?: string;
        }>;

    assertEqual(
        catalog.length,
        502,
        "Catalog must contain exactly 502 modules.",
    );

    const bindings =
        happyModuleCapabilityBindingRegistry.bindMany(
            catalog,
        );

    assertEqual(
        bindings.length,
        502,
        "Every catalog module must produce one binding record.",
    );

    assert(
        bindings.every(
            (binding) =>
                binding.moduleId.length > 0 &&
                binding.moduleName.length > 0 &&
                (
                    binding.status === "AVAILABLE" ||
                    binding.status ===
                        "NOT_YET_CONNECTED" ||
                    binding.status === "BLOCKED"
                ),
        ),
        "Every binding must be structurally valid.",
    );

    const website =
        happyModuleRouter.resolve(
            "generate AI Website",
        );

    assertEqual(
        website.module?.number,
        322,
        "AI Website Generator router resolution failed.",
    );

    const websiteBinding =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    website.module?.id ??
                    "m322-ai-website-generator",
                number:
                    website.module?.number,
                name:
                    website.module?.name ??
                    "AI Website Generator",
                category:
                    website.module?.category,
            },
            website.action,
        );

    console.log(
        JSON.stringify({
            case: "generate AI Website",
            moduleNumber:
                websiteBinding.moduleNumber,
            module:
                websiteBinding.moduleName,
            action:
                websiteBinding.action,
            capability:
                websiteBinding.capability,
            status:
                websiteBinding.status,
        }),
    );

    assertEqual(
        websiteBinding.capability,
        "CODE",
        "AI Website Generator must bind to CODE.",
    );

    const customer =
        happyModuleRouter.resolve(
            "create customer",
        );

    const customerBinding =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    customer.module?.id ??
                    "m282-customer-registration",
                number:
                    customer.module?.number,
                name:
                    customer.module?.name ??
                    "Customer Registration",
                category:
                    customer.module?.category,
            },
            customer.action,
        );

    console.log(
        JSON.stringify({
            case: "create customer",
            moduleNumber:
                customerBinding.moduleNumber,
            module:
                customerBinding.moduleName,
            action:
                customerBinding.action,
            capability:
                customerBinding.capability,
            status:
                customerBinding.status,
        }),
    );

    assertEqual(
        customerBinding.moduleNumber,
        282,
        "Customer router number must remain 282.",
    );

    assertEqual(
        customerBinding.capability,
        "DATABASE",
        "Customer Registration must bind to DATABASE.",
    );

    const mobile =
        happyModuleRouter.resolve(
            "build mobile application",
        );

    const mobileBinding =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    mobile.module?.id ??
                    "m345-cross-platform-builder",
                number:
                    mobile.module?.number,
                name:
                    mobile.module?.name ??
                    "Cross Platform Builder",
                category:
                    mobile.module?.category,
            },
            mobile.action,
        );

    console.log(
        JSON.stringify({
            case: "build mobile application",
            moduleNumber:
                mobileBinding.moduleNumber,
            module:
                mobileBinding.moduleName,
            action:
                mobileBinding.action,
            capability:
                mobileBinding.capability,
            status:
                mobileBinding.status,
        }),
    );

    assertEqual(
        mobileBinding.moduleNumber,
        345,
        "Cross-platform mobile router number must remain 345.",
    );

    assertEqual(
        mobileBinding.capability,
        "CODE",
        "Cross Platform Builder must bind to CODE.",
    );

    const deploy =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    "test-deployment-boundary",
                number: 999,
                name:
                    "Deployment Test Boundary",
                category:
                    "Cloud & Developer Platform",
            },
            "DEPLOY",
        );

    console.log(
        JSON.stringify({
            case: "DEPLOY boundary",
            capability:
                deploy.capability,
            status:
                deploy.status,
        }),
    );

    assertEqual(
        deploy.capability,
        "DEPLOYMENT",
        "DEPLOY must bind to DEPLOYMENT.",
    );

    assertEqual(
        deploy.status,
        "NOT_YET_CONNECTED",
        "Deployment must remain NOT_YET_CONNECTED.",
    );

    const shell =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    "test-shell-boundary",
                number: 1000,
                name:
                    "Shell Execution",
                category:
                    "Developer Platform",
            },
            "EXECUTE",
        );

    console.log(
        JSON.stringify({
            case: "SHELL safety boundary",
            capability:
                shell.capability,
            status:
                shell.status,
        }),
    );

    assertEqual(
        shell.capability,
        "SHELL",
        "Shell boundary must resolve to SHELL capability.",
    );

    assertEqual(
        shell.status,
        "BLOCKED",
        "Shell execution must remain BLOCKED.",
    );

    const statusCounts = bindings.reduce(
        (
            result,
            binding,
        ) => {
            result[binding.status] += 1;
            return result;
        },
        {
            AVAILABLE: 0,
            NOT_YET_CONNECTED: 0,
            BLOCKED: 0,
        } as Record<string, number>,
    );

    console.log(
        JSON.stringify({
            catalogModules:
                catalog.length,
            bindingRecords:
                bindings.length,
            statusCounts,
        }),
    );

    console.log(
        "STEP 7 HAPPY MODULE -> CAPABILITY BINDING: PASS",
    );
}

main().catch(
    (error: unknown) => {
        console.error(error);
        process.exit(1);
    },
);

