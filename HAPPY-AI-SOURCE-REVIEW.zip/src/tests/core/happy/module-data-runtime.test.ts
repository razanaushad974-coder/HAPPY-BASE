import { ModuleDataStore } from "../../../core/modules/data/module-data-store";

const assert: (condition: unknown, message: string) => asserts condition = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

const store = new ModuleDataStore();

const created = store.create({
  id: "customer-001",
  tenantId: "tenant-a",
  moduleNumber: 282,
  data: {
    name: "Test Customer",
    status: "ACTIVE",
  },
});

assert(created.version === 1, "create version must be 1");
assert(created.tenantId === "tenant-a", "tenant isolation metadata missing");
assert(created.moduleNumber === 282, "module number missing");

const fetched = store.get("tenant-a", 282, "customer-001");
assert(fetched?.data.name === "Test Customer", "get failed");

const listed = store.list("tenant-a", 282);
assert(listed.length === 1, "list failed");

const updated = store.update({
  id: "customer-001",
  tenantId: "tenant-a",
  moduleNumber: 282,
  expectedVersion: 1,
  data: {
    name: "Updated Customer",
    status: "ACTIVE",
  },
});

assert(updated.version === 2, "update version did not increment");
assert(updated.data.name === "Updated Customer", "update data failed");

let staleVersionBlocked = false;
try {
  store.update({
    id: "customer-001",
    tenantId: "tenant-a",
    moduleNumber: 282,
    expectedVersion: 1,
    data: {
      name: "Should Not Write",
    },
  });
} catch {
  staleVersionBlocked = true;
}
assert(staleVersionBlocked, "stale version update was not blocked");

const crossTenantRead = store.get("tenant-b", 282, "customer-001");
assert(crossTenantRead === null, "cross-tenant read leaked data");

store.delete("tenant-a", 282, "customer-001", 2);
assert(store.count("tenant-a", 282) === 0, "delete failed");

let invalidModuleBlocked = false;
try {
  store.create({
    id: "invalid",
    tenantId: "tenant-a",
    moduleNumber: 503,
    data: {},
  });
} catch {
  invalidModuleBlocked = true;
}
assert(invalidModuleBlocked, "module 503 was incorrectly accepted");

console.log("HAPPY COMMAND 16 MODULE DATA RUNTIME: PASS");
console.log({
  tenantIsolation: true,
  crud: true,
  optimisticConcurrency: true,
  moduleRange: "1..502",
  crossTenantReadBlocked: true,
  invalidModuleBlocked: true,
});

