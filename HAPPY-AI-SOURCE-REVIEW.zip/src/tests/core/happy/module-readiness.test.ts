import {
  buildHappyModuleReadiness,
} from "../../../core/integration/happy-module-readiness";

const snapshot =
  buildHappyModuleReadiness();

if (snapshot.totalModules !== 502) {
  throw new Error(
    `Expected 502 modules, got ${snapshot.totalModules}.`,
  );
}

if (
  snapshot.catalogIntegrity !==
  "VALID"
) {
  throw new Error(
    "Module catalog integrity is not VALID.",
  );
}

if (
  snapshot.modules.length !== 502
) {
  throw new Error(
    `Expected 502 readiness records, got ${snapshot.modules.length}.`,
  );
}

const numbers =
  new Set(
    snapshot.modules.map(
      (module) => module.number,
    ),
  );

const ids =
  new Set(
    snapshot.modules.map(
      (module) => module.id,
    ),
  );

if (numbers.size !== 502) {
  throw new Error(
    "Module numbers are not unique.",
  );
}

if (ids.size !== 502) {
  throw new Error(
    "Module IDs are not unique.",
  );
}

for (
  let number = 1;
  number <= 502;
  number += 1
) {
  if (!numbers.has(number)) {
    throw new Error(
      `Missing module number ${number}.`,
    );
  }
}

const implementationClaims =
  snapshot.modules.filter(
    (module) =>
      module.implementationStatus !==
      "NOT_PROVEN",
  );

if (
  implementationClaims.length !== 0
) {
  throw new Error(
    "A module was marked implemented without direct evidence.",
  );
}

const counted =
  snapshot.summary.available +
  snapshot.summary.notYetConnected +
  snapshot.summary.blocked;

if (
  counted !== 502
) {
  throw new Error(
    `Readiness counts do not total 502: ${counted}.`,
  );
}

console.log(
  "STEP 10B MODULE REGISTRY: VERIFIED PASS",
);

console.log({
  totalModules:
    snapshot.totalModules,
  available:
    snapshot.summary.available,
  notYetConnected:
    snapshot.summary.notYetConnected,
  blocked:
    snapshot.summary.blocked,
  unmapped:
    snapshot.summary.unmapped,
  implementationStatus:
    "NOT_PROVEN_BY_POLICY",
});
