﻿import {
    happyModuleRouter,
} from "../../../core/happy/kernel/runtime/happy-module-router";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

const result =
    happyModuleRouter.resolve(
        "create customer",
    );

console.log(
    JSON.stringify({
        input: "create customer",
        status: result.status,
        moduleNumber:
            result.module?.number ?? null,
        module:
            result.module?.name ?? null,
        category:
            result.module?.category ?? null,
        action: result.action,
        confidence:
            result.confidence,
    }),
);

assert(
    result.status === "RESOLVED",
    "create customer must resolve.",
);

assert(
    result.module?.number === 282,
    "create customer must resolve to module 282.",
);

assert(
    result.module?.name ===
        "Customer Registration",
    "create customer must resolve to Customer Registration.",
);

assert(
    result.action === "CREATE",
    "create customer must infer CREATE action.",
);

console.log(
    "STEP 6 CREATE CUSTOMER PROOF: PASS",
);
