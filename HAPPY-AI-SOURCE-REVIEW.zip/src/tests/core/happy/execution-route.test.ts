﻿import {
    resolveHappyModuleExecutionRoute,
} from "../../../core/happy/kernel/runtime/happy-execution-route";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

interface RouteCase {
    readonly input: string;
    readonly action: string;
    readonly moduleNumber: number;
    readonly moduleName: string;
    readonly capability: string;
}

const cases: readonly RouteCase[] = [
    {
        input:
            "generate AI Website",
        action:
            "GENERATE",
        moduleNumber:
            322,
        moduleName:
            "AI Website Generator",
        capability:
            "CODE",
    },
    {
        input:
            "build mobile application",
        action:
            "BUILD",
        moduleNumber:
            345,
        moduleName:
            "Cross Platform Builder",
        capability:
            "CODE",
    },
    {
        input:
            "create customer",
        action:
            "CREATE",
        moduleNumber:
            282,
        moduleName:
            "Customer Registration",
        capability:
            "DATABASE",
    },
    {
        input:
            "open Founder Dashboard",
        action:
            "OPEN",
        moduleNumber:
            41,
        moduleName:
            "Founder Dashboard",
        capability:
            "AI",
    },
];

for (const expected of cases) {
    const route =
        resolveHappyModuleExecutionRoute(
            expected.input,
            expected.action,
        );

    console.log(
        JSON.stringify({
            input:
                expected.input,
            status:
                route.status,
            source:
                route.source,
            moduleNumber:
                route.moduleNumber ?? null,
            module:
                route.moduleName ?? null,
            bindingCapability:
                route.binding?.capability ??
                null,
            executionCapability:
                route.executionCapability,
            bindingStatus:
                route.binding?.status ??
                null,
        }),
    );

    assert(
        route.status ===
            "RESOLVED",
        `Route did not resolve: ${expected.input}`,
    );

    assert(
        route.source ===
            "MODULE_BINDING",
        `Module binding was not used: ${expected.input}`,
    );

    assert(
        route.moduleNumber ===
            expected.moduleNumber,
        `Wrong module number: ${expected.input}`,
    );

    assert(
        route.moduleName ===
            expected.moduleName,
        `Wrong module name: ${expected.input}`,
    );

    assert(
        route.executionCapability ===
            expected.capability,
        `Wrong execution capability: ${expected.input}`,
    );

    assert(
        route.binding?.capability ===
            expected.capability,
        `Binding capability mismatch: ${expected.input}`,
    );
}

const unknown =
    resolveHappyModuleExecutionRoute(
        "this module does not exist in HAPPY",
        "CREATE",
    );

console.log(
    JSON.stringify({
        input:
            "this module does not exist in HAPPY",
        status:
            unknown.status,
        source:
            unknown.source,
        capability:
            unknown.executionCapability,
    }),
);

assert(
    unknown.status ===
        "NOT_FOUND",
    "Unknown module route must remain NOT_FOUND.",
);

assert(
    unknown.source ===
        "CANONICAL_ACTION_FALLBACK",
    "Unknown module route must use canonical action fallback.",
);

assert(
    unknown.executionCapability ===
        "CODE",
    "CREATE fallback must preserve canonical CODE execution.",
);

console.log(
    "STEP 8D MODULE -> EXECUTION ROUTE: PASS",
);

