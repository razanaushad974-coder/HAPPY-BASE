import { buildHappyModuleEvidence } from "../../../core/integration/happy-module-evidence";

function assert(c:boolean,m:string):void{if(!c)throw new Error(m)}

const s=buildHappyModuleEvidence();
assert(s.totalModules===502,`Expected 502 modules, got ${s.totalModules}.`);
assert(s.modules.length===502,`Expected 502 records, got ${s.modules.length}.`);

const nums=s.modules.map(m=>m.number);
assert(new Set(nums).size===502,"Duplicate module numbers.");
for(let n=1;n<=502;n++)assert(nums.includes(n),`Missing module ${n}.`);

for(const m of s.modules){
  assert(typeof m.number==="number",`Invalid number for ${m.id}.`);
  assert(typeof m.id==="string"&&m.id.length>0,`Invalid id for module ${m.number}.`);
  assert(typeof m.name==="string"&&m.name.length>0,`Invalid name for module ${m.number}.`);
  assert(m.capability===null||typeof m.capability==="string",`Invalid capability for module ${m.number}.`);
  assert(["AVAILABLE","BLOCKED","NOT_YET_CONNECTED"].includes(m.capabilityStatus),`Invalid capabilityStatus for module ${m.number}.`);
  assert(m.implementationStatus==="NOT_PROVEN",`Implementation truth changed for module ${m.number}.`);
  assert(typeof m.evidenceLevel==="string",`Missing evidence level for module ${m.number}.`);
  assert(Array.isArray(m.evidenceSources),`Missing evidence sources for module ${m.number}.`);
}

assert(s.catalogIntegrity==="VALID","Catalog integrity is not VALID.");
assert(s.implementationEvidencePolicy==="NO_MODULE_IS_MARKED_IMPLEMENTED_WITHOUT_DIRECT_EVIDENCE","Implementation evidence policy changed.");

console.log("HAPPY COMMAND 03 MODULE EXECUTION CONTRACT: PASS");
console.log({
  totalModules:s.totalModules,
  uniqueNumbers:new Set(nums).size,
  catalogIntegrity:s.catalogIntegrity,
  implementationTruth:"PRESERVED",
  executionClaim:"NOT_IMPLIED"
});
