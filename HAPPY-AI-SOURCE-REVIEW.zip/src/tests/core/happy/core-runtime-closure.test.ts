import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

import {
    HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import {
    resolveHappyModuleExecutionRoute,
} from "../../../core/happy/kernel/runtime/happy-execution-route";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

function assertDefined<T>(
    value: T | undefined,
    message: string,
): asserts value is T {
    if (value === undefined) {
        throw new Error(message);
    }
}

async function main(): Promise<void> {
    const tempDirectory =
        mkdtempSync(
            join(
                tmpdir(),
                "happy-core-runtime-",
            ),
        );

    const persistenceFile =
        join(
            tempDirectory,
            "state.json",
        );

    try {
        // ----------------------------------------------------
        // 1. CANONICAL MODULE ROUTING
        // ----------------------------------------------------

        const websiteRoute =
            resolveHappyModuleExecutionRoute(
                "generate an AI website",
                "GENERATE",
            );

        const customerRoute =
            resolveHappyModuleExecutionRoute(
                "create customer",
                "CREATE",
            );

        const founderRoute =
            resolveHappyModuleExecutionRoute(
                "open Founder Dashboard",
                "OPEN",
            );

        const mobileRoute =
            resolveHappyModuleExecutionRoute(
                "build mobile application",
                "BUILD",
            );

        assert(
            websiteRoute.status === "RESOLVED",
            "AI Website route did not resolve.",
        );

        assert(
            websiteRoute.moduleNumber === 322,
            `Expected website module 322, received ${String(websiteRoute.moduleNumber)}.`,
        );

        assert(
            websiteRoute.moduleAction === "GENERATE",
            `Expected website action GENERATE, received ${String(websiteRoute.moduleAction)}.`,
        );

        assert(
            customerRoute.status === "RESOLVED" &&
            customerRoute.moduleNumber === 282,
            "Customer Registration route contract failed.",
        );

        assert(
            founderRoute.status === "RESOLVED" &&
            founderRoute.moduleNumber === 41,
            "Founder Dashboard route contract failed.",
        );

        assert(
            mobileRoute.status === "RESOLVED" &&
            mobileRoute.moduleNumber === 345,
            "Cross Platform Builder route contract failed.",
        );

        // ----------------------------------------------------
        // 2. CANONICAL ORCHESTRATION
        // ----------------------------------------------------

        const orchestration =
            new HappyOrchestrationEngine(
                persistenceFile,
            );

        const request = {
            id:
                `core-runtime-closure-${Date.now()}`,
            command:
                "analyze the current HAPPY runtime",
            organizationId:
                "core-runtime-org",
            workspaceId:
                "core-runtime-workspace",
            userId:
                "core-runtime-user",
            source:
                "TEXT" as const,
            approved:
                true,
            createdAt:
                new Date().toISOString(),
        };

        const result =
            await orchestration.run(
                request,
            );

        assert(
            result.status === "COMPLETED",
            `Canonical runtime did not complete. Received ${result.status}.`,
        );

        assert(
            result.currentStage === "COMPLETE",
            `Canonical runtime did not finish at COMPLETE. Received ${result.currentStage}.`,
        );

        assert(
            result.persisted === true,
            "Canonical runtime result was not persisted.",
        );

        // ----------------------------------------------------
        // 3. EXECUTION / VERIFICATION / EVIDENCE REFERENCES
        // ----------------------------------------------------

        assert(
            typeof result.executionRequestId === "string" &&
            result.executionRequestId.length > 0,
            "Execution request ID missing.",
        );

        assert(
            typeof result.verificationRequestId === "string" &&
            result.verificationRequestId.length > 0,
            "Verification request ID missing.",
        );

        assert(
            result.evidenceIds.length > 0,
            "Execution produced no evidence IDs.",
        );

        const stateRaw =
            readFileSync(
                persistenceFile,
                "utf8",
            );

        const persisted =
            JSON.parse(
                stateRaw,
            ) as {
                schemaVersion?: number;
                state?: {
                    commands?: unknown[];
                    missions?: unknown[];
                    tasks?: unknown[];
                    executions?: unknown[];
                    verifications?: unknown[];
                    evidence?: unknown[];
                };
            };

        assert(
            persisted.schemaVersion === 1,
            "Persistent state schema version is invalid.",
        );

        assert(
            persisted.state !== undefined,
            "Persistent state payload missing.",
        );

        const persistedState =
            persisted.state;

        assertDefined(
            persistedState,
            "Persistent state payload missing after validation.",
        );

        assert(
            Array.isArray(
                persistedState.executions,
            ) &&
            persistedState.executions.length > 0,
            "No persisted execution record found.",
        );

        assert(
            Array.isArray(
                persistedState.verifications,
            ) &&
            persistedState.verifications.length > 0,
            "No persisted verification record found.",
        );

        assert(
            Array.isArray(
                persistedState.evidence,
            ) &&
            persistedState.evidence.length > 0,
            "No persisted evidence record found.",
        );

        // ----------------------------------------------------
        // 4. RESTART / RECOVERY
        // ----------------------------------------------------

        const restarted =
            new HappyOrchestrationEngine(
                persistenceFile,
            );

        assertDefined(
            restarted,
            "Runtime could not be recreated from persisted state.",
        );

        const recoveredState =
            JSON.parse(
                readFileSync(
                    persistenceFile,
                    "utf8",
                ),
            ) as {
                state?: {
                    missions?: unknown[];
                    tasks?: unknown[];
                    executions?: unknown[];
                    verifications?: unknown[];
                    evidence?: unknown[];
                };
            };

        assert(
            Array.isArray(
                recoveredState.state?.missions,
            ) &&
            recoveredState.state.missions.length > 0,
            "Persisted mission was not recoverable.",
        );

        assert(
            Array.isArray(
                recoveredState.state?.tasks,
            ) &&
            recoveredState.state.tasks.length > 0,
            "Persisted tasks were not recoverable.",
        );

        assert(
            Array.isArray(
                recoveredState.state?.executions,
            ) &&
            recoveredState.state.executions.length > 0,
            "Persisted executions were not recoverable.",
        );

        assert(
            Array.isArray(
                recoveredState.state?.verifications,
            ) &&
            recoveredState.state.verifications.length > 0,
            "Persisted verifications were not recoverable.",
        );

        assert(
            Array.isArray(
                recoveredState.state?.evidence,
            ) &&
            recoveredState.state.evidence.length > 0,
            "Persisted evidence was not recoverable.",
        );

        console.log(
            "HAPPY CORE RUNTIME CLOSURE: PASS",
        );

        console.log({
            moduleRouting: {
                website: 322,
                customer: 282,
                founder: 41,
                mobile: 345,
            },
            finalStatus:
                result.status,
            finalStage:
                result.currentStage,
            executionPersisted:
                true,
            verificationPersisted:
                true,
            evidencePersisted:
                true,
            restartRecovery:
                true,
            canonicalEngine:
                "HappyOrchestrationEngine",
        });
    } finally {
        rmSync(
            tempDirectory,
            {
                recursive: true,
                force: true,
            },
        );
    }
}

main().catch(
    (error: unknown) => {
        console.error(
            error instanceof Error
                ? error.message
                : String(error),
        );
        process.exitCode = 1;
    },
);