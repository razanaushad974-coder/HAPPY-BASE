import {
  buildHappyModuleEvidence,
} from "@/core/integration/happy-module-evidence";

const snapshot = buildHappyModuleEvidence();

if (
  snapshot.systemId !== "happy"
) {
  throw new Error("systemId contract mismatch.");
}

if (
  snapshot.name !== "HAPPY"
) {
  throw new Error("name contract mismatch.");
}

if (snapshot.totalModules !== 502) {
  throw new Error(
    `Expected 502 modules; received ${snapshot.totalModules}.`,
  );
}

if (
  snapshot.catalogIntegrity !== "VALID"
) {
  throw new Error(
    "Catalog integrity must remain VALID.",
  );
}

if (
  snapshot.implementationEvidencePolicy !==
  "NO_MODULE_IS_MARKED_IMPLEMENTED_WITHOUT_DIRECT_EVIDENCE"
) {
  throw new Error(
    "Existing implementation evidence policy was not preserved.",
  );
}

if (
  snapshot.evidencePolicy !==
  "DIRECT_EXECUTION_EVIDENCE_REQUIRED"
) {
  throw new Error(
    "Evidence policy mismatch.",
  );
}

if (snapshot.modules.length !== 502) {
  throw new Error(
    `Expected 502 module records; received ${snapshot.modules.length}.`,
  );
}

if (snapshot.catalogOnly !== 498) {
  throw new Error(
    `Expected 498 catalog-only modules; received ${snapshot.catalogOnly}.`,
  );
}

if (snapshot.routingProven !== 4) {
  throw new Error(
    `Expected 4 routing-proven modules; received ${snapshot.routingProven}.`,
  );
}

if (snapshot.executionProven !== 0) {
  throw new Error(
    `Expected 0 execution-proven modules; received ${snapshot.executionProven}.`,
  );
}

if (snapshot.implemented !== 0) {
  throw new Error(
    `Expected 0 implemented modules; received ${snapshot.implemented}.`,
  );
}

const routingNumbers = snapshot.modules
  .filter(
    (module) =>
      module.evidenceLevel ===
      "ROUTING_PROVEN",
  )
  .map((module) => module.number)
  .sort((a, b) => a - b);

const expectedRoutingNumbers = [
  41,
  282,
  322,
  345,
];

if (
  JSON.stringify(routingNumbers) !==
  JSON.stringify(expectedRoutingNumbers)
) {
  throw new Error(
    `Routing proof mismatch: ${JSON.stringify(routingNumbers)}`,
  );
}

const routingWithoutSources =
  snapshot.modules.filter(
    (module) =>
      module.evidenceLevel ===
        "ROUTING_PROVEN" &&
      module.evidenceSources.length === 0,
  );

if (routingWithoutSources.length !== 0) {
  throw new Error(
    "A routing-proven module has no evidence source.",
  );
}

const implementedModules =
  snapshot.modules.filter(
    (module) =>
      module.evidenceLevel ===
      "IMPLEMENTED",
  );

if (implementedModules.length !== 0) {
  throw new Error(
    "Unexpected IMPLEMENTED module detected.",
  );
}

const executionProvenModules =
  snapshot.modules.filter(
    (module) =>
      module.evidenceLevel ===
      "EXECUTION_PROVEN",
  );

if (executionProvenModules.length !== 0) {
  throw new Error(
    "Unexpected EXECUTION_PROVEN module detected.",
  );
}

console.log(
  "STEP 10C-2 EVIDENCE CONTRACT: VERIFIED PASS",
);

console.log({
  totalModules: snapshot.totalModules,
  catalogOnly: snapshot.catalogOnly,
  routingProven: snapshot.routingProven,
  executionProven: snapshot.executionProven,
  implemented: snapshot.implemented,
  routingModules: routingNumbers,
});
