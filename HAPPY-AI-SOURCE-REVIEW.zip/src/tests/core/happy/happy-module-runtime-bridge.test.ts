import { bootstrapHappyModuleRuntimeBridge } from "../../../core/modules/runtime/happy-module-runtime-bridge";
import { happyModuleRegistry } from "../../../core/happy/kernel/registry/happy-module-runtime";

const assert: (
  condition: unknown,
  message: string,
) => asserts condition = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

const bridge = bootstrapHappyModuleRuntimeBridge();
const canonical = happyModuleRegistry.list();

assert(canonical.length === 502, "canonical registry is not 502");
assert(bridge.canonicalCount === 502, "canonical count is not 502");
assert(bridge.runtimeCount === 502, "runtime count is not 502");

const sampleNumbers = [1, 41, 282, 322, 345, 502];

for (const number of sampleNumbers) {
  const canonicalModule = canonical.find(
    (module) => module.number === number,
  );
  const runtimeModule = bridge.registry.get(number);

  assert(canonicalModule !== undefined, `canonical module ${number} missing`);
  assert(runtimeModule !== null, `runtime module ${number} missing`);

  assert(
    runtimeModule?.module.id === canonicalModule?.id,
    `module ${number} id mismatch`,
  );

  assert(
    runtimeModule?.module.name === canonicalModule?.name,
    `module ${number} name mismatch`,
  );

  assert(
    runtimeModule?.module.capability ===
      canonicalModule?.capabilities.join(","),
    `module ${number} capabilities mismatch`,
  );

  assert(
    runtimeModule?.dataStore !== undefined,
    `module ${number} data store missing`,
  );
}

assert(
  bridge.registry.get(503) === null,
  "invalid module 503 exists",
);

const statuses = bridge.statuses;

assert(
  statuses.DATA_READY === 0,
  "unproven DATA_READY modules detected",
);

console.log("HAPPY COMMAND 18 CANONICAL MODULE RUNTIME BRIDGE: PASS");
console.log({
  canonicalCount: bridge.canonicalCount,
  runtimeCount: bridge.runtimeCount,
  sampleModulesVerified: sampleNumbers,
  statuses,
  canonicalSource: "happyModuleRegistry",
  canonicalFieldsPreserved: true,
  dataStoreAttached: true,
  implementationTruthPreserved: true,
});
