import {
  HappyModuleDataService,
} from "../../../core/modules/runtime/happy-module-data-service";
import {
  InMemoryModulePersistenceAdapter,
} from "../../../core/modules/data/module-persistence";

const assert: (
  condition: unknown,
  message: string,
) => asserts condition = (
  condition,
  message,
) => {
  if (!condition) {
    throw new Error(message);
  }
};

async function main(): Promise<void> {
  const persistence =
    new InMemoryModulePersistenceAdapter();

  const service =
    new HappyModuleDataService(
      persistence,
    );

  assert(
    service.persistenceKind() ===
      "IN_MEMORY",
    "persistence kind incorrect",
  );

  assert(
    service.persistenceConnected() ===
      true,
    "in-memory persistence should be connected",
  );

  const created =
    await service.create({
      tenantId: "tenant-a",
      moduleNumber: 282,
      recordId: "customer-001",
      data: {
        name: "Customer One",
      },
    });

  assert(
    created.version === 1,
    "create version incorrect",
  );

  const fetched =
    await service.get(
      "tenant-a",
      282,
      "customer-001",
    );

  assert(
    fetched?.data.name ===
      "Customer One",
    "get failed",
  );

  const updated =
    await service.update({
      tenantId: "tenant-a",
      moduleNumber: 282,
      recordId: "customer-001",
      expectedVersion: 1,
      data: {
        name: "Customer Updated",
      },
    });

  assert(
    updated.version === 2,
    "update version incorrect",
  );

  assert(
    updated.data.name ===
      "Customer Updated",
    "update data incorrect",
  );

  const list =
    await service.list(
      "tenant-a",
      282,
    );

  assert(
    list.length === 1,
    "list failed",
  );

  assert(
    (await service.count(
      "tenant-a",
      282,
    )) === 1,
    "count failed",
  );

  let staleVersionBlocked =
    false;

  try {
    await service.update({
      tenantId: "tenant-a",
      moduleNumber: 282,
      recordId: "customer-001",
      expectedVersion: 1,
      data: {
        name: "Invalid",
      },
    });
  } catch (error) {
    staleVersionBlocked =
      error instanceof Error &&
      error.message.includes(
        "version conflict",
      );
  }

  assert(
    staleVersionBlocked,
    "stale version update was not blocked",
  );

  const otherTenant =
    await service.get(
      "tenant-b",
      282,
      "customer-001",
    );

  assert(
    otherTenant === null,
    "cross-tenant read leaked data",
  );

  await service.delete(
    "tenant-a",
    282,
    "customer-001",
    2,
  );

  assert(
    (await service.count(
      "tenant-a",
      282,
    )) === 0,
    "delete failed",
  );

  let invalidModuleBlocked =
    false;

  try {
    await service.get(
      "tenant-a",
      503,
      "invalid",
    );
  } catch {
    invalidModuleBlocked = true;
  }

  assert(
    invalidModuleBlocked,
    "unregistered module was not blocked",
  );

  console.log(
    "HAPPY COMMAND 27 PERSISTENCE-AWARE MODULE SERVICE: PASS",
  );

  console.log({
    service: "HappyModuleDataService",
    persistenceKind:
      service.persistenceKind(),
    create: true,
    read: true,
    list: true,
    update: true,
    delete: true,
    versioning: true,
    tenantIsolation: true,
    invalidModuleBlocked: true,
    adapterInjectable: true,
    supabaseAdapterCompatible: true,
  });
}

void main().catch(
  (error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  },
);
