import { ModuleRuntimeDescriptor, ModuleRuntimeRegistry } from "../../../core/modules/runtime/module-runtime-registry";

const assert: (
  condition: unknown,
  message: string,
) => asserts condition = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

const registry = new ModuleRuntimeRegistry();

const modules: ModuleRuntimeDescriptor[] = Array.from(
  { length: 502 },
  (_, index) => {
    const number = index + 1;

    return {
      number,
      id: `module-${number}`,
      name: `Module ${number}`,
      capability: "UNRESOLVED",
      runtimeStatus: "ROUTING_ONLY",
    };
  },
);

registry.registerMany(modules);

assert(registry.count() === 502, "registry must contain exactly 502 modules");
assert(registry.has(1), "module 1 missing");
assert(registry.has(502), "module 502 missing");
assert(!registry.has(503), "module 503 incorrectly registered");

const module41 = registry.get(41);
assert(module41?.module.number === 41, "module 41 lookup failed");
assert(module41?.module.runtimeStatus === "ROUTING_ONLY", "runtime truth changed");

const statuses = registry.statuses();
assert(statuses.ROUTING_ONLY === 502, "unexpected runtime status count");
assert(statuses.DATA_READY === 0, "unproven DATA_READY modules detected");

console.log("HAPPY COMMAND 17 MODULE RUNTIME REGISTRY: PASS");
console.log({
  totalModules: registry.count(),
  module1: registry.has(1),
  module41: registry.has(41),
  module502: registry.has(502),
  module503Blocked: !registry.has(503),
  runtimeTruthPreserved: statuses,
});
