﻿import {
    happyModuleRouter,
} from "../../../core/happy/kernel/runtime/happy-module-router";

interface ExpectedCase {
    readonly input: string;
    readonly moduleNumber: number;
    readonly moduleName: string;
    readonly action: string;
}

const cases: readonly ExpectedCase[] = [
    {
        input: "generate AI Website",
        moduleNumber: 322,
        moduleName: "AI Website Generator",
        action: "GENERATE",
    },
    {
        input: "build mobile application",
        moduleNumber: 345,
        moduleName: "Cross Platform Builder",
        action: "BUILD",
    },
    {
        input: "create customer",
        moduleNumber: 282,
        moduleName: "Customer Registration",
        action: "CREATE",
    },
    {
        input: "open Founder Dashboard",
        moduleNumber: 41,
        moduleName: "Founder Dashboard",
        action: "OPEN",
    },
];

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

for (const expected of cases) {
    const result =
        happyModuleRouter.resolve(
            expected.input,
        );

    console.log(
        JSON.stringify({
            input: expected.input,
            status: result.status,
            moduleNumber:
                result.module?.number ?? null,
            module:
                result.module?.name ?? null,
            action: result.action,
            confidence:
                result.confidence,
        }),
    );

    assert(
        result.status === "RESOLVED",
        `Expected RESOLVED for: ${expected.input}`,
    );

    assert(
        result.module?.number ===
            expected.moduleNumber,
        `Wrong module number for: ${expected.input}`,
    );

    assert(
        result.module?.name ===
            expected.moduleName,
        `Wrong module name for: ${expected.input}`,
    );

    assert(
        result.action ===
            expected.action,
        `Wrong action for: ${expected.input}`,
    );
}

const unknown =
    happyModuleRouter.resolve(
        "this module does not exist in HAPPY",
    );

console.log(
    JSON.stringify({
        input:
            "this module does not exist in HAPPY",
        status: unknown.status,
        module:
            unknown.module?.name ?? null,
    }),
);

assert(
    unknown.status === "NOT_FOUND",
    "Unknown command must remain NOT_FOUND.",
);

console.log(
    "STEP 6 DIRECT ROUTER PROOF: PASS",
);
