import {
    getExecutionCapabilityDefinition,
    listExecutionCapabilities,
} from "../../../core/capabilities/registry";

import {
    resolveExecutionCapability,
} from "../../../core/execution/capability-resolver";

const expectedCapabilities = [
    "CODE",
    "FILE",
    "API",
    "BROWSER",
    "SHELL",
    "DATABASE",
    "AI",
    "DEPLOYMENT",
    "PUBLISH",
    "AUTOMATION",
] as const;

const executionCapabilities =
    listExecutionCapabilities();

if (
    executionCapabilities.length !==
    expectedCapabilities.length
) {
    throw new Error(
        `EXPECTED_10_EXECUTION_CAPABILITIES_GOT_${executionCapabilities.length}`,
    );
}

for (
    const capability
    of expectedCapabilities
) {
    const definition =
        getExecutionCapabilityDefinition(
            capability,
        );

    if (!definition) {
        throw new Error(
            `EXECUTION_CAPABILITY_MISSING:${capability}`,
        );
    }

    console.log(
        `${capability}: ${definition.status}`,
    );
}

const routingChecks = [
    ["CREATE", "CODE"],
    ["MODIFY", "CODE"],
    ["BUILD", "CODE"],
    ["TEST", "CODE"],
    ["REQUEST", "API"],
    ["NAVIGATE", "BROWSER"],
    ["CLICK", "BROWSER"],
    ["FILL", "BROWSER"],
    ["EXTRACT", "BROWSER"],
    ["SCREENSHOT", "BROWSER"],
    ["UNDERSTAND", "AI"],
    ["RESEARCH", "AI"],
    ["VERIFY", "AI"],
    ["DEPLOY", "DEPLOYMENT"],
    ["PUBLISH", "PUBLISH"],
    ["AUTOMATE", "AUTOMATION"],
    ["SHELL", "SHELL"],
    ["DB_SELECT", "DATABASE"],
    ["DB_QUERY", "DATABASE"],
    ["DB_INSERT", "DATABASE"],
    ["DB_UPDATE", "DATABASE"],
    ["DB_DELETE", "DATABASE"],
    ["DB_TRANSACTION", "DATABASE"],
] as const;

for (
    const [
        action,
        expected,
    ]
    of routingChecks
) {
    const resolved =
        resolveExecutionCapability(
            action,
        );

    if (
        resolved !== expected
    ) {
        throw new Error(
            `ROUTING_MISMATCH:${action}:${resolved}:EXPECTED:${expected}`,
        );
    }
}

const codeDefinition =
    getExecutionCapabilityDefinition(
        "CODE",
    );

if (
    !codeDefinition ||
    codeDefinition.status !==
        "AVAILABLE"
) {
    throw new Error(
        "CODE_EXECUTION_REGISTRY_INVALID",
    );
}

const shellDefinition =
    getExecutionCapabilityDefinition(
        "SHELL",
    );

if (
    !shellDefinition ||
    shellDefinition.status !==
        "BLOCKED"
) {
    throw new Error(
        "SHELL_EXECUTION_REGISTRY_INVALID",
    );
}

console.log(
    `Execution capability profiles: ${executionCapabilities.length}`,
);

console.log(
    "CODE: AVAILABLE",
);

console.log(
    "SHELL: BLOCKED",
);

console.log(
    "Browser routing: PASS",
);

console.log(
    "Action routing: PASS",
);

console.log(
    "RESULT: PASS",
);
