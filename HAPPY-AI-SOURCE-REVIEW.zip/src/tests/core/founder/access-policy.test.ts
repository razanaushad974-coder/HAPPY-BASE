import assert from "node:assert/strict";

import {
  canUseFounderAction,
  evaluateFounderAccess,
  isFounderAction,
  isFounderRole,
} from "../../../core/founder/access-policy";

function main(): void {
  const unauthenticated =
    evaluateFounderAccess({
      userId: "user-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: false,
      configuredFounderUserId:
        "user-1",
      action:
        "VIEW_FOUNDER_DASHBOARD",
    });

  assert.equal(
    unauthenticated.status,
    "BLOCKED",
  );

  const clientRole =
    evaluateFounderAccess({
      userId: "user-1",
      role: "FOUNDER",
      roleSource:
        "CLIENT",
      authenticated: true,
      configuredFounderUserId:
        "user-1",
      action:
        "CONTROL_HAPPY",
    });

  assert.equal(
    clientRole.status,
    "BLOCKED",
  );

  const normalUser =
    evaluateFounderAccess({
      userId: "user-2",
      role: "USER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "user-1",
      action:
        "VIEW_FOUNDER_DASHBOARD",
    });

  assert.equal(
    normalUser.status,
    "BLOCKED",
  );

  const adminUser =
    evaluateFounderAccess({
      userId: "user-admin",
      role: "ADMIN",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "user-1",
      action:
        "CONTROL_HAPPY",
    });

  assert.equal(
    adminUser.status,
    "BLOCKED",
  );

  const missingRegistry =
    evaluateFounderAccess({
      userId: "user-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      action:
        "VIEW_FOUNDER_DASHBOARD",
    });

  assert.equal(
    missingRegistry.status,
    "NOT_YET_CONNECTED",
  );

  const wrongFounder =
    evaluateFounderAccess({
      userId: "user-2",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "user-1",
      action:
        "CONTROL_HAPPY",
    });

  assert.equal(
    wrongFounder.status,
    "BLOCKED",
  );

  const founder =
    evaluateFounderAccess({
      userId: "founder-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "founder-1",
      action:
        "CONTROL_HAPPY",
    });

  assert.equal(
    founder.status,
    "ALLOW",
  );

  const founderDeploy =
    evaluateFounderAccess({
      userId: "founder-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "founder-1",
      action:
        "DEPLOY",
    });

  assert.equal(
    founderDeploy.status,
    "ALLOW",
  );

  const founderSecurity =
    evaluateFounderAccess({
      userId: "founder-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "founder-1",
      action:
        "SECURITY_CHANGE",
    });

  assert.equal(
    founderSecurity.status,
    "ALLOW",
  );

  assert.equal(
    isFounderRole("FOUNDER"),
    true,
  );

  assert.equal(
    isFounderRole("USER"),
    false,
  );

  assert.equal(
    isFounderAction(
      "MANAGE_CAPABILITIES",
    ),
    true,
  );

  assert.equal(
    isFounderAction(
      "CONTROL_HAPPY",
    ),
    true,
  );

  assert.equal(
    canUseFounderAction({
      userId: "founder-1",
      role: "FOUNDER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "founder-1",
      action:
        "CONTROL_HAPPY",
    }),
    true,
  );

  assert.equal(
    canUseFounderAction({
      userId: "user-2",
      role: "USER",
      roleSource:
        "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId:
        "founder-1",
      action:
        "VIEW_FOUNDER_DASHBOARD",
    }),
    false,
  );

  console.log(
    "Unauthenticated Founder access blocked: PASS",
  );

  console.log(
    "Client-supplied Founder role blocked: PASS",
  );

  console.log(
    "Normal USER cannot access Founder OS: PASS",
  );

  console.log(
    "ADMIN cannot access Founder-only boundary: PASS",
  );

  console.log(
    "Missing Founder registry -> NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Wrong Founder identity blocked: PASS",
  );

  console.log(
    "Trusted Founder identity allowed: PASS",
  );

  console.log(
    "Founder deployment action allowed: PASS",
  );

  console.log(
    "Founder security action allowed: PASS",
  );

  console.log(
    "Founder action registry: PASS",
  );

  console.log(
    "Founder role helper: PASS",
  );

  console.log(
    "Founder capability helper: PASS",
  );

  console.log(
    "#28 Founder access-policy test: PASS",
  );
}

main();
