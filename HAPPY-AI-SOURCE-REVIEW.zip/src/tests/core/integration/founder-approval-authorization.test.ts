import assert from "node:assert/strict";
import {
  resolveTrustedFounderIdentity,
} from "../../../core/founder/identity";
import {
  evaluateFounderAccess,
} from "../../../core/founder/access-policy";

async function main() {
  const originalFounderId = process.env.HAPPY_FOUNDER_USER_ID;

  try {
    delete process.env.HAPPY_FOUNDER_USER_ID;

    assert.notEqual(
      (await resolveTrustedFounderIdentity("founder-user")).status,
      "ALLOW",
      "Missing configured founder must not be allowed",
    );

    process.env.HAPPY_FOUNDER_USER_ID = "founder-user";

    assert.notEqual(
      (await resolveTrustedFounderIdentity()).status,
      "ALLOW",
      "Missing authenticated user must not be allowed",
    );

    assert.notEqual(
      (await resolveTrustedFounderIdentity("different-user")).status,
      "ALLOW",
      "Non-founder user must not be allowed",
    );

    const identity = await resolveTrustedFounderIdentity("founder-user");

    assert.equal(identity.status, "ALLOW");

    if (identity.status !== "ALLOW" || !identity.access) {
      throw new Error("Expected trusted founder identity and access context");
    }

    assert.equal(
      evaluateFounderAccess({
        ...identity.access,
        action: "CONTROL_HAPPY",
      }).status,
      "ALLOW",
      "Configured trusted founder should pass the registered action policy",
    );

    assert.notEqual(
      evaluateFounderAccess({
        ...identity.access,
        roleSource: "CLIENT",
        action: "CONTROL_HAPPY",
      }).status,
      "ALLOW",
      "Client-sourced role must be rejected",
    );

    assert.notEqual(
      evaluateFounderAccess({
        ...identity.access,
        role: "ADMIN",
        action: "CONTROL_HAPPY",
      }).status,
      "ALLOW",
      "Admin role must not inherit founder-only access",
    );

    assert.notEqual(
      evaluateFounderAccess({
        ...identity.access,
        configuredFounderUserId: "different-user",
        action: "CONTROL_HAPPY",
      }).status,
      "ALLOW",
      "Mismatched configured founder ID must be rejected",
    );

    console.log("Missing founder configuration blocked: PASS");
    console.log("Missing authentication blocked: PASS");
    console.log("Non-founder identity blocked: PASS");
    console.log("Trusted founder authorization: PASS");
    console.log("Client-sourced role blocked: PASS");
    console.log("Admin role blocked from founder action: PASS");
    console.log("Founder ID mismatch blocked: PASS");
    console.log("Founder authorization policy test: PASS");
  } finally {
    if (originalFounderId === undefined) {
      delete process.env.HAPPY_FOUNDER_USER_ID;
    } else {
      process.env.HAPPY_FOUNDER_USER_ID = originalFounderId;
    }
  }
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

