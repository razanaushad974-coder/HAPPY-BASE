import assert from "node:assert/strict";

import {
  buildSystemReadiness,
} from "../../../core/integration/system-readiness";

async function main(): Promise<void> {
  const snapshot =
    buildSystemReadiness();

  assert.equal(
    snapshot.systemId,
    "happy",
  );

  assert.equal(
    snapshot.name,
    "HAPPY",
  );

  assert.equal(
    snapshot.singleIntelligence,
    true,
  );

  assert.ok(
    snapshot.checks.length >= 15,
  );

  const getCheck =
    (
      id: string,
    ) =>
      snapshot.checks.find(
        (item) =>
          item.id === id,
      );

  assert.equal(
    getCheck(
      "identity.single-happy",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "persistence.scope",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "context.reference-safety",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "approval.execution-boundary",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "verification.completion-boundary",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "evidence.execution-contract",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "memory.context-bridge",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "workspace.live-state",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "agents.registry",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "founder.privilege-boundary",
    )?.status,
    "READY",
  );

  assert.equal(
    getCheck(
      "workflow.agent-capability-routing",
    )?.status,
    "READY",
  );

  const automation =
    getCheck(
      "execution.automation",
    );

  const deployment =
    getCheck(
      "execution.deployment",
    );

  const publish =
    getCheck(
      "execution.publish",
    );

  const shell =
    getCheck(
      "execution.shell",
    );

  assert.ok(
    automation,
  );

  assert.ok(
    deployment,
  );

  assert.ok(
    publish,
  );

  assert.ok(
    shell,
  );

  assert.notEqual(
    automation.status,
    "READY",
  );

  assert.notEqual(
    deployment.status,
    "READY",
  );

  assert.notEqual(
    publish.status,
    "READY",
  );

  assert.notEqual(
    shell.status,
    "READY",
  );

  assert.ok(
    [
      "READY",
      "PARTIAL",
      "BLOCKED",
      "NOT_YET_CONNECTED",
    ].includes(
      snapshot.status,
    ),
  );

  console.log(
    "One HAPPY identity contract: PASS",
  );

  console.log(
    "Single-intelligence flag: PASS",
  );

  console.log(
    "Persistence readiness: PASS",
  );

  console.log(
    "Context safety readiness: PASS",
  );

  console.log(
    "Approval execution boundary: PASS",
  );

  console.log(
    "Verification completion boundary: PASS",
  );

  console.log(
    "Evidence contract: PASS",
  );

  console.log(
    "Memory-context integration: PASS",
  );

  console.log(
    "Workspace live-state integration: PASS",
  );

  console.log(
    "Agent registry integration: PASS",
  );

  console.log(
    "Founder privilege boundary: PASS",
  );

  console.log(
    "Workflow capability routing: PASS",
  );

  console.log(
    "Automation remains explicitly unconnected: PASS",
  );

  console.log(
    "Deployment remains explicitly unconnected: PASS",
  );

  console.log(
    "Publishing remains explicitly unconnected: PASS",
  );

  console.log(
    "Safe Shell remains explicitly gated: PASS",
  );

  console.log(
    "#30 system-readiness test: PASS",
  );
}

main().catch(
  (error: unknown) => {
    console.error(
      error,
    );

    process.exitCode = 1;
  },
);
