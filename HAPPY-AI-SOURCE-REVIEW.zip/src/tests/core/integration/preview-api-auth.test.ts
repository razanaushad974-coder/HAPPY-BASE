import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";

async function main(): Promise<void> {
    const source = await readFile("src/app/api/preview/route.ts", "utf8");

    assert.ok(source.includes("getAuthenticatedExecutionRuntimeContext"),
        "Route must use the existing authentication helper.");
    assert.ok(source.includes(
        "!runtimeContext.authenticatedUserId || !runtimeContext.supabaseAccessToken"
    ), "Production access must require an authenticated user and Supabase token.");
    assert.ok(source.includes(
        'return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });'
    ), "Unauthenticated production requests must receive HTTP 401.");
    assert.ok(source.includes("HAPPY_LIVE_PREVIEW"),
        "Existing production preview feature gate must remain.");
    assert.ok(source.includes('"Cache-Control"') && source.includes("no-store"),
        "Existing no-store response policy must remain.");

    console.log("Preview API auth source-contract: PASS");
}

void main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
