import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";

async function main(): Promise<void> {
    const routeFile =
        "src/app/api/runtime/snapshot/route.ts";

    const source =
        await readFile(
            routeFile,
            "utf8",
        );

    assert.equal(
        source.includes(
            "export async function GET",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "export async function POST",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "getAuthenticatedExecutionRuntimeContext",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "createAuthenticatedWorkspaceState",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "createSupabaseServerClient",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "SupabaseRuntimeSnapshotStore",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "resolveExistingRemoteScope",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "LOCAL_FALLBACK",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "NOT_YET_CONNECTED",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "local state retained",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "organizationId",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "workspaceId",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "userId",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "SUPABASE_SERVICE_ROLE_KEY",
        ),
        false,
    );

    assert.equal(
        source.includes(
            "SERVICE_ROLE",
        ),
        false,
    );

    assert.equal(
        source.includes(
            "Remove-Item",
        ),
        false,
    );

    console.log(
        "Authenticated snapshot API: PASS",
    );

    console.log(
        "Supabase primary path: PASS",
    );

    console.log(
        "Local fallback path: PASS",
    );

    console.log(
        "GET fallback preservation: PASS",
    );

    console.log(
        "POST fallback preservation: PASS",
    );

    console.log(
        "Tenant scope contract: PASS",
    );

    console.log(
        "No service-role bypass: PASS",
    );

    console.log(
        "No destructive local-state operation: PASS",
    );

    console.log(
        "Runtime snapshot fallback contract: PASS",
    );
}

main().catch(
    (error: unknown) => {
        console.error(error);
        process.exitCode = 1;
    },
);