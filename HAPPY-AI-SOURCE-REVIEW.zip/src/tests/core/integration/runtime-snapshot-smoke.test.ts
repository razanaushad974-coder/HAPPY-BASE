import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";

async function main(): Promise<void> {
    const routeFile =
        "src/app/api/runtime/snapshot/smoke/route.ts";

    const source =
        await readFile(
            routeFile,
            "utf8",
        );

    assert.equal(
        source.includes(
            "getAuthenticatedExecutionRuntimeContext",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "createAuthenticatedWorkspaceState",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "createSupabaseServerClient",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "SupabaseRuntimeSnapshotStore",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "store.save",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "store.load",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "scopeMatches",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "versionMatches",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "LIVE_REMOTE_VERIFIED",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "UNAUTHENTICATED",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "NOT_YET_CONNECTED",
        ),
        true,
    );

    assert.equal(
        source.includes(
            "SUPABASE_SERVICE_ROLE_KEY",
        ),
        false,
    );

    assert.equal(
        source.includes(
            "SERVICE_ROLE",
        ),
        false,
    );

    console.log(
        "Authenticated smoke boundary: PASS",
    );

    console.log(
        "Remote SAVE path: PASS",
    );

    console.log(
        "Remote LOAD path: PASS",
    );

    console.log(
        "Scope verification: PASS",
    );

    console.log(
        "Version verification: PASS",
    );

    console.log(
        "LIVE_REMOTE_VERIFIED result contract: PASS",
    );

    console.log(
        "No service-role bypass: PASS",
    );

    console.log(
        "Live Supabase smoke contract: PASS",
    );
}

main().catch(
    (error: unknown) => {
        console.error(error);
        process.exitCode = 1;
    },
);