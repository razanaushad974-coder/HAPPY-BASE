import { beforeEach, describe, expect, it, vi } from "vitest";
import type { NextRequest } from "next/server";

const mocks = vi.hoisted(() => ({
  getRuntimeContext: vi.fn(),
  createWorkspace: vi.fn(),
  createServerClient: vi.fn(),
  loadSnapshot: vi.fn(),
  saveIfVersion: vi.fn(),
  applyDecision: vi.fn(),
  resume: vi.fn(),
  replaceScopedSnapshot: vi.fn(),
  resolveFounder: vi.fn(),
  evaluateAccess: vi.fn(),
}));

vi.mock("../../../core/auth/supabase-runtime-context", () => ({
  getAuthenticatedExecutionRuntimeContext: mocks.getRuntimeContext,
}));

vi.mock("../../../core/workspace/file-backed-state", () => ({
  createAuthenticatedWorkspaceState: mocks.createWorkspace,
}));

vi.mock("../../../lib/supabase/server", () => ({
  createSupabaseServerClient: mocks.createServerClient,
}));

vi.mock("../../../core/persistence/adapters/supabase-runtime-snapshot", () => ({
  SupabaseRuntimeSnapshotStore: class {
    load(...args: unknown[]) {
      return mocks.loadSnapshot(...args);
    }
    saveIfVersion(...args: unknown[]) {
      return mocks.saveIfVersion(...args);
    }
  },
}));

vi.mock("../../../core/approval/persist-decision", () => ({
  applyApprovalDecision: mocks.applyDecision,
}));

vi.mock("../../../core/orchestration/engine", () => ({
  HappyOrchestrationEngine: class {
    resumeAfterApproval(...args: unknown[]) {
      return mocks.resume(...args);
    }
  },
}));

vi.mock("../../../core/founder/identity", () => ({
  resolveTrustedFounderIdentity: mocks.resolveFounder,
}));

vi.mock("../../../core/founder/access-policy", () => ({
  evaluateFounderAccess: mocks.evaluateAccess,
}));

import { POST } from "../../../app/api/approvals/decision/route";

const tenant = {
  organizationId: "test-org",
  workspaceId: "test-workspace",
  userId: "founder-user",
};

const snapshotState = {
  approvals: [{
    id: "approval-1",
    data: {
      requestId: "request-1",
      planId: "plan-1",
      level: "FOUNDER",
    },
  }],
  missions: [{
    id: "plan-1",
    data: { id: "plan-1" },
  }],
};

const decisionResult = {
  state: snapshotState,
  approvalId: "approval-1",
  requestId: "request-1",
  planId: "plan-1",
  decisionId: "decision-1",
  auditEventId: "audit-1",
  decision: "APPROVED",
  approverId: "founder-user",
  reason: "runtime test",
  decidedAt: "2026-01-01T00:00:00.000Z",
};

function request() {
  return new Request("http://localhost/api/approvals/decision", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      approvalId: "approval-1",
      decision: "APPROVED",
      reason: "runtime test",
    }),
  }) as NextRequest;
}

async function responseBody(response: Response) {
  return response.json() as Promise<Record<string, unknown>>;
}

beforeEach(() => {
  vi.clearAllMocks();

  mocks.getRuntimeContext.mockResolvedValue({
    authenticatedUserId: "founder-user",
    supabaseAccessToken: "test-token",
  });

  mocks.createWorkspace.mockReturnValue({
    tenant,
    persistence: {
      replaceScopedSnapshot: mocks.replaceScopedSnapshot,
    },
  });

  mocks.createServerClient.mockResolvedValue({});
  mocks.loadSnapshot.mockResolvedValue({
    state: snapshotState,
    version: 4,
    scopeKey: "test-scope",
  });

  mocks.saveIfVersion.mockResolvedValue({
    scopeKey: "test-scope",
    version: 5,
    updatedAt: "2026-01-01T00:00:01.000Z",
  });

  mocks.applyDecision.mockReturnValue(decisionResult);
  mocks.replaceScopedSnapshot.mockImplementation(() => undefined);
  mocks.resume.mockResolvedValue({ status: "RESUMED" });

  mocks.resolveFounder.mockReturnValue({
    status: "ALLOW",
    access: {
      userId: "founder-user",
      role: "FOUNDER",
      roleSource: "TRUSTED_SERVER",
      authenticated: true,
      configuredFounderUserId: "founder-user",
      action: "CONTROL_HAPPY",
    },
  });

  mocks.evaluateAccess.mockReturnValue({ status: "ALLOW" });
});

describe("approval decision POST runtime contract", () => {
  it("returns 401 without authentication and does not load a snapshot", async () => {
    mocks.getRuntimeContext.mockResolvedValue({
      authenticatedUserId: undefined,
      supabaseAccessToken: undefined,
    });

    const response = await POST(request());

    expect(response.status).toBe(401);
    expect(await responseBody(response)).toMatchObject({
      status: "UNAUTHENTICATED",
    });
    expect(mocks.loadSnapshot).not.toHaveBeenCalled();
    expect(mocks.applyDecision).not.toHaveBeenCalled();
    expect(mocks.saveIfVersion).not.toHaveBeenCalled();
  });

  it("returns 409 on a CAS conflict without claiming persistence or resuming", async () => {
    mocks.saveIfVersion.mockRejectedValue(
      new Error("RUNTIME_SNAPSHOT_VERSION_CONFLICT"),
    );

    const response = await POST(request());
    const body = await responseBody(response);

    expect(response.status).toBe(409);
    expect(body).toMatchObject({
      status: "VERSION_CONFLICT",
      code: "RUNTIME_SNAPSHOT_VERSION_CONFLICT",
      decisionPersisted: false,
    });
    expect(mocks.saveIfVersion).toHaveBeenCalledWith(
      tenant,
      decisionResult.state,
      4,
    );
    expect(mocks.replaceScopedSnapshot).not.toHaveBeenCalled();
    expect(mocks.resume).not.toHaveBeenCalled();
  });

  it("does not resume when local persistence hydration fails after the authoritative save", async () => {
    mocks.replaceScopedSnapshot.mockImplementation(() => {
      throw new Error("INJECTED_HYDRATION_FAILURE");
    });

    const response = await POST(request());
    const body = await responseBody(response);

    expect(response.status).toBe(503);
    expect(body).toMatchObject({
      status: "APPROVAL_DECISION_PERSISTED_RESUME_RECOVERY_REQUIRED",
      code: "RESUME_RECOVERY_REQUIRED",
      decisionPersisted: true,
      recoveryRequired: true,
      approvalId: "approval-1",
      requestId: "request-1",
      planId: "plan-1",
      version: 5,
    });

    expect(mocks.saveIfVersion).toHaveBeenCalledTimes(1);
    expect(mocks.applyDecision).toHaveBeenCalledTimes(1);
    expect(mocks.replaceScopedSnapshot).toHaveBeenCalledTimes(1);
    expect(mocks.resume).not.toHaveBeenCalled();
  });
  it("reports persisted decision and recovery required if resume fails after save", async () => {
    mocks.resume.mockRejectedValue(new Error("INJECTED_RESUME_FAILURE"));

    const response = await POST(request());
    const body = await responseBody(response);

    expect(response.status).toBe(503);
    expect(body).toMatchObject({
      status: "APPROVAL_DECISION_PERSISTED_RESUME_RECOVERY_REQUIRED",
      code: "RESUME_RECOVERY_REQUIRED",
      decisionPersisted: true,
      recoveryRequired: true,
      approvalId: "approval-1",
      requestId: "request-1",
      planId: "plan-1",
      version: 5,
    });
    expect(mocks.saveIfVersion).toHaveBeenCalledTimes(1);
    expect(mocks.replaceScopedSnapshot).toHaveBeenCalledTimes(1);
    expect(mocks.resume).toHaveBeenCalledTimes(1);
  });
});
