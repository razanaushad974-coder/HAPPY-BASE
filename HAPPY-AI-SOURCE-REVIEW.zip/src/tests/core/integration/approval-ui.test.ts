import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const file =
    "src/app/workspace/approvals/page.tsx";

const text =
    readFileSync(
        file,
        "utf8",
    );

assert.match(
    text,
    /\/api\/approvals\/decision/,
);

assert.match(
    text,
    /method:\s*"GET"/,
);

assert.match(
    text,
    /method:\s*"POST"/,
);

assert.match(
    text,
    /credentials:\s*"include"/,
);

assert.match(
    text,
    /"APPROVED"/,
);

assert.match(
    text,
    /"REJECTED"/,
);

assert.match(
    text,
    /const\s+decide\s*=\s*async/,
);

assert.match(
    text,
    /decision:\s*[\s\S]*?"APPROVED"[\s\S]*?"REJECTED"/,
);

assert.match(
    text,
    /loadApprovals/,
);

assert.match(
    text,
    /Pending approvals/,
);

assert.match(
    text,
    /Approve/,
);

assert.match(
    text,
    /Reject/,
);

assert.match(
    text,
    /disabled=\{busy\}/,
);

assert.match(
    text,
    /setBusyId/,
);

assert.match(
    text,
    /await\s+loadApprovals\(\)/,
);

assert.match(
    text,
    /JSON\.stringify\(\{[\s\S]*approvalId[\s\S]*decision/,
);

console.log(
    "Approval UI route binding: PASS",
);

console.log(
    "Authenticated browser credentials: PASS",
);

console.log(
    "Pending approval GET: PASS",
);

console.log(
    "Approval decision function: PASS",
);

console.log(
    "APPROVED decision support: PASS",
);

console.log(
    "REJECTED decision support: PASS",
);

console.log(
    "Approve control label: PASS",
);

console.log(
    "Reject control label: PASS",
);

console.log(
    "Busy-state protection: PASS",
);

console.log(
    "Approval reload after decision: PASS",
);

console.log(
    "Approval POST payload binding: PASS",
);

console.log(
    "#36G approval UI contract test: PASS",
);
