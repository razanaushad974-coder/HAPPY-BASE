import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const routeFile =
    "src/app/api/approvals/decision/route.ts";

const text =
    readFileSync(
        routeFile,
        "utf8",
    );

assert.match(
    text,
    /getAuthenticatedExecutionRuntimeContext/,
);

assert.match(
    text,
    /createAuthenticatedWorkspaceState/,
);

assert.match(
    text,
    /SupabaseRuntimeSnapshotStore/,
);

assert.match(
    text,
    /export async function GET/,
);

assert.match(
    text,
    /export async function POST/,
);

assert.match(
    text,
    /applyApprovalDecision/,
);

assert.match(
    text,
    /\.load\(/,
);

assert.match(
    text,
    /\.saveIfVersion\(/,
);

assert.match(
    text,
    /APPROVAL_DECISION_PERSISTED/,
);

assert.match(
    text,
    /APPROVAL_NOT_PENDING/,
);

assert.doesNotMatch(
    text,
    /service_role|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_SERVICE_KEY/i,
);

// Approval linkage must be validated before any decision mutation.
assert.match(text, /APPROVAL_LINKAGE_INVALID/);
assert.match(text, /APPROVAL_PLAN_LINKAGE_INVALID/);
assert.match(text, /APPROVAL_DECISION_LINKAGE_MISMATCH/);
assert.match(text, /RUNTIME_SNAPSHOT_VERSION_CONFLICT/);
assert.match(text, /decisionPersisted: false/);
assert.match(text, /APPROVAL_DECISION_PERSISTED_RESUME_RECOVERY_REQUIRED/);
assert.match(text, /decisionPersisted: true/);
assert.match(text, /recoveryRequired: true/);
assert.match(text, /approvalPayload\.requestId/);
assert.match(text, /approvalPayload\.planId/);
assert.match(text, /missionPayload\.id !== approvalPlanId/);

const linkageValidationIndex = text.indexOf(
    'code: "APPROVAL_LINKAGE_INVALID"',
);
const mutationIndex = text.indexOf("applyApprovalDecision(");
const linkageGuardIndex = text.indexOf(
    'code: "APPROVAL_DECISION_LINKAGE_MISMATCH"',
);
const saveIndex = text.indexOf("saveIfVersion(");

assert.notEqual(linkageValidationIndex, -1);
assert.notEqual(mutationIndex, -1);
assert.notEqual(linkageGuardIndex, -1);
assert.notEqual(saveIndex, -1);
assert.ok(
    linkageValidationIndex < mutationIndex,
    "Approval linkage validation must precede decision mutation",
);
assert.ok(
    linkageGuardIndex < saveIndex,
    "Decision linkage mismatch guard must precede snapshot save",
);

console.log("Approval linkage validation before mutation: PASS");
console.log("Decision linkage guard before persistence: PASS");

console.log(
    "Authenticated approval API boundary: PASS",
);

console.log(
    "Approval GET contract: PASS",
);

console.log(
    "Approval POST contract: PASS",
);

console.log(
    "Remote snapshot load binding: PASS",
);

console.log(
    "Remote snapshot save binding: PASS",
);

console.log(
    "Persisted decision response contract: PASS",
);

console.log(
    "Duplicate decision protection: PASS",
);

console.log(
    "No service-role bypass: PASS",
);

console.log(
    "#36F approval API contract test: PASS",
);
