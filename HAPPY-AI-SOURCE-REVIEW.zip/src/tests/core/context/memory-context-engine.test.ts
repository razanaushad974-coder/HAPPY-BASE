import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import {
  MemoryContextEngine,
} from "../../../core/context/memory-context-engine";

import {
  PersistentMemoryService,
} from "../../../core/memory/persistent-service";

function createMemoryService(
  stateDir: string,
  userId: string,
): PersistentMemoryService {
  return new PersistentMemoryService(
    "org-test",
    "workspace-test",
    userId,
    join(
      stateDir,
      "memory-state.json",
    ),
  );
}

async function main(): Promise<void> {
  const stateDir =
    mkdtempSync(
      join(
        tmpdir(),
        "happy-context-",
      ),
    );

  try {
    const userA =
      createMemoryService(
        stateDir,
        "user-a",
      );

    const userB =
      createMemoryService(
        stateDir,
        "user-b",
      );

    await userA.remember({
      type: "PREFERENCE",
      scope: "USER",
      userId: "user-a",
      workspaceId: "workspace-test",
      key: "language",
      value: "Hindi + English + Hinglish",
      confidence: "HIGH",
      source: "TEST",
    });

    await userA.remember({
      type: "EPISODIC",
      scope: "SESSION",
      userId: "user-a",
      workspaceId: "workspace-test",
      key: "current-goal",
      value: "Build HAPPY AI safely",
      confidence: "HIGH",
      source: "TEST",
    });

    await userA.remember({
      type: "EPISODIC",
      scope: "SESSION",
      userId: "user-a",
      workspaceId: "workspace-test",
      key: "expired-memory",
      value: "must not enter active context",
      confidence: "HIGH",
      source: "TEST",
      expiresAt:
        new Date(
          Date.now() - 60_000,
        ).toISOString(),
    });

    await userB.remember({
      type: "EPISODIC",
      scope: "SESSION",
      userId: "user-b",
      workspaceId: "workspace-test",
      key: "private-user-b-memory",
      value: "must not leak to user-a",
      confidence: "HIGH",
      source: "TEST",
    });

    const engineA =
      new MemoryContextEngine(
        userA,
      );

    const activeContext =
      await engineA.resolve({
        userId: "user-a",
        workspaceId: "workspace-test",
        activeProjectId: "project-1",
        activeMissionId: "mission-1",
        activeTaskId: "task-1",
        recentCommand:
          "this task continue karo",
        language: "en",
      });

    assert.equal(
      activeContext.memoriesUsed,
      2,
    );

    assert.equal(
      activeContext.memorySummary.includes(
        "expired-memory",
      ),
      false,
    );

    assert.equal(
      activeContext.memorySummary.includes(
        "private-user-b-memory",
      ),
      false,
    );

    const explicitTask =
      activeContext.resolution
        .resolvedReferences
        .some(
          (reference) =>
            reference.entityType ===
              "TASK" &&
            reference.entityId ===
              "task-1",
        );

    assert.equal(
      explicitTask,
      true,
    );

    assert.equal(
      activeContext.resolution
        .requiresClarification,
      false,
    );

    const genericSingle =
      await engineA.resolve({
        userId: "user-a",
        workspaceId: "workspace-test",
        activeTaskId: "task-single",
        recentCommand:
          "isko update karo",
      });

    assert.equal(
      genericSingle.resolution
        .requiresClarification,
      false,
    );

    assert.equal(
      genericSingle.resolution
        .resolvedReferences
        .some(
          (reference) =>
            reference.entityType ===
              "TASK" &&
            reference.entityId ===
              "task-single",
        ),
      true,
    );

    const genericAmbiguous =
      await engineA.resolve({
        userId: "user-a",
        workspaceId: "workspace-test",
        activeMissionId: "mission-ambiguous",
        activeTaskId: "task-ambiguous",
        recentCommand:
          "isko update karo",
      });

    assert.equal(
      genericAmbiguous.resolution
        .requiresClarification,
      true,
    );

    assert.equal(
      genericAmbiguous.resolution
        .unresolvedReferences
        .includes(
          "ambiguous_entity",
        ),
      true,
    );

    const noTarget =
      await engineA.resolve({
        userId: "user-a",
        workspaceId: "workspace-test",
        recentCommand:
          "isko publish karo",
      });

    assert.equal(
      noTarget.resolution
        .requiresClarification,
      true,
    );

    assert.equal(
      noTarget.resolution
        .unresolvedReferences
        .includes(
          "referenced_entity",
        ),
      true,
    );

    const scopedB =
      new MemoryContextEngine(
        userB,
      );

    const userBContext =
      await scopedB.resolve({
        userId: "user-b",
        workspaceId: "workspace-test",
        recentCommand:
          "show my memory",
      });

    assert.equal(
      userBContext.memorySummary.includes(
        "private-user-b-memory",
      ),
      true,
    );

    assert.equal(
      userBContext.memorySummary.includes(
        "current-goal",
      ),
      false,
    );

    console.log(
      "Persistent memory loaded into context: PASS",
    );

    console.log(
      "Expired memories excluded from context: PASS",
    );

    console.log(
      "Cross-user memory isolation: PASS",
    );

    console.log(
      "Explicit task reference resolution: PASS",
    );

    console.log(
      "Single-candidate generic reference resolution: PASS",
    );

    console.log(
      "Ambiguous generic reference -> clarification: PASS",
    );

    console.log(
      "Missing generic reference -> clarification: PASS",
    );

    console.log(
      "No unsafe reference guessing: PASS",
    );

    console.log(
      "#26 memory-context engine test: PASS",
    );
  }
  finally {
    rmSync(
      stateDir,
      {
        recursive: true,
        force: true,
      },
    );
  }
}

main().catch(
  (error: unknown) => {
    console.error(
      error,
    );
    process.exitCode = 1;
  },
);
