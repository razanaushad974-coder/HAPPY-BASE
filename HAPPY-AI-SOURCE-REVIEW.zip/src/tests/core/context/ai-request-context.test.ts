﻿import { resolveContext } from "../../../core/context/resolver";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

function main(): void {
  const emptyContext =
    {} as Parameters<typeof resolveContext>[0];

  const aiCommand =
    "Use the connected AI provider to answer this request. Return exactly GEMINI_OK_2026.";

  const aiResult =
    resolveContext(
      emptyContext,
      aiCommand,
    );

  assert(
    aiResult.requiresClarification === false,
    "AI command was incorrectly blocked by CONTEXT.",
  );

  assert(
    aiResult.unresolvedReferences.length === 0,
    "AI command produced unexpected unresolved references.",
  );

  const explicitMissionCommand =
    "Continue this mission.";

  const missionResult =
    resolveContext(
      emptyContext,
      explicitMissionCommand,
    );

  assert(
    missionResult.requiresClarification === true,
    "Missing explicit mission context was incorrectly allowed.",
  );

  assert(
    missionResult.unresolvedReferences.includes(
      "this mission",
    ),
    "Explicit mission reference was not preserved.",
  );

  console.log(
    "AI request context false-positive: FIXED",
  );

  console.log({
    aiCommandBlocked: aiResult.requiresClarification,
    aiCommandUnresolvedReferences:
      aiResult.unresolvedReferences,
    explicitMissionStillRequiresContext:
      missionResult.requiresClarification,
    explicitMissionReferencePreserved:
      missionResult.unresolvedReferences.includes(
        "this mission",
      ),
  });
}

main();
