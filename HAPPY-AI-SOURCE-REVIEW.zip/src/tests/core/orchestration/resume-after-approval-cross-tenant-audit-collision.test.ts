import { join } from "node:path";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

class RecordingExecutionEngine {
    public readonly calls: ExecutionRequest[] = [];

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);
        const now = new Date().toISOString();

        return {
            id: `tenant-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };
    }
}

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

async function main(): Promise<void> {
    const stateDir = await mkdtemp(join(tmpdir(), "happy-resume-cross-tenant-"));
    const stateFile = join(stateDir, "orchestration-state.json");
    const persistence = new PersistenceService(new JsonFileStateAdapter(stateFile));

    const requestId = "resume-shared-request-id";
    const tenants = [
        { organizationId: "org-legacy-a", workspaceId: "workspace-legacy-a", userId: "user-legacy-a", planId: "plan-legacy-a", approvalId: "approval-legacy-a" },
        { organizationId: "org-tenant-b", workspaceId: "workspace-tenant-b", userId: "user-tenant-b", planId: "plan-tenant-b", approvalId: "approval-tenant-b" },
    ] as const;

    const actions = ["UNDERSTAND", "BUILD", "TEST", "VERIFY", "CONTROL"] as const;

    for (const tenant of tenants) {
        const store = createHappyStateStore(
            persistence,
            tenant.organizationId,
            tenant.workspaceId,
            tenant.userId,
        );

        const plan: ExecutionPlan = {
            id: tenant.planId,
            reasoningRequestId: `reasoning-${tenant.planId}`,
            goal: "Verify tenant isolation for legacy resume audit IDs",
            status: "WAITING_APPROVAL",
            risk: "HIGH",
            resolvedReferences: [],
            assumptions: [],
            unresolvedQuestions: [],
            requiredCapabilities: [],
            steps: actions.map((action, index) => ({
                id: `${tenant.planId}-step-${index + 1}`,
                order: index + 1,
                action,
                title: `${action} task`,
                description: `Tenant-isolation regression action ${action}`,
                dependencies: index === 0 ? [] : [`${tenant.planId}-step-${index}`],
                requiresApproval: false,
                risk: "LOW",
                verificationRequired: true,
            })),
            expectedOutputs: ["Completed tasks", "Verification results", "Evidence records"],
            failureConditions: ["Any task fails", "Any task executes more than once"],
            verificationRequirements: ["Every task completes and is verified"],
            createdAt: new Date().toISOString(),
        };

        await store.mission().create(tenant.planId, plan, tenant.userId);
        await store.approval().create(tenant.approvalId, {
            requestId,
            planId: tenant.planId,
            status: "APPROVED",
            createdAt: new Date().toISOString(),
            approvedAt: new Date().toISOString(),
            decision: "APPROVED",
            decisionId: `decision-${tenant.planId}`,
            approverId: tenant.userId,
            decidedAt: new Date().toISOString(),
            decisionReason: "Cross-tenant audit collision regression",
        }, tenant.userId);
    }

    // Simulate an unresolved legacy marker owned by Tenant A.
    const tenantA = tenants[0];
    const tenantAStore = createHappyStateStore(
        persistence,
        tenantA.organizationId,
        tenantA.workspaceId,
        tenantA.userId,
    );

    await tenantAStore.audit().create(
        `audit-resume-${requestId}`,
        {
            event: "PIPELINE_RESUME_OUTCOME_UNKNOWN",
            requestId,
            approvalId: tenantA.approvalId,
            planId: tenantA.planId,
            finalStatus: "RECONCILIATION_REQUIRED",
            reconciliationRequired: true,
        },
        tenantA.userId,
    );

    const tenantB = tenants[1];
    const tenantBEngine = new HappyOrchestrationEngine(stateFile);
    const tenantBRecorder = new RecordingExecutionEngine();

    (tenantBEngine as unknown as { execution: RecordingExecutionEngine }).execution =
        tenantBRecorder;

    // Tenant B uses the same requestId, but must not be blocked by Tenant A's marker.
    const tenantBResult = await tenantBEngine.resumeAfterApproval(
        requestId,
        tenantB.approvalId,
        tenantB.planId,
        tenantB.organizationId,
        tenantB.workspaceId,
        tenantB.userId,
    );

    assert(
        tenantBResult.status === "COMPLETED",
        `Tenant B expected COMPLETED, got ${tenantBResult.status}`,
    );
    assert(
        tenantBRecorder.calls.length === actions.length,
        `Tenant B expected ${actions.length} execution calls, got ${tenantBRecorder.calls.length}`,
    );

    // Tenant A's unresolved marker must still prevent an unsafe replay.
    const tenantAEngine = new HappyOrchestrationEngine(stateFile);
    const tenantARecorder = new RecordingExecutionEngine();

    (tenantAEngine as unknown as { execution: RecordingExecutionEngine }).execution =
        tenantARecorder;

    let tenantAError = "";
    try {
        await tenantAEngine.resumeAfterApproval(
            requestId,
            tenantA.approvalId,
            tenantA.planId,
            tenantA.organizationId,
            tenantA.workspaceId,
            tenantA.userId,
        );
    } catch (error) {
        tenantAError = error instanceof Error ? error.message : String(error);
    }

    assert(
        tenantAError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Tenant A expected fail-closed reconciliation, got "${tenantAError}"`,
    );
    assert(
        tenantARecorder.calls.length === 0,
        `Tenant A unexpectedly executed ${tenantARecorder.calls.length} actions during retry`,
    );

    console.log(JSON.stringify({
        test: "resume-after-approval-cross-tenant-audit-collision",
        tenantBStatus: tenantBResult.status,
        tenantBExecutionCalls: tenantBRecorder.calls.length,
        tenantARepeatError: tenantAError,
        tenantARepeatExecutionCalls: tenantARecorder.calls.length,
        status: "PASS",
    }, null, 2));
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
