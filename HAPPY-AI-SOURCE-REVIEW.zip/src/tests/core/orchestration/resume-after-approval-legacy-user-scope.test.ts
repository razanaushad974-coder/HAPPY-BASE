import { join } from "node:path";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

class RecordingExecutionEngine {
    readonly calls: ExecutionRequest[] = [];

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);
        const now = new Date().toISOString();
        return {
            id: `legacy-user-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };
    }
}

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

async function main(): Promise<void> {
    const dir = await mkdtemp(join(tmpdir(), "happy-resume-legacy-user-"));
    const stateFile = join(dir, "state.json");
    const persistence = new PersistenceService(new JsonFileStateAdapter(stateFile));

    const scope = {
        organizationId: "org-legacy-scope-test",
        workspaceId: "workspace-legacy-scope-test",
        userId: "user-legacy-scope-test",
    };
    const requestId = "legacy-missing-user-request";
    const approvalId = "legacy-missing-user-approval";
    const planId = "legacy-missing-user-plan";

    const actions = ["UNDERSTAND", "BUILD", "TEST", "VERIFY", "CONTROL"] as const;
    const store = createHappyStateStore(
        persistence,
        scope.organizationId,
        scope.workspaceId,
        scope.userId,
    );

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId: "reasoning-legacy-missing-user",
        goal: "Verify fail-closed handling of legacy audit records without user scope",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: actions.map((action, index) => ({
            id: `${planId}-step-${index + 1}`,
            order: index + 1,
            action,
            title: `${action} task`,
            description: "Legacy user-scope fail-closed regression",
            dependencies: index === 0 ? [] : [`${planId}-step-${index}`],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        })),
        expectedOutputs: ["Completed and verified tasks"],
        failureConditions: ["Unsafe resume execution"],
        verificationRequirements: ["Resume must fail before execution"],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(planId, plan, scope.userId);
    await store.approval().create(approvalId, {
        requestId,
        planId,
        status: "APPROVED",
        createdAt: new Date().toISOString(),
        approvedAt: new Date().toISOString(),
        decision: "APPROVED",
        decisionId: "decision-legacy-missing-user",
        approverId: scope.userId,
        decidedAt: new Date().toISOString(),
        decisionReason: "Legacy user-scope regression",
    }, scope.userId);

    // Seed the old un-namespaced marker with tenant metadata but no userId.
    // This deliberately bypasses the scoped repository to model a legacy record.
    persistence.create("AUDIT_EVENT", `audit-resume-${requestId}`, {
        data: {
            event: "PIPELINE_RESUME_OUTCOME_UNKNOWN",
            requestId,
            approvalId,
            planId,
            finalStatus: "RECONCILIATION_REQUIRED",
            reconciliationRequired: true,
        },
        organizationId: scope.organizationId,
        workspaceId: scope.workspaceId,
    });

    const engine = new HappyOrchestrationEngine(stateFile);
    const recorder = new RecordingExecutionEngine();
    (engine as unknown as { execution: RecordingExecutionEngine }).execution = recorder;

    let actualError = "";
    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            scope.organizationId,
            scope.workspaceId,
            scope.userId,
        );
    } catch (error) {
        actualError = error instanceof Error ? error.message : String(error);
    }

    assert(
        actualError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Expected fail-closed reconciliation, received "${actualError}"`,
    );
    assert(
        recorder.calls.length === 0,
        `Unsafe execution detected: ${recorder.calls.length} action(s) executed`,
    );

    console.log(JSON.stringify({
        test: "resume-after-approval-legacy-user-scope",
        legacyUserId: "MISSING",
        error: actualError,
        executionCalls: recorder.calls.length,
        status: "PASS",
    }, null, 2));
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
