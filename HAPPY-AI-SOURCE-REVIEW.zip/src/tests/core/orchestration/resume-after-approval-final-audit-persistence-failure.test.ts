import { join } from "node:path";
import { tmpdir } from "node:os";
import { mkdtemp } from "node:fs/promises";
import { it } from "vitest";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import type { EntityType, PersistedRecord } from "../../../core/persistence/types";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

const PERSISTENCE_FAILURE = "INJECTED_FINAL_AUDIT_PERSISTENCE_FAILURE";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

class SuccessfulExecutionRecorder {
    public readonly calls: ExecutionRequest[] = [];
    public returnedSuccess = false;

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);

        const now = new Date().toISOString();
        const result: ExecutionResult = {
            id: `result-persistence-failure-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };

        this.returnedSuccess = true;
        return result;
    }
}

class FailExecutionResultUpdateOnce extends PersistenceService {
    private injected = false;

    constructor(
        adapter: JsonFileStateAdapter,
        private readonly executionReturnedSuccess: () => boolean,
    ) {
        super(adapter);
    }

    override update<T>(
        entityType: EntityType,
        id: string,
        data: T,
    ): PersistedRecord<T> {
        const payload = data as Record<string, unknown>;
        const nestedData = payload["data"];
        const auditData =
            nestedData !== null && typeof nestedData === "object"
                ? nestedData as Record<string, unknown>
                : payload;

        if (
            !this.injected &&
            entityType === "AUDIT_EVENT" &&
            auditData["event"] === "PIPELINE_RESUMED_AFTER_APPROVAL_COMPLETED" &&
            this.executionReturnedSuccess()
        ) {
            this.injected = true;
            throw new Error(PERSISTENCE_FAILURE);
        }

        return super.update<T>(entityType, id, data);
    }
}

it("fails closed when final resume audit persistence fails", async () => {
    const stateDir = await mkdtemp(
        join(tmpdir(), "happy-final-audit-persistence-failure-"),
    );
    const stateFile = join(stateDir, "orchestration-state.json");

    const setupPersistence = new PersistenceService(
        new JsonFileStateAdapter(stateFile),
    );
    const store = createHappyStateStore(
        setupPersistence,
        "org-final-audit-failure",
        "workspace-final-audit-failure",
        "user-final-audit-failure",
    );

    const requestId = "resume-final-audit-failure";
    const approvalId = "approval-final-audit-failure";
    const planId = "plan-final-audit-failure";

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId: "reasoning-final-audit-failure",
        goal: "Verify no replay after execution-result persistence failure",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: [{
            id: "plan-step-final-audit-failure-1",
            order: 1,
            action: "BUILD",
            title: "Persistence failure test task",
            description: "A deterministic task for crash recovery testing.",
            dependencies: [],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        }],
        expectedOutputs: ["One completed execution result"],
        failureConditions: [
            "The execution action is replayed after an uncertain outcome.",
        ],
        verificationRequirements: [
            "The execution result must be persisted before completion is claimed.",
        ],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(planId, plan, "user-final-audit-failure");
    await store.approval().create(
        approvalId,
        {
            requestId,
            planId,
            status: "APPROVED",
            createdAt: new Date().toISOString(),
            approvedAt: new Date().toISOString(),
            decision: "APPROVED",
            decisionId: "decision-result-persistence-failure",
            approverId: "user-final-audit-failure",
            decidedAt: new Date().toISOString(),
            decisionReason: "Deterministic recovery regression test.",
        },
        "user-final-audit-failure",
    );

    const recorder = new SuccessfulExecutionRecorder();
    const failingPersistence = new FailExecutionResultUpdateOnce(
        new JsonFileStateAdapter(stateFile),
        () => recorder.returnedSuccess,
    );

    const engine = new HappyOrchestrationEngine(stateFile, failingPersistence);
    (engine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let initialError = "";
    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-final-audit-failure",
            "workspace-final-audit-failure",
            "user-final-audit-failure",
        );
    } catch (error) {
        initialError = error instanceof Error ? error.message : String(error);
    }

    assert(recorder.returnedSuccess, "Executor did not return its successful result.");
    assert(
        initialError.includes(PERSISTENCE_FAILURE),
        `Expected injected final-audit persistence failure, received: ${initialError}`,
    );
    assert(
        recorder.calls.length === 1,
        `Expected one initial execution, got ${recorder.calls.length}.`,
    );

    const auditId =
        `audit-resume:${encodeURIComponent("org-final-audit-failure")}:` +
        `${encodeURIComponent("workspace-final-audit-failure")}:` +
        `${encodeURIComponent("user-final-audit-failure")}:` +
        `${encodeURIComponent(requestId)}`;

    const persistedStore = createHappyStateStore(
        new PersistenceService(new JsonFileStateAdapter(stateFile)),
        "org-final-audit-failure",
        "workspace-final-audit-failure",
        "user-final-audit-failure",
    );

    const audit = await persistedStore.audit<Record<string, unknown>>().get(auditId);
    assert(
        audit?.data.event === "PIPELINE_RESUME_STARTED",
        `Expected durable start marker after final audit update failure; got ${String(audit?.data.event)}.`,
    );
    assert(
        audit?.data.finalStatus === "RUNNING",
        `Expected original RUNNING marker to remain; got ${String(audit?.data.finalStatus)}.`,
    );
    const retryEngine = new HappyOrchestrationEngine(stateFile);
    (retryEngine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let retryError = "";
    try {
        await retryEngine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-final-audit-failure",
            "workspace-final-audit-failure",
            "user-final-audit-failure",
        );
    } catch (error) {
        retryError = error instanceof Error ? error.message : String(error);
    }

    assert(
        retryError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Expected fail-closed retry; got: ${retryError}`,
    );
    assert(
        recorder.calls.length === 1,
        `FAIL-CLOSED REGRESSION: action replayed; execution calls=${recorder.calls.length}.`,
    );

    console.log("EXECUTOR_RETURNED_COMPLETED: PASS");
    console.log("FINAL_AUDIT_PERSISTENCE_FAILURE: PASS");
    console.log("DURABLE_START_MARKER_REMAINS: PASS");
    console.log("NO_AUTOMATIC_REPLAY: PASS");
    console.log(JSON.stringify({
        initialError,
        retryError,
        executionCalls: recorder.calls.length,
        persistedAuditEvent: audit?.data.event,
        persistedFinalStatus: audit?.data.finalStatus,
        durableStartMarkerRemains: true,
    }, null, 2));
});

