import { join } from "node:path";
import { tmpdir } from "node:os";
import { mkdtemp } from "node:fs/promises";
import { it } from "vitest";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import type { EntityType, PersistedRecord } from "../../../core/persistence/types";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

const PERSISTENCE_FAILURE = "INJECTED_EVIDENCE_CREATE_PERSISTENCE_FAILURE";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

class SuccessfulExecutionRecorder {
    public readonly calls: ExecutionRequest[] = [];
    public returnedSuccess = false;

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);

        const now = new Date().toISOString();
        const result: ExecutionResult = {
            id: `result-persistence-failure-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };

        this.returnedSuccess = true;
        return result;
    }
}

class FailEvidenceCreateOnce extends PersistenceService {
    private injected = false;

    constructor(
        adapter: JsonFileStateAdapter,
        private readonly executionReturnedSuccess: () => boolean,
    ) {
        super(adapter);
    }

    override create<T>(
        entityType: EntityType,
        id: string,
        data: T,
    ): PersistedRecord<T> {
        if (
            !this.injected &&
            entityType === "EVIDENCE" &&
            this.executionReturnedSuccess()
        ) {
            this.injected = true;
            throw new Error(PERSISTENCE_FAILURE);
        }

        return super.create<T>(entityType, id, data);
    }
}

it("fails closed when evidence persistence fails after execution", async () => {
    const stateDir = await mkdtemp(
        join(tmpdir(), "happy-evidence-create-persistence-failure-"),
    );
    const stateFile = join(stateDir, "orchestration-state.json");

    const setupPersistence = new PersistenceService(
        new JsonFileStateAdapter(stateFile),
    );
    const store = createHappyStateStore(
        setupPersistence,
        "org-evidence-create-failure",
        "workspace-evidence-create-failure",
        "user-evidence-create-failure",
    );

    const requestId = "resume-evidence-create-failure";
    const approvalId = "approval-evidence-create-failure";
    const planId = "plan-evidence-create-failure";

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId: "reasoning-evidence-create-failure",
        goal: "Verify no replay after evidence persistence failure",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: [{
            id: "plan-step-evidence-create-failure-1",
            order: 1,
            action: "BUILD",
            title: "Persistence failure test task",
            description: "A deterministic task for crash recovery testing.",
            dependencies: [],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        }],
        expectedOutputs: ["One completed execution result"],
        failureConditions: [
            "The execution action is replayed after an uncertain outcome.",
        ],
        verificationRequirements: [
            "The execution result must be persisted before completion is claimed.",
        ],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(planId, plan, "user-evidence-create-failure");
    await store.approval().create(
        approvalId,
        {
            requestId,
            planId,
            status: "APPROVED",
            createdAt: new Date().toISOString(),
            approvedAt: new Date().toISOString(),
            decision: "APPROVED",
            decisionId: "decision-evidence-persistence-failure",
            approverId: "user-evidence-create-failure",
            decidedAt: new Date().toISOString(),
            decisionReason: "Deterministic recovery regression test.",
        },
        "user-evidence-create-failure",
    );

    const recorder = new SuccessfulExecutionRecorder();
    const failingPersistence = new FailEvidenceCreateOnce(
        new JsonFileStateAdapter(stateFile),
        () => recorder.returnedSuccess,
    );

    const engine = new HappyOrchestrationEngine(stateFile, failingPersistence);
    (engine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let initialError = "";
    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-evidence-create-failure",
            "workspace-evidence-create-failure",
            "user-evidence-create-failure",
        );
    } catch (error) {
        initialError = error instanceof Error ? error.message : String(error);
    }

    assert(recorder.returnedSuccess, "Executor did not return its successful result.");
    assert(
        initialError.includes(PERSISTENCE_FAILURE),
        `Expected injected evidence-create persistence failure, received: ${initialError}`,
    );
    assert(
        recorder.calls.length === 1,
        `Expected one initial execution, got ${recorder.calls.length}.`,
    );

    const auditId =
        `audit-resume:${encodeURIComponent("org-evidence-create-failure")}:` +
        `${encodeURIComponent("workspace-evidence-create-failure")}:` +
        `${encodeURIComponent("user-evidence-create-failure")}:` +
        `${encodeURIComponent(requestId)}`;

    const persistedStore = createHappyStateStore(
        new PersistenceService(new JsonFileStateAdapter(stateFile)),
        "org-evidence-create-failure",
        "workspace-evidence-create-failure",
        "user-evidence-create-failure",
    );

    const audit = await persistedStore.audit<Record<string, unknown>>().get(auditId);
    assert(
        audit?.data.event === "PIPELINE_RESUME_STARTED",
        `Expected durable start marker after evidence create failure; got ${String(audit?.data.event)}.`,
    );
    assert(
        audit?.data.finalStatus === "RUNNING",
        `Expected original RUNNING marker to remain; got ${String(audit?.data.finalStatus)}.`,
    );
    const retryEngine = new HappyOrchestrationEngine(stateFile);
    (retryEngine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let retryError = "";
    try {
        await retryEngine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-evidence-create-failure",
            "workspace-evidence-create-failure",
            "user-evidence-create-failure",
        );
    } catch (error) {
        retryError = error instanceof Error ? error.message : String(error);
    }

    assert(
        retryError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Expected fail-closed retry; got: ${retryError}`,
    );
    assert(
        recorder.calls.length === 1,
        `FAIL-CLOSED REGRESSION: action replayed; execution calls=${recorder.calls.length}.`,
    );

    console.log("EXECUTOR_RETURNED_COMPLETED: PASS");
    console.log("EVIDENCE_CREATE_PERSISTENCE_FAILURE: PASS");
    console.log("DURABLE_START_MARKER_REMAINS: PASS");
    console.log("NO_AUTOMATIC_REPLAY: PASS");
    console.log(JSON.stringify({
        initialError,
        retryError,
        executionCalls: recorder.calls.length,
        persistedAuditEvent: audit?.data.event,
        persistedFinalStatus: audit?.data.finalStatus,
        durableStartMarkerRemains: true,
    }, null, 2));
});


