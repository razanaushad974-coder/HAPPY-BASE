import { join } from "node:path";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

class RecordingExecutionEngine {
    readonly calls: ExecutionRequest[] = [];

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);
        const now = new Date().toISOString();

        return {
            id: `plan-linkage-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };
    }
}

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

async function main(): Promise<void> {
    const dir = await mkdtemp(join(tmpdir(), "happy-resume-plan-linkage-"));
    const stateFile = join(dir, "state.json");
    const persistence = new PersistenceService(new JsonFileStateAdapter(stateFile));

    const scope = {
        organizationId: "org-plan-linkage-test",
        workspaceId: "workspace-plan-linkage-test",
        userId: "user-plan-linkage-test",
    };

    const requestId = "plan-linkage-request";
    const approvalId = "plan-linkage-approval";
    const requestedPlanId = "requested-plan-id";
    const embeddedPlanId = "different-embedded-plan-id";

    const store = createHappyStateStore(
        persistence,
        scope.organizationId,
        scope.workspaceId,
        scope.userId,
    );

    const actions = ["UNDERSTAND", "BUILD", "TEST", "VERIFY", "CONTROL"] as const;

    // Deliberately store a plan under requestedPlanId whose own id disagrees.
    const plan: ExecutionPlan = {
        id: embeddedPlanId,
        reasoningRequestId: "reasoning-plan-linkage",
        goal: "Verify mismatched execution-plan identity is rejected",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: actions.map((action, index) => ({
            id: `${embeddedPlanId}-step-${index + 1}`,
            order: index + 1,
            action,
            title: `${action} task`,
            description: "Plan identity mismatch regression",
            dependencies: index === 0 ? [] : [`${embeddedPlanId}-step-${index}`],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        })),
        expectedOutputs: ["Plan identity mismatch rejected"],
        failureConditions: ["Execution proceeds with mismatched plan identity"],
        verificationRequirements: ["Reject before execution"],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(requestedPlanId, plan, scope.userId);

    await store.approval().create(approvalId, {
        requestId,
        planId: requestedPlanId,
        status: "APPROVED",
        createdAt: new Date().toISOString(),
        approvedAt: new Date().toISOString(),
        decision: "APPROVED",
        decisionId: "decision-plan-linkage",
        approverId: scope.userId,
        decidedAt: new Date().toISOString(),
        decisionReason: "Plan linkage regression test",
    }, scope.userId);

    const engine = new HappyOrchestrationEngine(stateFile);
    const recorder = new RecordingExecutionEngine();

    (engine as unknown as { execution: RecordingExecutionEngine }).execution = recorder;

    let actualError = "";

    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            requestedPlanId,
            scope.organizationId,
            scope.workspaceId,
            scope.userId,
        );
    } catch (error) {
        actualError = error instanceof Error ? error.message : String(error);
    }

    assert(
        actualError === "EXECUTION_PLAN_LINKAGE_MISMATCH",
        `Expected EXECUTION_PLAN_LINKAGE_MISMATCH, received "${actualError}"`,
    );

    assert(
        recorder.calls.length === 0,
        `Unsafe execution detected: ${recorder.calls.length} action(s) executed`,
    );

    console.log(JSON.stringify({
        test: "resume-after-approval-plan-linkage",
        requestedPlanId,
        embeddedPlanId,
        error: actualError,
        executionCalls: recorder.calls.length,
        status: "PASS",
    }, null, 2));
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
