import {
  mkdtempSync,
  readFileSync,
  rmSync,
} from "node:fs";

import {
  tmpdir,
} from "node:os";

import {
  join,
} from "node:path";

import {
  HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import type {
  ExecutionRequest,
  ExecutionResult,
} from "../../../core/execution/types";

import type {
  ExecutionRuntimeContext,
} from "../../../core/execution/runtime-context";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

function assertDefined<T>(
  value: T | undefined,
  message: string,
): asserts value is T {
  if (value === undefined) {
    throw new Error(message);
  }
}

class RecordingExecutionEngine {
  public calls = 0;

  public lastRequest:
    | ExecutionRequest
    | undefined;

  public lastRuntimeContext:
    | ExecutionRuntimeContext
    | undefined;

  async execute(
    request: ExecutionRequest,
    runtimeContext: ExecutionRuntimeContext = {},
  ): Promise<ExecutionResult> {
    this.calls += 1;
    this.lastRequest = request;
    this.lastRuntimeContext = runtimeContext;

    return {
      id:
        `recorded-execution-${request.id}`,
      requestId:
        request.id,
      capability:
        request.capability,
      status:
        "COMPLETED",
      output: {
        runtimeBinding:
          "RECORDED_EXECUTION_ENGINE",
      },
      evidenceIds: [],
      startedAt:
        new Date().toISOString(),
      completedAt:
        new Date().toISOString(),
    };
  }
}

async function main(): Promise<void> {
  const tempDirectory =
    mkdtempSync(
      join(
        tmpdir(),
        "happy-20m-",
      ),
    );

  const persistenceFile =
    join(
      tempDirectory,
      "orchestration-state.json",
    );

  try {
    const orchestration =
      new HappyOrchestrationEngine(
        persistenceFile,
      );

    const recorder =
      new RecordingExecutionEngine();

    (
      orchestration as unknown as {
        execution:
          RecordingExecutionEngine;
      }
    ).execution = recorder;

    const request = {
      id:
        `execution-verification-evidence-${Date.now()}`,
      command:
        "verify the execution result and persist the evidence",
      organizationId:
        "runtime-20m-org",
      workspaceId:
        "runtime-20m-workspace",
      userId:
        "runtime-20m-user",
      source:
        "TEXT" as const,
      authorization: {
          role: "USER" as const,
          scope: "WORKSPACE" as const,
          roleSource: "TRUSTED_SERVER" as const,
          authenticated: true,
      },
      approved:
        true,
      createdAt:
        new Date().toISOString(),
    };

    const result =
      await orchestration.run(
        request,
      );

    assert(
      recorder.calls >= 1,
      `Expected at least one delegated execution call, received ${recorder.calls}.`,
    );

    const executionRequest =
      recorder.lastRequest;

    assertDefined(
      executionRequest,
      "Execution request was not delegated.",
    );

    assert(
      result.executionRequestId ===
        executionRequest.id,
      "Final result does not reference the delegated execution request.",
    );

    assert(
      typeof result.verificationRequestId ===
        "string" &&
      result.verificationRequestId.length > 0,
      "Verification request was not created or returned.",
    );

    assertDefined(
      result.verificationRequestId,
      "Verification request ID missing.",
    );

    assert(
      result.evidenceIds.length > 0,
      "No evidence ID was produced by the execution → evidence → verification chain.",
    );

    assert(
      result.status ===
        "COMPLETED",
      `Expected final pipeline status COMPLETED, received ${result.status}.`,
    );

    assert(
      result.currentStage ===
        "COMPLETE",
      `Expected final pipeline stage COMPLETE, received ${result.currentStage}.`,
    );

    assert(
      result.persisted ===
        true,
      "Final pipeline result was not marked persisted.",
    );

    assert(
      result.output !== undefined,
      "Execution output did not reach the final pipeline result.",
    );

    const outputCandidates =
      Array.isArray(result.output)
        ? result.output
        : [
            result.output,
          ];

    const recordedOutput =
      outputCandidates.find(
        (value) =>
          value &&
          typeof value === "object" &&
          "runtimeBinding" in value &&
          (
            value as {
              runtimeBinding?: unknown;
            }
          ).runtimeBinding ===
            "RECORDED_EXECUTION_ENGINE",
      ) as {
        runtimeBinding?: unknown;
      } | undefined;

    assert(
      recordedOutput !== undefined,
      "Execution output was not propagated through verification/persistence flow.",
    );

    assert(
      recordedOutput?.runtimeBinding ===
        "RECORDED_EXECUTION_ENGINE",
      "Recorded execution output binding was not preserved.",
    );

    const executionStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "EXECUTION",
      );

    const verificationStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "VERIFICATION",
      );

    const evidenceStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "EVIDENCE",
      );

    const persistStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "PERSIST",
      );

    assertDefined(
      executionStage,
      "EXECUTION stage missing from pipeline trace.",
    );

    assertDefined(
      verificationStage,
      "VERIFICATION stage missing from pipeline trace.",
    );

    assertDefined(
      evidenceStage,
      "EVIDENCE stage missing from pipeline trace.",
    );

    assertDefined(
      persistStage,
      "PERSIST stage missing from pipeline trace.",
    );

    assert(
      verificationStage.status ===
        "COMPLETED",
      `VERIFICATION stage was not COMPLETED. Received ${verificationStage.status}.`,
    );

    assert(
      evidenceStage.status ===
        "COMPLETED",
      `EVIDENCE stage was not COMPLETED. Received ${evidenceStage.status}.`,
    );assert(
      persistStage.status ===
        "COMPLETED",
      `PERSIST stage was not COMPLETED. Received ${persistStage.status}.`,
    );

    assert(
      typeof result.verificationRequestId ===
        "string",
      "Verification request ID missing for persistence check.",
    );

    const evidenceId =
      result.evidenceIds[0];

    assert(
      typeof evidenceId ===
        "string" &&
      evidenceId.length > 0,
      "First evidence ID is invalid.",
    );

    assert(
      (
        readFileSync(
          persistenceFile,
          "utf8",
        ).includes(
          executionRequest.id,
        )
      ),
      "Persisted state does not contain the execution request ID.",
    );

    assert(
      (
        readFileSync(
          persistenceFile,
          "utf8",
        ).includes(
          result.verificationRequestId,
        )
      ),
      "Persisted state does not contain the verification request ID.",
    );

    assert(
      (
        readFileSync(
          persistenceFile,
          "utf8",
        ).includes(
          evidenceId,
        )
      ),
      "Persisted state does not contain the evidence ID.",
    );

    console.log(
      "Execution → Evidence → Verification → Persist test: PASS",
    );

    console.log({
      executionCalls:
        recorder.calls,
      executionRequestId:
        executionRequest.id,
      verificationRequestId:
        result.verificationRequestId,
      evidenceCount:
        result.evidenceIds.length,
      firstEvidenceId:
        evidenceId,
      executionStage:
        executionStage.status,
      verificationStage:
        verificationStage.status,
      evidenceStage:
        evidenceStage.status,
      persistStage:
        persistStage.status,
      finalStatus:
        result.status,
      finalStage:
        result.currentStage,
      outputPropagated:
        recordedOutput?.runtimeBinding ===
        "RECORDED_EXECUTION_ENGINE",
      executionPersisted:
        true,
      verificationPersisted:
        true,
      evidencePersisted:
        true,
      noRealAdapterExecuted:
        true,
    });
  } finally {
    rmSync(
      tempDirectory,
      {
        recursive: true,
        force: true,
      },
    );
  }
}

main().catch(
  (error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  },
);




