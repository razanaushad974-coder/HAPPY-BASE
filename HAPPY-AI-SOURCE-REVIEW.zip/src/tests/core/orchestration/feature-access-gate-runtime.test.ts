import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const gate = vi.hoisted(() => ({
  decision: "APPROVAL_REQUIRED" as
    | "APPROVAL_REQUIRED"
    | "BLOCKED"
    | "NOT_YET_CONNECTED",
}));

vi.mock("../../../core/authorization/happy-feature-access", () => ({
  evaluateHappyFeatureAccess: () => ({
    allowed: false,
    decision: gate.decision,
    reason: `test gate decision: ${gate.decision}`,
  }),
}));

vi.mock("../../../core/happy/kernel/runtime/happy-execution-route", () => ({
  resolveHappyModuleExecutionRoute: () => ({
    executionCapability: "test-capability",
    binding: { status: "NOT_YET_CONNECTED" },
  }),
}));

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";

const tempDirectories: string[] = [];

afterEach(() => {
  for (const directory of tempDirectories.splice(0)) {
    rmSync(directory, { recursive: true, force: true });
  }
  vi.clearAllMocks();
});

async function runGateCase(
  decision: typeof gate.decision,
) {
  gate.decision = decision;

  const directory = mkdtempSync(join(tmpdir(), "happy-feature-gate-"));
  tempDirectories.push(directory);
  const persistenceFile = join(directory, "state.json");

  const engine = new HappyOrchestrationEngine(persistenceFile);

  const plan = {
    id: `gate-plan-${decision}`,
    reasoningRequestId: `gate-reason-${decision}`,
    goal: "controlled feature gate regression",
    status: "READY",
    risk: "LOW",
    resolvedReferences: [],
    assumptions: [],
    unresolvedQuestions: [],
    requiredCapabilities: [],
    steps: [{
      id: `step-${decision}`,
      order: 1,
      action: "AUTOMATE",
      title: "Controlled automation step",
      description: "Regression-only synthetic task",
      dependencies: [],
      requiresApproval: false,
      verificationRequired: false,
    }],
    expectedOutputs: [],
    failureConditions: [],
    verificationRequirements: [],
    createdAt: new Date().toISOString(),
  };

  const reasoning = (engine as unknown as {
    reasoning: { createAIExecutionPlan: (input: unknown) => Promise<unknown> };
  }).reasoning;

  reasoning.createAIExecutionPlan = async () => plan;

  const execution = (engine as unknown as {
    execution: { execute: (...args: unknown[]) => Promise<unknown> };
  }).execution;

  let executionCalls = 0;
  execution.execute = async () => {
    executionCalls += 1;
    throw new Error("Execution must not run when the feature gate denies access.");
  };

  const requestId = `gate-request-${decision}`;
  const result = await engine.run({
    id: requestId,
    command: "run controlled automation test",
    organizationId: `gate-org-${decision}`,
    workspaceId: `gate-workspace-${decision}`,
    userId: `gate-user-${decision}`,
    source: "TEXT",
    authorization: {
      role: "FOUNDER",
      scope: "FOUNDER",
      roleSource: "TRUSTED_SERVER",
      authenticated: true,
    },
    approved: false,
    createdAt: new Date().toISOString(),
  });

  const persisted = readFileSync(persistenceFile, "utf8");

  return { result, persisted, executionCalls, requestId, plan };
}

describe("feature access gate runtime regression", () => {
  it("persists approval and waiting mission/task state without executing", async () => {
    const { result, persisted, executionCalls, requestId } =
      await runGateCase("APPROVAL_REQUIRED");

    expect(result.status).toBe("WAITING_APPROVAL");
    expect(result.currentStage).toBe("APPROVAL");
    expect(executionCalls).toBe(0);
    expect(persisted).toContain(`approval-${requestId}`);
    expect(persisted).toContain("PIPELINE_WAITING_APPROVAL");
    expect(persisted).toContain('"WAITING_APPROVAL"');
    expect(persisted).toContain('"PENDING"');
  });

  it("persists BLOCKED state and never executes", async () => {
    const { result, persisted, executionCalls } =
      await runGateCase("BLOCKED");

    expect(result.status).toBe("BLOCKED");
    expect(result.currentStage).toBe("EXECUTION");
    expect(executionCalls).toBe(0);
    expect(persisted).toContain('"BLOCKED"');
  });

  it("preserves NOT_YET_CONNECTED and never executes", async () => {
    const { result, executionCalls } =
      await runGateCase("NOT_YET_CONNECTED");

    expect(result.status).toBe("NOT_YET_CONNECTED");
    expect(result.currentStage).toBe("EXECUTION");
    expect(executionCalls).toBe(0);
  });
});
