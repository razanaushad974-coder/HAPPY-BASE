import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { PersistenceService } from "../../../core/persistence/service";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import type { EntityType, PersistedRecord } from "../../../core/persistence/types";

const gate = vi.hoisted(() => ({ decision: "APPROVAL_REQUIRED" }));

vi.mock("../../../core/authorization/happy-feature-access", () => ({
  evaluateHappyFeatureAccess: () => ({
    allowed: false,
    decision: gate.decision,
    reason: "Injected persistence-failure regression",
  }),
}));

vi.mock("../../../core/happy/kernel/runtime/happy-execution-route", () => ({
  resolveHappyModuleExecutionRoute: () => ({
    executionCapability: "test-capability",
    binding: { status: "NOT_YET_CONNECTED" },
  }),
}));

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";

const tempDirectories: string[] = [];
const PERSISTENCE_FAILURE = "INJECTED_FEATURE_GATE_TASK_PERSISTENCE_FAILURE";

class FailPendingTaskUpdateOnce extends PersistenceService {
  private injected = false;

  override update<T>(
    entityType: EntityType,
    id: string,
    data: T,
  ): PersistedRecord<T> {
    const candidate = data as { data?: { status?: unknown } };

    if (
      !this.injected &&
      entityType === "TASK" &&
      candidate.data?.status === "PENDING"
    ) {
      this.injected = true;
      throw new Error(PERSISTENCE_FAILURE);
    }

    return super.update<T>(entityType, id, data);
  }
}

afterEach(() => {
  for (const directory of tempDirectories.splice(0)) {
    rmSync(directory, { recursive: true, force: true });
  }
  vi.clearAllMocks();
});

describe("feature gate persistence failure", () => {
  it("never reports successful waiting approval when task persistence fails", async () => {
    gate.decision = "APPROVAL_REQUIRED";

    const directory = mkdtempSync(join(tmpdir(), "happy-gate-persist-failure-"));
    tempDirectories.push(directory);
    const persistenceFile = join(directory, "state.json");

    const persistence = new FailPendingTaskUpdateOnce(
      new JsonFileStateAdapter(persistenceFile),
    );
    const engine = new HappyOrchestrationEngine(undefined, persistence);

    const plan = {
      id: "gate-persist-failure-plan",
      reasoningRequestId: "gate-persist-failure-reason",
      goal: "Test feature gate persistence failure",
      status: "READY",
      risk: "LOW",
      resolvedReferences: [],
      assumptions: [],
      unresolvedQuestions: [],
      requiredCapabilities: [],
      steps: [{
        id: "gate-persist-failure-step",
        order: 1,
        action: "AUTOMATE",
        title: "Synthetic automation",
        description: "Regression-only task",
        dependencies: [],
        requiresApproval: false,
        verificationRequired: false,
      }],
      expectedOutputs: [],
      failureConditions: [],
      verificationRequirements: [],
      createdAt: new Date().toISOString(),
    };

    const reasoning = (engine as unknown as {
      reasoning: { createAIExecutionPlan: (input: unknown) => Promise<unknown> };
    }).reasoning;
    reasoning.createAIExecutionPlan = async () => plan;

    let executionCalls = 0;
    const execution = (engine as unknown as {
      execution: { execute: (...args: unknown[]) => Promise<unknown> };
    }).execution;
    execution.execute = async () => {
      executionCalls += 1;
      throw new Error("Execution must not run after a denied feature gate.");
    };

    let result: { status?: string } | undefined;
    let caughtError: unknown;

    try {
      result = await engine.run({
        id: "gate-persist-failure-request",
        command: "test controlled automation",
        organizationId: "gate-failure-org",
        workspaceId: "gate-failure-workspace",
        userId: "gate-failure-user",
        source: "TEXT",
        authorization: {
          role: "FOUNDER",
          scope: "FOUNDER",
          roleSource: "TRUSTED_SERVER",
          authenticated: true,
        },
        approved: false,
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      caughtError = error;
    }

    expect(executionCalls).toBe(0);

    if (caughtError !== undefined) {
      expect(String(caughtError)).toContain(PERSISTENCE_FAILURE);
    } else {
      expect(result?.status).not.toBe("WAITING_APPROVAL");
    }

    const persisted = readFileSync(persistenceFile, "utf8");

    // Approval/audit may persist before the failing task update; no atomic
    // rollback is assumed by this regression.
    expect(persisted).toContain("approval-gate-persist-failure-request");
    expect(persisted).toContain("PIPELINE_WAITING_APPROVAL");
  });
});
