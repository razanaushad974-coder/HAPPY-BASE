import { join } from "node:path";
import { tmpdir } from "node:os";
import { mkdtemp } from "node:fs/promises";
import { it } from "vitest";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import type { EntityType, PersistedRecord } from "../../../core/persistence/types";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

const PERSISTENCE_FAILURE = "INJECTED_EXECUTION_AND_RECOVERY_AUDIT_PERSISTENCE_FAILURE";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

class SuccessfulExecutionRecorder {
    public readonly calls: ExecutionRequest[] = [];
    public returnedSuccess = false;

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        this.calls.push(request);

        const now = new Date().toISOString();
        const result: ExecutionResult = {
            id: `result-persistence-failure-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };

        this.returnedSuccess = true;
        return result;
    }
}

class FailCompoundPersistenceOnce extends PersistenceService {
    executionFailureWasInjected = false;
    recoveryAuditFailureWasInjected = false;
    private executionFailureInjected = false;
    private recoveryAuditFailureInjected = false;

    constructor(
        adapter: JsonFileStateAdapter,
        private readonly executionReturnedSuccess: () => boolean,
    ) {
        super(adapter);
    }

    override update<T>(
        entityType: EntityType,
        id: string,
        data: T,
    ): PersistedRecord<T> {
        if (
            !this.executionFailureInjected &&
            entityType === "EXECUTION" &&
            this.executionReturnedSuccess()
        ) {
            this.executionFailureInjected = true;
            this.executionFailureWasInjected = true;
            throw new Error(PERSISTENCE_FAILURE);
        }

        const event = (data as { data?: { event?: unknown } } | null)?.data?.event;
        if (
            !this.recoveryAuditFailureInjected &&
            entityType === "AUDIT_EVENT" &&
            event === "PIPELINE_RESUME_OUTCOME_UNKNOWN"
        ) {
            this.recoveryAuditFailureInjected = true;
            this.recoveryAuditFailureWasInjected = true;
            throw new Error("INJECTED_RECOVERY_AUDIT_UPDATE_FAILURE");
        }

        return super.update<T>(entityType, id, data);
    }
}

it("fails closed when execution and recovery-audit persistence both fail", async () => {
    const stateDir = await mkdtemp(
        join(tmpdir(), "happy-recovery-audit-persistence-failure-"),
    );
    const stateFile = join(stateDir, "orchestration-state.json");

    const setupPersistence = new PersistenceService(
        new JsonFileStateAdapter(stateFile),
    );
    const store = createHappyStateStore(
        setupPersistence,
        "org-recovery-audit-failure",
        "workspace-recovery-audit-failure",
        "user-recovery-audit-failure",
    );

    const requestId = "resume-recovery-audit-failure";
    const approvalId = "approval-recovery-audit-failure";
    const planId = "plan-recovery-audit-failure";

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId: "reasoning-recovery-audit-failure",
        goal: "Verify no replay after evidence persistence failure",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: [{
            id: "plan-step-recovery-audit-failure-1",
            order: 1,
            action: "BUILD",
            title: "Persistence failure test task",
            description: "A deterministic task for crash recovery testing.",
            dependencies: [],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        }],
        expectedOutputs: ["One completed execution result"],
        failureConditions: [
            "The execution action is replayed after an uncertain outcome.",
        ],
        verificationRequirements: [
            "The execution result must be persisted before completion is claimed.",
        ],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(planId, plan, "user-recovery-audit-failure");
    await store.approval().create(
        approvalId,
        {
            requestId,
            planId,
            status: "APPROVED",
            createdAt: new Date().toISOString(),
            approvedAt: new Date().toISOString(),
            decision: "APPROVED",
            decisionId: "decision-evidence-persistence-failure",
            approverId: "user-recovery-audit-failure",
            decidedAt: new Date().toISOString(),
            decisionReason: "Deterministic recovery regression test.",
        },
        "user-recovery-audit-failure",
    );

    const recorder = new SuccessfulExecutionRecorder();
    const failingPersistence = new FailCompoundPersistenceOnce(
        new JsonFileStateAdapter(stateFile),
        () => recorder.returnedSuccess,
    );

    const engine = new HappyOrchestrationEngine(stateFile, failingPersistence);
    (engine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let initialError = "";
    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-recovery-audit-failure",
            "workspace-recovery-audit-failure",
            "user-recovery-audit-failure",
        );
    } catch (error) {
        initialError = error instanceof Error ? error.message : String(error);
    }

    assert(recorder.returnedSuccess, "Executor did not return its successful result.");
    assert(failingPersistence.executionFailureWasInjected, "Execution-result persistence failure was not injected.");
    assert(failingPersistence.recoveryAuditFailureWasInjected, "Recovery-audit update failure was not injected.");
    assert(
        initialError.includes(PERSISTENCE_FAILURE),
        `Expected injected execution-result persistence failure, received: ${initialError}`,
    );
    assert(
        recorder.calls.length === 1,
        `Expected one initial execution, got ${recorder.calls.length}.`,
    );

    const auditId =
        `audit-resume:${encodeURIComponent("org-recovery-audit-failure")}:` +
        `${encodeURIComponent("workspace-recovery-audit-failure")}:` +
        `${encodeURIComponent("user-recovery-audit-failure")}:` +
        `${encodeURIComponent(requestId)}`;

    const persistedStore = createHappyStateStore(
        new PersistenceService(new JsonFileStateAdapter(stateFile)),
        "org-recovery-audit-failure",
        "workspace-recovery-audit-failure",
        "user-recovery-audit-failure",
    );

    const audit = await persistedStore.audit<Record<string, unknown>>().get(auditId);
    assert(
        audit?.data.event === "PIPELINE_RESUME_OUTCOME_UNKNOWN" ||
            audit?.data.event === "PIPELINE_RESUME_STARTED",
        `Expected a durable fail-closed audit marker; got ${String(audit?.data.event)}.`,
    );
    if (audit?.data.event === "PIPELINE_RESUME_OUTCOME_UNKNOWN") {
        assert(
            audit.data.finalStatus === "RECONCILIATION_REQUIRED",
            `Expected reconciliation-required status; got ${String(audit?.data.finalStatus)}.`,
        );
    } else {
        assert(
            audit?.data.finalStatus === "RUNNING",
            `Expected original RUNNING marker to remain; got ${String(audit?.data.finalStatus)}.`,
        );
    }
    const retryEngine = new HappyOrchestrationEngine(stateFile);
    (retryEngine as unknown as { execution: SuccessfulExecutionRecorder }).execution = recorder;

    let retryError = "";
    try {
        await retryEngine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-recovery-audit-failure",
            "workspace-recovery-audit-failure",
            "user-recovery-audit-failure",
        );
    } catch (error) {
        retryError = error instanceof Error ? error.message : String(error);
    }

    assert(
        retryError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Expected fail-closed retry; got: ${retryError}`,
    );
    assert(
        recorder.calls.length === 1,
        `FAIL-CLOSED REGRESSION: action replayed; execution calls=${recorder.calls.length}.`,
    );

    console.log("EXECUTOR_RETURNED_COMPLETED: PASS");
    console.log("EXECUTION_AND_RECOVERY_AUDIT_FAILURES: PASS");
    console.log("DURABLE_START_MARKER_REMAINS_AFTER_BOTH_FAILURES: PASS");
    console.log("NO_AUTOMATIC_REPLAY_AFTER_BOTH_FAILURES: PASS");
    console.log(JSON.stringify({
        initialError,
        retryError,
        executionCalls: recorder.calls.length,
        persistedAuditEvent: audit?.data.event,
        persistedFinalStatus: audit?.data.finalStatus,
        durableStartMarkerRemains: true,
    }, null, 2));
});






