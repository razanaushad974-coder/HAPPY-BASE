import {
  createDefaultExecutionRegistry,
} from "../../../core/execution/default-registry";

import {
  ExecutionEngine,
} from "../../../core/execution/engine";

async function main(): Promise<void> {
  const registry =
    createDefaultExecutionRegistry();

  const engine =
    new ExecutionEngine(registry);

  const baseRequest = {
    id: crypto.randomUUID(),
    taskId: crypto.randomUUID(),
    missionId: crypto.randomUUID(),
    action: "UNDERSTAND",
    input: {
      specification: "HAPPY API",
    },
    risk: "HIGH" as const,
    createdAt: new Date().toISOString(),
  };

  // -----------------------------------------------
  // APPROVAL GATE
  // -----------------------------------------------

  const unapprovedResult =
    await engine.execute({
      ...baseRequest,
      capability: "CODE",
      requiresApproval: true,
      approved: false,
    });

  if (
    unapprovedResult.status !==
    "WAITING_APPROVAL"
  ) {
    throw new Error(
      "Approval gate bypass detected.",
    );
  }

  // -----------------------------------------------
  // AVAILABLE CODE ADAPTER
  // -----------------------------------------------

  const codeResult =
    await engine.execute({
      ...baseRequest,
      capability: "CODE",
      requiresApproval: false,
      approved: false,
    });

  if (
    codeResult.status ===
    "NOT_YET_CONNECTED"
  ) {
    throw new Error(
      "Canonical CODE adapter is unexpectedly disconnected.",
    );
  }

  // -----------------------------------------------
  // DISCONNECTED CAPABILITIES
  // -----------------------------------------------

  for (
    const capability of [
      "DEPLOYMENT",
      "PUBLISH",
      "AUTOMATION",
    ] as const
  ) {
    const result =
      await engine.execute({
        ...baseRequest,
        capability,
        requiresApproval: false,
        approved: false,
      });

    if (
      result.status !==
      "NOT_YET_CONNECTED"
    ) {
      throw new Error(
        `${capability} must remain NOT_YET_CONNECTED.`,
      );
    }

    if (
      result.output !==
      undefined
    ) {
      throw new Error(
        `${capability} produced fake execution output.`,
      );
    }
  }

  // -----------------------------------------------
  // SHELL SAFETY
  // -----------------------------------------------

  const shellResult =
    await engine.execute({
      ...baseRequest,
      capability: "SHELL",
      requiresApproval: false,
      approved: false,
    });

  if (
    shellResult.status !==
    "BLOCKED"
  ) {
    throw new Error(
      "SHELL safety boundary was bypassed.",
    );
  }

  // -----------------------------------------------
  // AI ADAPTER STATE
  // -----------------------------------------------

  const aiResult =
    await engine.execute({
      ...baseRequest,
      capability: "AI",
      requiresApproval: false,
      approved: false,
    });

  if (
    aiResult.status !==
      "COMPLETED" &&
    aiResult.status !==
      "NOT_YET_CONNECTED"
  ) {
    throw new Error(
      "AI adapter returned an invalid canonical state.",
    );
  }

  // -----------------------------------------------
  // REGISTRY
  // -----------------------------------------------

  const adapters =
    registry.list();

  if (adapters.length !== 10) {
    throw new Error(
      "Canonical execution adapter registry is incomplete.",
    );
  }

  const disconnectedAdapters =
    adapters.filter(
      (adapter) =>
        adapter.status() ===
        "NOT_YET_CONNECTED",
    );

  if (
    disconnectedAdapters.length !== 4
  ) {
    throw new Error(
      "Expected exactly four disconnected canonical adapters.",
    );
  }

  const blockedAdapters =
    adapters.filter(
      (adapter) =>
        adapter.capability ===
        "SHELL" &&
        adapter.status() !==
        "AVAILABLE",
    );

  if (
    blockedAdapters.length !== 1
  ) {
    throw new Error(
      "Expected exactly one blocked canonical adapter.",
    );
  }

  // -----------------------------------------------
  // NO FAKE DISCONNECTED EXECUTION
  // -----------------------------------------------

  for (
    const capability of [
      "DEPLOYMENT",
      "PUBLISH",
      "AUTOMATION",
    ] as const
  ) {
    const result =
      await engine.execute({
        ...baseRequest,
        capability,
        requiresApproval: false,
        approved: false,
      });

    if (
      result.output !==
      undefined
    ) {
      throw new Error(
        `${capability} produced fake output.`,
      );
    }
  }

  console.log(
    "Execution adapter canonical registry test: PASS",
  );

  console.log({
    adapters:
      adapters.length,
    disconnectedAdapters:
      disconnectedAdapters.length,
    blockedAdapters:
      blockedAdapters.length,
    approvalGate:
      unapprovedResult.status ===
      "WAITING_APPROVAL",
    codeAvailable:
      registry.get("CODE")?.status() ===
      "AVAILABLE",
    shellBlocked:
      shellResult.status ===
      "BLOCKED",
    disconnectedExecutionBlocked:
      disconnectedAdapters.length ===
      4,
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
