import assert from "node:assert/strict";
import {
  existsSync,
  linkSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { WorkspaceCodeExecutor } from "../../../core/execution/workspace-code-executor";

const root = mkdtempSync(join(tmpdir(), "happy-symlink-root-"));
const outside = mkdtempSync(join(tmpdir(), "happy-symlink-outside-"));

try {
  const link = join(root, "linked");
  symlinkSync(outside, link, "junction");

  const executor = new WorkspaceCodeExecutor(root);

  const assertBlocked = (
    action: Parameters<typeof executor.executeOperation>[0]["action"],
    path: string,
    destinationPath?: string,
    content?: string,
  ) => {
    const result = executor.executeOperation({
      action,
      path,
      destinationPath,
      content,
    });

    assert.notEqual(
      result.status,
      "COMPLETED",
      `${action} unexpectedly succeeded for ${path}`,
    );
  };

  // CREATE must not write outside the configured root.
  const created = join(outside, "created.txt");
  assertBlocked("CREATE", "linked/created.txt", undefined, "blocked");
  assert.equal(existsSync(created), false);

  // MODIFY and READ must not access files through the junction.
  const modify = join(outside, "modify.txt");
  writeFileSync(modify, "original", "utf8");
  assertBlocked("MODIFY", "linked/modify.txt", undefined, "changed");
  assert.equal(readFileSync(modify, "utf8"), "original");

  const read = join(outside, "read.txt");
  writeFileSync(read, "private", "utf8");
  assertBlocked("READ", "linked/read.txt");
  assert.equal(readFileSync(read, "utf8"), "private");

  // DELETE must leave the outside file intact.
  const deleted = join(outside, "delete.txt");
  writeFileSync(deleted, "keep", "utf8");
  assertBlocked("DELETE", "linked/delete.txt");
  assert.equal(existsSync(deleted), true);

  // COPY must not create an outside destination.
  writeFileSync(join(root, "copy-source.txt"), "copy me", "utf8");
  assertBlocked("COPY", "copy-source.txt", "linked/copied.txt");
  assert.equal(existsSync(join(outside, "copied.txt")), false);

  // MOVE and RENAME must not move workspace files outside.
  writeFileSync(join(root, "move-source.txt"), "move me", "utf8");
  assertBlocked("MOVE", "move-source.txt", "linked/moved.txt");
  assert.equal(existsSync(join(root, "move-source.txt")), true);
  assert.equal(existsSync(join(outside, "moved.txt")), false);

  writeFileSync(join(root, "rename-source.txt"), "rename me", "utf8");
  assertBlocked("RENAME", "rename-source.txt", "linked/renamed.txt");
  assert.equal(existsSync(join(root, "rename-source.txt")), true);
  assert.equal(existsSync(join(outside, "renamed.txt")), false);

  // Hard links must not expose or mutate files outside the workspace.
  const outsideHardLinkFile = join(outside, "hardlink-private.txt");
  const workspaceHardLink = join(root, "hardlink-private.txt");

  writeFileSync(
    outsideHardLinkFile,
    "OUTSIDE_HARDLINK_PRIVATE",
    "utf8",
  );
  linkSync(outsideHardLinkFile, workspaceHardLink);

  assertBlocked("READ", "hardlink-private.txt");
  assertBlocked(
    "MODIFY",
    "hardlink-private.txt",
    undefined,
    "MUST_NOT_MODIFY_OUTSIDE",
  );
  assertBlocked("DELETE", "hardlink-private.txt");
  assertBlocked(
    "COPY",
    "hardlink-private.txt",
    "hardlink-copy.txt",
  );
  assertBlocked(
    "MOVE",
    "hardlink-private.txt",
    "hardlink-move.txt",
  );
  assertBlocked(
    "RENAME",
    "hardlink-private.txt",
    "hardlink-rename.txt",
  );

  assert.equal(
    readFileSync(outsideHardLinkFile, "utf8"),
    "OUTSIDE_HARDLINK_PRIVATE",
  );
  assert.equal(existsSync(workspaceHardLink), true);
  assert.equal(existsSync(join(root, "hardlink-copy.txt")), false);
  assert.equal(existsSync(join(root, "hardlink-move.txt")), false);
  assert.equal(existsSync(join(root, "hardlink-rename.txt")), false);

  // Valid in-workspace writes must still work.
  const safe = executor.executeOperation({
    action: "CREATE",
    path: "safe/inside.txt",
    content: "inside workspace",
  });
  assert.equal(safe.status, "COMPLETED");
  assert.equal(
    readFileSync(join(root, "safe", "inside.txt"), "utf8"),
    "inside workspace",
  );

  console.log("PASS: symlink/junction boundary regression");
  console.log({
    createBlocked: !existsSync(created),
    modifyBlocked: readFileSync(modify, "utf8") === "original",
    readBlocked: true,
    deleteBlocked: existsSync(deleted),
    copyBlocked: !existsSync(join(outside, "copied.txt")),
    moveBlocked: existsSync(join(root, "move-source.txt")),
    renameBlocked: existsSync(join(root, "rename-source.txt")),
    safeWorkspaceWrite: safe.status === "COMPLETED",
  });
} finally {
  rmSync(root, { recursive: true, force: true });
  rmSync(outside, { recursive: true, force: true });
}

