import type {
  ExecutionAdapter,
  ExecutionRequest,
  ExecutionResult,
} from "../../../core/execution/types";

import {
  ExecutionAdapterRegistry,
} from "../../../core/execution/registry";

import {
  ExecutionEngine,
} from "../../../core/execution/engine";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

function makeRequest(
  capability: ExecutionRequest["capability"],
): ExecutionRequest {
  return {
    id:
      `registry-gate-${capability.toLowerCase()}`,
    taskId:
      "registry-gate-task",
    missionId:
      "registry-gate-mission",
    capability,
    action:
      "EXECUTE",
    input: {},
    requiresApproval:
      false,
    approved:
      true,
    risk:
      "LOW",
    createdAt:
      new Date().toISOString(),
  };
}

class FakeAvailableAdapter
  implements ExecutionAdapter
{
  public executions = 0;

  constructor(
    public readonly capability: ExecutionRequest["capability"],
  ) {}

  status() {
    return "AVAILABLE" as const;
  }

  canExecute(): boolean { return true; }

  async execute(
    request: ExecutionRequest,
  ): Promise<ExecutionResult> {
    this.executions += 1;

    return {
      id:
        crypto.randomUUID(),
      requestId:
        request.id,
      capability:
        request.capability,
      status:
        "COMPLETED",
      output: {
        fakeAdapterExecuted:
          true,
      },
      evidenceIds: [],
      startedAt:
        new Date().toISOString(),
      completedAt:
        new Date().toISOString(),
    };
  }
}

async function main(): Promise<void> {
  // --------------------------------------------------
  // BLOCKED CAPABILITY MUST NEVER REACH ADAPTER
  // --------------------------------------------------

  const blockedRegistry =
    new ExecutionAdapterRegistry();

  const shellAdapter =
    new FakeAvailableAdapter(
      "SHELL",
    );

  blockedRegistry.register(
    shellAdapter,
  );

  const blockedEngine =
    new ExecutionEngine(
      blockedRegistry,
    );

  const shellResult =
    await blockedEngine.execute(
      makeRequest(
        "SHELL",
      ),
    );

  assert(
    shellResult.status ===
      "BLOCKED",
    "Canonical BLOCKED capability was not blocked.",
  );

  assert(
    shellAdapter.executions ===
      0,
    "BLOCKED capability reached the adapter.",
  );

  assert(
    shellResult.error?.includes(
      "canonical capability registry",
    ) === true,
    "BLOCKED result did not identify canonical registry enforcement.",
  );

  // --------------------------------------------------
  // NOT-YET-CONNECTED CAPABILITY MUST NEVER REACH ADAPTER
  // --------------------------------------------------

  const disconnectedRegistry =
    new ExecutionAdapterRegistry();

  const deploymentAdapter =
    new FakeAvailableAdapter(
      "DEPLOYMENT",
    );

  disconnectedRegistry.register(
    deploymentAdapter,
  );

  const disconnectedEngine =
    new ExecutionEngine(
      disconnectedRegistry,
    );

  const deploymentResult =
    await disconnectedEngine.execute(
      makeRequest(
        "DEPLOYMENT",
      ),
    );

  assert(
    deploymentResult.status ===
      "NOT_YET_CONNECTED",
    "Canonical NOT_YET_CONNECTED capability was not blocked.",
  );

  assert(
    deploymentAdapter.executions ===
      0,
    "NOT_YET_CONNECTED capability reached the adapter.",
  );

  assert(
    deploymentResult.error?.includes(
      "canonical capability registry",
    ) === true,
    "NOT_YET_CONNECTED result did not identify canonical registry enforcement.",
  );

  // --------------------------------------------------
  // AVAILABLE CAPABILITY MUST PRESERVE NORMAL FLOW
  // --------------------------------------------------

  const availableRegistry =
    new ExecutionAdapterRegistry();

  const codeAdapter =
    new FakeAvailableAdapter(
      "CODE",
    );

  availableRegistry.register(
    codeAdapter,
  );

  const availableEngine =
    new ExecutionEngine(
      availableRegistry,
    );

  const codeResult =
    await availableEngine.execute(
      makeRequest(
        "CODE",
      ),
    );

  assert(
    codeResult.status ===
      "COMPLETED",
    "AVAILABLE capability did not continue through normal adapter flow.",
  );

  assert(
    codeAdapter.executions ===
      1,
    "AVAILABLE capability did not reach its adapter.",
  );

  // --------------------------------------------------
  // ADDITIONAL SAFETY STATES
  // --------------------------------------------------

  const publishRegistry =
    new ExecutionAdapterRegistry();

  const publishAdapter =
    new FakeAvailableAdapter(
      "PUBLISH",
    );

  publishRegistry.register(
    publishAdapter,
  );

  const publishEngine =
    new ExecutionEngine(
      publishRegistry,
    );

  const publishResult =
    await publishEngine.execute(
      makeRequest(
        "PUBLISH",
      ),
    );

  assert(
    publishResult.status ===
      "NOT_YET_CONNECTED",
    "PUBLISH registry state was bypassed.",
  );

  assert(
    publishAdapter.executions ===
      0,
    "PUBLISH adapter was reached despite registry state.",
  );

  const automationRegistry =
    new ExecutionAdapterRegistry();

  const automationAdapter =
    new FakeAvailableAdapter(
      "AUTOMATION",
    );

  automationRegistry.register(
    automationAdapter,
  );

  const automationEngine =
    new ExecutionEngine(
      automationRegistry,
    );

  const automationResult =
    await automationEngine.execute(
      makeRequest(
        "AUTOMATION",
      ),
    );

  assert(
    automationResult.status ===
      "NOT_YET_CONNECTED",
    "AUTOMATION registry state was bypassed.",
  );

  assert(
    automationAdapter.executions ===
      0,
    "AUTOMATION adapter was reached despite registry state.",
  );

  console.log(
    "Canonical registry safety gate test: PASS",
  );

  console.log({
    shellBlockedBeforeAdapter:
      true,
    deploymentBlockedBeforeAdapter:
      true,
    publishBlockedBeforeAdapter:
      true,
    automationBlockedBeforeAdapter:
      true,
    codeAvailableFlowPreserved:
      true,
    adapterBypassPrevented:
      true,
  });
}

main().catch(
  (error: unknown) => {
    console.error(error);
    process.exit(1);
  },
);
