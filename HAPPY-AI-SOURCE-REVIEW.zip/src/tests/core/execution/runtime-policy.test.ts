import assert from "node:assert/strict";

import {
  assertRuntimeTransition,
  canTransitionRuntimeStatus,
  isTerminalRuntimeStatus,
  shouldRetry,
} from "../../../core/execution/runtime-policy";

function expectThrows(
  fn: () => void,
  expectedMessage: string,
): void {
  let thrown = false;

  try {
    fn();
  } catch (error) {
    thrown = true;

    assert.equal(
      error instanceof Error
        ? error.message
        : String(error),
      expectedMessage,
    );
  }

  assert.equal(
    thrown,
    true,
    `Expected error: ${expectedMessage}`,
  );
}

function main(): void {
  // Valid lifecycle transitions.
  assert.equal(
    canTransitionRuntimeStatus(
      "PENDING",
      "READY",
    ),
    true,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "READY",
      "RUNNING",
    ),
    true,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "RUNNING",
      "VERIFYING",
    ),
    true,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "VERIFYING",
      "COMPLETED",
    ),
    true,
  );

  // Terminal states cannot silently continue.
  assert.equal(
    canTransitionRuntimeStatus(
      "COMPLETED",
      "RUNNING",
    ),
    false,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "FAILED",
      "RUNNING",
    ),
    false,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "BLOCKED",
      "RUNNING",
    ),
    false,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "NOT_YET_CONNECTED",
      "RUNNING",
    ),
    false,
  );

  expectThrows(
    () =>
      assertRuntimeTransition(
        "COMPLETED",
        "RUNNING",
      ),
    "INVALID_RUNTIME_TRANSITION:COMPLETED->RUNNING",
  );

  // WAITING_APPROVAL remains non-terminal
  // but cannot be bypassed as a terminal success.
  assert.equal(
    canTransitionRuntimeStatus(
      "WAITING_APPROVAL",
      "RUNNING",
    ),
    true,
  );

  assert.equal(
    canTransitionRuntimeStatus(
      "WAITING_APPROVAL",
      "CANCELLED",
    ),
    true,
  );

  assert.equal(
    isTerminalRuntimeStatus(
      "WAITING_APPROVAL",
    ),
    false,
  );

  // Terminal-state classification.
  const terminalStates = [
    "COMPLETED",
    "PARTIAL",
    "FAILED",
    "BLOCKED",
    "NOT_YET_CONNECTED",
    "CANCELLED",
  ] as const;

  for (const status of terminalStates) {
    assert.equal(
      isTerminalRuntimeStatus(status),
      true,
      `${status} must be terminal.`,
    );
  }

  // Retry policy.
  const retry1 = shouldRetry(
    "FAILED",
    0,
    3,
  );

  assert.equal(retry1.retry, true);
  assert.equal(
    retry1.nextRetryCount,
    1,
  );

  const retry2 = shouldRetry(
    "FAILED",
    2,
    3,
  );

  assert.equal(retry2.retry, true);
  assert.equal(
    retry2.nextRetryCount,
    3,
  );

  const retry3 = shouldRetry(
    "FAILED",
    3,
    3,
  );

  assert.equal(retry3.retry, false);
  assert.equal(
    retry3.nextRetryCount,
    3,
  );

  const retry4 = shouldRetry(
    "BLOCKED",
    0,
    3,
  );

  assert.equal(
    retry4.retry,
    false,
  );

  const retry5 = shouldRetry(
    "NOT_YET_CONNECTED",
    0,
    3,
  );

  assert.equal(
    retry5.retry,
    false,
  );

  const retry6 = shouldRetry(
    "COMPLETED",
    0,
    3,
  );

  assert.equal(
    retry6.retry,
    false,
  );

  console.log(
    "Runtime lifecycle transition safety: PASS",
  );

  console.log(
    "Terminal-state protection: PASS",
  );

  console.log(
    "WAITING_APPROVAL lifecycle handling: PASS",
  );

  console.log(
    "Retry policy safety: PASS",
  );

  console.log(
    "FAILED retry limit enforcement: PASS",
  );

  console.log(
    "BLOCKED/NOT_YET_CONNECTED non-retryable: PASS",
  );

  console.log(
    "#21 runtime policy test: PASS",
  );
}

main();
