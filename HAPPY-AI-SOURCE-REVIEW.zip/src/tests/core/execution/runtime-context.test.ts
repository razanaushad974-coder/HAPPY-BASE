import assert from "node:assert/strict";

import {
  ExecutionEngine,
} from "../../../core/execution/engine";

import {
  ExecutionAdapterRegistry,
} from "../../../core/execution/registry";

import {
  DatabaseExecutionAdapter,
  type DatabaseExecutionInput,
  type DatabaseProvider,
} from "../../../core/execution/database-execution-adapter";

class CaptureDatabaseProvider
  implements DatabaseProvider
{
  private captured:
    | DatabaseExecutionInput
    | undefined;

  status() {
    return "AVAILABLE" as const;
  }

  async execute(
    input: DatabaseExecutionInput,
  ): Promise<unknown> {
    this.captured = input;

    return {
      ok: true,
    };
  }

  get latest() {
    return this.captured;
  }
}

async function main(): Promise<void> {
  const provider =
    new CaptureDatabaseProvider();

  const registry =
    new ExecutionAdapterRegistry();

  registry.register(
    new DatabaseExecutionAdapter(
      provider,
    ),
  );

  const engine =
    new ExecutionEngine(
      registry,
    );

  const request = {
    id: "runtime-context-test",
    taskId: "task-1",
    missionId: "mission-1",
    capability: "DATABASE" as const,
    action: "DB_SELECT",
    input: {
      action:
        "DB_SELECT",
      resource:
        "happy_records",
      scope: {
        organizationId:
          "org-1",
        workspaceId:
          "workspace-1",
      },
    },
    requiresApproval: false,
    approved: false,
    risk: "LOW" as const,
    createdAt:
      new Date().toISOString(),
  };

  const original =
    structuredClone(
      request.input,
    );

  const result =
    await engine.execute(
      request,
      {
        supabaseAccessToken:
          "ephemeral-user-jwt",
        authenticatedUserId:
          "user-123",
      },
    );

  assert.equal(
    result.status,
    "COMPLETED",
  );

  assert.equal(
    provider.latest?.auth?.accessToken,
    "ephemeral-user-jwt",
  );

  assert.equal(
    provider.latest?.scope.userId,
    "user-123",
  );

  assert.deepEqual(
    request.input,
    original,
  );

  assert.equal(
    (
      request.input as Record<
        string,
        unknown
      >
    ).auth,
    undefined,
  );

  console.log(
    "Execution runtime-context test: PASS",
  );

  console.log({
    authInjectedEphemerally: true,
    authenticatedUserPropagated: true,
    persistedRequestMutated: false,
    accessTokenPersistedInRequest: false,
  });
}

void main().catch(
  (error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  },
);

