import { evaluateHappyFeatureAccess } from "../../../core/authorization/happy-feature-access";

function assert(condition: boolean, message: string): void {
    if (!condition) {
        throw new Error(message);
    }
}

function main(): void {
    process.env.HAPPY_FOUNDER_USER_ID = "founder-test-user";

    const founderDeploy = evaluateHappyFeatureAccess({
        userId: "founder-test-user",
        role: "FOUNDER",
        scope: "FOUNDER",
        action: "DEPLOY",
        capabilityStatus: "AVAILABLE",
        requiresApproval: true,
        approved: true,
    });

    assert(
        founderDeploy.decision === "ALLOW",
        `Expected Founder deploy to be allowed, got ${founderDeploy.decision}`,
    );

    const userDeploy = evaluateHappyFeatureAccess({
        userId: "normal-test-user",
        role: "USER",
        scope: "WORKSPACE",
        action: "DEPLOY",
        capabilityStatus: "AVAILABLE",
        requiresApproval: true,
        approved: true,
    });

    assert(
        userDeploy.decision === "BLOCKED",
        `Expected USER deploy to be blocked, got ${userDeploy.decision}`,
    );

    const disconnectedPublish = evaluateHappyFeatureAccess({
        userId: "founder-test-user",
        role: "FOUNDER",
        scope: "FOUNDER",
        action: "PUBLISH",
        capabilityStatus: "NOT_YET_CONNECTED",
        requiresApproval: true,
        approved: true,
    });

    assert(
        disconnectedPublish.decision === "NOT_YET_CONNECTED",
        `Expected disconnected publish to remain NOT_YET_CONNECTED, got ${disconnectedPublish.decision}`,
    );

    const pendingAutomation = evaluateHappyFeatureAccess({
        userId: "founder-test-user",
        role: "FOUNDER",
        scope: "FOUNDER",
        action: "AUTOMATE",
        capabilityStatus: "AVAILABLE",
        requiresApproval: true,
        approved: false,
    });

    assert(
        pendingAutomation.decision === "APPROVAL_REQUIRED",
        `Expected automation approval gate, got ${pendingAutomation.decision}`,
    );

    console.log("HAPPY feature-access policy test: PASS");
    console.log({
        founderDeploy: founderDeploy.decision,
        userDeploy: userDeploy.decision,
        disconnectedPublish: disconnectedPublish.decision,
        pendingAutomation: pendingAutomation.decision,
    });
}

main();
