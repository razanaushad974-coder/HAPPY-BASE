import { evaluateHappyFeatureAccess } from "../../../core/authorization/happy-feature-access";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

process.env.HAPPY_FOUNDER_USER_ID = "founder-test-user";

const approval = evaluateHappyFeatureAccess({
    userId: "founder-test-user",
    role: "FOUNDER",
    scope: "FOUNDER",
    action: "AUTOMATE",
    capabilityStatus: "AVAILABLE",
    requiresApproval: true,
    approved: false,
});

assert(approval.decision === "APPROVAL_REQUIRED",
    `Expected APPROVAL_REQUIRED; received ${approval.decision}`);
assert(!approval.allowed, "Unapproved automation must not be allowed.");

const blocked = evaluateHappyFeatureAccess({
    userId: "ordinary-test-user",
    role: "USER",
    scope: "WORKSPACE",
    action: "DEPLOY",
    capabilityStatus: "AVAILABLE",
    requiresApproval: true,
    approved: true,
});

assert(blocked.decision === "BLOCKED",
    `Expected BLOCKED; received ${blocked.decision}`);
assert(!blocked.allowed, "A non-founder must not deploy even with approved=true.");

const disconnected = evaluateHappyFeatureAccess({
    userId: "founder-test-user",
    role: "FOUNDER",
    scope: "FOUNDER",
    action: "PUBLISH",
    capabilityStatus: "NOT_YET_CONNECTED",
    requiresApproval: true,
    approved: true,
});

assert(disconnected.decision === "NOT_YET_CONNECTED",
    `Expected NOT_YET_CONNECTED; received ${disconnected.decision}`);
assert(!disconnected.allowed, "A disconnected capability must remain unavailable.");

console.log("Feature access gate regression policy: PASS");
console.log({
    approval: approval.decision,
    blocked: blocked.decision,
    disconnected: disconnected.decision,
});
