import assert from "node:assert/strict";

import {
  canCompleteExecution,
  canStartExecution,
  evaluateApprovalGate,
  evaluateVerificationGate,
} from "../../../core/execution/control-gates";

function main(): void {
  const noApproval =
    evaluateApprovalGate({
      approvalRequired: false,
    });

  assert.equal(
    noApproval.status,
    "ALLOW",
  );

  const pendingApproval =
    evaluateApprovalGate({
      approvalRequired: true,
      approvalStatus: "PENDING",
    });

  assert.equal(
    pendingApproval.status,
    "WAITING_APPROVAL",
  );

  const missingApproval =
    evaluateApprovalGate({
      approvalRequired: true,
    });

  assert.equal(
    missingApproval.status,
    "WAITING_APPROVAL",
  );

  const approved =
    evaluateApprovalGate({
      approvalRequired: true,
      approvalStatus: "APPROVED",
    });

  assert.equal(
    approved.status,
    "ALLOW",
  );

  const explicitApproved =
    evaluateApprovalGate({
      approvalRequired: true,
      approved: true,
    });

  assert.equal(
    explicitApproved.status,
    "ALLOW",
  );

  const rejected =
    evaluateApprovalGate({
      approvalRequired: true,
      approvalStatus: "REJECTED",
    });

  assert.equal(
    rejected.status,
    "BLOCKED",
  );

  const cancelled =
    evaluateApprovalGate({
      approvalRequired: true,
      approvalStatus: "CANCELLED",
    });

  assert.equal(
    cancelled.status,
    "BLOCKED",
  );

  const expired =
    evaluateApprovalGate({
      approvalRequired: true,
      approvalStatus: "EXPIRED",
    });

  assert.equal(
    expired.status,
    "BLOCKED",
  );

  assert.equal(
    canStartExecution(
      false,
    ),
    true,
  );

  assert.equal(
    canStartExecution(
      true,
      "PENDING",
    ),
    false,
  );

  assert.equal(
    canStartExecution(
      true,
      "APPROVED",
    ),
    true,
  );

  const verificationPassed =
    evaluateVerificationGate({
      verificationStatus:
        "PASSED",
      requiresVerification:
        true,
    });

  assert.equal(
    verificationPassed.status,
    "COMPLETED",
  );

  const verificationPartial =
    evaluateVerificationGate({
      verificationStatus:
        "PARTIAL",
      requiresVerification:
        true,
    });

  assert.equal(
    verificationPartial.status,
    "PARTIAL",
  );

  const verificationFailed =
    evaluateVerificationGate({
      verificationStatus:
        "FAILED",
      requiresVerification:
        true,
    });

  assert.equal(
    verificationFailed.status,
    "FAILED",
  );

  const verificationBlocked =
    evaluateVerificationGate({
      verificationStatus:
        "BLOCKED",
      requiresVerification:
        true,
    });

  assert.equal(
    verificationBlocked.status,
    "BLOCKED",
  );

  const verificationDisconnected =
    evaluateVerificationGate({
      verificationStatus:
        "NOT_YET_CONNECTED",
      requiresVerification:
        true,
    });

  assert.equal(
    verificationDisconnected.status,
    "NOT_YET_CONNECTED",
  );

  const noVerificationRequired =
    evaluateVerificationGate({
      verificationStatus:
        "FAILED",
      requiresVerification:
        false,
    });

  assert.equal(
    noVerificationRequired.status,
    "COMPLETED",
  );

  assert.equal(
    canCompleteExecution(
      "PASSED",
      true,
    ),
    true,
  );

  assert.equal(
    canCompleteExecution(
      "PARTIAL",
      true,
    ),
    false,
  );

  assert.equal(
    canCompleteExecution(
      "FAILED",
      true,
    ),
    false,
  );

  assert.equal(
    canCompleteExecution(
      "NOT_YET_CONNECTED",
      true,
    ),
    false,
  );

  console.log(
    "Approval not required -> execution allowed: PASS",
  );

  console.log(
    "Pending approval -> execution blocked: PASS",
  );

  console.log(
    "Missing approval -> execution blocked: PASS",
  );

  console.log(
    "Explicit approval -> execution allowed: PASS",
  );

  console.log(
    "Rejected approval -> execution blocked: PASS",
  );

  console.log(
    "Cancelled approval -> execution blocked: PASS",
  );

  console.log(
    "Expired approval -> execution blocked: PASS",
  );

  console.log(
    "PASSED verification -> COMPLETED allowed: PASS",
  );

  console.log(
    "PARTIAL verification -> COMPLETED denied: PASS",
  );

  console.log(
    "FAILED verification -> COMPLETED denied: PASS",
  );

  console.log(
    "BLOCKED verification -> COMPLETED denied: PASS",
  );

  console.log(
    "NOT_YET_CONNECTED verification -> COMPLETED denied: PASS",
  );

  console.log(
    "Verification bypass disabled when required: PASS",
  );

  console.log(
    "#25 control-gates test: PASS",
  );
}

main();
