import assert from "node:assert/strict";

import {
  findAgentForCapability,
  getAgent,
  listAgents,
} from "../../../core/agents/registry";

import {
  AgentWorkflowEngine,
} from "../../../core/workflow/engine";

import {
  evaluateAutomation,
} from "../../../core/automation/policy";

async function main(): Promise<void> {
  const agents =
    listAgents();

  assert.ok(
    agents.length >= 10,
  );

  assert.equal(
    getAgent("builder")?.status,
    "AVAILABLE",
  );

  assert.equal(
    getAgent("automation")?.status,
    "NOT_YET_CONNECTED",
  );

  assert.equal(
    getAgent("deployment")?.status,
    "NOT_YET_CONNECTED",
  );

  assert.equal(
    getAgent("safe-shell")?.status,
    "BLOCKED",
  );

  assert.equal(
    findAgentForCapability(
      "CODE",
    )?.id,
    "builder",
  );

  assert.equal(
    findAgentForCapability(
      "FILE",
    )?.id,
    "builder",
  );

  assert.equal(
    findAgentForCapability(
      "AUTOMATION",
    )?.status,
    "NOT_YET_CONNECTED",
  );

  const engine =
    new AgentWorkflowEngine();

  const readyPlan =
    engine.createPlan(
      "build HAPPY website",
      [
        {
          id: "build",
          action: "BUILD",
        },
        {
          id: "test",
          action: "TEST",
          dependsOn: ["build"],
        },
      ],
    );

  assert.equal(
    readyPlan.status,
    "READY",
  );

  assert.equal(
    readyPlan.steps[0].capability,
    "CODE",
  );

  assert.equal(
    readyPlan.steps[0].agentId,
    "builder",
  );

  const approvalPlan =
    engine.createPlan(
      "delete project data",
      [
        {
          id: "delete",
          action: "DELETE",
          requiresApproval: true,
        },
      ],
    );

  assert.equal(
    approvalPlan.status,
    "WAITING_APPROVAL",
  );

  const automationPlan =
    engine.createPlan(
      "automate publishing",
      [
        {
          id: "automate",
          action: "AUTOMATE",
        },
      ],
    );

  assert.equal(
    automationPlan.status,
    "NOT_YET_CONNECTED",
  );

  const deploymentPlan =
    engine.createPlan(
      "deploy application",
      [
        {
          id: "deploy",
          action: "DEPLOY",
        },
      ],
    );

  assert.equal(
    deploymentPlan.status,
    "NOT_YET_CONNECTED",
  );

  const publishPlan =
    engine.createPlan(
      "publish application",
      [
        {
          id: "publish",
          action: "PUBLISH",
        },
      ],
    );

  assert.equal(
    publishPlan.status,
    "NOT_YET_CONNECTED",
  );

  const duplicatePlan =
    engine.createPlan(
      "bad duplicate graph",
      [
        {
          id: "same",
          action: "BUILD",
        },
        {
          id: "same",
          action: "TEST",
        },
      ],
    );

  assert.equal(
    duplicatePlan.status,
    "BLOCKED",
  );

  const unknownDependencyPlan =
    engine.createPlan(
      "bad dependency",
      [
        {
          id: "test",
          action: "TEST",
          dependsOn: [
            "missing",
          ],
        },
      ],
    );

  assert.equal(
    unknownDependencyPlan.status,
    "BLOCKED",
  );

  const cyclePlan =
    engine.createPlan(
      "cyclic workflow",
      [
        {
          id: "a",
          action: "BUILD",
          dependsOn: ["b"],
        },
        {
          id: "b",
          action: "TEST",
          dependsOn: ["a"],
        },
      ],
    );

  assert.equal(
    cyclePlan.status,
    "BLOCKED",
  );

  const disabledAutomation =
    evaluateAutomation({
      id: "automation-1",
      workflowId: readyPlan.id,
      enabled: false,
      approved: true,
      trigger: "MANUAL",
    });

  assert.equal(
    disabledAutomation.status,
    "BLOCKED",
  );

  const pendingAutomation =
    evaluateAutomation({
      id: "automation-2",
      workflowId: readyPlan.id,
      enabled: true,
      approved: false,
      trigger: "SCHEDULE",
    });

  assert.equal(
    pendingAutomation.status,
    "WAITING_APPROVAL",
  );

  const connectedAutomation =
    evaluateAutomation({
      id: "automation-3",
      workflowId: readyPlan.id,
      enabled: true,
      approved: true,
      trigger: "WEBHOOK",
    });

  assert.equal(
    connectedAutomation.status,
    "NOT_YET_CONNECTED",
  );

  console.log(
    "Agent registry: PASS",
  );

  console.log(
    "Builder agent available: PASS",
  );

  console.log(
    "Automation agent NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Deployment agent NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Publishing agent NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Safe Shell agent BLOCKED: PASS",
  );

  console.log(
    "Capability -> agent mapping: PASS",
  );

  console.log(
    "Builder workflow -> CODE capability: PASS",
  );

  console.log(
    "Workflow dependency ordering: PASS",
  );

  console.log(
    "Approval-required workflow: PASS",
  );

  console.log(
    "Automation workflow -> NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Deployment workflow -> NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Publishing workflow -> NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "Duplicate workflow IDs blocked: PASS",
  );

  console.log(
    "Unknown workflow dependency blocked: PASS",
  );

  console.log(
    "Cyclic workflow graph blocked: PASS",
  );

  console.log(
    "Disabled automation blocked: PASS",
  );

  console.log(
    "Unapproved automation -> WAITING_APPROVAL: PASS",
  );

  console.log(
    "Approved automation without runtime -> NOT_YET_CONNECTED: PASS",
  );

  console.log(
    "#29 builder-agents-workflow test: PASS",
  );
}

main().catch(
  (error: unknown) => {
    console.error(
      error,
    );

    process.exitCode = 1;
  },
);
