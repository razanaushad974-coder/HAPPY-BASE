import {
  existsSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(message);
}

async function main(): Promise<void> {
  const directory = mkdtempSync(join(tmpdir(), "happy-incomplete-lock-"));
  const stateFile = join(directory, "state.json");
  const lockPath = `${stateFile}.lock`;
  const testFile = resolve(process.argv[1] ?? __filename);

  try {
    const service = new PersistenceService(
      new JsonFileStateAdapter(stateFile),
    );

    service.create("PROJECT", "seed-record", {
      source: "incomplete-lock-regression",
    });

    // Simulate a process that creates the lock file and crashes
    // before writing ownership metadata.
    execFileSync(
      process.execPath,
      ["--import", "tsx", testFile, "--worker-empty-lock", lockPath],
      {
        cwd: process.cwd(),
        stdio: "pipe",
        timeout: 15000,
      },
    );

    assert(existsSync(lockPath), "Incomplete lock was not created.");
    assert(
      readFileSync(lockPath, "utf8") === "",
      "Lock file is not in the expected incomplete state.",
    );

    let timeoutObserved = false;

    try {
      service.create("PROJECT", "must-not-persist", {
        source: "blocked-by-incomplete-lock",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);

      if (!message.includes("PERSISTENCE_LOCK_TIMEOUT")) {
        throw new Error(`Unexpected persistence error: ${message}`);
      }

      timeoutObserved = true;
    }

    assert(timeoutObserved, "Incomplete lock did not cause a safe timeout.");
    assert(existsSync(lockPath), "Incomplete lock was unexpectedly removed.");
    assert(
      readFileSync(lockPath, "utf8") === "",
      "Incomplete lock contents were unexpectedly modified.",
    );

    const freshService = new PersistenceService(
      new JsonFileStateAdapter(stateFile),
    );

    const ids = new Set(
      freshService.list("PROJECT").map((record) => record.id),
    );

    assert(ids.has("seed-record"), "Existing state was lost.");
    assert(
      !ids.has("must-not-persist"),
      "Write proceeded despite incomplete lock.",
    );

    console.log(JSON.stringify({
      test: "json-file-adapter-incomplete-lock",
      incompleteLockCreated: true,
      timeoutObserved,
      incompleteLockPreserved: true,
      blockedWritePersisted: false,
      existingStatePreserved: true,
      status: "PASS",
    }, null, 2));

    console.log("JSON FILE ADAPTER INCOMPLETE-LOCK REGRESSION: PASS");
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
}

if (process.argv[2] === "--worker-empty-lock") {
  const lockPath = process.argv[3];

  if (!lockPath) {
    throw new Error("Worker requires a lock path.");
  }

  writeFileSync(resolve(lockPath), "", {
    encoding: "utf8",
    flag: "wx",
  });
} else {
  void main().catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  });
}
