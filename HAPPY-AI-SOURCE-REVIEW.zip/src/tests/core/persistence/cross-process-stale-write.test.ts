import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

async function worker(stateFile: string, recordId: string): Promise<void> {
    // Intentionally load the snapshot before the parent releases either worker.
    const service = new PersistenceService(new JsonFileStateAdapter(stateFile));

    process.stdout.write("READY\n");
    process.stdin.setEncoding("utf8");
    process.stdin.once("data", () => {
        try {
            service.create("PROJECT", recordId, {
                testRecord: true,
                writer: recordId,
            });
            process.stdout.write("DONE\n");
            process.exitCode = 0;
        } catch (error) {
            console.error(error);
            process.exitCode = 1;
        }
    });
}

async function main(): Promise<void> {
    const dir = await mkdtemp(join(tmpdir(), "happy-cross-process-"));
    const stateFile = join(dir, "state.json");
    const testFile = resolve(process.argv[1] ?? __filename);
    const ids = ["writer-process-A", "writer-process-B"];
    const children: ReturnType<typeof spawn>[] = [];

    try {
        // Create a valid initial snapshot before starting independent processes.
        const seed = new PersistenceService(new JsonFileStateAdapter(stateFile));
        seed.create("PROJECT", "seed-record", { seed: true });

        const readyPromises: Promise<void>[] = [];

        for (const id of ids) {
            const child = spawn(
                process.execPath,
                ["--import", "tsx", testFile, "--worker", stateFile, id],
                {
                    cwd: process.cwd(),
                    stdio: ["pipe", "pipe", "pipe"],
                },
            );

            children.push(child);

            let stdout = "";
            let stderr = "";

            child.stdout.setEncoding("utf8");
            child.stderr.setEncoding("utf8");
            child.stdout.on("data", (chunk: string) => { stdout += chunk; });
            child.stderr.on("data", (chunk: string) => { stderr += chunk; });

            readyPromises.push(new Promise<void>((resolveReady, rejectReady) => {
                const timeout = setTimeout(
                    () => rejectReady(new Error(`Worker readiness timeout: ${id}`)),
                    15000,
                );

                const check = () => {
                    if (stdout.includes("READY")) {
                        clearTimeout(timeout);
                        resolveReady();
                    }
                    if (child.exitCode !== null && !stdout.includes("READY")) {
                        clearTimeout(timeout);
                        rejectReady(new Error(`Worker exited before READY: ${id}; ${stderr}`));
                    }
                };

                child.stdout.on("data", check);
                child.on("error", (error) => {
                    clearTimeout(timeout);
                    rejectReady(error);
                });
                child.on("exit", () => {
                    if (!stdout.includes("READY")) check();
                });
            }));
        }

        await Promise.all(readyPromises);

        // Both services now hold the same old snapshot; release both together.
        for (const child of children) {
            if (!child.stdin) {
                throw new Error("Worker stdin is unavailable.");
            }
            child.stdin.end("GO\n");
        }

        const exits = await Promise.all(children.map((child, index) =>
            new Promise<void>((resolveExit, rejectExit) => {
                child.on("close", (code) => {
                    if (code === 0) resolveExit();
                    else rejectExit(new Error(`Worker ${ids[index]} exited ${code}`));
                });
            }),
        ));
        void exits;

        const fresh = new PersistenceService(new JsonFileStateAdapter(stateFile));
        const projects = fresh.list("PROJECT");
        const persistedIds = new Set(projects.map((record) => record.id));

        console.log(JSON.stringify({
            test: "cross-process-stale-write",
            persistedIds: [...persistedIds],
            expectedWriterIds: ids,
            writerAFound: persistedIds.has(ids[0]),
            writerBFound: persistedIds.has(ids[1]),
            projectCount: projects.length,
        }, null, 2));

        assert(persistedIds.has(ids[0]), "Writer A record was lost.");
        assert(persistedIds.has(ids[1]), "Writer B record was lost.");
        assert(persistedIds.has("seed-record"), "Seed record was lost.");

        console.log("CROSS-PROCESS PERSISTENCE REGRESSION: PASS");
    } finally {
        for (const child of children) {
            if (child.exitCode === null) child.kill();
        }
        await rm(dir, { recursive: true, force: true });
    }
}

if (process.argv[2] === "--worker") {
    const stateFile = process.argv[3];
    const recordId = process.argv[4];

    if (!stateFile || !recordId) {
        throw new Error("Worker requires state file and record ID.");
    }

    void worker(resolve(stateFile), recordId).catch((error) => {
        console.error(error);
        process.exitCode = 1;
    });
} else {
    void main().catch((error) => {
        console.error(error);
        process.exitCode = 1;
    });
}


