import {
  existsSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(message);
}

function createOrphanLock(lockPath: string): void {
  writeFileSync(
    lockPath,
    JSON.stringify({
      token: "simulated-crashed-process",
      pid: process.pid,
      hostname: "crash-test",
      createdAt: new Date().toISOString(),
    }),
    { encoding: "utf8", flag: "wx" },
  );
}

async function main(): Promise<void> {
  const directory = mkdtempSync(join(tmpdir(), "happy-crash-lock-"));
  const stateFile = join(directory, "state.json");
  const lockPath = `${stateFile}.lock`;
  const testFile = resolve(process.argv[1] ?? __filename);

  try {
    const service = new PersistenceService(
      new JsonFileStateAdapter(stateFile),
    );

    // 1. Normal operation must release its own lock.
    service.create("PROJECT", "seed-record", {
      source: "crash-lock-regression",
    });

    assert(existsSync(stateFile), "Initial state file was not created.");
    assert(!existsSync(lockPath), "Normal operation left its lock behind.");

    // 2. A separate process creates a lock and exits without cleanup.
    execFileSync(
      process.execPath,
      ["--import", "tsx", testFile, "--worker-lock", lockPath],
      {
        cwd: process.cwd(),
        stdio: "pipe",
        timeout: 15000,
      },
    );

    assert(existsSync(lockPath), "Crash worker did not leave an orphan lock.");

    const orphanMetadata = JSON.parse(
      readFileSync(lockPath, "utf8"),
    ) as { token?: string };

    assert(
      orphanMetadata.token === "simulated-crashed-process",
      "Unexpected orphan lock metadata.",
    );

    // 3. Adapter must fail closed after its configured lock timeout.
    let timeoutObserved = false;

    try {
      service.create("PROJECT", "must-not-persist", {
        source: "blocked-by-orphan-lock",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      timeoutObserved = message.includes("PERSISTENCE_LOCK_TIMEOUT");

      if (!timeoutObserved) {
        throw new Error(`Unexpected persistence error: ${message}`);
      }
    }

    assert(
      timeoutObserved,
      "Adapter did not reject the write with PERSISTENCE_LOCK_TIMEOUT.",
    );

    // 4. The unverified orphan lock must remain untouched.
    assert(
      existsSync(lockPath),
      "Adapter unexpectedly removed an unverified orphan lock.",
    );

    const preservedMetadata = JSON.parse(
      readFileSync(lockPath, "utf8"),
    ) as { token?: string };

    assert(
      preservedMetadata.token === "simulated-crashed-process",
      "Orphan lock metadata was modified.",
    );

    // 5. The blocked record must not have been persisted.
    const freshService = new PersistenceService(
      new JsonFileStateAdapter(stateFile),
    );

    const projects = freshService.list("PROJECT");
    const ids = new Set(projects.map((record) => record.id));

    assert(ids.has("seed-record"), "Existing seed record was lost.");
    assert(
      !ids.has("must-not-persist"),
      "Blocked write unexpectedly reached persistent state.",
    );

    console.log(JSON.stringify({
      test: "json-file-adapter-crash-lock",
      normalLockCleanup: true,
      crashedWorkerExit: true,
      orphanLockPreserved: true,
      timeoutObserved,
      blockedWritePersisted: false,
      existingStatePreserved: true,
      status: "PASS",
    }, null, 2));

    console.log("JSON FILE ADAPTER CRASH-LOCK REGRESSION: PASS");
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
}

if (process.argv[2] === "--worker-lock") {
  const lockPath = process.argv[3];

  if (!lockPath) {
    throw new Error("Worker requires a lock path.");
  }

  createOrphanLock(resolve(lockPath));
} else {
  void main().catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  });
}
