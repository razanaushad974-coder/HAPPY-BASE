import assert from "node:assert/strict";
import type { SupabaseClient } from "@supabase/supabase-js";

import type { HappyState } from "../../../core/persistence/state";
import {
  createRuntimeScopeKey,
  isSupabaseRuntimePersistenceConfigured,
  SupabaseRuntimeSnapshotStore,
  type RuntimeSnapshotScope,
} from "../../../core/persistence/adapters/supabase-runtime-snapshot";

function createEmptyState(): HappyState {
  return {
    users: [],
    workspaces: [],
    projects: [],
    commands: [],
    missions: [],
    tasks: [],
    executions: [],
    verifications: [],
    evidence: [],
    memories: [],
    approvals: [],
    auditEvents: [],
  };
}

type FakeRow = {
  scope_key: string;
  organization_id: string;
  workspace_id: string;
  user_id: string;
  state: HappyState;
  version: number;
  created_at: string;
  updated_at: string;
};

class FakeQueryBuilder {
  private filters = new Map<string, unknown>();
  private mode: "upsert" | "insert" | "update" | "delete" | null = null;
  private writeRow: Record<string, unknown> | null = null;

  constructor(private readonly rows: Map<string, FakeRow>) {}

  upsert(row: Record<string, unknown>): FakeQueryBuilder {
    this.mode = "upsert";
    this.writeRow = row;
    return this;
  }

  insert(row: Record<string, unknown>): FakeQueryBuilder {
    this.mode = "insert";
    this.writeRow = row;
    return this;
  }

  update(row: Record<string, unknown>): FakeQueryBuilder {
    this.mode = "update";
    this.writeRow = row;
    return this;
  }

  select(): FakeQueryBuilder {
    return this;
  }

  eq(key: string, value: unknown): FakeQueryBuilder {
    this.filters.set(key, value);

    // The adapter awaits the delete query builder directly.
    if (this.mode === "delete" && key === "scope_key") {
      this.rows.delete(String(value));
    }

    return this;
  }

  single(): { data: FakeRow; error: { message: string; code?: string } | null } {
    const result = this.execute();
    assert.ifError(result.error);
    assert.ok(result.data);
    return { data: result.data, error: null };
  }

  maybeSingle(): {
    data: FakeRow | null;
    error: { message: string; code?: string } | null;
  } {
    return this.execute();
  }

  delete(): FakeQueryBuilder {
    this.mode = "delete";
    return this;
  }

  private matches(row: FakeRow): boolean {
    for (const [key, value] of this.filters) {
      if ((row as unknown as Record<string, unknown>)[key] !== value) {
        return false;
      }
    }
    return true;
  }

  private execute(): {
    data: FakeRow | null;
    error: { message: string; code?: string } | null;
  } {
    if (this.mode === "delete") {
      for (const [key, row] of this.rows) {
        if (this.matches(row)) this.rows.delete(key);
      }
      return { data: null, error: null };
    }

    if (this.mode === "insert" || this.mode === "upsert") {
      if (!this.writeRow) return { data: null, error: { message: "Missing row" } };

      const row = this.writeRow as unknown as FakeRow;
      const existing = this.rows.get(row.scope_key);

      if (this.mode === "insert" && existing) {
        return {
          data: null,
          error: { message: "duplicate key", code: "23505" },
        };
      }

      const saved: FakeRow = {
        ...row,
        created_at: existing?.created_at ?? new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      this.rows.set(saved.scope_key, saved);
      return { data: saved, error: null };
    }

    if (this.mode === "update") {
      if (!this.writeRow) return { data: null, error: { message: "Missing row" } };

      const match = [...this.rows.entries()].find(([, row]) => this.matches(row));
      if (!match) return { data: null, error: null };

      const [key, existing] = match;
      const saved: FakeRow = {
        ...existing,
        ...(this.writeRow as unknown as FakeRow),
        created_at: existing.created_at,
        updated_at: new Date().toISOString(),
      };
      this.rows.set(key, saved);
      return { data: saved, error: null };
    }

    for (const row of this.rows.values()) {
      if (this.matches(row)) return { data: row, error: null };
    }
    return { data: null, error: null };
  }
}

class FakeSupabaseClient {
  readonly rows = new Map<string, FakeRow>();

  from(): FakeQueryBuilder {
    return new FakeQueryBuilder(this.rows);
  }
}
function fakeClient(): SupabaseClient {
  return new FakeSupabaseClient() as unknown as SupabaseClient;
}

async function main(): Promise<void> {
  const scope: RuntimeSnapshotScope = {
    organizationId: "11111111-1111-4111-8111-111111111111",
    workspaceId: "22222222-2222-4222-8222-222222222222",
    userId: "33333333-3333-4333-8333-333333333333",
  };

  assert.equal(
    createRuntimeScopeKey(scope),
    "11111111-1111-4111-8111-111111111111|22222222-2222-4222-8222-222222222222|33333333-3333-4333-8333-333333333333",
  );

  const emptyEnv = {
    NODE_ENV: "test",
  } as NodeJS.ProcessEnv;

  assert.equal(
    isSupabaseRuntimePersistenceConfigured(
      emptyEnv,
    ),
    false,
  );

  const configuredEnv = {
    NODE_ENV: "test",
    NEXT_PUBLIC_SUPABASE_URL:
      "https://example.supabase.co",
    NEXT_PUBLIC_SUPABASE_ANON_KEY:
      "test-key",
  } as NodeJS.ProcessEnv;

  assert.equal(
    isSupabaseRuntimePersistenceConfigured(
      configuredEnv,
    ),
    true,
  );

  const disconnected =
    new SupabaseRuntimeSnapshotStore();

  assert.equal(
    disconnected.status(),
    "NOT_YET_CONNECTED",
  );

  const client = fakeClient();

  const connected =
    new SupabaseRuntimeSnapshotStore(
      client,
    );

  assert.equal(
    connected.status(),
    "AVAILABLE",
  );

  const state = createEmptyState();

  state.commands.push({
    id: "command-test",
    entityType: "COMMAND",
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    data: {
      text: "Persist this runtime state.",
    },
  });

  const saved =
    await connected.save(
      scope,
      state,
      7,
    );

  assert.equal(
    saved.scopeKey,
    "11111111-1111-4111-8111-111111111111|22222222-2222-4222-8222-222222222222|33333333-3333-4333-8333-333333333333",
  );

  assert.equal(
    saved.organizationId,
    "11111111-1111-4111-8111-111111111111",
  );

  assert.equal(
    saved.workspaceId,
    "22222222-2222-4222-8222-222222222222",
  );

  assert.equal(
    saved.userId,
    "33333333-3333-4333-8333-333333333333",
  );

  assert.equal(
    saved.version,
    7,
  );

  assert.equal(
    saved.state.commands.length,
    1,
  );

  const loaded =
    await connected.load(scope);

  assert.ok(loaded);
  assert.equal(
    loaded.version,
    7,
  );

  assert.equal(
    loaded.state.commands[0]?.id,
    "command-test",
  );

  const casSaved = await connected.saveIfVersion(
    scope,
    loaded.state,
    7,
  );
  assert.equal(casSaved.version, 8);

  await assert.rejects(
    () => connected.saveIfVersion(scope, state, 7),
    /RUNTIME_SNAPSHOT_VERSION_CONFLICT/,
  );

  const afterStaleWrite = await connected.load(scope);
  assert.equal(afterStaleWrite?.version, 8);

  const newScope: RuntimeSnapshotScope = {
    organizationId: "44444444-4444-4444-8444-444444444444",
    workspaceId: "55555555-5555-4555-8555-555555555555",
    userId: "66666666-6666-4666-8666-666666666666",
  };

  const firstSnapshot = await connected.saveIfVersion(
    newScope,
    createEmptyState(),
    0,
  );
  assert.equal(firstSnapshot.version, 1);

  await assert.rejects(
    () => connected.saveIfVersion(newScope, createEmptyState(), 0),
    /RUNTIME_SNAPSHOT_VERSION_CONFLICT/,
  );

  await connected.clear(scope);

  const afterClear =
    await connected.load(scope);

  assert.equal(
    afterClear,
    undefined,
  );

  let invalidClientCalls = 0;
  const guardedClient = {
    from() {
      invalidClientCalls += 1;
      return new FakeQueryBuilder(new Map<string, FakeRow>());
    },
  } as unknown as SupabaseClient;

  const invalidScope: RuntimeSnapshotScope = {
    organizationId: "demo-org",
    workspaceId: "workspace-test",
    userId: "user-test",
  };

  await assert.rejects(
    () => new SupabaseRuntimeSnapshotStore(guardedClient).save(
      invalidScope,
      createEmptyState(),
    ),
    /INVALID_SUPABASE_SCOPE/,
  );
  assert.equal(invalidClientCalls, 0);

  await assert.rejects(
    () => connected.load(invalidScope),
    /INVALID_SUPABASE_SCOPE/,
  );

  await assert.rejects(
    () => connected.clear(invalidScope),
    /INVALID_SUPABASE_SCOPE/,
  );

  console.log("Invalid UUID scope blocked before Supabase access: PASS");
  console.log(
    "Supabase runtime scope-key safety: PASS",
  );

  console.log(
    "Supabase configuration detection: PASS",
  );

  console.log(
    "NOT_YET_CONNECTED protection: PASS",
  );

  console.log(
    "Supabase snapshot save mapping: PASS",
  );

  console.log(
    "Supabase snapshot load mapping: PASS",
  );

  console.log(
    "Supabase snapshot clear mapping: PASS",
  );

  console.log(
    "#22 persistence adapter test: PASS",
  );
}

main().catch((error: unknown) => {
  console.error(error);
  throw error;
});
