import assert from "node:assert/strict";

import {
    applyApprovalDecision,
} from "../../../core/approval/persist-decision";

function createState() {
    return {
        users: [],
        workspaces: [],
        projects: [],
        commands: [],
        missions: [],
        tasks: [],
        executions: [],
        verifications: [],
        evidence: [],
        memories: [],
        approvals: [
            {
                id:
                    "approval-test-001",
                data: {
                    requestId:
                        "request-test-001",
                    planId:
                        "plan-test-001",
                    status:
                        "WAITING_APPROVAL",
                },
                version: 1,
                createdAt:
                    "2026-09-20T05:00:00.000Z",
                updatedAt:
                    "2026-09-20T05:00:00.000Z",
                entityType:
                    "APPROVAL",
            },
        ],
        auditEvents: [],
    };
}

function main(): void {
    const state =
        createState();

    const approved =
        applyApprovalDecision(
            state,
            "approval-test-001",
            "APPROVED",
            "user-test-001",
            "Approved for controlled execution.",
            "2026-09-20T05:30:00.000Z",
        );

    const approvalRecord =
        approved.state.approvals[0];

    assert.ok(
        approvalRecord,
    );

    const approval =
        approvalRecord.data as Record<
            string,
            unknown
        >;

    assert.equal(
        approval.status,
        "APPROVED",
    );

    assert.equal(
        approval.decision,
        "APPROVED",
    );

    assert.equal(
        approval.approverId,
        "user-test-001",
    );

    assert.equal(
        approval.decisionReason,
        "Approved for controlled execution.",
    );

    assert.equal(
        approved.state
            .auditEvents.length,
        1,
    );

    const auditRecord =
        approved.state.auditEvents[0];

    assert.ok(
        auditRecord,
    );

    const auditData =
        (auditRecord as unknown as {
            data: Record<string, unknown>;
        }).data;

    assert.equal(
        auditData.event,
        "APPROVAL_DECISION",
    );

    assert.equal(
        auditData.approvalId,
        "approval-test-001",
    );

    assert.equal(
        auditData.decision,
        "APPROVED",
    );

    assert.equal(
        auditData.approverId,
        "user-test-001",
    );

    let duplicateBlocked =
        false;

    try {
        applyApprovalDecision(
            approved.state,
            "approval-test-001",
            "REJECTED",
            "user-test-001",
            "Second decision must be blocked.",
        );
    } catch (error) {
        duplicateBlocked =
            error instanceof Error &&
            error.message ===
                "APPROVAL_NOT_PENDING";
    }

    assert.equal(
        duplicateBlocked,
        true,
    );

    console.log(
        "Approval decision mutation: PASS",
    );

    console.log(
        "Approval status persistence: PASS",
    );

    console.log(
        "Approver identity persistence: PASS",
    );

    console.log(
        "Decision reason persistence: PASS",
    );

    console.log(
        "Approval audit event persistence: PASS",
    );

    console.log(
        "Duplicate decision blocked: PASS",
    );

    console.log(
        "#36F pure approval decision test: PASS",
    );
}

main();
