import assert from "node:assert/strict";

import {
  SupabaseDatabaseProvider,
} from "../../../core/database/supabase-database-provider";

function clearEnv(): void {
  delete process.env.SUPABASE_URL;
  delete process.env.SUPABASE_SECRET_KEY;
  delete process.env.SUPABASE_PUBLISHABLE_KEY;
  delete process.env.NEXT_PUBLIC_SUPABASE_URL;
  delete process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
}

async function main(): Promise<void> {
  clearEnv();

  const disconnected =
    new SupabaseDatabaseProvider();

  assert.equal(
    disconnected.status(),
    "NOT_YET_CONNECTED",
  );

  process.env.SUPABASE_URL =
    "https://example.supabase.co";

  process.env.SUPABASE_PUBLISHABLE_KEY =
    "fake-publishable-key";

  const userProvider =
    new SupabaseDatabaseProvider();

  assert.equal(
    userProvider.status(),
    "AVAILABLE",
  );

  await assert.rejects(
    () =>
      userProvider.execute({
        action: "DB_SELECT",
        resource: "happy_records",
        scope: {
          organizationId:
            "00000000-0000-0000-0000-000000000001",
          workspaceId:
            "00000000-0000-0000-0000-000000000002",
        },
      }),
    /Authenticated Supabase access token is required/,
  );

  clearEnv();

  process.env.SUPABASE_URL =
    "https://example.supabase.co";

  process.env.SUPABASE_SECRET_KEY =
    "fake-secret-key";

  const secretProvider =
    new SupabaseDatabaseProvider();

  assert.equal(
    secretProvider.status(),
    "NOT_YET_CONNECTED",
  );

  process.env.SUPABASE_PUBLISHABLE_KEY =
    "";

  await assert.rejects(
    () =>
      secretProvider.execute({
        action: "DB_SELECT",
        resource: "happy_records",
        scope: {
          organizationId:
            "00000000-0000-0000-0000-000000000001",
          workspaceId:
            "00000000-0000-0000-0000-000000000002",
        },
        auth: {
          accessToken:
            "fake-access-token",
        },
      }),
    /SUPABASE_SECRET_KEY is reserved/,
  );

  clearEnv();

  console.log(
    "Supabase authenticated provider contract test: PASS",
  );

  console.log({
    disconnectedStatus:
      disconnected.status(),
    userProviderStatus:
      userProvider.status(),
    secretOnlyProviderStatus:
      secretProvider.status(),
    missingAccessTokenBlocked: true,
    secretKeyRlsBypassBlocked: true,
    realConnectionAttempted: false,
  });
}

void main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});
