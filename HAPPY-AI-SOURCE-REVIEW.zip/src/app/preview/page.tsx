"use client";

import {
    useEffect,
    useMemo,
    useState,
} from "react";

type WorkspacePayload = {
    metrics?: Record<string, unknown>;
    currentMission?: unknown;
    recentActivity?: unknown[];
    taskFlow?: unknown[];
    [key: string]: unknown;
};

type Capability = {
    name: string;
    status:
        | "DETECTED"
        | "NOT_DETECTED"
        | "BLOCKED"
        | "NOT_YET_CONNECTED";
    evidence: string;
};

type CapabilityRegistryItem = {
    id: string;
    name: string;
    domain: string;
    description: string;
    status:
        | "AVAILABLE"
        | "NOT_YET_CONNECTED"
        | "BLOCKED";
    executionTypes?: string[];
    actions?: string[];
    riskLevel?: string;
    requiresApproval?: boolean;
    verificationRequired?: boolean;
    evidenceRequired?: boolean;
};

type CapabilityRegistryPayload = {
    total: number;
    counts: {
        AVAILABLE: number;
        NOT_YET_CONNECTED: number;
        BLOCKED: number;
    };
    capabilities: CapabilityRegistryItem[];
};

type PreviewPayload = {
    generatedAt: string;
    environment: string;
    inventory: {
        sourceFiles: number;
        pages: number;
        apiRoutes: number;
        moduleFiles: number;
        coreFiles: number;
        integrationFiles: number;
        aiFiles: number;
        tests: number;
        totalTrackedProjectFiles: number;
    };
    codebase: {
        pages: string[];
        apiRoutes: string[];
        modules: string[];
        integrations: string[];
    };
    git: {
        branch: string;
        latestCommit: string;
        changedFiles: string[];
        changedFileCount: number;
        recentMilestones: string[];
    };
    capabilities: Capability[];
    configuration: {
        geminiConfigured: boolean;
        supabaseUrlConfigured: boolean;
        supabasePublishableKeyConfigured: boolean;
        livePreviewEnabled: boolean;
    };
};

const HISTORICAL_REFERENCE = [
    ["#09", "Safe File Execution"],
    ["#10", "Workspace File Operations"],
    ["#11", "HTTP API Execution"],
    ["#13", "Browser Execution"],
    ["#14", "Database Execution Boundary"],
    ["#15", "Supabase Foundation"],
    ["#16", "AI + Context + Output"],
    ["#17", "Workspace Persistence"],
    ["#18", "Authenticated Tenant Binding"],
    ["#19", "Authenticated Tenant Bootstrap"],
];

function numberMetric(
    value: unknown,
): number {
    if (
        typeof value === "number" &&
        Number.isFinite(value)
    ) {
        return value;
    }

    return 0;
}

function getStateNumber(
    payload: WorkspacePayload | null,
    names: string[],
): number {
    if (!payload) {
        return 0;
    }

    const root =
        payload.metrics &&
        typeof payload.metrics === "object"
            ? payload.metrics
            : {};

    for (
        const name
        of names
    ) {
        if (
            name in root
        ) {
            return numberMetric(
                root[name],
            );
        }
    }

    return 0;
}

function capabilityClass(
    status: Capability["status"],
): string {
    if (
        status === "DETECTED"
    ) {
        return "border-emerald-400/25 bg-emerald-400/10 text-emerald-300";
    }

    if (
        status === "BLOCKED"
    ) {
        return "border-red-400/25 bg-red-400/10 text-red-300";
    }

    if (
        status === "NOT_YET_CONNECTED"
    ) {
        return "border-amber-400/25 bg-amber-400/10 text-amber-300";
    }

    return "border-zinc-700 bg-zinc-900 text-zinc-400";
}

function prettyJson(
    value: unknown,
): string {
    try {
        return JSON.stringify(
            value,
            null,
            2,
        );
    }
    catch {
        return String(value);
    }
}

export default function HappyLiveBuildObservatory() {
    const [
        preview,
        setPreview,
    ] =
        useState<PreviewPayload | null>(
            null,
        );

    const [
        workspace,
        setWorkspace,
    ] =
        useState<WorkspacePayload | null>(
            null,
        );

    const [
        capabilityRegistry,
        setCapabilityRegistry,
    ] =
        useState<CapabilityRegistryPayload | null>(
            null,
        );

    const [
        loading,
        setLoading,
    ] =
        useState(true);

    const [
        error,
        setError,
    ] =
        useState("");

    const [
        lastUpdated,
        setLastUpdated,
    ] =
        useState("");

    async function refresh() {
        try {
            const results =
                await Promise.all(
                    [
                        fetch(
                            "/api/preview",
                            {
                                cache:
                                    "no-store",
                            },
                        ),
                        fetch(
                            "/api/workspace/state",
                            {
                                cache:
                                    "no-store",
                            },
                        ),
                        fetch(
                            "/api/capabilities",
                            {
                                cache:
                                    "no-store",
                            },
                        ),
                    ],
                );

            const previewResponse =
                results[0];

            const workspaceResponse =
                results[1];

            const capabilityResponse =
                results[2];

            const previewData =
                await previewResponse.json();

            const workspaceData =
                await workspaceResponse.json();

            const capabilityData =
                await capabilityResponse.json();

            if (
                !previewResponse.ok
            ) {
                throw new Error(
                    previewData?.error ||
                    "Live preview inventory failed",
                );
            }

            if (
                !capabilityResponse.ok
            ) {
                throw new Error(
                    capabilityData?.error ||
                    "Capability registry unavailable",
                );
            }

            setPreview(
                previewData as PreviewPayload,
            );

            setCapabilityRegistry(
                capabilityData as CapabilityRegistryPayload,
            );

            if (
                workspaceResponse.ok
            ) {
                setWorkspace(
                    workspaceData as WorkspacePayload,
                );
            }

            if (
                !workspaceResponse.ok &&
                !workspaceData?.error
            ) {
                throw new Error(
                    "Workspace state unavailable",
                );
            }

            setError("");

            setLastUpdated(
                new Date().toLocaleTimeString(),
            );
        }
        catch (
            requestError
        ) {
            setError(
                requestError instanceof Error
                    ? requestError.message
                    : "Live observatory request failed",
            );
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(
        () => {
            const initialRequest =
                window.setTimeout(
                    () => {
                        void refresh();
                    },
                    0,
                );

            const timer =
                window.setInterval(
                    () => {
                        void refresh();
                    },
                    3000,
                );

            return () => {
                window.clearTimeout(
                    initialRequest,
                );

                window.clearInterval(
                    timer,
                );
            };
        },
        [],
    );

    const runtimeMetrics =
        useMemo(
            () => [
                [
                    "Commands",
                    getStateNumber(
                        workspace,
                        [
                            "commands",
                            "commandCount",
                            "totalCommands",
                        ],
                    ),
                ],
                [
                    "Missions",
                    getStateNumber(
                        workspace,
                        [
                            "missions",
                            "missionCount",
                            "totalMissions",
                            "activeMissions",
                        ],
                    ),
                ],
                [
                    "Tasks",
                    getStateNumber(
                        workspace,
                        [
                            "tasks",
                            "taskCount",
                            "totalTasks",
                        ],
                    ),
                ],
                [
                    "Executions",
                    getStateNumber(
                        workspace,
                        [
                            "executions",
                            "executionCount",
                            "totalExecutions",
                        ],
                    ),
                ],
                [
                    "Verifications",
                    getStateNumber(
                        workspace,
                        [
                            "verifications",
                            "verificationCount",
                            "totalVerifications",
                        ],
                    ),
                ],
                [
                    "Evidence",
                    getStateNumber(
                        workspace,
                        [
                            "evidence",
                            "evidenceCount",
                            "totalEvidence",
                        ],
                    ),
                ],
                [
                    "Memories",
                    getStateNumber(
                        workspace,
                        [
                            "memories",
                            "memoryCount",
                            "totalMemories",
                        ],
                    ),
                ],
                [
                    "Approvals",
                    getStateNumber(
                        workspace,
                        [
                            "approvals",
                            "approvalCount",
                            "pendingApprovals",
                        ],
                    ),
                ],
            ],
            [workspace],
        );

    const recentActivity =
        Array.isArray(
            workspace?.recentActivity,
        )
            ? workspace.recentActivity
            : [];

    const currentMission =
        workspace?.currentMission;

    return (
        <main className="min-h-screen bg-[#050505] text-zinc-100">
            <div className="mx-auto max-w-[1500px] px-5 py-8 md:px-8">

                <header className="mb-8">
                    <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
                        <div>
                            <div className="text-xs font-semibold uppercase tracking-[0.3em] text-amber-400">
                                HAPPY AI
                            </div>

                            <h1 className="mt-2 text-4xl font-black tracking-tight md:text-6xl">
                                Live Build Observatory
                            </h1>

                            <p className="mt-4 max-w-4xl text-sm leading-7 text-zinc-400 md:text-base">
                                Automatic view of the HAPPY codebase, runtime state,
                                execution boundaries, current Git changes, missions,
                                tasks, evidence and newly discovered project files.
                            </p>
                        </div>

                        <div className="rounded-3xl border border-emerald-400/20 bg-emerald-400/5 px-5 py-4">
                            <div className="flex items-center gap-2">
                                <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-emerald-400" />

                                <span className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">
                                    {loading
                                        ? "CONNECTING"
                                        : error
                                            ? "PARTIAL"
                                            : "LIVE"}
                                </span>
                            </div>

                            <div className="mt-2 text-xs text-zinc-500">
                                {lastUpdated
                                    ? `Last refresh ${lastUpdated}`
                                    : "Awaiting state"}
                            </div>

                            <div className="mt-1 text-xs text-zinc-600">
                                Automatic refresh every 3 seconds
                            </div>
                        </div>
                    </div>
                </header>

                {error && (
                    <section className="mb-6 rounded-2xl border border-amber-400/20 bg-amber-400/5 px-5 py-4">
                        <div className="text-xs font-bold uppercase tracking-[0.18em] text-amber-300">
                            Observatory notice
                        </div>

                        <div className="mt-2 text-sm text-zinc-300">
                            {error}
                        </div>

                        <div className="mt-2 text-xs text-zinc-500">
                            Auto-discovered codebase data can still remain visible;
                            authenticated workspace runtime data appears when its
                            existing session boundary is available.
                        </div>
                    </section>
                )}

                <section className="mb-8 rounded-3xl border border-amber-400/20 bg-gradient-to-br from-amber-400/10 via-zinc-950 to-black p-6">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                        <div>
                            <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                                HAPPY Runtime
                            </div>

                            <h2 className="mt-2 text-2xl font-bold md:text-3xl">
                                COMMAND → UNDERSTAND → PLAN → EXECUTE → VERIFY → PERSIST
                            </h2>
                        </div>

                        <div className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-4 py-2 text-xs font-bold tracking-[0.12em] text-emerald-300">
                            ONE HAPPY INTELLIGENCE
                        </div>
                    </div>

                    <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                        {[
                            "COMMAND",
                            "UNDERSTAND",
                            "PLAN",
                            "EXECUTE",
                            "VERIFY",
                            "PERSIST",
                        ].map(
                            (
                                stage,
                                index,
                            ) => (
                                <div
                                    key={stage}
                                    className="rounded-2xl border border-zinc-800 bg-black/50 p-4"
                                >
                                    <div className="text-[10px] text-zinc-600">
                                        {String(
                                            index + 1,
                                        ).padStart(
                                            2,
                                            "0",
                                        )}
                                    </div>

                                    <div className="mt-2 text-sm font-bold">
                                        {stage}
                                    </div>

                                    <div className="mt-2 text-[10px] uppercase tracking-[0.14em] text-emerald-300">
                                        Engine path
                                    </div>
                                </div>
                            ),
                        )}
                    </div>
                </section>

                <section className="mb-8">
                    <div className="mb-4 flex items-end justify-between">
                        <div>
                            <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                                LIVE RUNTIME
                            </div>

                            <h2 className="mt-1 text-2xl font-bold">
                                Real persisted workspace state
                            </h2>
                        </div>

                        <div className="text-xs text-zinc-600">
                            Source: /api/workspace/state
                        </div>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                        {runtimeMetrics.map(
                            (
                                [label, value],
                            ) => (
                                <div
                                    key={String(label)}
                                    className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5"
                                >
                                    <div className="text-xs uppercase tracking-[0.16em] text-zinc-600">
                                        {String(label)}
                                    </div>

                                    <div className="mt-3 text-4xl font-black">
                                        {String(value)}
                                    </div>

                                    <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.16em] text-emerald-300">
                                        LIVE STATE
                                    </div>
                                </div>
                            ),
                        )}
                    </div>
                </section>

                <section className="mb-8 grid gap-6 xl:grid-cols-2">
                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            AUTO-DISCOVERED CODEBASE
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            What exists right now
                        </h2>

                        {preview && (
                            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
                                {[
                                    ["Source files", preview.inventory.sourceFiles],
                                    ["Pages", preview.inventory.pages],
                                    ["API routes", preview.inventory.apiRoutes],
                                    ["Modules", preview.inventory.moduleFiles],
                                    ["Core files", preview.inventory.coreFiles],
                                    ["Integrations", preview.inventory.integrationFiles],
                                    ["AI files", preview.inventory.aiFiles],
                                    ["Tests", preview.inventory.tests],
                                ].map(
                                    (
                                        [label, value],
                                    ) => (
                                        <div
                                            key={String(label)}
                                            className="rounded-2xl border border-zinc-800 bg-black/40 p-4"
                                        >
                                            <div className="text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                                {String(label)}
                                            </div>

                                            <div className="mt-2 text-2xl font-black">
                                                {String(value)}
                                            </div>
                                        </div>
                                    ),
                                )}
                            </div>
                        )}
                    </div>

                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            GIT LIVE VIEW
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Current working tree
                        </h2>

                        {preview && (
                            <>
                                <div className="mt-5 rounded-2xl border border-zinc-800 bg-black/40 p-4">
                                    <div className="text-[10px] uppercase tracking-[0.14em] text-zinc-600">
                                        Branch
                                    </div>

                                    <div className="mt-2 break-all font-semibold text-amber-300">
                                        {preview.git.branch}
                                    </div>

                                    <div className="mt-4 text-[10px] uppercase tracking-[0.14em] text-zinc-600">
                                        Latest commit
                                    </div>

                                    <div className="mt-2 break-words text-sm text-zinc-300">
                                        {preview.git.latestCommit}
                                    </div>

                                    <div className="mt-4 text-[10px] uppercase tracking-[0.14em] text-zinc-600">
                                        Changed files
                                    </div>

                                    <div className="mt-2 text-2xl font-black">
                                        {preview.git.changedFileCount}
                                    </div>
                                </div>

                                <div className="mt-4 max-h-44 overflow-auto rounded-2xl border border-zinc-800 bg-black/30 p-4">
                                    {preview.git.changedFiles.length === 0 && (
                                        <div className="text-sm text-zinc-600">
                                            Working tree clean.
                                        </div>
                                    )}

                                    {preview.git.changedFiles.map(
                                        (
                                            file,
                                        ) => (
                                            <div
                                                key={file}
                                                className="border-b border-zinc-900 py-2 font-mono text-xs text-zinc-500 last:border-0"
                                            >
                                                {file}
                                            </div>
                                        ),
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                </section>

                <section className="mb-8">
                    <div className="mb-4">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            CAPABILITY DETECTION
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Observed from the actual project
                        </h2>

                        <p className="mt-2 text-sm text-zinc-600">
                            These labels come from detected source boundaries and
                            configuration. They are not treated as proof of successful
                            production execution.
                        </p>
                    </div>

                    <div className="grid gap-3 lg:grid-cols-2">
                        {(preview?.capabilities || []).map(
                            (
                                capability,
                            ) => (
                                <div
                                    key={capability.name}
                                    className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4"
                                >
                                    <div className="flex items-center justify-between gap-4">
                                        <div className="font-semibold text-zinc-200">
                                            {capability.name}
                                        </div>

                                        <span
                                            className={`shrink-0 rounded-full border px-3 py-1 text-[10px] font-bold tracking-[0.1em] ${capabilityClass(
                                                capability.status,
                                            )}`}
                                        >
                                            {capability.status}
                                        </span>
                                    </div>

                                    <div className="mt-3 break-words text-xs leading-5 text-zinc-600">
                                        {capability.evidence}
                                    </div>
                                </div>
                            ),
                        )}
                    </div>
                </section>

                <section className="mb-8 rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                        <div>
                            <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                                LIVE CAPABILITY REGISTRY
                            </div>

                            <h2 className="mt-1 text-2xl font-bold">
                                Actual HAPPY capability definitions
                            </h2>

                            <p className="mt-2 max-w-4xl text-sm leading-6 text-zinc-600">
                                This panel is sourced directly from
                                <span className="font-mono text-zinc-500">
                                    {" /api/capabilities "}
                                </span>
                                and reflects the actual registered capability state.
                                It does not convert NOT_YET_CONNECTED or BLOCKED entries
                                into available functionality.
                            </p>
                        </div>

                        <div className="rounded-2xl border border-zinc-800 bg-black/40 px-4 py-3">
                            <div className="text-[10px] uppercase tracking-[0.14em] text-zinc-600">
                                Registry source
                            </div>

                            <div className="mt-1 font-mono text-xs text-amber-300">
                                /api/capabilities
                            </div>
                        </div>
                    </div>

                    {capabilityRegistry && (
                        <>
                            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                                <div className="rounded-2xl border border-zinc-800 bg-black/40 p-4">
                                    <div className="text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                        Total
                                    </div>

                                    <div className="mt-2 text-3xl font-black">
                                        {capabilityRegistry.total}
                                    </div>

                                    <div className="mt-1 text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                        Registered
                                    </div>
                                </div>

                                <div className="rounded-2xl border border-emerald-400/15 bg-emerald-400/5 p-4">
                                    <div className="text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                        Available
                                    </div>

                                    <div className="mt-2 text-3xl font-black text-emerald-300">
                                        {capabilityRegistry.counts.AVAILABLE}
                                    </div>

                                    <div className="mt-1 text-[10px] uppercase tracking-[0.12em] text-emerald-300">
                                        AVAILABLE
                                    </div>
                                </div>

                                <div className="rounded-2xl border border-amber-400/15 bg-amber-400/5 p-4">
                                    <div className="text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                        Pending connection
                                    </div>

                                    <div className="mt-2 text-3xl font-black text-amber-300">
                                        {capabilityRegistry.counts.NOT_YET_CONNECTED}
                                    </div>

                                    <div className="mt-1 text-[10px] uppercase tracking-[0.12em] text-amber-300">
                                        NOT_YET_CONNECTED
                                    </div>
                                </div>

                                <div className="rounded-2xl border border-red-400/15 bg-red-400/5 p-4">
                                    <div className="text-[10px] uppercase tracking-[0.12em] text-zinc-600">
                                        Safety blocked
                                    </div>

                                    <div className="mt-2 text-3xl font-black text-red-300">
                                        {capabilityRegistry.counts.BLOCKED}
                                    </div>

                                    <div className="mt-1 text-[10px] uppercase tracking-[0.12em] text-red-300">
                                        BLOCKED
                                    </div>
                                </div>
                            </div>

                            <div className="mt-5 max-h-[720px] space-y-3 overflow-auto pr-1">
                                {capabilityRegistry.capabilities.map(
                                    (
                                        capability,
                                    ) => (
                                        <div
                                            key={capability.id}
                                            className="rounded-2xl border border-zinc-800 bg-black/30 p-5"
                                        >
                                            <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                                                <div className="min-w-0">
                                                    <div className="flex flex-wrap items-center gap-2">
                                                        <div className="font-semibold text-zinc-200">
                                                            {capability.name}
                                                        </div>

                                                        <span className="rounded-full border border-zinc-800 bg-zinc-900 px-2.5 py-1 font-mono text-[9px] text-zinc-500">
                                                            {capability.id}
                                                        </span>
                                                    </div>

                                                    <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.14em] text-amber-300">
                                                        {capability.domain}
                                                    </div>

                                                    <div className="mt-2 text-xs leading-5 text-zinc-500">
                                                        {capability.description}
                                                    </div>
                                                </div>

                                                <span
                                                    className={`shrink-0 rounded-full border px-3 py-1 text-[10px] font-bold tracking-[0.1em] ${capabilityClass(
                                                        capability.status ===
                                                        "AVAILABLE"
                                                            ? "DETECTED"
                                                            : capability.status,
                                                    )}`}
                                                >
                                                    {capability.status}
                                                </span>
                                            </div>

                                            <div className="mt-4 flex flex-wrap gap-2">
                                                {capability.riskLevel && (
                                                    <span className="rounded-full border border-zinc-800 bg-zinc-900 px-3 py-1 text-[9px] uppercase tracking-[0.1em] text-zinc-500">
                                                        Risk: {capability.riskLevel}
                                                    </span>
                                                )}

                                                {capability.requiresApproval && (
                                                    <span className="rounded-full border border-amber-400/20 bg-amber-400/5 px-3 py-1 text-[9px] uppercase tracking-[0.1em] text-amber-300">
                                                        Approval required
                                                    </span>
                                                )}

                                                {capability.verificationRequired && (
                                                    <span className="rounded-full border border-zinc-700 bg-zinc-900 px-3 py-1 text-[9px] uppercase tracking-[0.1em] text-zinc-400">
                                                        Verification required
                                                    </span>
                                                )}

                                                {capability.evidenceRequired && (
                                                    <span className="rounded-full border border-zinc-700 bg-zinc-900 px-3 py-1 text-[9px] uppercase tracking-[0.1em] text-zinc-400">
                                                        Evidence required
                                                    </span>
                                                )}
                                            </div>

                                            {capability.executionTypes &&
                                                capability.executionTypes.length > 0 && (
                                                    <div className="mt-3">
                                                        <div className="text-[9px] uppercase tracking-[0.12em] text-zinc-700">
                                                            Execution types
                                                        </div>

                                                        <div className="mt-2 flex flex-wrap gap-2">
                                                            {capability.executionTypes.map(
                                                                (
                                                                    executionType,
                                                                ) => (
                                                                    <span
                                                                        key={executionType}
                                                                        className="rounded-full border border-zinc-800 bg-zinc-950 px-2.5 py-1 font-mono text-[9px] text-zinc-500"
                                                                    >
                                                                        {executionType}
                                                                    </span>
                                                                ),
                                                            )}
                                                        </div>
                                                    </div>
                                                )}
                                        </div>
                                    ),
                                )}
                            </div>
                        </>
                    )}

                    {!capabilityRegistry && (
                        <div className="mt-5 rounded-2xl border border-zinc-800 bg-black/30 p-5 text-sm text-zinc-600">
                            Capability registry data is not available yet.
                        </div>
                    )}
                </section>

                <section className="mb-8 grid gap-6 xl:grid-cols-2">
                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            CURRENT MISSION
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Live mission snapshot
                        </h2>

                        <pre className="mt-5 max-h-64 overflow-auto rounded-2xl border border-zinc-800 bg-black/50 p-4 font-mono text-xs leading-6 text-zinc-400">
                            {prettyJson(
                                currentMission ||
                                {
                                    status:
                                        "NO_CURRENT_MISSION",
                                },
                            )}
                        </pre>
                    </div>

                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            RECENT ACTIVITY
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Latest runtime events
                        </h2>

                        <div className="mt-5 max-h-64 space-y-2 overflow-auto">
                            {recentActivity.length === 0 && (
                                <div className="rounded-2xl border border-zinc-800 bg-black/30 p-4 text-sm text-zinc-600">
                                    No recent activity exposed by the live state endpoint.
                                </div>
                            )}

                            {recentActivity
                                .slice(
                                    0,
                                    20,
                                )
                                .map(
                                    (
                                        event,
                                        index,
                                    ) => (
                                        <div
                                            key={`${index}-${JSON.stringify(event)}`}
                                            className="rounded-2xl border border-zinc-800 bg-black/30 p-4"
                                        >
                                            <div className="text-xs leading-5 text-zinc-500">
                                                {prettyJson(
                                                    event,
                                                )}
                                            </div>
                                        </div>
                                    ),
                                )}
                        </div>
                    </div>
                </section>

                <section className="mb-8 grid gap-6 xl:grid-cols-2">
                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            BUILD CONTINUITY
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Historical milestones
                        </h2>

                        <div className="mt-5 space-y-2">
                            {HISTORICAL_REFERENCE.map(
                                (
                                    [id, title],
                                ) => (
                                    <div
                                        key={id}
                                        className="flex items-center justify-between rounded-xl border border-zinc-800 bg-black/30 px-4 py-3"
                                    >
                                        <div>
                                            <span className="mr-3 font-black text-amber-400">
                                                {id}
                                            </span>

                                            <span className="text-sm text-zinc-300">
                                                {title}
                                            </span>
                                        </div>

                                        <span className="text-[10px] font-bold uppercase tracking-[0.1em] text-emerald-300">
                                            REFERENCE
                                        </span>
                                    </div>
                                ),
                            )}
                        </div>

                        {preview && (
                            <div className="mt-5 rounded-2xl border border-amber-400/10 bg-amber-400/5 p-4">
                                <div className="text-[10px] uppercase tracking-[0.14em] text-amber-300">
                                    Git milestones detected automatically
                                </div>

                                <div className="mt-3 flex flex-wrap gap-2">
                                    {preview.git.recentMilestones.length === 0 && (
                                        <span className="text-xs text-zinc-600">
                                            No numbered milestone tags detected in recent commits.
                                        </span>
                                    )}

                                    {preview.git.recentMilestones.map(
                                        (
                                            milestone,
                                        ) => (
                                            <span
                                                key={milestone}
                                                className="rounded-full border border-zinc-700 bg-zinc-900 px-3 py-1 text-[10px] font-bold text-zinc-400"
                                            >
                                                {milestone}
                                            </span>
                                        ),
                                    )}
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                        <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                            CONFIGURATION
                        </div>

                        <h2 className="mt-1 text-2xl font-bold">
                            Connection visibility
                        </h2>

                        <div className="mt-5 space-y-2">
                            {preview && [
                                [
                                    "Gemini API configured",
                                    preview.configuration.geminiConfigured,
                                ],
                                [
                                    "Supabase URL configured",
                                    preview.configuration.supabaseUrlConfigured,
                                ],
                                [
                                    "Supabase publishable key configured",
                                    preview.configuration.supabasePublishableKeyConfigured,
                                ],
                                [
                                    "Live preview enabled",
                                    preview.configuration.livePreviewEnabled,
                                ],
                            ].map(
                                (
                                    [label, configured],
                                ) => (
                                    <div
                                        key={String(label)}
                                        className="flex items-center justify-between rounded-xl border border-zinc-800 bg-black/30 px-4 py-3"
                                    >
                                        <span className="text-sm text-zinc-400">
                                            {String(label)}
                                        </span>

                                        <span
                                            className={
                                                configured
                                                    ? "rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-bold text-emerald-300"
                                                    : "rounded-full border border-zinc-700 bg-zinc-900 px-3 py-1 text-[10px] font-bold text-zinc-500"
                                            }
                                        >
                                            {configured
                                                ? "CONFIGURED"
                                                : "NOT CONFIGURED"}
                                        </span>
                                    </div>
                                ),
                            )}

                            <div className="rounded-2xl border border-red-400/15 bg-red-400/5 p-4">
                                <div className="text-[10px] font-bold uppercase tracking-[0.14em] text-red-300">
                                    Explicit safety state
                                </div>

                                <div className="mt-2 text-sm text-zinc-300">
                                    External DB persistence remains
                                    NOT_YET_CONNECTED and sandbox execution
                                    remains BLOCKED.
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="mb-8 rounded-3xl border border-amber-400/20 bg-amber-400/5 p-6">
                    <div className="text-xs uppercase tracking-[0.22em] text-amber-300">
                        FUTURE-PROOF PREVIEW
                    </div>

                    <h2 className="mt-1 text-2xl font-bold">
                        New work appears automatically
                    </h2>

                    <p className="mt-3 max-w-5xl text-sm leading-7 text-zinc-400">
                        New source files, modules, API routes, pages, integrations,
                        AI files, tests and Git changes are discovered automatically
                        by the observatory. Future HAPPY development therefore becomes
                        visible here without rebuilding this preview page for every
                        individual module.
                    </p>

                    <div className="mt-5 grid gap-3 md:grid-cols-3">
                        <div className="rounded-2xl border border-zinc-800 bg-black/40 p-4">
                            <div className="text-xs text-zinc-600">
                                HISTORY
                            </div>

                            <div className="mt-2 font-semibold">
                                Previous milestones stay visible
                            </div>
                        </div>

                        <div className="rounded-2xl border border-zinc-800 bg-black/40 p-4">
                            <div className="text-xs text-zinc-600">
                                NOW
                            </div>

                            <div className="mt-2 font-semibold">
                                Runtime + codebase stay live
                            </div>
                        </div>

                        <div className="rounded-2xl border border-zinc-800 bg-black/40 p-4">
                            <div className="text-xs text-zinc-600">
                                NEXT
                            </div>

                            <div className="mt-2 font-semibold">
                                New work is auto-discovered
                            </div>
                        </div>
                    </div>
                </section>

                <footer className="border-t border-zinc-900 pt-6 text-xs text-zinc-700">
                    HAPPY AI • Live Build Observatory v2 • Existing Mission Engine preserved •
                    Status labels distinguish detected boundaries from verified execution
                </footer>
            </div>
        </main>
    );
}



