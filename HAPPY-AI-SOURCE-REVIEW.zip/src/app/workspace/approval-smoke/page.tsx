"use client";

import {
    useEffect,
    useState,
} from "react";

const TARGET_APPROVAL_ID =
    "approval-2298c5bb-3875-4cd7-805c-984c4983bb07";

const TARGET_REQUEST_ID =
    "2298c5bb-3875-4cd7-805c-984c4983bb07";

interface ApprovalItem {
    id: string;
    requestId: string | null;
    planId: string | null;
    status: string | null;
    createdAt: string;
    updatedAt: string;
}

interface ApiResponse {
    status?: string;
    verified?: boolean;
    scopeKey?: string;
    approvalId?: string;
    requestId?: string | null;
    planId?: string | null;
    decisionId?: string;
    auditEventId?: string;
    decision?: string;
    approverId?: string;
    reason?: string;
    decidedAt?: string;
    version?: number;
    updatedAt?: string;
    remotePersistence?: string;
    approvals?: ApprovalItem[];
    count?: number;
    error?: string;
}

export default function ApprovalSmokePage() {
    const [loading, setLoading] =
        useState(true);

    const [submitting, setSubmitting] =
        useState(false);

    const [result, setResult] =
        useState<ApiResponse | null>(null);

    const [error, setError] =
        useState<string | null>(null);

    async function loadApprovals() {
        setLoading(true);
        setError(null);

        try {
            const response =
                await fetch(
                    "/api/approvals/decision",
                    {
                        method: "GET",
                        credentials: "include",
                        cache: "no-store",
                    },
                );

            const body =
                (await response.json()) as ApiResponse;

            if (!response.ok) {
                throw new Error(
                    body.error ||
                        `HTTP ${response.status}`,
                );
            }

            const target =
                body.approvals?.find(
                    (item) =>
                        item.id ===
                            TARGET_APPROVAL_ID &&
                        item.requestId ===
                            TARGET_REQUEST_ID,
                );

            setResult({
                ...body,
                approvalId:
                    target?.id ||
                    TARGET_APPROVAL_ID,
                requestId:
                    target?.requestId ??
                    TARGET_REQUEST_ID,
            });
        } catch (caught) {
            setError(
                caught instanceof Error
                    ? caught.message
                    : "Approval GET failed.",
            );
        } finally {
            setLoading(false);
        }
    }

    async function approveTarget() {
        setSubmitting(true);
        setError(null);

        try {
            const response =
                await fetch(
                    "/api/approvals/decision",
                    {
                        method: "POST",
                        credentials: "include",
                        headers: {
                            "Content-Type":
                                "application/json",
                        },
                        body: JSON.stringify({
                            approvalId:
                                TARGET_APPROVAL_ID,
                            decision:
                                "APPROVED",
                            reason:
                                "#36F live authenticated approval test.",
                        }),
                    },
                );

            const body =
                (await response.json()) as ApiResponse;

            if (!response.ok) {
                throw new Error(
                    body.error ||
                        `HTTP ${response.status}`,
                );
            }

            setResult(body);
        } catch (caught) {
            setError(
                caught instanceof Error
                    ? caught.message
                    : "Approval POST failed.",
            );
        } finally {
            setSubmitting(false);
        }
    }

    useEffect(() => {
        const initialRequest =
            window.setTimeout(() => {
                void loadApprovals();
            }, 0);

        return () => {
            window.clearTimeout(initialRequest);
        };
    }, []);

    const currentTargetStatus =
        result?.approvals?.find(
            (item) =>
                item.id ===
                TARGET_APPROVAL_ID,
        )?.status;

    const persistedApproval =
        result?.status ===
        "APPROVAL_DECISION_PERSISTED";

    return (
        <main
            style={{
                minHeight: "100vh",
                padding: "40px",
                background: "#080808",
                color: "#f5f5f5",
                fontFamily:
                    "Arial, sans-serif",
            }}
        >
            <div
                style={{
                    maxWidth: "900px",
                    margin: "0 auto",
                }}
            >
                <p
                    style={{
                        opacity: 0.65,
                        letterSpacing: "0.08em",
                    }}
                >
                    HAPPY / DIAGNOSTICS
                </p>

                <h1>
                    #36F Live Approval Decision
                </h1>

                <p
                    style={{
                        opacity: 0.75,
                        lineHeight: 1.6,
                    }}
                >
                    Authenticated browser session →
                    GET pending approval →
                    APPROVE exact #36B approval →
                    remote Supabase persistence.
                </p>

                <section
                    style={{
                        marginTop: "28px",
                        padding: "24px",
                        border:
                            "1px solid #333",
                        borderRadius: "14px",
                    }}
                >
                    <div>
                        <strong>
                            Target approval
                        </strong>
                        <div
                            style={{
                                marginTop: "8px",
                                wordBreak:
                                    "break-all",
                                opacity: 0.8,
                            }}
                        >
                            {TARGET_APPROVAL_ID}
                        </div>
                    </div>

                    <div
                        style={{
                            marginTop: "20px",
                        }}
                    >
                        <strong>
                            Target request
                        </strong>
                        <div
                            style={{
                                marginTop: "8px",
                                wordBreak:
                                    "break-all",
                                opacity: 0.8,
                            }}
                        >
                            {TARGET_REQUEST_ID}
                        </div>
                    </div>
                </section>

                {loading && (
                    <p
                        style={{
                            marginTop: "24px",
                        }}
                    >
                        Loading authenticated approvals...
                    </p>
                )}

                {error && (
                    <pre
                        style={{
                            marginTop: "24px",
                            padding: "18px",
                            borderRadius: "10px",
                            background:
                                "#241010",
                            color: "#ffb0b0",
                            whiteSpace:
                                "pre-wrap",
                        }}
                    >
                        {error}
                    </pre>
                )}

                {!loading &&
                    !error && (
                        <section
                            style={{
                                marginTop: "24px",
                                padding: "24px",
                                border:
                                    "1px solid #333",
                                borderRadius: "14px",
                            }}
                        >
                            <h2>
                                Current target status
                            </h2>

                            <p>
                                {currentTargetStatus ||
                                    "NOT_FOUND"}
                            </p>

                            {currentTargetStatus ===
                                "WAITING_APPROVAL" && (
                                <button
                                    type="button"
                                    onClick={
                                        approveTarget
                                    }
                                    disabled={
                                        submitting
                                    }
                                    style={{
                                        marginTop:
                                            "14px",
                                        padding:
                                            "12px 18px",
                                        borderRadius:
                                            "10px",
                                        border:
                                            "1px solid #8f7a36",
                                        background:
                                            "#151515",
                                        color:
                                            "#f5d77a",
                                        cursor:
                                            submitting
                                                ? "wait"
                                                : "pointer",
                                    }}
                                >
                                    {submitting
                                        ? "Approving..."
                                        : "Approve #36B test approval"}
                                </button>
                            )}

                            {currentTargetStatus ===
                                "APPROVED" && (
                                <p
                                    style={{
                                        marginTop:
                                            "16px",
                                        color:
                                            "#9fe3a6",
                                    }}
                                >
                                    Target approval
                                    is already APPROVED.
                                </p>
                            )}
                        </section>
                    )}

                {persistedApproval && (
                    <section
                        style={{
                            marginTop: "24px",
                            padding: "24px",
                            border:
                                "1px solid #3b6",
                            borderRadius: "14px",
                        }}
                    >
                        <h2>
                            LIVE_REMOTE_APPROVAL_PERSISTED
                        </h2>

                        <pre
                            style={{
                                marginTop: "16px",
                                whiteSpace:
                                    "pre-wrap",
                                overflowX:
                                    "auto",
                                lineHeight: 1.5,
                            }}
                        >
                            {JSON.stringify(
                                result,
                                null,
                                2,
                            )}
                        </pre>

                        <button
                            type="button"
                            onClick={
                                loadApprovals
                            }
                            style={{
                                marginTop: "16px",
                                padding:
                                    "10px 16px",
                                borderRadius:
                                    "10px",
                                border:
                                    "1px solid #555",
                                background:
                                    "#111",
                                color: "#fff",
                                cursor:
                                    "pointer",
                            }}
                        >
                            Verify persisted approval
                        </button>
                    </section>
                )}

                {!persistedApproval &&
                    result && (
                        <section
                            style={{
                                marginTop: "24px",
                                padding: "24px",
                                border:
                                    "1px solid #333",
                                borderRadius: "14px",
                            }}
                        >
                            <h2>
                                Authenticated API response
                            </h2>

                            <pre
                                style={{
                                    marginTop: "16px",
                                    whiteSpace:
                                        "pre-wrap",
                                    overflowX:
                                        "auto",
                                    lineHeight: 1.5,
                                }}
                            >
                                {JSON.stringify(
                                    result,
                                    null,
                                    2,
                                )}
                            </pre>
                        </section>
                    )}
            </div>
        </main>
    );
}
