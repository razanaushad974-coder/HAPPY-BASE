"use client";

import { useState } from "react";

type SmokeResult = {
    httpStatus?: number;
    body?: Record<string, unknown>;
    error?: string;
};

export default function SupabaseSmokePage() {
    const [running, setRunning] =
        useState(false);

    const [result, setResult] =
        useState<SmokeResult | null>(null);

    async function runSmokeTest() {
        setRunning(true);
        setResult(null);

        try {
            const response =
                await fetch(
                    "/api/runtime/snapshot/smoke",
                    {
                        method: "POST",
                        credentials: "include",
                        cache: "no-store",
                    },
                );

            const text =
                await response.text();

            let body:
                | Record<string, unknown>
                | undefined;

            try {
                body =
                    JSON.parse(text) as Record<
                        string,
                        unknown
                    >;
            } catch {
                body = {
                    raw: text,
                };
            }

            setResult({
                httpStatus:
                    response.status,
                body,
            });
        } catch (error: unknown) {
            setResult({
                error:
                    error instanceof Error
                        ? error.message
                        : "Smoke request failed.",
            });
        } finally {
            setRunning(false);
        }
    }

    const verified =
        result?.body?.verified === true &&
        result?.body?.status ===
            "LIVE_REMOTE_VERIFIED";

    return (
        <main
            style={{
                minHeight: "100vh",
                background:
                    "#090807",
                color: "#f5f0df",
                padding: "48px",
                fontFamily:
                    "Arial, sans-serif",
            }}
        >
            <div
                style={{
                    maxWidth: "900px",
                    margin: "0 auto",
                }}
            >
                <div
                    style={{
                        fontSize: "13px",
                        letterSpacing:
                            "0.14em",
                        color: "#d6b65c",
                        marginBottom:
                            "12px",
                    }}
                >
                    HAPPY / DIAGNOSTICS
                </div>

                <h1
                    style={{
                        fontSize: "42px",
                        margin:
                            "0 0 12px",
                    }}
                >
                    Live Supabase Smoke Test
                </h1>

                <p
                    style={{
                        color: "#b9b19d",
                        lineHeight: 1.6,
                        maxWidth: "720px",
                    }}
                >
                    This uses the current
                    authenticated browser
                    session to test:
                    SAVE → LOAD → VERIFY.
                </p>

                <button
                    type="button"
                    onClick={
                        runSmokeTest
                    }
                    disabled={running}
                    style={{
                        marginTop:
                            "28px",
                        padding:
                            "14px 22px",
                        borderRadius:
                            "10px",
                        border:
                            "1px solid #c9a94e",
                        background:
                            running
                                ? "#302c20"
                                : "#c9a94e",
                        color:
                            running
                                ? "#e7dfc8"
                                : "#11100d",
                        fontWeight: 700,
                        cursor:
                            running
                                ? "wait"
                                : "pointer",
                    }}
                >
                    {running
                        ? "Running..."
                        : "Run Live Supabase Smoke Test"}
                </button>

                {verified && (
                    <div
                        style={{
                            marginTop:
                                "28px",
                            padding:
                                "20px",
                            borderRadius:
                                "12px",
                            border:
                                "1px solid #687c45",
                            background:
                                "#14200f",
                        }}
                    >
                        <strong>
                            LIVE_REMOTE_VERIFIED
                        </strong>
                        <div
                            style={{
                                marginTop:
                                    "8px",
                            }}
                        >
                            Real authenticated
                            remote SAVE →
                            LOAD verification
                            succeeded.
                        </div>
                    </div>
                )}

                {result && (
                    <pre
                        style={{
                            marginTop:
                                "28px",
                            padding:
                                "20px",
                            borderRadius:
                                "12px",
                            background:
                                "#11100e",
                            border:
                                "1px solid #302c25",
                            overflowX:
                                "auto",
                            whiteSpace:
                                "pre-wrap",
                            lineHeight:
                                1.5,
                        }}
                    >
                        {JSON.stringify(
                            result,
                            null,
                            2,
                        )}
                    </pre>
                )}

                <div
                    style={{
                        marginTop:
                            "28px",
                        color: "#847b68",
                        fontSize:
                            "13px",
                        lineHeight: 1.5,
                    }}
                >
                    Temporary diagnostic page.
                    No service-role key is exposed
                    to the browser.
                </div>
            </div>
        </main>
    );
}