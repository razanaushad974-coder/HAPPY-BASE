"use client";

import { useEffect, useState } from "react";

type ReadinessStatus =
  | "READY"
  | "PARTIAL"
  | "BLOCKED"
  | "NOT_YET_CONNECTED";

type ReadinessCheck = {
  id: string;
  area: string;
  status: ReadinessStatus;
  reason: string;
};

type ReadinessSnapshot = {
  systemId: "happy";
  name: "HAPPY";
  singleIntelligence: true;
  status: ReadinessStatus;
  checks: ReadinessCheck[];
  summary: string;
  generatedAt: string;
};

function statusLabel(status: ReadinessStatus): string {
  return status.replaceAll("_", " ");
}

function statusClass(status: ReadinessStatus): string {
  if (status === "READY") {
    return "border-emerald-500/40 bg-emerald-500/10 text-emerald-300";
  }

  if (status === "BLOCKED") {
    return "border-red-500/40 bg-red-500/10 text-red-300";
  }

  if (status === "NOT_YET_CONNECTED") {
    return "border-amber-500/40 bg-amber-500/10 text-amber-300";
  }

  return "border-blue-500/40 bg-blue-500/10 text-blue-300";
}

export default function SystemReadinessPage() {
  const [snapshot, setSnapshot] =
    useState<ReadinessSnapshot | null>(null);

  const [error, setError] =
    useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const response =
          await fetch(
            "/api/system/readiness",
            {
              cache: "no-store",
            },
          );

        if (!response.ok) {
          throw new Error(
            `Readiness API returned ${response.status}.`,
          );
        }

        const data =
          (await response.json()) as ReadinessSnapshot;

        if (!cancelled) {
          setSnapshot(data);
          setError(null);
        }
      } catch (cause) {
        if (!cancelled) {
          setError(
            cause instanceof Error
              ? cause.message
              : "Unable to load system readiness.",
          );
        }
      }
    }

    void load();

    const interval =
      window.setInterval(
        load,
        5000,
      );

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, []);

  const readyCount =
    snapshot?.checks.filter(
      (check) => check.status === "READY",
    ).length ?? 0;

  const blockedCount =
    snapshot?.checks.filter(
      (check) => check.status === "BLOCKED",
    ).length ?? 0;

  const notConnectedCount =
    snapshot?.checks.filter(
      (check) =>
        check.status === "NOT_YET_CONNECTED",
    ).length ?? 0;

  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "#050505",
        color: "#f5f5f5",
        padding: "32px",
        fontFamily:
          "Arial, Helvetica, sans-serif",
      }}
    >
      <div
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: "24px",
            marginBottom: "28px",
          }}
        >
          <div>
            <div
              style={{
                color: "#d4af37",
                fontSize: "13px",
                letterSpacing: "0.16em",
                fontWeight: 700,
                marginBottom: "8px",
              }}
            >
              HAPPY SYSTEM CONTROL
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: "34px",
                fontWeight: 800,
              }}
            >
              Live System Readiness
            </h1>

            <p
              style={{
                marginTop: "10px",
                color: "#a3a3a3",
                maxWidth: "760px",
                lineHeight: 1.6,
              }}
            >
              Source: HAPPY&apos;s existing system-readiness
              contract. This page does not create a second
              readiness engine.
            </p>
          </div>

          <a
            href="/workspace"
            style={{
              border: "1px solid #333",
              borderRadius: "10px",
              padding: "10px 14px",
              color: "#f5f5f5",
              textDecoration: "none",
              background: "#111",
            }}
          >
            Back to Workspace
          </a>
        </div>

        {error && (
          <div
            style={{
              border: "1px solid rgba(239,68,68,.4)",
              background: "rgba(239,68,68,.08)",
              color: "#fca5a5",
              borderRadius: "12px",
              padding: "16px",
              marginBottom: "20px",
            }}
          >
            {error}
          </div>
        )}

        {!snapshot && !error && (
          <div
            style={{
              border: "1px solid #262626",
              background: "#0d0d0d",
              borderRadius: "14px",
              padding: "24px",
              color: "#a3a3a3",
            }}
          >
            Loading HAPPY system readiness…
          </div>
        )}

        {snapshot && (
          <>
            <section
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit,minmax(180px,1fr))",
                gap: "14px",
                marginBottom: "20px",
              }}
            >
              {[
                ["SYSTEM", snapshot.status],
                ["READY", String(readyCount)],
                ["BLOCKED", String(blockedCount)],
                [
                  "NOT CONNECTED",
                  String(notConnectedCount),
                ],
              ].map(([label, value]) => (
                <div
                  key={label}
                  style={{
                    border: "1px solid #262626",
                    background: "#0d0d0d",
                    borderRadius: "14px",
                    padding: "18px",
                  }}
                >
                  <div
                    style={{
                      color: "#737373",
                      fontSize: "12px",
                      letterSpacing: "0.1em",
                      marginBottom: "8px",
                    }}
                  >
                    {label}
                  </div>

                  <div
                    style={{
                      fontSize: "22px",
                      fontWeight: 800,
                      color:
                        label === "SYSTEM"
                          ? "#d4af37"
                          : "#f5f5f5",
                    }}
                  >
                    {value}
                  </div>
                </div>
              ))}
            </section>

            <section
              style={{
                border:
                  "1px solid rgba(212,175,55,.28)",
                background:
                  "linear-gradient(145deg,#111,#080808)",
                borderRadius: "16px",
                padding: "22px",
                marginBottom: "20px",
              }}
            >
              <div
                style={{
                  color: "#d4af37",
                  fontSize: "12px",
                  letterSpacing: "0.12em",
                  marginBottom: "8px",
                }}
              >
                HAPPY
              </div>

              <div
                style={{
                  fontSize: "22px",
                  fontWeight: 800,
                  marginBottom: "8px",
                }}
              >
                {snapshot.summary}
              </div>

              <div
                style={{
                  color: "#737373",
                  fontSize: "12px",
                }}
              >
                Generated:
                {" "}
                {snapshot.generatedAt}
              </div>
            </section>

            <section
              style={{
                border: "1px solid #262626",
                borderRadius: "16px",
                overflow: "hidden",
                background: "#0a0a0a",
              }}
            >
              <div
                style={{
                  padding: "18px 20px",
                  borderBottom:
                    "1px solid #202020",
                  fontWeight: 700,
                }}
              >
                Readiness Checks
              </div>

              {snapshot.checks.map(
                (check) => (
                  <div
                    key={check.id}
                    style={{
                      padding: "18px 20px",
                      borderBottom:
                        "1px solid #171717",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: "16px",
                        flexWrap: "wrap",
                      }}
                    >
                      <div>
                        <div
                          style={{
                            fontWeight: 700,
                            marginBottom: "5px",
                          }}
                        >
                          {check.id}
                        </div>

                        <div
                          style={{
                            color: "#737373",
                            fontSize: "12px",
                          }}
                        >
                          Area: {check.area}
                        </div>
                      </div>

                      <span
                        className={statusClass(
                          check.status,
                        )}
                        style={{
                          border:
                            "1px solid",
                          borderRadius: "999px",
                          padding:
                            "6px 10px",
                          fontSize: "11px",
                          fontWeight: 800,
                        }}
                      >
                        {statusLabel(
                          check.status,
                        )}
                      </span>
                    </div>

                    <div
                      style={{
                        color: "#a3a3a3",
                        marginTop: "12px",
                        lineHeight: 1.5,
                        fontSize: "13px",
                      }}
                    >
                      {check.reason}
                    </div>
                  </div>
                ),
              )}
            </section>

            <div
              style={{
                marginTop: "18px",
                color: "#525252",
                fontSize: "12px",
              }}
            >
              Single intelligence:{" "}
              {snapshot.singleIntelligence
                ? "YES"
                : "NO"}
              {" • "}
              Auto-refresh: 5 seconds
            </div>
          </>
        )}
      </div>
    </main>
  );
}
