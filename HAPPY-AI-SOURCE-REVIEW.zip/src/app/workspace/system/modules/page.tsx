import { buildHappyModuleEvidence } from "@/core/integration/happy-module-evidence";

import HappyModulesClient from "./ModuleRegistryClient";

export const dynamic = "force-dynamic";

export default function HappyModulesPage() {
  const snapshot = buildHappyModuleEvidence();

  return (
    <HappyModulesClient
      initialSnapshot={snapshot}
    />
  );
}
