"use client";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

type CapabilityStatus =
  | "AVAILABLE"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

type Module = {
  number: number;
  id: string;
  name: string;
  category?: string;
  capability:
    | string
    | null;
  capabilityStatus:
    CapabilityStatus;
  capabilityReason: string;
  implementationStatus:
    "NOT_PROVEN";
  evidenceLevel:
    | "CATALOG_ONLY"
    | "ROUTING_PROVEN"
    | "EXECUTION_PROVEN"
    | "IMPLEMENTED";
  evidenceSources:
    readonly string[];
};

type Snapshot = {
  systemId: "happy";
  name: "HAPPY";
  totalModules: number;
  catalogIntegrity:
    "VALID" | "INVALID";
  implementationEvidencePolicy:
    "NO_MODULE_IS_MARKED_IMPLEMENTED_WITHOUT_DIRECT_EVIDENCE";
  summary: {
    available: number;
    notYetConnected: number;
    blocked: number;
    unmapped: number;
  };
  capabilitySummary:
    Record<string, number>;
  modules: readonly Module[];
  generatedAt: string;
};

function statusClass(
  status: CapabilityStatus,
): string {
  if (status === "AVAILABLE") {
    return "status-ready";
  }

  if (status === "BLOCKED") {
    return "status-blocked";
  }

  return "status-pending";
}

type HappyModulesClientProps = {
  initialSnapshot: Snapshot;
};

export default function HappyModulesClient({
  initialSnapshot,
}: HappyModulesClientProps) {
  const [
    snapshot,
    setSnapshot,
  ] = useState<Snapshot | null>(initialSnapshot);

  const [
    error,
    setError,
  ] = useState<string | null>(null);

  const [
    search,
    setSearch,
  ] = useState("");

  const [
    filter,
    setFilter,
  ] = useState<
    "ALL" |
    CapabilityStatus
  >("ALL");

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const response =
          await fetch(
            "/api/system/modules",
            {
              cache: "no-store",
            },
          );

        if (!response.ok) {
          throw new Error(
            `Module API returned ${response.status}.`,
          );
        }

        const data =
          (await response.json()) as Snapshot;

        if (!cancelled) {
          setSnapshot(data);
          setError(null);
        }
      } catch (cause) {
        if (!cancelled) {
          setError(
            cause instanceof Error
              ? cause.message
              : "Unable to load module registry.",
          );
        }
      }
    }

    void load();

    const interval =
      window.setInterval(
        load,
        5000,
      );

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, []);

  const filteredModules =
    useMemo(() => {
      if (!snapshot) {
        return [];
      }

      const normalized =
        search.trim().toLowerCase();

      return snapshot.modules.filter(
        (module) => {
          const matchesSearch =
            normalized === "" ||
            module.name
              .toLowerCase()
              .includes(normalized) ||
            module.id
              .toLowerCase()
              .includes(normalized) ||
            String(module.number)
              .includes(normalized);

          const matchesFilter =
            filter === "ALL" ||
            module.capabilityStatus ===
              filter;

          return (
            matchesSearch &&
            matchesFilter
          );
        },
      );
    }, [
      snapshot,
      search,
      filter,
    ]);

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#050505",
        color: "#f5f5f5",
        padding: "28px",
        fontFamily:
          "Arial, Helvetica, sans-serif",
      }}
    >
      <style>{`
        .module-card {
          border: 1px solid #252525;
          background: #0c0c0c;
          border-radius: 14px;
          overflow: hidden;
        }

        .module-row {
          display: grid;
          grid-template-columns:
            70px minmax(260px,2fr)
            150px 150px 160px;
          gap: 14px;
          padding: 15px 17px;
          border-top: 1px solid #191919;
          align-items: center;
        }

        .module-row.header {
          border-top: 0;
          color: #737373;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: .08em;
          font-weight: 800;
        }

        .module-id {
          font-size: 11px;
          color: #737373;
          margin-top: 4px;
        }

        .badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: fit-content;
          border: 1px solid;
          border-radius: 999px;
          padding: 5px 9px;
          font-size: 10px;
          font-weight: 800;
        }

        .status-ready {
          border-color: rgba(52,211,153,.35);
          background: rgba(52,211,153,.09);
          color: #86efac;
        }

        .status-blocked {
          border-color: rgba(248,113,113,.35);
          background: rgba(248,113,113,.09);
          color: #fca5a5;
        }

        .status-pending {
          border-color: rgba(251,191,36,.35);
          background: rgba(251,191,36,.09);
          color: #fcd34d;
        }

        @media (max-width: 900px) {
          .module-row {
            grid-template-columns:
              60px minmax(180px,1fr)
              130px;
          }

          .optional-col {
            display: none;
          }
        }
      `}</style>

      <div
        style={{
          maxWidth: "1450px",
          margin: "0 auto",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "18px",
            alignItems: "flex-start",
            marginBottom: "22px",
          }}
        >
          <div>
            <div
              style={{
                color: "#d4af37",
                fontSize: "12px",
                letterSpacing: ".16em",
                fontWeight: 800,
                marginBottom: "7px",
              }}
            >
              HAPPY SYSTEM CONTROL
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: "32px",
                fontWeight: 850,
              }}
            >
              502 Module Truth Registry
            </h1>

            <p
              style={{
                marginTop: "9px",
                color: "#8b8b8b",
                lineHeight: 1.5,
                maxWidth: "900px",
              }}
            >
              The canonical HAPPY module catalog is shown here
              without claiming that catalog registration equals
              implementation. Direct implementation evidence is
              required before a module can be marked implemented.
            </p>
          </div>

          <a
            href="/workspace/system"
            style={{
              textDecoration: "none",
              color: "#f5f5f5",
              background: "#111",
              border: "1px solid #303030",
              borderRadius: "10px",
              padding: "10px 13px",
              whiteSpace: "nowrap",
            }}
          >
            System Readiness
          </a>
        </div>

        {error && (
          <div
            style={{
              marginBottom: "18px",
              padding: "15px",
              borderRadius: "12px",
              border:
                "1px solid rgba(248,113,113,.35)",
              background:
                "rgba(248,113,113,.08)",
              color: "#fca5a5",
            }}
          >
            {error}
          </div>
        )}

        {snapshot && (
          <>
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit,minmax(175px,1fr))",
                gap: "12px",
                marginBottom: "18px",
              }}
            >
              {[
                [
                  "TOTAL MODULES",
                  snapshot.totalModules,
                ],
                [
                  "AVAILABLE",
                  snapshot.summary.available,
                ],
                [
                  "NOT CONNECTED",
                  snapshot.summary.notYetConnected,
                ],
                [
                  "BLOCKED",
                  snapshot.summary.blocked,
                ],
                [
                  "UNMAPPED",
                  snapshot.summary.unmapped,
                ],
              ].map(
                ([label, value]) => (
                  <div
                    key={label}
                    style={{
                      background: "#0d0d0d",
                      border: "1px solid #242424",
                      borderRadius: "13px",
                      padding: "16px",
                    }}
                  >
                    <div
                      style={{
                        color: "#666",
                        fontSize: "10px",
                        fontWeight: 800,
                        letterSpacing: ".1em",
                        marginBottom: "8px",
                      }}
                    >
                      {label}
                    </div>

                    <div
                      style={{
                        fontSize: "24px",
                        fontWeight: 850,
                      }}
                    >
                      {value}
                    </div>
                  </div>
                ),
              )}
            </div>

            <div
              style={{
                display: "flex",
                gap: "10px",
                flexWrap: "wrap",
                marginBottom: "15px",
              }}
            >
              <input
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value,
                  )
                }
                placeholder="Search module number, name, or ID…"
                style={{
                  flex: "1 1 280px",
                  minWidth: "260px",
                  background: "#0d0d0d",
                  border: "1px solid #2a2a2a",
                  color: "#f5f5f5",
                  borderRadius: "10px",
                  padding: "11px 13px",
                  outline: "none",
                }}
              />

              {[
                ["ALL", "ALL"],
                ["AVAILABLE", "AVAILABLE"],
                [
                  "NOT CONNECTED",
                  "NOT_YET_CONNECTED",
                ],
                ["BLOCKED", "BLOCKED"],
              ].map(
                ([label, value]) => (
                  <button
                    key={value}
                    onClick={() =>
                      setFilter(
                        value as
                          | "ALL"
                          | CapabilityStatus,
                      )
                    }
                    style={{
                      cursor: "pointer",
                      border:
                        "1px solid #2a2a2a",
                      background:
                        filter === value
                          ? "#1a1a1a"
                          : "#0d0d0d",
                      color:
                        filter === value
                          ? "#d4af37"
                          : "#a3a3a3",
                      borderRadius: "10px",
                      padding: "10px 12px",
                      fontWeight: 750,
                      fontSize: "11px",
                    }}
                  >
                    {label}
                  </button>
                ),
              )}
            </div>

            <div
              style={{
                marginBottom: "12px",
                color: "#5f5f5f",
                fontSize: "12px",
              }}
            >
              Showing{" "}
              {filteredModules.length}
              {" "}
              of{" "}
              {snapshot.totalModules}
              {" "}
              modules
            </div>

            <section className="module-card">
              <div className="module-row header">
                <div>#</div>
                <div>Module</div>
                <div>Capability</div>
                <div>Status</div>
                <div className="optional-col">
                  Implementation
                </div>
              </div>

              {filteredModules.map(
                (module) => (
                  <div
                    className="module-row"
                    key={module.id}
                  >
                    <div
                      style={{
                        color: "#d4af37",
                        fontWeight: 850,
                      }}
                    >
                      {module.number}
                    </div>

                    <div>
                      <div
                        style={{
                          fontWeight: 750,
                        }}
                      >
                        {module.name}
                      </div>

                      <div
                        className="module-id"
                      >
                        {module.id}
                      </div>

                      {module.category && (
                        <div
                          className="module-id"
                        >
                          {module.category}
                        </div>
                      )}
                    </div>

                    <div
                      style={{
                        fontSize: "12px",
                      }}
                    >
                      {module.capability ??
                        "UNMAPPED"}
                    </div>

                    <div>
                      <span
                        className={
                          `badge ${statusClass(
                            module.capabilityStatus,
                          )}`
                        }
                      >
                        {module.capabilityStatus
                          .replaceAll("_", " ")}
                      </span>
                    </div>

                    <div
                      className="optional-col"
                    >
                      <span
                        className={
                          `badge ${
                            module.evidenceLevel ===
                              "IMPLEMENTED"
                              ? "status-ready"
                              : "status-pending"
                          }`
                        }
                      >
                        {module.evidenceLevel.replaceAll(
                          "_",
                          " ",
                        )}
                      </span>

                      {module.evidenceSources.length >
                        0 && (
                        <div
                          className="module-id"
                          style={{
                            marginTop: "4px",
                          }}
                        >
                          {module.evidenceSources.length}{" "}
                          evidence source
                          {module.evidenceSources.length ===
                          1
                            ? ""
                            : "s"}
                        </div>
                      )}
                    </div>
                  </div>
                ),
              )}
            </section>

            <div
              style={{
                marginTop: "14px",
                color: "#555",
                fontSize: "11px",
                lineHeight: 1.5,
              }}
            >
              Catalog integrity:{" "}
              {snapshot.catalogIntegrity}
              {" • "}
              Auto-refresh: 5 seconds
              {" • "}
              Implementation policy: direct evidence required
            </div>
          </>
        )}

        {!snapshot && !error && (
          <div
            style={{
              padding: "22px",
              background: "#0d0d0d",
              border: "1px solid #242424",
              borderRadius: "13px",
              color: "#777",
            }}
          >
            Loading 502-module registry…
          </div>
        )}
      </div>
    </main>
  );
}
