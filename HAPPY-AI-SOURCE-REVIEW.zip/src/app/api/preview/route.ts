import { getAuthenticatedExecutionRuntimeContext } from "../../../core/auth/supabase-runtime-context";
import {
    execFileSync,
} from "node:child_process";

import {
    existsSync,
    readdirSync,
    readFileSync,
    statSync,
} from "node:fs";

import {
    join,
    relative,
} from "node:path";

import {
    NextResponse,
} from "next/server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type InventoryFile = {
    path: string;
    size: number;
};

type Capability = {
    name: string;
    status:
        | "DETECTED"
        | "NOT_DETECTED"
        | "BLOCKED"
        | "NOT_YET_CONNECTED";
    evidence: string;
};

const SOURCE_ROOTS = [
    "src",
];

const TEST_ROOTS = [
    "src/tests",
    "tests",
];

const IGNORED_NAMES = new Set([
    "node_modules",
    ".next",
    ".git",
    ".happy-state",
    ".turbo",
    "dist",
    "build",
]);

function collectFiles(
    absoluteRoot: string,
    projectRoot: string,
    output: InventoryFile[],
): void {
    if (!existsSync(absoluteRoot)) {
        return;
    }

    let entries:
        Array<{
            name: string;
            isDirectory: () => boolean;
        }> = [];

    try {
        entries =
            readdirSync(
                absoluteRoot,
                {
                    withFileTypes: true,
                },
            );
    }
    catch {
        return;
    }

    for (
        const entry
        of entries
    ) {
        if (
            IGNORED_NAMES.has(
                entry.name,
            )
        ) {
            continue;
        }

        const absolutePath =
            join(
                absoluteRoot,
                entry.name,
            );

        if (
            entry.isDirectory()
        ) {
            collectFiles(
                absolutePath,
                projectRoot,
                output,
            );
            continue;
        }

        try {
            output.push(
                {
                    path:
                        relative(
                            projectRoot,
                            absolutePath,
                        ).replaceAll(
                            "\\",
                            "/",
                        ),
                    size:
                        statSync(
                            absolutePath,
                        ).size,
                },
            );
        }
        catch {
            continue;
        }
    }
}

function safeGit(
    args: string[],
): string {
    try {
        return execFileSync(
            "git",
            args,
            {
                cwd:
                    process.cwd(),
                encoding:
                    "utf8",
            },
        ).trim();
    }
    catch {
        return "";
    }
}

function fileMatches(
    files: InventoryFile[],
    predicates: Array<
        (
            path: string,
        ) => boolean
    >,
): string | undefined {
    for (
        const file
        of files
    ) {
        const lowerPath =
            file.path.toLowerCase();

        for (
            const predicate
            of predicates
        ) {
            if (
                predicate(
                    lowerPath,
                )
            ) {
                return file.path;
            }
        }
    }

    return undefined;
}

function packageDependencyPresent(
    dependencyName: string,
): boolean {
    const packageFile =
        join(
            process.cwd(),
            "package.json",
        );

    if (
        !existsSync(
            packageFile,
        )
    ) {
        return false;
    }

    try {
        const packageJson =
            JSON.parse(
                readFileSync(
                    packageFile,
                    "utf8",
                ),
            ) as {
                dependencies?: Record<
                    string,
                    unknown
                >;
                devDependencies?: Record<
                    string,
                    unknown
                >;
            };

        return Boolean(
            packageJson.dependencies?.[
                dependencyName
            ] ||
            packageJson.devDependencies?.[
                dependencyName
            ],
        );
    }
    catch {
        return false;
    }
}

function detectCapabilities(
    files: InventoryFile[],
): Capability[] {
    const capabilities:
        Capability[] = [];

    const fileExecutionEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "file-execution-adapter",
                    ),
                (path) =>
                    path.includes(
                        "file-executor",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "File execution boundary",
            status:
                fileExecutionEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                fileExecutionEvidence ||
                "No file execution adapter detected",
        },
    );

    const apiExecutionEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "api-execution-adapter",
                    ),
                (path) =>
                    path.includes(
                        "api-executor",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "API execution boundary",
            status:
                apiExecutionEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                apiExecutionEvidence ||
                "No API execution adapter detected",
        },
    );

    const browserEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "browser-execution-adapter",
                    ),
                (path) =>
                    path.includes(
                        "browser",
                    ) &&
                    path.includes(
                        "execution",
                    ),
                (path) =>
                    path.includes(
                        "playwright",
                    ),
            ],
        );

    const playwrightDependency =
        packageDependencyPresent(
            "playwright",
        );

    const browserDetected =
        Boolean(
            browserEvidence ||
            playwrightDependency,
        );

    capabilities.push(
        {
            name:
                "Browser / Playwright",
            status:
                browserDetected
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                browserEvidence
                    ? `${browserEvidence} • Playwright dependency: ${playwrightDependency}`
                    : playwrightDependency
                        ? "playwright dependency detected in package configuration"
                        : "No browser/Playwright implementation detected",
        },
    );

    const databaseEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "database-execution-adapter",
                    ),
                (path) =>
                    path.includes(
                        "supabase-database",
                    ),
                (path) =>
                    path.includes(
                        "/database/",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "Database execution boundary",
            status:
                databaseEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                databaseEvidence ||
                "No database execution boundary detected",
        },
    );

    const geminiEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "/ai/",
                    ) &&
                    path.includes(
                        "gemini",
                    ),
                (path) =>
                    path.includes(
                        "gemini-adapter",
                    ),
            ],
        );

    const geminiConfigured =
        Boolean(
            process.env.GEMINI_API_KEY,
        );

    const geminiDetected =
        Boolean(
            geminiEvidence,
        );

    capabilities.push(
        {
            name:
                "Gemini AI",
            status:
                geminiDetected &&
                geminiConfigured
                    ? "DETECTED"
                    : geminiDetected
                        ? "NOT_YET_CONNECTED"
                        : "NOT_DETECTED",
            evidence:
                geminiEvidence
                    ? `${geminiEvidence} • API key configured: ${geminiConfigured}`
                    : "No Gemini adapter detected",
        },
    );

    const supabaseAuthEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "supabase-runtime-context",
                    ),
                (path) =>
                    path.includes(
                        "supabase-client",
                    ),
                (path) =>
                    path.includes(
                        "supabase",
                    ) &&
                    path.includes(
                        "auth",
                    ),
            ],
        );

    const supabaseConfigured =
        Boolean(
            process.env.NEXT_PUBLIC_SUPABASE_URL,
        ) &&
        Boolean(
            process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
        );

    capabilities.push(
        {
            name:
                "Supabase authentication",
            status:
                supabaseAuthEvidence &&
                supabaseConfigured
                    ? "DETECTED"
                    : supabaseAuthEvidence
                        ? "NOT_YET_CONNECTED"
                        : "NOT_DETECTED",
            evidence:
                supabaseAuthEvidence
                    ? `${supabaseAuthEvidence} • Public client config: ${supabaseConfigured}`
                    : "No Supabase authentication boundary detected",
        },
    );

    const orchestrationEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "/orchestration/",
                    ),
                (path) =>
                    path.includes(
                        "happy-state-store",
                    ),
                (path) =>
                    path.includes(
                        "mission-engine",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "Orchestration / Mission Engine",
            status:
                orchestrationEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                orchestrationEvidence ||
                "No orchestration boundary detected",
        },
    );

    const persistenceEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "json-file-adapter",
                    ),
                (path) =>
                    path.includes(
                        "/persistence/",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "Persistence layer",
            status:
                persistenceEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                persistenceEvidence ||
                "No persistence implementation detected",
        },
    );

    const verificationEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "/verification/",
                    ),
                (path) =>
                    path.includes(
                        "verification",
                    ),
                (path) =>
                    path.includes(
                        "evidence",
                    ),
            ],
        );

    capabilities.push(
        {
            name:
                "Verification / Evidence",
            status:
                verificationEvidence
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                verificationEvidence ||
                "No verification/evidence boundary detected",
        },
    );

    const tenantEvidence =
        fileMatches(
            files,
            [
                (path) =>
                    path.includes(
                        "file-backed-state",
                    ),
            ],
        );

    let tenantBootstrapDetected =
        false;

    if (
        tenantEvidence
    ) {
        const tenantFile =
            join(/*turbopackIgnore: true*/ process.cwd(), tenantEvidence,
            );

        try {
            tenantBootstrapDetected =
                readFileSync(
                    tenantFile,
                    "utf8",
                ).includes(
                    "ensureFileBackedWorkspaceTenant",
                );
        }
        catch {
            tenantBootstrapDetected =
                false;
        }
    }

    capabilities.push(
        {
            name:
                "Authenticated tenant bootstrap",
            status:
                tenantBootstrapDetected
                    ? "DETECTED"
                    : "NOT_DETECTED",
            evidence:
                tenantBootstrapDetected
                    ? `${tenantEvidence} • ensureFileBackedWorkspaceTenant detected`
                    : "Authenticated tenant bootstrap not detected",
        },
    );

    capabilities.push(
        {
            name:
                "Real external DB persistence",
            status:
                "NOT_YET_CONNECTED",
            evidence:
                "Current orchestration persistence remains file-backed; external DB persistence is kept as an explicit future connection boundary",
        },
    );

    capabilities.push(
        {
            name:
                "Sandbox execution",
            status:
                "BLOCKED",
            evidence:
                "Current safety boundary keeps sandbox execution blocked",
        },
    );

    return capabilities;
}

export async function GET() {
    if (
        process.env.NODE_ENV ===
            "production" &&
        process.env.HAPPY_LIVE_PREVIEW !==
            "true"
    ) {
        return NextResponse.json(
            {
                error:
                    "LIVE_PREVIEW_DISABLED",
            },
            {
                status: 404,
            },
        );
    }

    if (process.env.NODE_ENV === "production") {
        const runtimeContext = await getAuthenticatedExecutionRuntimeContext();
        if (!runtimeContext.authenticatedUserId || !runtimeContext.supabaseAccessToken) {
            return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
        }
    }

    const projectRoot =
        process.cwd();

    const sourceFiles:
        InventoryFile[] = [];

    for (
        const root
        of SOURCE_ROOTS
    ) {
        collectFiles(
            join(/*turbopackIgnore: true*/ projectRoot, root), projectRoot, sourceFiles,
        );
    }

    const testFiles:
        InventoryFile[] = [];

    for (
        const root
        of TEST_ROOTS
    ) {
        collectFiles(
            join(/*turbopackIgnore: true*/ projectRoot, root), projectRoot, testFiles,
        );
    }

    const pages =
        sourceFiles.filter(
            (file) =>
                /\/page\.(tsx|ts|jsx|js)$/.test(
                    `/${file.path}`,
                ),
        );

    const apiRoutes =
        sourceFiles.filter(
            (file) =>
                /\/route\.(tsx|ts|jsx|js)$/.test(
                    `/${file.path}`,
                ) &&
                file.path.includes(
                    "/api/",
                ),
        );

    const moduleFiles =
        sourceFiles.filter(
            (file) =>
                file.path.startsWith(
                    "src/modules/",
                ),
        );

    const coreFiles =
        sourceFiles.filter(
            (file) =>
                file.path.startsWith(
                    "src/core/",
                ),
        );

    const integrationFiles =
        sourceFiles.filter(
            (file) =>
                file.path.startsWith(
                    "src/integrations/",
                ),
        );

    const aiFiles =
        sourceFiles.filter(
            (file) =>
                file.path.includes(
                    "/ai/",
                ) ||
                file.path.includes(
                    "gemini",
                ),
        );

    const domainPrefixes = [
        "src/core/auth/",
        "src/core/context/",
        "src/core/database/",
        "src/core/evidence/",
        "src/core/execution/",
        "src/core/memory/",
        "src/core/mission/",
        "src/core/orchestration/",
        "src/core/persistence/",
        "src/core/planning/",
        "src/core/state/",
        "src/core/tasks/",
        "src/core/verification/",
        "src/core/workspace/",
        "src/core/approval/",
        "src/core/events/",
        "src/core/audit/",
    ];

    const implementationDomains =
        domainPrefixes
            .map(
                (prefix) => ({
                    name:
                        prefix
                            .replace(
                                "src/core/",
                                "",
                            )
                            .replace(
                                "/",
                                "",
                            ),
                    prefix,
                    fileCount:
                        sourceFiles.filter(
                            (file) =>
                                file.path.startsWith(
                                    prefix,
                                ),
                        ).length,
                }),
            )
            .filter(
                (domain) =>
                    domain.fileCount > 0,
            );

    const gitBranch =
        safeGit(
            [
                "rev-parse",
                "--abbrev-ref",
                "HEAD",
            ],
        );

    const latestCommit =
        safeGit(
            [
                "log",
                "-1",
                "--pretty=%h|%s|%ad",
                "--date=short",
            ],
        );

    const gitStatusRaw =
        safeGit(
            [
                "status",
                "--short",
            ],
        );

    const changedFiles =
        gitStatusRaw
            ? gitStatusRaw
                .split(/\r?\n/)
                .filter(
                    Boolean,
                )
                .map(
                    (
                        line,
                    ) =>
                        line.trim(),
                )
            : [];

    const recentSubjects =
        safeGit(
            [
                "log",
                "-50",
                "--pretty=%s",
            ],
        );

    const recentMilestones =
        Array.from(
            new Set(
                Array.from(
                    recentSubjects.matchAll(
                        /(?:#|R|PW-)\d{1,5}/gi,
                    ),
                ).map(
                    (
                        match,
                    ) =>
                        match[0],
                ),
            ),
        ).slice(
            0,
            50,
        );

    return NextResponse.json(
        {
            generatedAt:
                new Date().toISOString(),

            environment:
                process.env.NODE_ENV,

            inventory: {
                sourceFiles:
                    sourceFiles.length,
                pages:
                    pages.length,
                apiRoutes:
                    apiRoutes.length,
                moduleFiles:
                    moduleFiles.length,
                coreFiles:
                    coreFiles.length,
                integrationFiles:
                    integrationFiles.length,
                aiFiles:
                    aiFiles.length,
                tests:
                    testFiles.length,
                totalTrackedProjectFiles:
                    sourceFiles.length +
                    testFiles.length,
            },

            implementationDomains,

            codebase: {
                pages:
                    pages
                        .map(
                            (
                                file,
                            ) =>
                                file.path,
                        )
                        .sort(),

                apiRoutes:
                    apiRoutes
                        .map(
                            (
                                file,
                            ) =>
                                file.path,
                        )
                        .sort(),

                modules:
                    moduleFiles
                        .map(
                            (
                                file,
                            ) =>
                                file.path,
                        )
                        .sort(),

                integrations:
                    integrationFiles
                        .map(
                            (
                                file,
                            ) =>
                                file.path,
                        )
                        .sort(),

                aiFiles:
                    aiFiles
                        .map(
                            (
                                file,
                            ) =>
                                file.path,
                        )
                        .sort(),
            },

            git: {
                branch:
                    gitBranch ||
                    "UNKNOWN",

                latestCommit:
                    latestCommit ||
                    "UNKNOWN",

                changedFiles:
                    changedFiles.slice(
                        0,
                        100,
                    ),

                changedFileCount:
                    changedFiles.length,

                recentMilestones,
            },

            capabilities:
                detectCapabilities(
                    sourceFiles,
                ),

            configuration: {
                geminiConfigured:
                    Boolean(
                        process.env.GEMINI_API_KEY,
                    ),

                supabaseUrlConfigured:
                    Boolean(
                        process.env
                            .NEXT_PUBLIC_SUPABASE_URL,
                    ),

                supabasePublishableKeyConfigured:
                    Boolean(
                        process.env
                            .NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
                    ),

                livePreviewEnabled:
                    process.env
                        .HAPPY_LIVE_PREVIEW !==
                    "false",
            },
        },
        {
            headers: {
                "Cache-Control":
                    "no-store, max-age=0",
            },
        },
    );
}
