import { resolveTrustedFounderIdentity } from "../../../../core/founder/identity";
import { evaluateFounderAccess } from "../../../../core/founder/access-policy";
import {
    NextRequest,
    NextResponse,
} from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

import {
    SupabaseRuntimeSnapshotStore,
} from "../../../../core/persistence/adapters/supabase-runtime-snapshot";

import {
    applyApprovalDecision,
} from "../../../../core/approval/persist-decision";

import {
    HappyOrchestrationEngine,
} from "../../../../core/orchestration/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function isNonEmptyString(
    value: unknown,
): value is string {
    return (
        typeof value === "string" &&
        value.trim().length > 0
    );
}

type Decision =
    | "APPROVED"
    | "REJECTED";

function isDecision(
    value: unknown,
): value is Decision {
    return (
        value === "APPROVED" ||
        value === "REJECTED"
    );
}

async function getAuthenticatedContext() {
    const runtimeContext =
        await getAuthenticatedExecutionRuntimeContext();

    const authenticatedUserId =
        runtimeContext.authenticatedUserId;

    if (
        !authenticatedUserId ||
        !runtimeContext.supabaseAccessToken
    ) {
        return {
            ok: false as const,
            response:
                NextResponse.json(
                    {
                        status:
                            "UNAUTHENTICATED",
                        error:
                            "Authenticated Supabase session is required.",
                    },
                    {
                        status: 401,
                    },
                ),
        };
    }

    const workspace =
        createAuthenticatedWorkspaceState(
            authenticatedUserId,
        );

    const tenant =
        workspace.tenant;

    const supabase =
        await createSupabaseServerClient();

    const store =
        new SupabaseRuntimeSnapshotStore(
            supabase,
        );

    const snapshot =
        await store.load({
            organizationId:
                tenant.organizationId,
            workspaceId:
                tenant.workspaceId,
            userId:
                tenant.userId,
        });

    return {
        ok: true as const,
        runtimeContext,
        authenticatedUserId,
        workspace,
        tenant,
        store,
        snapshot,
    };
}

export async function GET(): Promise<Response> {
    try {
        const context =
            await getAuthenticatedContext();

        if (!context.ok) {
            return context.response;
        }

        if (!context.snapshot) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    approvals: [],
                    count: 0,
                },
                {
                    status: 404,
                },
            );
        }

        const pendingApprovals =
            context.snapshot.state.approvals
                .filter((approval) => {
                    const status =
                        (
                            approval.data as Record<
                                string,
                                unknown
                            >
                        )?.status;

                    return (
                        status ===
                            "WAITING_APPROVAL" ||
                        status === "PENDING"
                    );
                })
                .map((approval) => {
                    const data =
                        approval.data as Record<
                            string,
                            unknown
                        >;

                    return {
                        id:
                            approval.id,
                        requestId:
                            typeof data.requestId ===
                            "string"
                                ? data.requestId
                                : null,
                        planId:
                            typeof data.planId ===
                            "string"
                                ? data.planId
                                : null,
                        status:
                            typeof data.status ===
                            "string"
                                ? data.status
                                : null,
                        createdAt:
                            approval.createdAt,
                        updatedAt:
                            approval.updatedAt,
                    };
                });

        return NextResponse.json(
            {
                status:
                    "AVAILABLE",
                scopeKey:
                    context.snapshot.scopeKey,
                count:
                    pendingApprovals.length,
                approvals:
                    pendingApprovals,
            },
            {
                status: 200,
            },
        );
    } catch (error) {
        return NextResponse.json(
            {
                status:
                    "ERROR",
                error:
                    error instanceof Error
                        ? error.message
                        : "Unknown approval query error.",
            },
            {
                status: 500,
            },
        );
    }
}

export async function POST(
    request: NextRequest,
): Promise<Response> {
    try {
        const context =
            await getAuthenticatedContext();

        if (!context.ok) {
            return context.response;
        }

        if (!context.snapshot) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    error:
                        "Authenticated runtime snapshot was not found.",
                },
                {
                    status: 404,
                },
            );
        }

        let body: unknown;

        try {
            body =
                await request.json();
        } catch {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "Request body must be valid JSON.",
                },
                {
                    status: 400,
                },
            );
        }

        if (
            !body ||
            typeof body !== "object"
        ) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "Request body must be an object.",
                },
                {
                    status: 400,
                },
            );
        }

        const payload =
            body as Record<
                string,
                unknown
            >;

        const approvalId =
            isNonEmptyString(
                payload.approvalId,
            )
                ? payload.approvalId.trim()
                : "";

        const decision =
            isDecision(
                payload.decision,
            )
                ? payload.decision
                : null;

        const reason =
            isNonEmptyString(
                payload.reason,
            )
                ? payload.reason.trim()
                : undefined;

        if (!approvalId) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "approvalId is required.",
                },
                {
                    status: 400,
                },
            );
        }

        if (!decision) {
            return NextResponse.json(
                {
                    status:
                        "INVALID_REQUEST",
                    error:
                        "decision must be APPROVED or REJECTED.",
                },
                {
                    status: 400,
                },
            );
        }

        // Authorization must pass before applyApprovalDecision or snapshot persistence.
        const approvalRecords = (context.snapshot.state as unknown as {
            approvals?: Array<{ id?: string; data?: unknown }>
        }).approvals ?? [];
        const approvalEntry = approvalRecords.find((item) => item.id === approvalId);
        const storedValue = approvalEntry?.data;
        const storedPayload =
            storedValue && typeof storedValue === "object" && "data" in storedValue
                ? (storedValue as { data?: unknown }).data
                : storedValue;
        const approvalPayload =
            storedPayload && typeof storedPayload === "object"
                ? storedPayload as Record<string, unknown>
                : null;
        // Validate persisted approval linkage before any decision mutation.
        if (
            !approvalPayload ||
            !isNonEmptyString(approvalPayload.requestId) ||
            !isNonEmptyString(approvalPayload.planId)
        ) {
            return NextResponse.json({
                error: "Approval is missing its persisted request or plan linkage.",
                code: "APPROVAL_LINKAGE_INVALID",
            }, { status: 409 });
        }

        const approvalRequestId = approvalPayload.requestId;
        const approvalPlanId = approvalPayload.planId;

        const missionRecords = (
            context.snapshot.state as unknown as {
                missions?: Array<{ id?: string; data?: unknown }>
            }
        ).missions ?? [];

        const missionEntry = missionRecords.find(
            (item) => item.id === approvalPlanId,
        );

        const missionStoredValue = missionEntry?.data;
        const missionStoredPayload =
            missionStoredValue &&
            typeof missionStoredValue === "object" &&
            "data" in missionStoredValue
                ? (missionStoredValue as { data?: unknown }).data
                : missionStoredValue;

        const missionPayload =
            missionStoredPayload &&
            typeof missionStoredPayload === "object"
                ? missionStoredPayload as Record<string, unknown>
                : null;

        if (
            !missionPayload ||
            missionPayload.id !== approvalPlanId
        ) {
            return NextResponse.json({
                error: "The approval's linked execution plan was not found or did not match.",
                code: "APPROVAL_PLAN_LINKAGE_INVALID",
            }, { status: 409 });
        }

        const approvalLevel = approvalPayload?.level;
        if (!approvalPayload || !["FOUNDER", "ADMIN", "SECURITY", "MULTI_APPROVER"].includes(String(approvalLevel))) {
            return NextResponse.json({
                error: "Approval lacks trusted server-generated authorization metadata. Reissue the approval request.",
                code: "APPROVER_AUTHORIZATION_REQUIRED",
            }, { status: 503 });
        }
        if (approvalLevel !== "FOUNDER") {
            return NextResponse.json({
                error: "This approval level is not connected to a verified approver registry.",
                code: "APPROVER_REGISTRY_NOT_YET_CONNECTED",
            }, { status: 503 });
        }
        const founderIdentity = resolveTrustedFounderIdentity(
            context.runtimeContext.authenticatedUserId ?? "",
        );
        if (!("access" in founderIdentity)) {
            return NextResponse.json({
                error: "Trusted Founder identity is not configured or does not match the authenticated user.",
                code: "TRUSTED_FOUNDER_IDENTITY_REQUIRED",
            }, { status: 403 });
        }
        const founderAccess = evaluateFounderAccess({
            ...founderIdentity.access,
            action: "CONTROL_HAPPY",
        });
        if (founderAccess.status !== "ALLOW") {
            return NextResponse.json({
                error: "Authenticated user is not authorized to decide this approval.",
                code: "FOUNDER_APPROVAL_ACCESS_DENIED",
            }, { status: 403 });
        }
        const result =
            applyApprovalDecision(
                context.snapshot.state,
                approvalId,
                decision,
                context.runtimeContext
                    .authenticatedUserId ?? "",
                reason,
            );

        // Guard against linkage changes before persisting the decision.
        if (
            result.requestId !== approvalRequestId ||
            result.planId !== approvalPlanId
        ) {
            return NextResponse.json({
                error: "Decision result does not match the validated approval linkage.",
                code: "APPROVAL_DECISION_LINKAGE_MISMATCH",
            }, { status: 409 });
        }

        const snapshotScope = {
            organizationId: context.tenant.organizationId,
            workspaceId: context.tenant.workspaceId,
            userId: context.tenant.userId,
        };

        let saved;
        try {
            saved = await context.store.saveIfVersion(
                snapshotScope,
                result.state,
                context.snapshot.version,
            );
        } catch (error) {
            const message =
                error instanceof Error ? error.message : "";

            if (message === "RUNTIME_SNAPSHOT_VERSION_CONFLICT") {
                return NextResponse.json(
                    {
                        status: "VERSION_CONFLICT",
                        code: "RUNTIME_SNAPSHOT_VERSION_CONFLICT",
                        error: "The runtime snapshot changed. Reload the current state before deciding.",
                        decisionPersisted: false,
                    },
                    { status: 409 },
                );
            }

            throw error;
        }

        try {
            // The approval decision is persisted to the authenticated
            // Supabase runtime snapshot above. The continuation engine,
            // however, operates on the workspace PersistenceService.
            // Hydrate that local continuation state from the same
            // authoritative approved snapshot before resuming.
            context.workspace.persistence.replaceScopedSnapshot(
                result.state,
                {
                    organizationId:
                        context.tenant.organizationId,
                    workspaceId:
                        context.tenant.workspaceId,
                    userId:
                        context.tenant.userId,
                },
            );

            if (
                result.decision ===
                    "APPROVED"
            ) {
                if (
                    !result.requestId ||
                    !result.planId
                ) {
                    return NextResponse.json(
                        {
                            status:
                                "APPROVAL_LINKAGE_INCOMPLETE",
                            error:
                                "Approved decision is missing requestId or planId.",
                            approvalId:
                                result.approvalId,
                        },
                        {
                            status: 500,
                        },
                    );
                }

                const executionRuntimeContext = {
                    ...context.runtimeContext,
                    organizationId:
                        context.tenant.organizationId,
                    workspaceId:
                        context.tenant.workspaceId,
                };

                const engine =
                    new HappyOrchestrationEngine(
                        undefined,
                        context.workspace.persistence,
                    );

                const resumed =
                    await engine.resumeAfterApproval(
                        result.requestId,
                        result.approvalId,
                        result.planId,
                        context.tenant.organizationId,
                        context.tenant.workspaceId,
                        context.authenticatedUserId,
                        executionRuntimeContext,
                    );

                return NextResponse.json(
                    {
                        status:
                            "APPROVAL_RESUMED",
                        verified:
                            true,
                        scopeKey:
                            saved.scopeKey,
                        approvalId:
                            result.approvalId,
                        requestId:
                            result.requestId,
                        planId:
                            result.planId,
                        decisionId:
                            result.decisionId,
                        auditEventId:
                            result.auditEventId,
                        decision:
                            result.decision,
                        approverId:
                            result.approverId,
                        reason:
                            result.reason,
                        decidedAt:
                            result.decidedAt,
                        version:
                            saved.version,
                        updatedAt:
                            saved.updatedAt,
                        remotePersistence:
                            "AVAILABLE",
                        resume:
                            resumed,
                    },
                    {
                        status: 200,
                    },
                );
            }


        } catch {
            // The snapshot save already succeeded. Do not retry or
            // reapply the decision here; report recovery as required.
            console.error(
                "[APPROVAL_DECISION_PERSISTED_RESUME_RECOVERY_REQUIRED]",
                {
                    approvalId: result.approvalId,
                    requestId: result.requestId ?? null,
                    planId: result.planId ?? null,
                    scopeKey: saved.scopeKey,
                    version: saved.version,
                },
            );

            return NextResponse.json(
                {
                    status: "APPROVAL_DECISION_PERSISTED_RESUME_RECOVERY_REQUIRED",
                    code: "RESUME_RECOVERY_REQUIRED",
                    decisionPersisted: true,
                    recoveryRequired: true,
                    error: "The approval decision was saved, but continuation did not complete. Reconcile runtime state before attempting recovery.",
                    approvalId: result.approvalId,
                    requestId: result.requestId ?? null,
                    planId: result.planId ?? null,
                    decisionId: result.decisionId,
                    scopeKey: saved.scopeKey,
                    version: saved.version,
                },
                { status: 503 },
            );
        }
        return NextResponse.json(
            {
                status:
                    "APPROVAL_DECISION_PERSISTED",
                verified:
                    true,
                scopeKey:
                    saved.scopeKey,
                approvalId:
                    result.approvalId,
                requestId:
                    result.requestId ?? null,
                planId:
                    result.planId ?? null,
                decisionId:
                    result.decisionId,
                auditEventId:
                    result.auditEventId,
                decision:
                    result.decision,
                approverId:
                    result.approverId,
                reason:
                    result.reason,
                decidedAt:
                    result.decidedAt,
                version:
                    saved.version,
                updatedAt:
                    saved.updatedAt,
                remotePersistence:
                    "AVAILABLE",
            },
            {
                status: 200,
            },
        );
    } catch (error) {
        const message =
            error instanceof Error
                ? error.message
                : "Unknown approval decision error.";

        if (
            message ===
            "APPROVAL_NOT_FOUND"
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_FOUND",
                    error: message,
                },
                {
                    status: 404,
                },
            );
        }

        if (
            message ===
            "APPROVAL_NOT_PENDING"
        ) {
            return NextResponse.json(
                {
                    status:
                        "ALREADY_DECIDED",
                    error: message,
                },
                {
                    status: 409,
                },
            );
        }

        return NextResponse.json(
            {
                status:
                    "ERROR",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}
