import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../../core/workspace/file-backed-state";

import {
    createSupabaseServerClient,
} from "../../../../../lib/supabase/server";

import {
    SupabaseRuntimeSnapshotStore,
} from "../../../../../core/persistence/adapters/supabase-runtime-snapshot";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(): Promise<Response> {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        if (
            !runtimeContext.authenticatedUserId ||
            !runtimeContext.supabaseAccessToken
        ) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    verified: false,
                    error:
                        "Authenticated Supabase session is required.",
                },
                {
                    status: 401,
                },
            );
        }

        const workspace =
            createAuthenticatedWorkspaceState(
                runtimeContext.authenticatedUserId,
            );

        const tenant =
            workspace.tenant;

        const localState =
            await workspace.store.snapshot();

        const supabase =
            await createSupabaseServerClient();

        const store =
            new SupabaseRuntimeSnapshotStore(
                supabase,
            );

        const scope = {
            organizationId:
                tenant.organizationId,
            workspaceId:
                tenant.workspaceId,
            userId:
                tenant.userId,
        };

        const saved =
            await store.save(
                scope,
                localState,
                1,
            );

        const loaded =
            await store.load(scope);

        if (!loaded) {
            return NextResponse.json(
                {
                    status:
                        "REMOTE_READ_FAILED",
                    verified: false,
                    scopeKey:
                        saved.scopeKey,
                    error:
                        "Remote snapshot save succeeded but remote load returned no snapshot.",
                },
                {
                    status: 502,
                },
            );
        }

        const scopeMatches =
            loaded.scopeKey ===
            saved.scopeKey;

        const versionMatches =
            loaded.version ===
            saved.version;

        const statePresent =
            loaded.state !== null &&
            loaded.state !== undefined;

        const verified =
            scopeMatches &&
            versionMatches &&
            statePresent;

        return NextResponse.json(
            {
                status:
                    verified
                        ? "LIVE_REMOTE_VERIFIED"
                        : "LIVE_REMOTE_MISMATCH",
                verified,
                authenticatedUserId:
                    runtimeContext.authenticatedUserId,
                scopeKey:
                    saved.scopeKey,
                savedVersion:
                    saved.version,
                loadedVersion:
                    loaded.version,
                scopeMatches,
                versionMatches,
                statePresent,
                savedAt:
                    saved.updatedAt,
                loadedAt:
                    loaded.updatedAt,
            },
            {
                status:
                    verified
                        ? 200
                        : 502,
            },
        );
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "Live Supabase snapshot smoke test failed.";

        if (
            message.startsWith(
                "NOT_YET_CONNECTED",
            )
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_YET_CONNECTED",
                    verified: false,
                    error: message,
                },
                {
                    status: 503,
                },
            );
        }

        return NextResponse.json(
            {
                status:
                    "LIVE_REMOTE_ERROR",
                verified: false,
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}