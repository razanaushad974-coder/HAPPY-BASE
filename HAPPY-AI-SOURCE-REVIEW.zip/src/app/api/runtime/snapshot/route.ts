import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

import {
    SupabaseRuntimeSnapshotStore,
} from "../../../../core/persistence/adapters/supabase-runtime-snapshot";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UUID_PATTERN =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type RemoteScope = {
    organizationId: string;
    workspaceId: string;
    userId: string;
};

function scopeKey(scope: RemoteScope): string {
    return [
        scope.organizationId,
        scope.workspaceId,
        scope.userId,
    ].join("|");
}

async function resolveExistingRemoteScope(
    supabase: Awaited<ReturnType<typeof createSupabaseServerClient>>,
    accessToken: string,
    expectedUserId: string,
): Promise<{ scope?: RemoteScope; reason?: string }> {
    const authResult = await supabase.auth.getUser(accessToken);

    if (
        authResult.error ||
        !authResult.data.user ||
        authResult.data.user.id !== expectedUserId
    ) {
        return { reason: "Authenticated Supabase identity could not be verified." };
    }

    const userId = authResult.data.user.id;

    const organizationsResult = await supabase
        .from("organizations")
        .select("id,name,slug,owner_user_id")
        .eq("owner_user_id", userId)
        .order("created_at", { ascending: true });

    if (organizationsResult.error) {
        return { reason: "Existing organization lookup failed: " + organizationsResult.error.message };
    }

    const organizations = organizationsResult.data ?? [];

    if (organizations.length !== 1) {
        return {
            reason: organizations.length === 0
                ? "No existing owned Supabase organization found; no tenant was created."
                : "Multiple owned Supabase organizations found; explicit tenant selection is required.",
        };
    }

    const organization = organizations[0];

    const workspacesResult = await supabase
        .from("workspaces")
        .select("id,organization_id,name,slug,owner_user_id")
        .eq("organization_id", organization.id)
        .eq("owner_user_id", userId)
        .order("created_at", { ascending: true });

    if (workspacesResult.error) {
        return { reason: "Existing workspace lookup failed: " + workspacesResult.error.message };
    }

    const workspaces = workspacesResult.data ?? [];

    if (workspaces.length !== 1) {
        return {
            reason: workspaces.length === 0
                ? "No existing owned Supabase workspace found; no tenant was created."
                : "Multiple owned Supabase workspaces found; explicit workspace selection is required.",
        };
    }

    const workspace = workspaces[0];

    if (
        !UUID_PATTERN.test(organization.id) ||
        !UUID_PATTERN.test(workspace.id) ||
        !UUID_PATTERN.test(userId)
    ) {
        return { reason: "Existing Supabase tenant scope contains an invalid UUID." };
    }

    return {
        scope: {
            organizationId: organization.id,
            workspaceId: workspace.id,
            userId,
        },
    };
}

async function getAuthenticatedSnapshotContext() {
    const runtimeContext =
        await getAuthenticatedExecutionRuntimeContext();

    if (
        !runtimeContext.authenticatedUserId ||
        !runtimeContext.supabaseAccessToken
    ) {
        return {
            kind: "unauthenticated" as const,
            response: NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    error: "Authenticated Supabase session is required.",
                },
                { status: 401 },
            ),
        };
    }

    const workspace = createAuthenticatedWorkspaceState(
        runtimeContext.authenticatedUserId,
    );

    const localState = await workspace.store.snapshot();
    const supabase = await createSupabaseServerClient();
    const store = new SupabaseRuntimeSnapshotStore(supabase);

    const resolution = await resolveExistingRemoteScope(
        supabase,
        runtimeContext.supabaseAccessToken,
        runtimeContext.authenticatedUserId,
    );

    return {
        kind: "authenticated" as const,
        localTenant: workspace.tenant,
        localState,
        store,
        remoteScope: resolution.scope,
        remoteScopeReason: resolution.reason,
    };
}

function localFallbackResponse(
    context: {
        localTenant: RemoteScope;
        localState: unknown;
    },
    reason: string,
    remotePersistence: "NOT_YET_CONNECTED" | "ERROR" = "NOT_YET_CONNECTED",
) {
    return NextResponse.json(
        {
            status: "LOCAL_FALLBACK",
            scopeKey: scopeKey(context.localTenant),
            version: null,
            createdAt: null,
            updatedAt: null,
            remotePersistence,
            reason,
            snapshot: context.localState,
        },
        { status: 200 },
    );
}

export async function GET(): Promise<Response> {
    try {
        const context = await getAuthenticatedSnapshotContext();

        if (context.kind === "unauthenticated") {
            return context.response;
        }

        if (!context.remoteScope) {
            return localFallbackResponse(
                context,
                context.remoteScopeReason ?? "Canonical remote tenant unavailable.",
            );
        }

        try {
            const snapshot = await context.store.load(context.remoteScope);

            if (snapshot) {
                return NextResponse.json(
                    {
                        status: "AVAILABLE",
                        scopeKey: snapshot.scopeKey,
                        version: snapshot.version,
                        createdAt: snapshot.createdAt,
                        updatedAt: snapshot.updatedAt,
                        remotePersistence: "SUPABASE",
                        snapshot: snapshot.state,
                    },
                    { status: 200 },
                );
            }

            return localFallbackResponse(
                context,
                "No remote snapshot exists for the verified tenant; local state was retained.",
            );
        } catch (error: unknown) {
            const message = error instanceof Error
                ? error.message
                : "Remote runtime snapshot read failed.";

            return localFallbackResponse(
                context,
                "Remote read failed; local state retained. " + message,
                "ERROR",
            );
        }
    } catch (error: unknown) {
        const message = error instanceof Error
            ? error.message
            : "Runtime snapshot read failed.";

        return NextResponse.json(
            { status: "ERROR", error: message },
            { status: 500 },
        );
    }
}

export async function POST(): Promise<Response> {
    try {
        const context = await getAuthenticatedSnapshotContext();

        if (context.kind === "unauthenticated") {
            return context.response;
        }

        if (!context.remoteScope) {
            return localFallbackResponse(
                context,
                context.remoteScopeReason ?? "Canonical remote tenant unavailable; remote write skipped.",
            );
        }

        try {
            const snapshot = await context.store.save(
                context.remoteScope,
                context.localState as Parameters<typeof context.store.save>[1],
                1,
            );

            return NextResponse.json(
                {
                    status: "AVAILABLE",
                    scopeKey: snapshot.scopeKey,
                    version: snapshot.version,
                    createdAt: snapshot.createdAt,
                    updatedAt: snapshot.updatedAt,
                    remotePersistence: "SUPABASE",
                    snapshot: snapshot.state,
                },
                { status: 200 },
            );
        } catch (error: unknown) {
            const message = error instanceof Error
                ? error.message
                : "Remote runtime snapshot save failed.";

            return localFallbackResponse(
                context,
                "Remote write failed; local state retained. " + message,
                "ERROR",
            );
        }
    } catch (error: unknown) {
        const message = error instanceof Error
            ? error.message
            : "Runtime snapshot save failed.";

        return NextResponse.json(
            { status: "ERROR", error: message },
            { status: 500 },
        );
    }
}
