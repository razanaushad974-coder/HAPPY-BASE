import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    FounderRuntimeBridge,
} from "../../../../core/founder/runtime-bridge";

import {
    HappyOrchestrationEngine,
} from "../../../../core/orchestration/engine";

import {
    resolveTrustedFounderIdentity,
} from "../../../../core/founder/identity";

import {
    persistAuthenticatedRuntimeSnapshot,
} from "../../../../core/integration/runtime-persistence";



export const runtime = "nodejs";

type FounderExecuteBody = {
    command?: unknown;
    activeProjectId?: unknown;
    activeMissionId?: unknown;
    activeTaskId?: unknown;
};

function isNonEmptyString(value: unknown): value is string {
    return typeof value === "string" && value.trim().length > 0;
}

function isOptionalString(value: unknown): value is string | undefined {
    return typeof value === "undefined" || isNonEmptyString(value);
}

export async function POST(request: Request): Promise<Response> {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        if (!runtimeContext.authenticatedUserId) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    error: "Authenticated Founder session is required.",
                },
                { status: 401 },
            );
        }

        const founderIdentity =
            resolveTrustedFounderIdentity(
                runtimeContext.authenticatedUserId,
            );

        if (founderIdentity.status !== "ALLOW") {
            return NextResponse.json(
                {
                    status: founderIdentity.status,
                    error: founderIdentity.reason,
                },
                { status: 503 },
            );
        }

        let body: FounderExecuteBody;

        try {
            body = (await request.json()) as FounderExecuteBody;
        } catch {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error: "Request body must be valid JSON.",
                },
                { status: 400 },
            );
        }

        if (!isNonEmptyString(body.command)) {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error: "command is required.",
                },
                { status: 400 },
            );
        }

        if (
            !isOptionalString(body.activeProjectId) ||
            !isOptionalString(body.activeMissionId) ||
            !isOptionalString(body.activeTaskId)
        ) {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error: "Invalid active identifier.",
                },
                { status: 400 },
            );
        }

        const workspace =
            createAuthenticatedWorkspaceState(
                runtimeContext.authenticatedUserId,
            );

        const tenant = workspace.tenant;

        if (tenant.userId !== runtimeContext.authenticatedUserId) {
            return NextResponse.json(
                {
                    status: "BLOCKED",
                    error: "Authenticated tenant scope mismatch.",
                },
                { status: 403 },
            );
        }

        const orchestration = new HappyOrchestrationEngine(
            undefined,
            workspace.persistence,
        );

        const bridge = new FounderRuntimeBridge(
            orchestration,
        );


        const access = {
            ...founderIdentity.access,
            action: "CONTROL_HAPPY" as const,
        };

        const result = await bridge.execute({
            rawCommand: body.command.trim(),
            access,
            action: access.action,
            organizationId: tenant.organizationId,
            workspaceId: tenant.workspaceId,
            userId: tenant.userId,
            runtimeContext,
            activeProjectId: isNonEmptyString(body.activeProjectId)
                ? body.activeProjectId.trim()
                : undefined,
            activeMissionId: isNonEmptyString(body.activeMissionId)
                ? body.activeMissionId.trim()
                : undefined,
            activeTaskId: isNonEmptyString(body.activeTaskId)
                ? body.activeTaskId.trim()
                : undefined,
        });

        let runtimePersistence: Awaited<ReturnType<typeof persistAuthenticatedRuntimeSnapshot>>;

        try {
            const supabase = await createSupabaseServerClient();
            runtimePersistence = await persistAuthenticatedRuntimeSnapshot(
                supabase,
                workspace.store,
                {
                    organizationId: tenant.organizationId,
                    workspaceId: tenant.workspaceId,
                    userId: tenant.userId,
                },
                1,
            );
        }
        catch (snapshotError) {
            runtimePersistence = {
                status: "ERROR",
                scopeKey: [tenant.organizationId, tenant.workspaceId, tenant.userId].join("|"),
                error: snapshotError instanceof Error ? snapshotError.message : "Founder runtime snapshot persistence failed.",
            };
        }

        return NextResponse.json({ ...result, runtimePersistence });
    } catch (error) {
        return NextResponse.json(
            {
                status: "FAILED",
                error:
                    error instanceof Error
                        ? error.message
                        : "Founder execution failed.",
            },
            { status: 500 },
        );
    }
}

