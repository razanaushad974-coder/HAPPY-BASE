import {
    NextResponse,
} from "next/server";

import {
    getCapabilityCounts,
    listCapabilities,
} from "../../../core/capabilities";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
    const capabilities =
        listCapabilities();

    const counts =
        getCapabilityCounts();

    return NextResponse.json(
        {
            generatedAt:
                new Date().toISOString(),

            total:
                capabilities.length,

            counts,

            capabilities,
        },
        {
            headers: {
                "Cache-Control":
                    "no-store, max-age=0",
            },
        },
    );
}

