import { resolveTrustedFounderIdentity } from "../../../core/founder/identity";
import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../core/auth/supabase-runtime-context";

import {
    createSupabaseServerClient,
} from "../../../lib/supabase/server";

import {
    HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import {
    persistAuthenticatedRuntimeSnapshot,
} from "../../../core/integration/runtime-persistence";

import type {
    HappyPipelineRequest,
} from "../../../core/orchestration/types";

import {
    createAuthenticatedWorkspaceState,
} from "../../../core/workspace/file-backed-state";

export const runtime = "nodejs";

type ExecuteBody = {
    id?: unknown;
    command?: unknown;
    activeProjectId?: unknown;
    activeMissionId?: unknown;
    activeTaskId?: unknown;
    source?: unknown;
};

function isNonEmptyString(
    value: unknown,
): value is string {
    return (
        typeof value === "string" &&
        value.trim().length > 0
    );
}

function isOptionalString(
    value: unknown,
): value is string | undefined {
    return (
        typeof value === "undefined" ||
        isNonEmptyString(value)
    );
}

function isValidSource(
    value: unknown,
): value is HappyPipelineRequest["source"] {
    return (
        value === "TEXT" ||
        value === "VOICE" ||
        value === "SYSTEM" ||
        value === "API" ||
        value === "AUTOMATION"
    );
}

export async function POST(
    request: Request,
): Promise<Response> {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        const localDevAuthenticated =
            process.env.HAPPY_LOCAL_DEV_MODE === "true" &&
            Boolean(
                runtimeContext.authenticatedUserId,
            ) &&
            !runtimeContext.supabaseAccessToken;

        if (
            !runtimeContext.authenticatedUserId ||
            (
                !runtimeContext.supabaseAccessToken &&
                !localDevAuthenticated
            )
        ) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    error:
                        "Authenticated Supabase user session is required.",
                },
                {
                    status: 401,
                },
            );
        }

        let body: ExecuteBody;

        try {
            body =
                (await request.json()) as ExecuteBody;
        }
        catch {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error:
                        "Request body must be valid JSON.",
                },
                {
                    status: 400,
                },
            );
        }

        if (
            !isNonEmptyString(body.command)
        ) {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error:
                        "command is required.",
                },
                {
                    status: 400,
                },
            );
        }

        if (
            !isOptionalString(body.id) ||
            !isOptionalString(body.activeProjectId) ||
            !isOptionalString(body.activeMissionId) ||
            !isOptionalString(body.activeTaskId)
        ) {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error:
                        "Optional identifiers must be non-empty strings when supplied.",
                },
                {
                    status: 400,
                },
            );
        }

        const source =
            typeof body.source === "undefined"
                ? "API"
                : body.source;

        if (!isValidSource(source)) {
            return NextResponse.json(
                {
                    status: "INVALID_REQUEST",
                    error:
                        "source must be TEXT, VOICE, SYSTEM, API or AUTOMATION.",
                },
                {
                    status: 400,
                },
            );
        }

        const authenticatedWorkspace =
            createAuthenticatedWorkspaceState(
                runtimeContext.authenticatedUserId,
            );

        const tenant =
            authenticatedWorkspace.tenant;

        const founderIdentity = resolveTrustedFounderIdentity(tenant.userId);
        const trustedRole = founderIdentity.status === "ALLOW" ? "FOUNDER" : "USER";

        const pipelineRequest:
            HappyPipelineRequest = {
            id:
                isNonEmptyString(body.id)
                    ? body.id.trim()
                    : crypto.randomUUID(),

            command:
                body.command.trim(),

            organizationId:
                tenant.organizationId,

            workspaceId:
                tenant.workspaceId,

            activeProjectId:
                isNonEmptyString(
                    body.activeProjectId,
                )
                    ? body.activeProjectId.trim()
                    : undefined,

            activeMissionId:
                isNonEmptyString(
                    body.activeMissionId,
                )
                    ? body.activeMissionId.trim()
                    : undefined,

            activeTaskId:
                isNonEmptyString(
                    body.activeTaskId,
                )
                    ? body.activeTaskId.trim()
                    : undefined,

            userId:
                tenant.userId,

            authorization: {
                role: trustedRole,
                scope: "WORKSPACE",
                roleSource: "TRUSTED_SERVER",
                authenticated: true,
            },

            source,

            approved:
                false,

            createdAt:
                new Date().toISOString(),
        };

        const executionRuntimeContext = {
            ...runtimeContext,
            organizationId: tenant.organizationId,
            workspaceId: tenant.workspaceId,
        };

        const engine =
            new HappyOrchestrationEngine(
                undefined,
                authenticatedWorkspace.persistence,
            );
        const result =
            await engine.run(
                pipelineRequest,
                executionRuntimeContext,
            );

        let runtimePersistence:
            Awaited<
                ReturnType<
                    typeof persistAuthenticatedRuntimeSnapshot
                >
            >;

        try {
            const supabase =
                await createSupabaseServerClient();

            runtimePersistence =
                await persistAuthenticatedRuntimeSnapshot(
                    supabase,
                    authenticatedWorkspace.store,
                    {
                        organizationId:
                            tenant.organizationId,
                        workspaceId:
                            tenant.workspaceId,
                        userId:
                            tenant.userId,
                    },
                    1,
                );
        }
        catch (snapshotError) {
            runtimePersistence = {
                status: "ERROR",
                scopeKey: [
                    tenant.organizationId,
                    tenant.workspaceId,
                    tenant.userId,
                ].join("|"),
                error:
                    snapshotError instanceof Error
                        ? snapshotError.message
                        : "Authenticated runtime snapshot persistence failed.",
            };
        }

        return NextResponse.json(
            {
                ...result,
                runtimePersistence: {
                    status:
                        runtimePersistence.status,
                    scopeKey:
                        runtimePersistence.scopeKey,
                    ...(runtimePersistence.version !== undefined
                        ? {
                            version:
                                runtimePersistence.version,
                          }
                        : {}),
                    ...(runtimePersistence.error
                        ? {
                            error:
                                runtimePersistence.error,
                          }
                        : {}),
                },
            },
            {
                status: 200,
            },
        );
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "HAPPY execution request failed.";

        if (
            message ===
            "WORKSPACE_TENANT_NOT_FOUND"
        ) {
            return NextResponse.json(
                {
                    status:
                        "WORKSPACE_NOT_INITIALIZED",
                    error:
                        "No persisted HAPPY workspace tenant exists for the authenticated user.",
                },
                {
                    status: 404,
                },
            );
        }

        if (
            message ===
            "AMBIGUOUS_WORKSPACE_TENANT"
        ) {
            return NextResponse.json(
                {
                    status:
                        "AMBIGUOUS_WORKSPACE_TENANT",
                    error:
                        "More than one persisted workspace tenant matches the authenticated user.",
                },
                {
                    status: 409,
                },
            );
        }

        if (
            message ===
            "Supabase server client is not configured."
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_YET_CONNECTED",
                    error: message,
                },
                {
                    status: 503,
                },
            );
        }

        console.error(
            "HAPPY /api/execute error:",
            error,
        );

        return NextResponse.json(
            {
                status: "FAILED",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}
