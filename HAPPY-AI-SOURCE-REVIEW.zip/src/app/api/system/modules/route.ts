import { NextResponse } from "next/server";

import {
  buildHappyModuleEvidence,
} from "@/core/integration/happy-module-evidence";

export async function GET() {
  const snapshot =
    buildHappyModuleEvidence();

  return NextResponse.json(
    snapshot,
    {
      status: 200,
      headers: {
        "Cache-Control": "no-store",
      },
    },
  );
}
