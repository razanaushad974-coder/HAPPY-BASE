import { NextResponse } from "next/server";

import {
  buildSystemReadiness,
} from "@/core/integration/system-readiness";

export async function GET() {
  const snapshot = buildSystemReadiness();

  return NextResponse.json(
    snapshot,
    {
      status: 200,
      headers: {
        "Cache-Control": "no-store",
      },
    },
  );
}
