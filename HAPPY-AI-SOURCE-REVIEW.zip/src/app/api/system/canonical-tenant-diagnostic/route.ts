import { NextResponse } from "next/server";
import { getAuthenticatedExecutionRuntimeContext } from "@/core/auth/supabase-runtime-context";
import { resolveTrustedFounderIdentity } from "@/core/founder/identity";
import { resolveCanonicalSupabaseTenant } from "@/core/workspace/supabase-tenant-resolver";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        if (!runtimeContext.authenticatedUserId) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    verified: false,
                    error: "Authenticated Founder session is required.",
                },
                { status: 401 },
            );
        }

        const founderIdentity =
            resolveTrustedFounderIdentity(
                runtimeContext.authenticatedUserId,
            );

        if (founderIdentity.status !== "ALLOW") {
            return NextResponse.json(
                {
                    status: founderIdentity.status,
                    verified: false,
                    error: founderIdentity.reason,
                },
                { status: 503 },
            );
        }

        if (!runtimeContext.supabaseAccessToken) {
            return NextResponse.json(
                {
                    status: "NOT_YET_CONNECTED",
                    verified: false,
                    error: "A verified Supabase access token is required.",
                },
                { status: 503 },
            );
        }

        const tenant =
            await resolveCanonicalSupabaseTenant(
                runtimeContext.supabaseAccessToken,
                { allowProvisioning: false },
            );

        return NextResponse.json({
            status: "LIVE_CANONICAL_TENANT_RESOLVED",
            verified: true,
            organizationId: tenant.organizationId,
            organizationName: tenant.organizationName,
            organizationSlug: tenant.organizationSlug,
            workspaceId: tenant.workspaceId,
            workspaceName: tenant.workspaceName,
            workspaceSlug: tenant.workspaceSlug,
            userId: tenant.userId,
            organizationIdLooksUuid:
                /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
                    tenant.organizationId,
                ),
            workspaceIdLooksUuid:
                /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
                    tenant.workspaceId,
                ),
        });
    } catch (error: unknown) {
        const notProvisioned =
            error instanceof Error &&
            error.message === "CANONICAL_TENANT_NOT_PROVISIONED";

        return NextResponse.json(
            {
                status: "LIVE_CANONICAL_TENANT_RESOLUTION_FAILED",
                verified: false,
                error: notProvisioned
                    ? "Canonical tenant is not provisioned."
                    : "Canonical tenant resolution failed.",
            },
            { status: 500 },
        );
    }
}
