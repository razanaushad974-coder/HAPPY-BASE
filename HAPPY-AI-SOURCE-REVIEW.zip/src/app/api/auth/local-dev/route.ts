﻿import { NextResponse } from "next/server";

const COOKIE_NAME = "happy_local_dev_session";

export async function POST() {
  if (process.env.HAPPY_LOCAL_DEV_MODE !== "true") {
    return NextResponse.json(
      { status: "DISABLED", error: "Local development mode is disabled." },
      { status: 404 }
    );
  }

  const response = NextResponse.json({
    status: "READY",
    userId: "local-dev-user",
  });

  response.cookies.set({
    name: COOKIE_NAME,
    value: "1",
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 86400,
  });

  return response;
}
