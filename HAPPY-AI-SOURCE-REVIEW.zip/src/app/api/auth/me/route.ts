﻿import { NextResponse } from "next/server";

import {
  classifySupabaseAuthError,
  requireSupabaseUser,
  resolveSupabaseUser,
} from "@/server/supabase-auth";

import {
  createSupabaseServerClient,
} from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

async function resolveAuthenticatedUser(
  request: Request,
) {
  const authorization =
    request.headers.get("authorization");

  if (authorization) {
    return requireSupabaseUser(
      authorization,
    );
  }

  const supabase =
    await createSupabaseServerClient();

  const sessionResult =
    await supabase.auth.getSession();

  if (
    sessionResult.error ||
    !sessionResult.data.session?.access_token
  ) {
    throw new Error(
      "UNAUTHENTICATED",
    );
  }

  return resolveSupabaseUser(
    sessionResult.data.session.access_token,
  );
}

export async function GET(
  request: Request,
): Promise<Response> {
  try {
    const user =
      await resolveAuthenticatedUser(
        request,
      );

    return NextResponse.json({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        metadata: user.metadata,
      },
    });
  } catch (error) {
    const status =
      classifySupabaseAuthError(
        error,
      );

    if (
      status === "UNAUTHENTICATED"
    ) {
      return NextResponse.json(
        {
          authenticated: false,
          status,
        },
        {
          status: 401,
        },
      );
    }

    if (
      status ===
      "NOT_YET_CONNECTED"
    ) {
      return NextResponse.json(
        {
          authenticated: false,
          status,
        },
        {
          status: 503,
        },
      );
    }

    return NextResponse.json(
      {
        authenticated: false,
        status: "ERROR",
      },
      {
        status: 500,
      },
    );
  }
}
