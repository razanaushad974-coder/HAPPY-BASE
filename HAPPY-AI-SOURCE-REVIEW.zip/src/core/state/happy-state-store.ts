import type { EntityType } from "../persistence/types";
import type { PersistenceService } from "../persistence/service";
import { ScopedStateRepository } from "./scoped-repository";
import type { TenantScope } from "./types";

export class HappyStateStore {
    constructor(
        private readonly persistence: PersistenceService,
        private readonly scope: TenantScope,
    ) {}

    repository<T>(
        entityType: EntityType,
    ): ScopedStateRepository<T> {
        return new ScopedStateRepository<T>(
            entityType,
            this.persistence,
            this.scope,
        );
    }

    memory<T = unknown>() {
        return this.repository<T>("MEMORY");
    }

    command<T = unknown>() {
        return this.repository<T>("COMMAND");
    }

    mission<T = unknown>() {
        return this.repository<T>("MISSION");
    }

    task<T = unknown>() {
        return this.repository<T>("TASK");
    }

    execution<T = unknown>() {
        return this.repository<T>("EXECUTION");
    }

    verification<T = unknown>() {
        return this.repository<T>("VERIFICATION");
    }

    evidence<T = unknown>() {
        return this.repository<T>("EVIDENCE");
    }

    approval<T = unknown>() {
        return this.repository<T>("APPROVAL");
    }

    audit<T = unknown>() {
        return this.repository<T>("AUDIT_EVENT");
    }

    async snapshot(): Promise<import("../persistence/state").HappyState> {
        const listScoped = async (
            entityType: EntityType,
        ): Promise<import("../persistence/state").HappyState[keyof import("../persistence/state").HappyState]> => {
            const records =
                await this.repository<unknown>(
                    entityType,
                ).list();

            return records.map((record) => ({
                id: record.id,
                entityType: record.entityType,
                version: record.version,
                createdAt: record.createdAt,
                updatedAt: record.updatedAt,
                data: record.data,
            })) as import("../persistence/types").PersistedRecord<unknown>[];
        };

        return {
            users:
                await listScoped("USER") as import("../persistence/state").HappyState["users"],
            workspaces:
                await listScoped("WORKSPACE") as import("../persistence/state").HappyState["workspaces"],
            projects:
                await listScoped("PROJECT") as import("../persistence/state").HappyState["projects"],
            commands:
                await listScoped("COMMAND") as import("../persistence/state").HappyState["commands"],
            missions:
                await listScoped("MISSION") as import("../persistence/state").HappyState["missions"],
            tasks:
                await listScoped("TASK") as import("../persistence/state").HappyState["tasks"],
            executions:
                await listScoped("EXECUTION") as import("../persistence/state").HappyState["executions"],
            verifications:
                await listScoped("VERIFICATION") as import("../persistence/state").HappyState["verifications"],
            evidence:
                await listScoped("EVIDENCE") as import("../persistence/state").HappyState["evidence"],
            memories:
                await listScoped("MEMORY") as import("../persistence/state").HappyState["memories"],
            approvals:
                await listScoped("APPROVAL") as import("../persistence/state").HappyState["approvals"],
            auditEvents:
                await listScoped("AUDIT_EVENT") as import("../persistence/state").HappyState["auditEvents"],
        };
    }
}
