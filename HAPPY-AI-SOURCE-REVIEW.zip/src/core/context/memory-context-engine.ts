import {
  resolveContext,
} from "./resolver";

import type {
  ContextResolution,
} from "./types";

import type {
  PersistentMemoryService,
} from "../memory/persistent-service";

export interface MemoryContextRequest {
  userId?: string;
  workspaceId?: string;
  activeProjectId?: string;
  activeMissionId?: string;
  activeTaskId?: string;
  recentCommand?: string;
  language?: string;
  limit?: number;
}

export interface MemoryContextResult {
  resolution: ContextResolution;
  memoriesUsed: number;
  memorySummary: string;
}

function isExpired(
  expiresAt: string | undefined,
  nowMs: number,
): boolean {
  if (!expiresAt) {
    return false;
  }

  const expiresMs =
    new Date(expiresAt).getTime();

  if (Number.isNaN(expiresMs)) {
    return true;
  }

  return expiresMs <= nowMs;
}

export class MemoryContextEngine {
  constructor(
    private readonly memory: PersistentMemoryService,
  ) {}

  async resolve(
    request: MemoryContextRequest,
  ): Promise<MemoryContextResult> {
    const nowMs = Date.now();

    const memories =
      await this.memory.search({
        userId:
          request.userId,
        workspaceId:
          request.workspaceId,
        limit:
          request.limit ?? 50,
      });

    const activeMemories =
      memories.filter(
        (memory) =>
          !isExpired(
            memory.expiresAt,
            nowMs,
          ),
      );

    const memorySummary =
      activeMemories
        .map(
          (memory) =>
            `${memory.key}: ${memory.value}`,
        )
        .join("\n");

    const resolution =
      resolveContext(
        {
          userId:
            request.userId,
          workspaceId:
            request.workspaceId,
          activeProjectId:
            request.activeProjectId,
          activeMissionId:
            request.activeMissionId,
          activeTaskId:
            request.activeTaskId,
          recentCommand:
            request.recentCommand,
          language:
            request.language,
          memorySummary,
        },
        request.recentCommand ?? "",
      );

    return {
      resolution,
      memoriesUsed:
        activeMemories.length,
      memorySummary,
    };
  }
}
