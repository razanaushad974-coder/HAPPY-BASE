import { PlanningEngine } from "./planning-engine";
import { ReasoningEngine } from "./engine";
import type { ExecutionPlan } from "./types";

export class ReasoningOrchestrator {
  private readonly reasoning =
    new ReasoningEngine();

  private readonly planning =
    new PlanningEngine();

  /*
   * EXISTING SYNCHRONOUS CONTRACT
   *
   * Preserved for existing tests and deterministic callers.
   */
  createExecutionPlan(
    input: {
      goal: string;
      contextSummary?: string;
      resolvedReferences?: import("../context/types").ResolvedReference[];
      constraints?: string[];
      knownFacts?: string[];
      assumptions?: string[];
      unresolvedQuestions?: string[];
      requiredCapabilities?: string[];
      requiredKnowledgeSources?: string[];
    },
  ): ExecutionPlan {
    const request =
      this.reasoning.createRequest(input);

    const plan =
      this.reasoning.createPlan(request);

    const validation =
      this.planning.validate(plan);

    if (!validation.valid) {
      return {
        ...plan,
        status: "FAILED",
        failureConditions: [
          ...plan.failureConditions,
          ...validation.errors,
        ],
      };
    }

    return plan;
  }

  /*
   * NEW ASYNCHRONOUS AI CONTRACT
   *
   * Uses Gemini through the single HAPPY AI gateway.
   */
  async createAIExecutionPlan(
    input: {
      goal: string;
      contextSummary?: string;
      resolvedReferences?: import("../context/types").ResolvedReference[];
      constraints?: string[];
      knownFacts?: string[];
      assumptions?: string[];
      unresolvedQuestions?: string[];
      requiredCapabilities?: string[];
      requiredKnowledgeSources?: string[];
    },
  ): Promise<ExecutionPlan> {
    const request =
      this.reasoning.createRequest(input);

    const plan =
      await this.reasoning.createAIPlan(request);

    const goalText =
      request.goal.toLowerCase();

    const requiredExternalAction:
      "DEPLOY" | "PUBLISH" | "AUTOMATE" | null =
      /\bdeploy(?:ment)?\b|\bgo[- ]live\b|\bproduction\s+deploy\b/.test(
        goalText,
      )
        ? "DEPLOY"
        : /\bpublish(?:ing|ed)?\b|\bmake\s+public\b/.test(
              goalText,
            )
          ? "PUBLISH"
          : /\bautomate(?:d|s|ing)?\b|\bautomation\b/.test(
                goalText,
              )
            ? "AUTOMATE"
            : null;

    /*
     * CRITICAL EXTERNAL ACTION BOUNDARY
     *
     * DEPLOY / PUBLISH / AUTOMATE execution plans must not
     * depend on variable AI-generated execution steps.
     *
     * AI may reason about the request, but the actual execution
     * boundary is normalized through the deterministic planner.
     * This prevents unrelated CODE/BUILD tasks from being
     * introduced into a critical external workflow.
     */
    if (requiredExternalAction) {
      const fallbackPlan =
        this.reasoning.createPlan(request);

      const fallbackValidation =
        this.planning.validate(fallbackPlan);

      if (!fallbackValidation.valid) {
        return {
          ...fallbackPlan,
          status: "FAILED",
          failureConditions: [
            ...fallbackPlan.failureConditions,
            ...fallbackValidation.errors,
          ],
        };
      }

      return fallbackPlan;
    }

    const validation =
      this.planning.validate(plan);

    if (!validation.valid) {
      return {
        ...plan,
        status: "FAILED",
        failureConditions: [
          ...plan.failureConditions,
          ...validation.errors,
        ],
      };
    }

    return plan;
  }
}


