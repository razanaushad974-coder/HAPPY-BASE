import { AIGateway } from "../ai/gateway";
import type { AIMessage } from "../ai/types";
import type {
  ExecutionPlan,
  ModuleCrudIntent,
  PlanRisk,
  PlanStep,
  PlanStepAction,
  ReasoningRequest,
} from "./types";

function createId(prefix: string): string {
  return `${prefix}-${crypto.randomUUID()}`;
}

function asString(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.filter(
    (item): item is string =>
      typeof item === "string",
  );
}

function asBoolean(value: unknown): boolean {
  return value === true;
}

function isPlanStepAction(
  value: unknown,
): value is PlanStepAction {
  return [
    "UNDERSTAND",
    "RESEARCH",
    "CREATE",
    "MODIFY",
    "BUILD",
    "TEST",
    "REQUEST",
    "CALL",
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "VERIFY",
    "DEPLOY",
    "PUBLISH",
    "AUTOMATE",
    "CONTROL",
    "DB_SELECT",
    "DB_QUERY",
    "DB_INSERT",
    "DB_UPDATE",
    "DB_DELETE",
    "DB_TRANSACTION",
  ].includes(value as PlanStepAction);
}

function isPlanRisk(
  value: unknown,
): value is PlanRisk {
  return [
    "LOW",
    "MEDIUM",
    "HIGH",
    "CRITICAL",
  ].includes(value as PlanRisk);
}

function parseJsonObject(
  content: string,
): Record<string, unknown> {
  const trimmed = content.trim();

  try {
    return JSON.parse(trimmed) as Record<string, unknown>;
  } catch {
    const fenced = trimmed
      .replace(/^```json\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();

    return JSON.parse(fenced) as Record<string, unknown>;
  }
}


function parseModuleCrudIntent(
  value: unknown,
): ModuleCrudIntent | undefined {
  if (
    typeof value !== "object" ||
    value === null ||
    Array.isArray(value)
  ) {
    return undefined;
  }

  const raw = value as Record<string, unknown>;

  const moduleNumber =
    typeof raw.moduleNumber === "number" &&
    Number.isInteger(raw.moduleNumber)
      ? raw.moduleNumber
      : undefined;

  if (
    moduleNumber === undefined ||
    moduleNumber < 1 ||
    moduleNumber > 502
  ) {
    return undefined;
  }

  const rawAction =
    typeof raw.action === "string"
      ? raw.action.trim().toUpperCase()
      : "";

  const allowedActions = [
    "CREATE",
    "GET",
    "READ",
    "LIST",
    "UPDATE",
    "MODIFY",
    "DELETE",
  ] as const;

  if (
    !allowedActions.includes(
      rawAction as (typeof allowedActions)[number],
    )
  ) {
    return undefined;
  }

  const moduleCrud: ModuleCrudIntent = {
    moduleNumber,
    action:
      rawAction as ModuleCrudIntent["action"],
  };

  if (typeof raw.moduleId === "string") {
    const moduleId = raw.moduleId.trim();

    if (moduleId) {
      moduleCrud.moduleId = moduleId;
    }
  }

  if (typeof raw.recordId === "string") {
    const recordId = raw.recordId.trim();

    if (recordId) {
      moduleCrud.recordId = recordId;
    }
  }

  if (
    typeof raw.data === "object" &&
    raw.data !== null &&
    !Array.isArray(raw.data)
  ) {
    moduleCrud.data =
      raw.data as Record<string, unknown>;
  }

  if (
    typeof raw.expectedVersion === "number" &&
    Number.isInteger(raw.expectedVersion) &&
    raw.expectedVersion >= 1
  ) {
    moduleCrud.expectedVersion =
      raw.expectedVersion;
  }

  return moduleCrud;
}
export class ReasoningEngine {
  constructor(
    private readonly gateway: AIGateway =
      new AIGateway(),
  ) {}

  createRequest(input: {
    goal: string;
    contextSummary?: string;
    resolvedReferences?: import("../context/types").ResolvedReference[];
    constraints?: string[];
    knownFacts?: string[];
    assumptions?: string[];
    unresolvedQuestions?: string[];
    requiredCapabilities?: string[];
    requiredKnowledgeSources?: string[];
  }): ReasoningRequest {
    const goal = input.goal.trim();

    if (!goal) {
      throw new Error("Reasoning goal is required.");
    }

    return {
      id: crypto.randomUUID(),
      mode: "REASON",
      goal,
      contextSummary:
        input.contextSummary?.trim() ?? "",
      resolvedReferences:
        input.resolvedReferences ?? [],
      constraints:
        input.constraints ?? [],
      knownFacts:
        input.knownFacts ?? [],
      assumptions:
        input.assumptions ?? [],
      unresolvedQuestions:
        input.unresolvedQuestions ?? [],
      requiredCapabilities:
        input.requiredCapabilities ?? [],
      requiredKnowledgeSources:
        input.requiredKnowledgeSources ?? [],
      createdAt:
        new Date().toISOString(),
    };
  }

  assessRisk(
    request: ReasoningRequest,
  ): PlanRisk {
    const text = [
      request.goal,
      ...request.constraints,
      ...request.requiredCapabilities,
    ]
      .join(" ")
      .toLowerCase();

    if (
      /payment|delete|security|credential|production|deploy|publish|admin|db_update|db_insert|db_delete|db_transaction/.test(
        text,
      )
    ) {
      return "HIGH";
    }

    if (
      /database|api|automation|external|auth|user data/.test(
        text,
      )
    ) {
      return "MEDIUM";
    }

    return "LOW";
  }

  private createDeterministicFallback(
    request: ReasoningRequest,
    risk: PlanRisk,
  ): ExecutionPlan {
    const steps: PlanStep[] = [
      {
        id: createId("plan-step"),
        order: 1,
        action: "UNDERSTAND",
        title:
          "Understand the requested goal",
        description:
          "Resolve the user's goal, context, constraints, facts and unresolved references before execution.",
        dependencies: [],
        requiresApproval: false,
        risk: "LOW",
        verificationRequired: true,
      },
      {
        id: createId("plan-step"),
        order: 2,
        action: "RESEARCH",
        title:
          "Collect required knowledge",
        description:
          "Identify and use the knowledge required for the goal.",
        dependencies: [],
        requiresApproval: false,
        risk: "LOW",
        verificationRequired: true,
      },
      {
        id: createId("plan-step"),
        order: 3,
        action: "BUILD",
        title:
          "Execute the planned work",
        description:
          "Hand the approved implementation work to the appropriate capability.",
        targetReference:
          request.resolvedReferences[0],
        dependencies: [],
        requiresApproval:
          risk === "HIGH" ||
          risk === "CRITICAL",
        risk,
        verificationRequired: true,
      },
      {
        id: createId("plan-step"),
        order: 4,
        action: "TEST",
        title: "Test the result",
        description:
          "Run validation before completion.",
        dependencies: [],
        requiresApproval: false,
        risk: "MEDIUM",
        verificationRequired: true,
      },
      {
        id: createId("plan-step"),
        order: 5,
        action: "VERIFY",
        title: "Verify the outcome",
        description:
          "Verify the actual result and require evidence.",
        dependencies: [],
        requiresApproval: false,
        risk: "MEDIUM",
        verificationRequired: true,
      },
    ];

    const intentText = [
      request.goal,
      ...request.requiredCapabilities,
      ...request.constraints,
    ]
      .join(" ")
      .toLowerCase();

    /*
     * Analysis/diagnostic/review commands are knowledge work.
     * They must never be converted into BUILD/TEST work merely
     * because the AI planner returned an underspecified plan.
     */
    const isAnalysisIntent =
      /\b(analy[sz]e|analysis|diagnos(?:e|is|tic)|inspect|investigate|investigation|review|audit|assess|assessment|evaluate|evaluation|examine|understand|explain|summari[sz]e|report)\b/.test(
        intentText,
      ) &&
      !/\b(?:build|create|develop|implement|modify|update|edit|code|fix|repair|deploy|publish|automate)\b/.test(
        intentText,
      );

    if (isAnalysisIntent) {
      steps.splice(
        0,
        steps.length,
        {
          id: createId("plan-step"),
          order: 1,
          action: "UNDERSTAND",
          title: "Understand the analysis request",
          description:
            "Resolve the requested analysis goal, context, constraints, facts and unresolved references.",
          dependencies: [],
          requiresApproval: false,
          risk: "LOW",
          verificationRequired: true,
        },
        {
          id: createId("plan-step"),
          order: 2,
          action: "RESEARCH",
          title: "Analyze the required knowledge",
          description:
            "Inspect the available context and gather the knowledge required to produce the requested analysis.",
          dependencies: [],
          requiresApproval: false,
          risk: "LOW",
          verificationRequired: true,
        },
        {
          id: createId("plan-step"),
          order: 3,
          action: "VERIFY",
          title: "Verify the analysis outcome",
          description:
            "Verify that the analysis is grounded in the available evidence and matches the requested goal.",
          dependencies: [],
          requiresApproval: false,
          risk: "LOW",
          verificationRequired: true,
        },
      );
    }
    const requestedExternalAction:
      PlanStep["action"] | null =
      /\bdeploy(?:ment)?\b|\bgo[- ]live\b|\bproduction\s+deploy\b/.test(
        intentText,
      )
        ? "DEPLOY"
        : /\bpublish(?:ing|ed)?\b|\bmake\s+public\b/.test(
              intentText,
            )
          ? "PUBLISH"
          : /\bautomate(?:d|s|ing)?\b|\bautomation\b/.test(
                intentText,
              )
            ? "AUTOMATE"
            : null;

    if (requestedExternalAction) {
      steps.splice(
        0,
        steps.length,
        {
          id: createId("plan-step"),
          order: 1,
          action: requestedExternalAction,
          title:
            requestedExternalAction === "DEPLOY"
              ? "Deploy the requested project"
              : requestedExternalAction === "PUBLISH"
                ? "Publish the requested result"
                : "Run the requested automation",
          description:
            requestedExternalAction === "DEPLOY"
              ? "Hand the approved deployment request to the deployment capability. Deployment must never be simulated by a build operation."
              : requestedExternalAction === "PUBLISH"
                ? "Hand the approved publishing request to the publishing capability. Publishing must never be simulated by a local implementation operation."
                : "Hand the approved automation request to the automation capability. Automation must never be simulated by a different execution capability.",
          targetReference:
            request.resolvedReferences[0],
          dependencies: [],
          requiresApproval: true,
          risk,
          verificationRequired: true,
        },
        {
          id: createId("plan-step"),
          order: 2,
          action: "VERIFY",
          title:
            "Verify the external outcome",
          description:
            "Verify the actual external result and require evidence before completion.",
          targetReference:
            request.resolvedReferences[0],
          dependencies: [],
          requiresApproval: false,
          risk: "MEDIUM",
          verificationRequired: true,
        },
      );
    }
    return {
      id: createId("execution-plan"),
      reasoningRequestId: request.id,
      goal: request.goal,
      status:
        request.unresolvedQuestions.length > 0
          ? "NEEDS_CLARIFICATION"
          : risk === "HIGH" ||
              risk === "CRITICAL"
            ? "WAITING_APPROVAL"
            : "READY",
      risk,
      resolvedReferences:
        request.resolvedReferences,
      assumptions:
        request.assumptions,
      unresolvedQuestions:
        request.unresolvedQuestions,
      requiredCapabilities:
        request.requiredCapabilities,
      steps,
      expectedOutputs: [
        "Completed requested work",
        "Test results",
        "Verification evidence",
      ],
      failureConditions: [
        "Required capability unavailable.",
        "Validation fails.",
        "Verification evidence is insufficient.",
      ],
      verificationRequirements: [
        "All required tests pass.",
        "Actual output matches the requested goal.",
        "Evidence is recorded before completion.",
      ],
      createdAt:
        new Date().toISOString(),
    };
  }

  private buildSystemPrompt(): string {
    return `
You are HAPPY's reasoning planner.

You do NOT execute actions.
You do NOT claim success.
You do NOT bypass approval.
You only create a structured execution plan.

Return ONLY valid JSON.

Required JSON:
{
  "steps": [
    {
      "order": 1,
      "action": "UNDERSTAND",
      "title": "string",
      "description": "string",
      "requiresApproval": false,
      "risk": "LOW",
      "verificationRequired": true
    }
  ],
  "expectedOutputs": ["string"],
  "failureConditions": ["string"],
  "verificationRequirements": ["string"]
}

Allowed actions:
UNDERSTAND, RESEARCH, CREATE, MODIFY, BUILD, TEST,
REQUEST, CALL, GET, POST, PUT, PATCH, DELETE,
DB_SELECT, DB_QUERY, DB_INSERT, DB_UPDATE, DB_DELETE, DB_TRANSACTION,
VERIFY, DEPLOY, PUBLISH, AUTOMATE, CONTROL

Allowed risks:
LOW, MEDIUM, HIGH, CRITICAL

Rules:
- Every step must require verification.
- HIGH or CRITICAL actions require approval.
- Never invent execution evidence.
- Do not claim a task was executed.

Module CRUD contract:
- When the user's goal explicitly targets a HAPPY module, include moduleCrud on the execution step.
- moduleCrud.moduleNumber must be the requested HAPPY module number from 1 through 502.
- moduleCrud.action must be one of CREATE, GET, READ, LIST, UPDATE, MODIFY, DELETE.
- For CREATE, put every user-requested field and value into moduleCrud.data.
- For UPDATE or MODIFY, include the requested fields in moduleCrud.data; include recordId and expectedVersion when the user supplied them.
- For GET, READ, and DELETE, include recordId when the user supplied or resolved one.
- For LIST, do not invent a recordId or data object.
- Never invent field values, record IDs, versions, module numbers, or database results.
- Preserve user-provided values exactly unless normalization is explicitly required by the request.
- moduleCrud describes intended database work only; it does not mean the work has been executed.
`;
  }
  private buildMessages(
    request: ReasoningRequest,
  ): AIMessage[] {
    return [
      {
        role: "system",
        content:
          this.buildSystemPrompt(),
      },
      {
        role: "user",
        content: JSON.stringify({
          goal: request.goal,
          contextSummary:
            request.contextSummary,
          resolvedReferences:
            request.resolvedReferences,
          constraints:
            request.constraints,
          knownFacts:
            request.knownFacts,
          assumptions:
            request.assumptions,
          unresolvedQuestions:
            request.unresolvedQuestions,
          requiredCapabilities:
            request.requiredCapabilities,
          requiredKnowledgeSources:
            request.requiredKnowledgeSources,
        }),
      },
    ];
  }

  private parseAIPlan(
    request: ReasoningRequest,
    content: string,
  ): ExecutionPlan {
    const raw =
      parseJsonObject(content);

    const rawSteps =
      Array.isArray(raw.steps)
        ? raw.steps
        : [];

    if (rawSteps.length === 0) {
      throw new Error(
        "Gemini returned no plan steps.",
      );
    }

    const assessedRisk =
      this.assessRisk(request);

    const steps: PlanStep[] =
      rawSteps.map(
        (
          item: unknown,
          index: number,
        ) => {
          if (
            typeof item !== "object" ||
            item === null
          ) {
            throw new Error(
              `Invalid plan step ${index + 1}.`,
            );
          }

          const step =
            item as Record<string, unknown>;

          if (
            !isPlanStepAction(
              step.action,
            )
          ) {
            throw new Error(
              `Invalid plan action at step ${index + 1}.`,
            );
          }

          const declaredRisk =
            isPlanRisk(step.risk)
              ? step.risk
              : "LOW";

          const requiresApproval =
            asBoolean(
              step.requiresApproval,
            ) ||
            declaredRisk === "HIGH" ||
            declaredRisk === "CRITICAL";

          const moduleCrud =
            parseModuleCrudIntent(
              step.moduleCrud,
            );

          return {
            id: createId("plan-step"),
            order:
              typeof step.order ===
              "number"
                ? step.order
                : index + 1,
            action: step.action,
            title:
              asString(step.title) ||
              `${step.action} step`,
            description:
              asString(
                step.description,
              ),
            targetReference:
              step.action === "BUILD"
                ? request.resolvedReferences[0]
                : undefined,
            moduleCrud,
            dependencies: [],
            requiresApproval,
            risk:
              declaredRisk === "LOW" &&
              (assessedRisk === "HIGH" ||
                assessedRisk === "CRITICAL") &&
              step.action === "BUILD"
                ? assessedRisk
                : declaredRisk,
            verificationRequired: true,
          };
        },
      );

    const approvalRequired =
      steps.some(
        (step) =>
          step.requiresApproval,
      );

    return {
      id: createId("execution-plan"),
      reasoningRequestId: request.id,
      goal: request.goal,
      status:
        request.unresolvedQuestions.length > 0
          ? "NEEDS_CLARIFICATION"
          : approvalRequired
            ? "WAITING_APPROVAL"
            : "READY",
      risk: assessedRisk,
      resolvedReferences:
        request.resolvedReferences,
      assumptions:
        request.assumptions,
      unresolvedQuestions:
        request.unresolvedQuestions,
      requiredCapabilities:
        request.requiredCapabilities,
      steps,
      expectedOutputs:
        asStringArray(
          raw.expectedOutputs,
        ),
      failureConditions:
        asStringArray(
          raw.failureConditions,
        ),
      verificationRequirements:
        asStringArray(
          raw.verificationRequirements,
        ),
      createdAt:
        new Date().toISOString(),
    };
  }

  async createAIPlan(
    request: ReasoningRequest,
  ): Promise<ExecutionPlan> {
    const risk =
      this.assessRisk(request);

    if (
      request.unresolvedQuestions.length > 0
    ) {
      return this.createDeterministicFallback(
        request,
        risk,
      );
    }

    const response =
      await this.gateway.complete({
        provider: "GEMINI",
        mode: "PLAN",
        messages:
          this.buildMessages(request),
        temperature: 0.2,
        maxTokens: 3000,
      });

    if (
      !response.success ||
      response.status !== "COMPLETED" ||
      !response.content
    ) {
      return this.createDeterministicFallback(
        request,
        risk,
      );
    }

    try {
      const parsedPlan =
        this.parseAIPlan(
          request,
          response.content,
        );

      const explicitModuleMatch =
        request.goal.match(
          /\bhappy\s+module\s+(\d{1,3})\b/i,
        );

      if (explicitModuleMatch) {
        const moduleNumber =
          Number(explicitModuleMatch[1]);

        const normalizedGoal =
          request.goal.trim().toLowerCase();

        let moduleAction:
          | "CREATE"
          | "GET"
          | "READ"
          | "LIST"
          | "UPDATE"
          | "MODIFY"
          | "DELETE"
          | undefined;

        if (
          /\b(create|add|new|register|registration|insert)\b/.test(
            normalizedGoal,
          )
        ) {
          moduleAction = "CREATE";
        } else if (
          /\blist\b/.test(normalizedGoal)
        ) {
          moduleAction = "LIST";
        } else if (
          /\b(delete|remove|destroy)\b/.test(
            normalizedGoal,
          )
        ) {
          moduleAction = "DELETE";
        } else if (
          /\b(update|edit|modify|change)\b/.test(
            normalizedGoal,
          )
        ) {
          moduleAction = "UPDATE";
        } else if (
          /\b(read|get|fetch|find|view|show|check)\b/.test(
            normalizedGoal,
          )
        ) {
          moduleAction = "GET";
        }

        if (
          Number.isInteger(moduleNumber) &&
          moduleNumber >= 1 &&
          moduleNumber <= 502 &&
          moduleAction
        ) {
          /*
           * Explicit HAPPY module CRUD intent is authoritative.
           * The execution route will resolve the canonical module
           * and send the operation through the DATABASE boundary.
           */
          const targetStepIndex =
            parsedPlan.steps.findIndex(
              (step) =>
                step.action !== "VERIFY" &&
                step.action !== "UNDERSTAND",
            );

          if (targetStepIndex >= 0) {
            const targetStep =
              parsedPlan.steps[targetStepIndex];

            const executionAction: PlanStepAction =
              moduleAction === "CREATE"
                ? "CREATE"
                : moduleAction === "UPDATE" ||
                    moduleAction === "MODIFY"
                  ? "MODIFY"
                  : moduleAction === "DELETE"
                    ? "DELETE"
                    : "GET";

            parsedPlan.steps[targetStepIndex] = {
              ...targetStep,
              action: executionAction,
              moduleCrud: {
                ...(targetStep.moduleCrud ?? {}),
                moduleNumber,
                action: moduleAction,
              },
              requiresApproval: true,
              risk:
                targetStep.risk === "CRITICAL"
                  ? "CRITICAL"
                  : "HIGH",
              verificationRequired: true,
            };

            return {
              ...parsedPlan,
              status: "WAITING_APPROVAL",
              risk:
                parsedPlan.risk === "CRITICAL"
                  ? "CRITICAL"
                  : "HIGH",
            };
          }
        }
      }

      /*
       * Canonical HAPPY reasoning requires ordinary AI plans
       * to be decomposed into a multi-stage execution plan.
       * Explicit HAPPY module CRUD is handled above and returns
       * before this guard.
       */
      if (parsedPlan.steps.length < 5) {
        throw new Error(
          "AI plan decomposition produced fewer than 5 steps.",
        );
      }

      return parsedPlan;
    } catch {
      return this.createDeterministicFallback(
        request,
        risk,
      );
    }
  }

  /*
   * Existing synchronous contract preserved
   * for Step 32 and deterministic callers.
   */
  createPlan(
    request: ReasoningRequest,
  ): ExecutionPlan {
    return this.createDeterministicFallback(
      request,
      this.assessRisk(request),
    );
  }

}
