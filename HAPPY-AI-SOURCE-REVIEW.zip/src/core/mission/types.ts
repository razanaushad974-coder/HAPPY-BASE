import type { ResolvedReference } from "../context/types";
export type MissionStatus =
  | "DRAFT"
  | "PLANNED"
  | "WAITING_APPROVAL"
  | "READY"
  | "RUNNING"
  | "VERIFYING"
  | "COMPLETED"
  | "FAILED"
  | "BLOCKED"
  | "CANCELLED";

export type TaskStatus =
  | "PENDING"
  | "BLOCKED"
  | "READY"
  | "RUNNING"
  | "VERIFYING"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export type TaskAction =
  | "UNDERSTAND"
  | "RESEARCH"
  | "CREATE"
  | "MODIFY"
  | "BUILD"
  | "TEST"
  | "REQUEST"
  | "CALL"
  | "GET"
  | "POST"
  | "PUT"
  | "PATCH"
  | "DELETE"
  | "VERIFY"
  | "DEPLOY"
  | "PUBLISH"
  | "AUTOMATE"
  | "CONTROL"
  | "DB_SELECT"
  | "DB_QUERY"
  | "DB_INSERT"
  | "DB_UPDATE"
  | "DB_DELETE"
  | "DB_TRANSACTION";

export interface Mission {
  id: string;
  goal: string;
  planId: string;
  status: MissionStatus;
  taskIds: string[];
  rootTaskIds: string[];
  completedTaskIds: string[];
  failedTaskIds: string[];
  blockedTaskIds: string[];
  progressPercent: number;
  createdAt: string;
  updatedAt: string;
}

export interface MissionTask {
  id: string;
  missionId: string;
  action: TaskAction;
  title: string;
  description: string;
  targetReference?: ResolvedReference;
  moduleCrud?: {
    moduleNumber: number;
    moduleId?: string;
    action:
      | "CREATE"
      | "GET"
      | "READ"
      | "LIST"
      | "UPDATE"
      | "MODIFY"
      | "DELETE";
    recordId?: string;
    data?: Record<string, unknown>;
    expectedVersion?: number;
  };
  status: TaskStatus;
  dependencyIds: string[];
  dependentTaskIds: string[];
  order: number;
  retryCount: number;
  maxRetries: number;
  requiresApproval: boolean;
  verificationRequired: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TaskGraph {
  missionId: string;
  tasks: MissionTask[];
  roots: string[];
  leaves: string[];
}

export interface MissionSnapshot {
  mission: Mission;
  graph: TaskGraph;
}

