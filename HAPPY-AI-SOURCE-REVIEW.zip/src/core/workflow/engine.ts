import {
  resolveExecutionCapability,
} from "../execution/capability-resolver";

import {
  evaluateApprovalGate,
} from "../execution/control-gates";

import {
  findAgentForCapability,
} from "../agents/registry";

export interface WorkflowStepInput {
  id: string;
  action: string;
  targetReference?: never;
  dependsOn?: string[];
  requiresApproval?: boolean;
}

export interface WorkflowStep {
  id: string;
  action: string;
  capability: ReturnType<
    typeof resolveExecutionCapability
  >;
  agentId?: string;
  agentStatus:
    | "AVAILABLE"
    | "NOT_YET_CONNECTED"
    | "BLOCKED"
    | "UNASSIGNED";
  dependsOn: string[];
  requiresApproval: boolean;
}

export type WorkflowPlanStatus =
  | "READY"
  | "WAITING_APPROVAL"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

export interface WorkflowPlan {
  id: string;
  command: string;
  status: WorkflowPlanStatus;
  steps: WorkflowStep[];
  reason: string;
}

function hasDuplicateIds(
  steps: WorkflowStepInput[],
): boolean {
  return (
    new Set(
      steps.map(
        (step) => step.id,
      ),
    ).size !== steps.length
  );
}

function hasUnknownDependency(
  steps: WorkflowStepInput[],
): boolean {
  const ids = new Set(
    steps.map(
      (step) => step.id,
    ),
  );

  return steps.some(
    (step) =>
      (step.dependsOn ?? []).some(
        (dependency) =>
          !ids.has(dependency),
      ),
  );
}

function hasCycle(
  steps: WorkflowStepInput[],
): boolean {
  const graph = new Map<
    string,
    string[]
  >(
    steps.map(
      (step) => [
        step.id,
        [...(step.dependsOn ?? [])],
      ],
    ),
  );

  const visiting = new Set<string>();
  const visited = new Set<string>();

  const visit = (
    id: string,
  ): boolean => {
    if (visiting.has(id)) {
      return true;
    }

    if (visited.has(id)) {
      return false;
    }

    visiting.add(id);

    for (
      const dependency of
        graph.get(id) ?? []
    ) {
      if (visit(dependency)) {
        return true;
      }
    }

    visiting.delete(id);
    visited.add(id);

    return false;
  };

  for (
    const step of steps
  ) {
    if (visit(step.id)) {
      return true;
    }
  }

  return false;
}

export class AgentWorkflowEngine {
  createPlan(
    command: string,
    steps: WorkflowStepInput[],
  ): WorkflowPlan {
    if (!command.trim()) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: [],
        reason:
          "Workflow command cannot be empty.",
      };
    }

    if (steps.length === 0) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: [],
        reason:
          "Workflow must contain at least one step.",
      };
    }

    if (hasDuplicateIds(steps)) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: [],
        reason:
          "Workflow step IDs must be unique.",
      };
    }

    if (hasUnknownDependency(steps)) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: [],
        reason:
          "Workflow contains an unknown dependency.",
      };
    }

    if (hasCycle(steps)) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: [],
        reason:
          "Workflow dependency graph contains a cycle.",
      };
    }

    const builtSteps: WorkflowStep[] =
      steps.map(
        (step): WorkflowStep => {
          const capability =
            resolveExecutionCapability(
              step.action,
            );

          const agent =
            findAgentForCapability(
              capability,
            );

          const approval =
            evaluateApprovalGate({
              approvalRequired:
                step.requiresApproval === true,
              approved: false,
            });

          return {
            id: step.id,
            action: step.action,
            capability,
            agentId:
              agent?.id,
            agentStatus:
              agent?.status ??
              "UNASSIGNED",
            dependsOn:
              [...(step.dependsOn ?? [])],
            requiresApproval:
              approval.status ===
              "WAITING_APPROVAL",
          };
        },
      );

    const blocked =
      builtSteps.some(
        (step) =>
          step.agentStatus ===
          "BLOCKED",
      );

    if (blocked) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "BLOCKED",
        steps: builtSteps,
        reason:
          "One or more required agents are blocked.",
      };
    }

    const disconnected =
      builtSteps.some(
        (step) =>
          step.agentStatus ===
          "NOT_YET_CONNECTED",
      );

    if (disconnected) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "NOT_YET_CONNECTED",
        steps: builtSteps,
        reason:
          "One or more required agent runtimes are not connected.",
      };
    }

    const waitingApproval =
      builtSteps.some(
        (step) =>
          step.requiresApproval,
      );

    if (waitingApproval) {
      return {
        id:
          `workflow_${crypto.randomUUID()}`,
        command,
        status: "WAITING_APPROVAL",
        steps: builtSteps,
        reason:
          "One or more workflow steps require approval.",
      };
    }

    return {
      id:
        `workflow_${crypto.randomUUID()}`,
      command,
      status: "READY",
      steps: builtSteps,
      reason:
        "Workflow is structurally valid and mapped to available agents.",
    };
  }
}
