import {
  buildHappyModuleReadiness,
} from "./happy-module-readiness";

export type HappyModuleEvidenceLevel =
  | "CATALOG_ONLY"
  | "ROUTING_PROVEN"
  | "EXECUTION_PROVEN"
  | "IMPLEMENTED";

export type HappyModuleEvidenceRecord =
  ReturnType<typeof buildHappyModuleReadiness>["modules"][number] & {
    readonly evidenceLevel: HappyModuleEvidenceLevel;
    readonly evidenceSources: readonly string[];
  };

type HappyModuleReadinessSnapshot =
  ReturnType<typeof buildHappyModuleReadiness>;

export type HappyModuleEvidenceSnapshot =
  Omit<HappyModuleReadinessSnapshot, "modules"> & {
    readonly evidencePolicy:
      "DIRECT_EXECUTION_EVIDENCE_REQUIRED";
    readonly catalogOnly: number;
    readonly routingProven: number;
    readonly executionProven: number;
    readonly implemented: number;
    readonly modules:
      readonly HappyModuleEvidenceRecord[];
  };

const ROUTING_PROVEN_MODULES = new Set<number>([
  41,
  282,
  322,
  345,
]);

const EXECUTION_PROVEN_MODULES = new Set<number>();

const IMPLEMENTED_MODULES = new Set<number>();

const EVIDENCE_SOURCES = new Map<number, readonly string[]>([
  [
    41,
    [
      "src/tests/core/happy/module-router-direct-proof.ts",
      "src/tests/core/happy/module-router-native-proof.ts",
    ],
  ],
  [
    282,
    [
      "src/tests/core/happy/module-router-direct-proof.ts",
      "src/tests/core/happy/module-router-native-proof.ts",
    ],
  ],
  [
    322,
    [
      "src/tests/core/happy/module-router-direct-proof.ts",
      "src/tests/core/happy/module-router-native-proof.ts",
    ],
  ],
  [
    345,
    [
      "src/tests/core/happy/module-router-direct-proof.ts",
      "src/tests/core/happy/module-router-native-proof.ts",
    ],
  ],
]);

export function buildHappyModuleEvidence(): HappyModuleEvidenceSnapshot {
  const readiness = buildHappyModuleReadiness();

  const modules: HappyModuleEvidenceRecord[] =
    readiness.modules.map((module) => {
      const moduleNumber = module.number;

      const evidenceLevel: HappyModuleEvidenceLevel =
        IMPLEMENTED_MODULES.has(moduleNumber)
          ? "IMPLEMENTED"
          : EXECUTION_PROVEN_MODULES.has(moduleNumber)
            ? "EXECUTION_PROVEN"
            : ROUTING_PROVEN_MODULES.has(moduleNumber)
              ? "ROUTING_PROVEN"
              : "CATALOG_ONLY";

      const evidenceSources =
        EVIDENCE_SOURCES.get(moduleNumber) ?? [];

      return {
        ...module,
        evidenceLevel,
        evidenceSources,
      };
    });

  return {
    ...readiness,
    evidencePolicy:
      "DIRECT_EXECUTION_EVIDENCE_REQUIRED",
    catalogOnly: modules.filter(
      (module) =>
        module.evidenceLevel === "CATALOG_ONLY",
    ).length,
    routingProven: modules.filter(
      (module) =>
        module.evidenceLevel === "ROUTING_PROVEN",
    ).length,
    executionProven: modules.filter(
      (module) =>
        module.evidenceLevel === "EXECUTION_PROVEN",
    ).length,
    implemented: modules.filter(
      (module) =>
        module.evidenceLevel === "IMPLEMENTED",
    ).length,
    modules,
  };
}
