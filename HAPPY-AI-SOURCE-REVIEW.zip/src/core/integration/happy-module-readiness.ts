import {
  HAPPY_MAJOR_MODULE_CATALOG,
} from "../happy/kernel/registry/happy-major-module-catalog";

import {
  happyModuleCapabilityBindingRegistry,
} from "../happy/kernel/registry/happy-module-capability-binding";

import type {
  HappyCapabilityId,
  HappyModuleCapabilityBinding,
} from "../happy/kernel/registry/happy-module-capability-binding";

export type ModuleImplementationStatus =
  | "NOT_PROVEN";

export interface HappyModuleReadinessRecord {
  readonly number: number;
  readonly id: string;
  readonly name: string;
  readonly category?: string;
  readonly capability: HappyCapabilityId | null;
  readonly capabilityStatus:
    HappyModuleCapabilityBinding["status"];
  readonly capabilityReason: string;
  readonly implementationStatus:
    ModuleImplementationStatus;
}

export interface HappyModuleReadinessSnapshot {
  readonly systemId: "happy";
  readonly name: "HAPPY";
  readonly totalModules: number;
  readonly catalogIntegrity:
    "VALID" | "INVALID";
  readonly implementationEvidencePolicy:
    "NO_MODULE_IS_MARKED_IMPLEMENTED_WITHOUT_DIRECT_EVIDENCE";
  readonly summary: {
    readonly available: number;
    readonly notYetConnected: number;
    readonly blocked: number;
    readonly unmapped: number;
  };
  readonly capabilitySummary:
    Record<HappyCapabilityId, number>;
  readonly modules:
    readonly HappyModuleReadinessRecord[];
  readonly generatedAt: string;
}

function validateCatalog(): void {
  const modules =
    HAPPY_MAJOR_MODULE_CATALOG;

  if (modules.length !== 502) {
    throw new Error(
      `HAPPY_MODULE_CATALOG_COUNT_INVALID:${modules.length}`,
    );
  }

  const numbers =
    new Set<number>();

  const ids =
    new Set<string>();

  for (const catalogModule of modules) {
    const moduleNumber =
      catalogModule.number;

    if (
      moduleNumber === undefined ||
      !Number.isInteger(
        moduleNumber,
      )
    ) {
      throw new Error(
        `HAPPY_MODULE_NUMBER_INVALID:${catalogModule.id}`,
      );
    }

    if (
      !catalogModule.id.trim()
    ) {
      throw new Error(
        `HAPPY_MODULE_ID_INVALID:${moduleNumber}`,
      );
    }

    if (
      !catalogModule.name.trim()
    ) {
      throw new Error(
        `HAPPY_MODULE_NAME_INVALID:${moduleNumber}`,
      );
    }

    if (
      numbers.has(moduleNumber)
    ) {
      throw new Error(
        `HAPPY_MODULE_NUMBER_DUPLICATE:${moduleNumber}`,
      );
    }

    if (
      ids.has(catalogModule.id)
    ) {
      throw new Error(
        `HAPPY_MODULE_ID_DUPLICATE:${catalogModule.id}`,
      );
    }

    numbers.add(
      moduleNumber,
    );

    ids.add(
      catalogModule.id,
    );
  }

  for (
    let number = 1;
    number <= 502;
    number += 1
  ) {
    if (
      !numbers.has(number)
    ) {
      throw new Error(
        `HAPPY_MODULE_NUMBER_MISSING:${number}`,
      );
    }
  }
}

export function buildHappyModuleReadiness():
  HappyModuleReadinessSnapshot {
  validateCatalog();

  const modules =
    HAPPY_MAJOR_MODULE_CATALOG;

  const bindings =
    happyModuleCapabilityBindingRegistry.bindMany(
      modules.map(
        (module) => ({
          id: module.id,
          number: module.number,
          name: module.name,
          category: module.category,
        }),
      ),
    );

  if (
    bindings.length !== 502
  ) {
    throw new Error(
      `HAPPY_MODULE_BINDING_COUNT_INVALID:${bindings.length}`,
    );
  }

  const implementationStatus:
    ModuleImplementationStatus =
    "NOT_PROVEN";

  const records:
    HappyModuleReadinessRecord[] =
    modules.map(
      (module, index) => {
        const moduleNumber =
          module.number;

        if (
          moduleNumber === undefined ||
          !Number.isInteger(
            moduleNumber,
          )
        ) {
          throw new Error(
            `HAPPY_MODULE_NUMBER_INVALID:${module.id}`,
          );
        }

        const binding =
          bindings[index];

        if (!binding) {
          throw new Error(
            `HAPPY_MODULE_BINDING_MISSING:${module.id}`,
          );
        }

        const capabilityStatus =
          binding.capability === null
            ? "NOT_YET_CONNECTED"
            : binding.status;

        return {
          number:
            moduleNumber,
          id:
            module.id,
          name:
            module.name,
          category:
            module.category,
          capability:
            binding.capability,
          capabilityStatus,
          capabilityReason:
            binding.reason,
          implementationStatus,
        };
      },
    );

  const available =
    records.filter(
      (module) =>
        module.capabilityStatus ===
        "AVAILABLE",
    ).length;

  const blocked =
    records.filter(
      (module) =>
        module.capabilityStatus ===
        "BLOCKED",
    ).length;

  const notYetConnected =
    records.filter(
      (module) =>
        module.capabilityStatus ===
        "NOT_YET_CONNECTED",
    ).length;

  const unmapped =
    records.filter(
      (module) =>
        module.capability === null,
    ).length;

  const capabilitySummary:
    Record<HappyCapabilityId, number> = {
    AI: 0,
    CODE: 0,
    FILE: 0,
    API: 0,
    BROWSER: 0,
    DATABASE: 0,
    DEPLOYMENT: 0,
    PUBLISH: 0,
    AUTOMATION: 0,
    SHELL: 0,
  };

  for (
    const moduleRecord of records
  ) {
    if (
      moduleRecord.capability !==
      null
    ) {
      capabilitySummary[
        moduleRecord.capability
      ] += 1;
    }
  }

  return {
    systemId: "happy",
    name: "HAPPY",
    totalModules:
      records.length,
    catalogIntegrity:
      "VALID",
    implementationEvidencePolicy:
      "NO_MODULE_IS_MARKED_IMPLEMENTED_WITHOUT_DIRECT_EVIDENCE",
    summary: {
      available,
      notYetConnected,
      blocked,
      unmapped,
    },
    capabilitySummary,
    modules: records,
    generatedAt:
      new Date().toISOString(),
  };
}

