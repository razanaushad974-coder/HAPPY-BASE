import type {
  ExecutionCapability,
} from "../execution/types";

import {
  listAgents,
} from "../agents/registry";

import {
  evaluateFounderAccess,
} from "../founder/access-policy";

import {
  evaluateApprovalGate,
} from "../execution/control-gates";

export type SystemReadinessStatus =
  | "READY"
  | "PARTIAL"
  | "BLOCKED"
  | "NOT_YET_CONNECTED";

export interface SystemReadinessCheck {
  id: string;
  area:
    | "IDENTITY"
    | "AUTH"
    | "PERSISTENCE"
    | "CONTEXT"
    | "EXECUTION"
    | "APPROVAL"
    | "VERIFICATION"
    | "EVIDENCE"
    | "MEMORY"
    | "WORKSPACE"
    | "FOUNDER"
    | "AGENTS"
    | "WORKFLOW"
    | "AUTOMATION"
    | "DEPLOYMENT"
    | "PUBLISH"
    | "OBSERVABILITY";
  status: SystemReadinessStatus;
  reason: string;
}

export interface SystemReadinessSnapshot {
  systemId: "happy";
  name: "HAPPY";
  singleIntelligence: true;
  status: SystemReadinessStatus;
  checks: SystemReadinessCheck[];
  summary: string;
  generatedAt: string;
}

function check(
  id: string,
  area: SystemReadinessCheck["area"],
  status: SystemReadinessStatus,
  reason: string,
): SystemReadinessCheck {
  return {
    id,
    area,
    status,
    reason,
  };
}

export function buildSystemReadiness(): SystemReadinessSnapshot {
  const checks: SystemReadinessCheck[] = [];

  checks.push(
    check(
      "identity.single-happy",
      "IDENTITY",
      "READY",
      "HAPPY is represented as one system identity and one intelligence contract.",
    ),
  );

  const authConfigured =
    Boolean(
      process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() &&
      (
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim() ||
        process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY?.trim() ||
        process.env.SUPABASE_PUBLISHABLE_KEY?.trim()
      ),
    );

  checks.push(
    check(
      "auth.supabase-config",
      "AUTH",
      authConfigured
        ? "READY"
        : "NOT_YET_CONNECTED",
      authConfigured
        ? "Supabase authentication configuration is available."
        : "Supabase authentication environment configuration is not fully available.",
    ),
  );

  checks.push(
    check(
      "persistence.scope",
      "PERSISTENCE",
      "READY",
      "Tenant-scoped repositories exist for core persistent entities.",
    ),
  );

  checks.push(
    check(
      "context.reference-safety",
      "CONTEXT",
      "READY",
      "Context resolution can preserve unresolved and ambiguous references instead of guessing.",
    ),
  );

  const capabilityStatuses:
    Record<
      ExecutionCapability,
      {
        status:
          | "AVAILABLE"
          | "BLOCKED"
          | "NOT_YET_CONNECTED";
        reason: string;
      }
    > = {
      CODE: {
        status: "AVAILABLE",
        reason:
          "CODE capability is available in the verified execution foundation.",
      },
      FILE: {
        status: "AVAILABLE",
        reason:
          "FILE capability is available in the verified execution foundation.",
      },
      API: {
        status: "AVAILABLE",
        reason:
          "API capability is available in the verified execution foundation.",
      },
      BROWSER: {
        status: "AVAILABLE",
        reason:
          "BROWSER capability is available in the verified execution foundation.",
      },
      DATABASE: {
        status: "AVAILABLE",
        reason:
          "DATABASE capability is available in the verified execution foundation.",
      },
      AI: {
        status: "AVAILABLE",
        reason:
          "AI capability is available in the verified execution foundation.",
      },
      SHELL: {
        status: "BLOCKED",
        reason:
          "SHELL remains explicitly gated by the safe-shell security boundary.",
      },
      DEPLOYMENT: {
        status: "NOT_YET_CONNECTED",
        reason:
          "Deployment runtime is not yet connected.",
      },
      PUBLISH: {
        status: "NOT_YET_CONNECTED",
        reason:
          "Publishing runtime is not yet connected.",
      },
      AUTOMATION: {
        status: "NOT_YET_CONNECTED",
        reason:
          "Automation runtime is not yet connected.",
      },
    };

  const requiredCapabilities:
    ExecutionCapability[] = [
      "CODE",
      "FILE",
      "API",
      "BROWSER",
      "DATABASE",
      "AI",
      "SHELL",
      "DEPLOYMENT",
      "PUBLISH",
      "AUTOMATION",
    ];

  for (
    const capability of
      requiredCapabilities
  ) {
    const capabilityState =
      capabilityStatuses[
        capability
      ];

    let status:
      SystemReadinessStatus;

    if (
      capabilityState.status ===
      "AVAILABLE"
    ) {
      status = "READY";
    }
    else if (
      capabilityState.status ===
      "BLOCKED"
    ) {
      status = "BLOCKED";
    }
    else {
      status =
        "NOT_YET_CONNECTED";
    }

    const area:
      SystemReadinessCheck["area"] =
      capability === "DEPLOYMENT"
        ? "DEPLOYMENT"
        : capability === "PUBLISH"
          ? "PUBLISH"
          : capability === "AUTOMATION"
            ? "AUTOMATION"
            : "EXECUTION";

    checks.push(
      check(
        `execution.${capability.toLowerCase()}`,
        area,
        status,
        capabilityState.reason,
      ),
    );
  }

  const agents =
    listAgents();

  checks.push(
    check(
      "agents.registry",
      "AGENTS",
      agents.length > 0
        ? "READY"
        : "BLOCKED",
      agents.length > 0
        ? `${agents.length} agent definitions are registered.`
        : "No agent definitions are registered.",
    ),
  );

  const founderPreview =
    evaluateFounderAccess({
      userId:
        "readiness-preview",
      role:
        "USER",
      roleSource:
        "CLIENT",
      authenticated:
        false,
      action:
        "VIEW_FOUNDER_DASHBOARD",
    });

  checks.push(
    check(
      "founder.privilege-boundary",
      "FOUNDER",
      founderPreview.status ===
        "BLOCKED"
        ? "READY"
        : "BLOCKED",
      founderPreview.reason,
    ),
  );

  const approvalPreview =
    evaluateApprovalGate({
      approvalRequired:
        true,
      approved:
        false,
    });

  checks.push(
    check(
      "approval.execution-boundary",
      "APPROVAL",
      approvalPreview.status ===
        "WAITING_APPROVAL"
        ? "READY"
        : "BLOCKED",
      approvalPreview.reason,
    ),
  );

  checks.push(
    check(
      "verification.completion-boundary",
      "VERIFICATION",
      "READY",
      "Completion must remain downstream of verification.",
    ),
  );

  checks.push(
    check(
      "evidence.execution-contract",
      "EVIDENCE",
      "READY",
      "Execution evidence is part of the verification/persistence path.",
    ),
  );

  checks.push(
    check(
      "memory.context-bridge",
      "MEMORY",
      "READY",
      "Persistent memory can feed the context resolver with scope and expiry protection.",
    ),
  );

  checks.push(
    check(
      "workspace.live-state",
      "WORKSPACE",
      "READY",
      "Workspace live-state service exposes tenant-scoped operational state.",
    ),
  );

  checks.push(
    check(
      "workflow.agent-capability-routing",
      "WORKFLOW",
      "READY",
      "Workflow planning maps actions to capabilities and registered agents.",
    ),
  );

  const externalStatuses =
    checks.filter(
      (item) =>
        item.status ===
        "NOT_YET_CONNECTED",
    );

  const blockedStatuses =
    checks.filter(
      (item) =>
        item.status ===
        "BLOCKED",
    );

  let status:
    SystemReadinessStatus;

  if (blockedStatuses.length > 0) {
    status = "BLOCKED";
  }
  else if (
    externalStatuses.length > 0
  ) {
    status = "PARTIAL";
  }
  else {
    status = "READY";
  }

  const summary =
    status === "READY"
      ? "HAPPY core integration is ready."
      : status === "PARTIAL"
        ? "HAPPY core is operational with explicitly unconnected external capabilities."
        : "HAPPY has one or more blocked readiness boundaries.";

  return {
    systemId: "happy",
    name: "HAPPY",
    singleIntelligence: true,
    status,
    checks,
    summary,
    generatedAt:
      new Date().toISOString(),
  };
}
