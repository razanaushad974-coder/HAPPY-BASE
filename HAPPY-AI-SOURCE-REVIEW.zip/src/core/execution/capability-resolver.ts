import type { ExecutionCapability } from "./types";
import type { ResolvedReference } from "../context/types";

import {
  requireExecutionCapabilityDefinition,
} from "../capabilities/registry";

export type ExecutionAction =
  | "UNDERSTAND"
  | "RESEARCH"
  | "CREATE"
  | "MODIFY"
  | "BUILD"
  | "TEST"
  | "REQUEST"
  | "CALL"
  | "GET"
  | "POST"
  | "PUT"
  | "PATCH"
  | "DELETE"
  | "VERIFY"
  | "DEPLOY"
  | "PUBLISH"
  | "AUTOMATE"
  | "CONTROL";

export function resolveExecutionCapability(
  action: ExecutionAction | string,
  targetReference?: ResolvedReference,
): ExecutionCapability {
  let capability: ExecutionCapability;

  if (
    targetReference?.entityType === "FILE" &&
    (
      action === "READ" ||
      action === "CREATE" ||
      action === "MODIFY" ||
      action === "COPY" ||
      action === "MOVE" ||
      action === "RENAME" ||
      action === "DELETE"
    )
  ) {
    capability = "FILE";
  } else {
    switch (action) {
      case "REQUEST":
      case "CALL":
      case "GET":
      case "POST":
      case "PUT":
      case "PATCH":
      case "DELETE":
        capability = "API";
        break;

      case "NAVIGATE":
      case "CLICK":
      case "FILL":
      case "EXTRACT":
      case "SCREENSHOT":
        capability = "BROWSER";
        break;

      case "UNDERSTAND":
      case "RESEARCH":
      case "VERIFY":
      case "CONTROL":
      case "GENERATE":
        capability = "AI";
        break;

      case "CREATE":
      case "MODIFY":
      case "BUILD":
      case "TEST":
        capability = "CODE";
        break;

      case "DEPLOY":
        capability = "DEPLOYMENT";
        break;

      case "PUBLISH":
        capability = "PUBLISH";
        break;

      case "AUTOMATE":
        capability = "AUTOMATION";
        break;

      case "SHELL":
      case "EXECUTE_SHELL":
        capability = "SHELL";
        break;

      case "DB_SELECT":
      case "DB_QUERY":
      case "DB_INSERT":
      case "DB_UPDATE":
      case "DB_DELETE":
      case "DB_TRANSACTION":
        capability = "DATABASE";
        break;

      default:
        capability = "AI";
        break;
    }
  }

  requireExecutionCapabilityDefinition(
    capability,
  );

  return capability;
}
