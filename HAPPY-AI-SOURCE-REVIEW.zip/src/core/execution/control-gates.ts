import type {
  ApprovalStatus,
} from "../approval/types";

import type {
  VerificationStatus,
} from "../verification/types";

export type ExecutionControlStatus =
  | "ALLOW"
  | "WAITING_APPROVAL"
  | "BLOCKED";

export type CompletionControlStatus =
  | "COMPLETED"
  | "PARTIAL"
  | "FAILED"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

export interface ApprovalGateInput {
  approvalRequired: boolean;
  approvalStatus?: ApprovalStatus;
  approved?: boolean;
}

export interface ApprovalGateDecision {
  status: ExecutionControlStatus;
  reason: string;
}

export interface VerificationGateInput {
  verificationStatus: VerificationStatus;
  requiresVerification: boolean;
}

export interface VerificationGateDecision {
  status: CompletionControlStatus;
  reason: string;
}

export function evaluateApprovalGate(
  input: ApprovalGateInput,
): ApprovalGateDecision {
  if (!input.approvalRequired) {
    return {
      status: "ALLOW",
      reason:
        "Execution does not require approval.",
    };
  }

  if (
    input.approvalStatus === "REJECTED"
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Execution approval was rejected.",
    };
  }

  if (
    input.approvalStatus === "CANCELLED"
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Execution approval was cancelled.",
    };
  }

  if (
    input.approvalStatus === "EXPIRED"
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Execution approval has expired.",
    };
  }

  if (
    input.approvalStatus === "APPROVED" ||
    input.approved === true
  ) {
    return {
      status: "ALLOW",
      reason:
        "Explicit execution approval is present.",
    };
  }

  return {
    status: "WAITING_APPROVAL",
    reason:
      "Execution is waiting for explicit approval.",
  };
}

export function evaluateVerificationGate(
  input: VerificationGateInput,
): VerificationGateDecision {
  if (!input.requiresVerification) {
    return {
      status: "COMPLETED",
      reason:
        "Execution does not require verification.",
    };
  }

  if (
    input.verificationStatus === "PASSED"
  ) {
    return {
      status: "COMPLETED",
      reason:
        "Required verification passed.",
    };
  }

  if (
    input.verificationStatus === "PARTIAL"
  ) {
    return {
      status: "PARTIAL",
      reason:
        "Verification produced a partial outcome.",
    };
  }

  if (
    input.verificationStatus ===
    "NOT_YET_CONNECTED"
  ) {
    return {
      status: "NOT_YET_CONNECTED",
      reason:
        "Required verification capability is not connected.",
    };
  }

  if (
    input.verificationStatus ===
    "BLOCKED"
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Verification is blocked.",
    };
  }

  return {
    status: "FAILED",
    reason:
      "Required verification did not pass.",
  };
}

export function canCompleteExecution(
  verificationStatus: VerificationStatus,
  requiresVerification: boolean,
): boolean {
  const decision =
    evaluateVerificationGate({
      verificationStatus,
      requiresVerification,
    });

  return decision.status ===
    "COMPLETED";
}

export function canStartExecution(
  approvalRequired: boolean,
  approvalStatus?: ApprovalStatus,
  approved?: boolean,
): boolean {
  const decision =
    evaluateApprovalGate({
      approvalRequired,
      approvalStatus,
      approved,
    });

  return decision.status === "ALLOW";
}
