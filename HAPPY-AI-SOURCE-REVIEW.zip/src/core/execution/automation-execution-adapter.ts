import type {
  AdapterStatus,
  ExecutionAdapter,
  ExecutionRequest,
  ExecutionResult,
} from "./types";
import type { ExecutionRuntimeContext } from "./runtime-context";
import type {
  HappyPipelineRequest,
  HappyPipelineResult,
} from "../orchestration/types";
import type { AutomationRequest } from "../automation/policy";

export interface AutomationPipelineRunner {
  run(
    request: HappyPipelineRequest,
    runtimeContext?: ExecutionRuntimeContext,
  ): Promise<HappyPipelineResult>;
}

function resultBase(
  request: ExecutionRequest,
  status: ExecutionResult["status"],
  startedAt: string,
): ExecutionResult {
  return {
    id: crypto.randomUUID(),
    requestId: request.id,
    capability: "AUTOMATION",
    status,
    evidenceIds: [],
    startedAt,
    completedAt: new Date().toISOString(),
  };
}

export class AutomationExecutionAdapter
  implements ExecutionAdapter
{
  public readonly capability = "AUTOMATION" as const;

  constructor(
    private readonly pipeline: AutomationPipelineRunner,
    private readonly runtimeContext: ExecutionRuntimeContext = {},
  ) {}

  status(): AdapterStatus {
    return "AVAILABLE";
  }

  canExecute(
    request: ExecutionRequest,
  ): boolean {
    if (
      request.capability !== "AUTOMATION" ||
      request.action !== "AUTOMATE"
    ) {
      return false;
    }

    if (
      !this.runtimeContext.organizationId ||
      !this.runtimeContext.workspaceId
    ) {
      return false;
    }

    return (
      typeof request.input === "object" &&
      request.input !== null &&
      typeof (
        request.input as Record<string, unknown>
      ).command === "string"
    );
  }

  async execute(
    request: ExecutionRequest,
  ): Promise<ExecutionResult> {
    const startedAt = new Date().toISOString();

    if (
      request.requiresApproval &&
      !request.approved
    ) {
      return {
        ...resultBase(
          request,
          "WAITING_APPROVAL",
          startedAt,
        ),
        error: "Explicit approval is required.",
      };
    }

    if (!this.canExecute(request)) {
      return {
        ...resultBase(
          request,
          "BLOCKED",
          startedAt,
        ),
        error:
          "Automation execution request is invalid or lacks authenticated workspace context.",
      };
    }

    const input =
      request.input as Record<string, unknown>;

    const automationRequest =
      input.automationRequest as
        | AutomationRequest
        | undefined;

    if (
      automationRequest &&
      (
        !automationRequest.enabled ||
        !automationRequest.approved
      )
    ) {
      return {
        ...resultBase(
          request,
          !automationRequest.enabled
            ? "BLOCKED"
            : "WAITING_APPROVAL",
          startedAt,
        ),
        error:
          !automationRequest.enabled
            ? "Automation is not enabled."
            : "Automation requires explicit approval.",
      };
    }

    const pipelineRequest: HappyPipelineRequest = {
      id: request.id,
      command: input.command as string,
      organizationId:
        this.runtimeContext.organizationId!,
      workspaceId:
        this.runtimeContext.workspaceId!,
      userId:
        this.runtimeContext.authenticatedUserId,
      source: "AUTOMATION",
      approved: request.approved,
      createdAt: request.createdAt,
    };

    try {
      const result =
        await this.pipeline.run(
          pipelineRequest,
          this.runtimeContext,
        );

      return {
        ...resultBase(
          request,
          result.status === "WAITING_APPROVAL"
            ? "WAITING_APPROVAL"
            : result.status === "COMPLETED"
              ? "COMPLETED"
              : result.status === "BLOCKED"
                ? "BLOCKED"
                : result.status === "NOT_YET_CONNECTED"
                  ? "NOT_YET_CONNECTED"
                  : result.status === "FAILED"
                    ? "FAILED"
                    : "RUNNING",
          startedAt,
        ),
        output: result,
        evidenceIds: result.evidenceIds,
        error:
          result.status === "FAILED"
            ? "Automation pipeline failed."
            : undefined,
      };
    } catch (error) {
      return {
        ...resultBase(
          request,
          "FAILED",
          startedAt,
        ),
        error:
          error instanceof Error
            ? error.message
            : "Automation pipeline execution failed.",
      };
    }
  }
}
