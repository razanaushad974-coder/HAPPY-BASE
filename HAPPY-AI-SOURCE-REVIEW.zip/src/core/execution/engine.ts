import type { ExecutionRuntimeContext } from "./runtime-context";
import type {
  ExecutionRequest,
  ExecutionResult,
} from "./types";

import { ExecutionAdapterRegistry } from "./registry";

import {
  HappyModuleExecutionAdapter,
} from "./happy-module-execution-adapter";

import {
  requireExecutionCapabilityDefinition,
} from "../capabilities/registry";

export class ExecutionEngine {
  constructor(
    private readonly registry: ExecutionAdapterRegistry,
  ) {}

  async execute(
    request: ExecutionRequest,
    runtimeContext: ExecutionRuntimeContext = {},
  ): Promise<ExecutionResult> {
    let capabilityDefinition;

    try {
      capabilityDefinition =
        requireExecutionCapabilityDefinition(
          request.capability,
        );
    } catch (error) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "BLOCKED",
        error:
          error instanceof Error
            ? error.message
            : "Execution capability is not registered.",
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    if (
      capabilityDefinition.status ===
      "BLOCKED"
    ) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "BLOCKED",
        error:
          `${request.capability} is BLOCKED by the canonical capability registry.`,
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    if (
      capabilityDefinition.status ===
      "NOT_YET_CONNECTED"
    ) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "NOT_YET_CONNECTED",
        error:
          `${request.capability} is NOT_YET_CONNECTED in the canonical capability registry.`,
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    const input =
      (
        request.input &&
        typeof request.input === "object"
      )
        ? request.input as Record<string, unknown>
        : {};

    const happyModuleRoute =
      (
        input.happyModuleRoute &&
        typeof input.happyModuleRoute === "object"
      )
        ? input.happyModuleRoute as Record<string, unknown>
        : undefined;

    const isHappyModuleRequest =
      request.capability === "DATABASE" &&
      typeof happyModuleRoute?.moduleNumber === "number";

    if (
      isHappyModuleRequest &&
      (
        !runtimeContext.organizationId ||
        !runtimeContext.workspaceId ||
        !runtimeContext.authenticatedUserId ||
        !runtimeContext.supabaseAccessToken
      )
    ) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "NOT_YET_CONNECTED",
        error:
          "Authenticated Supabase module persistence context is unavailable.",
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    let adapter = this.registry.get(
      request.capability,
    );

    if (
      isHappyModuleRequest &&
      runtimeContext.organizationId &&
      runtimeContext.workspaceId &&
      runtimeContext.authenticatedUserId &&
      runtimeContext.supabaseAccessToken
    ) {
      const moduleAdapter =
        new HappyModuleExecutionAdapter(
          runtimeContext,
        );

      if (moduleAdapter.canExecute(request)) {
        adapter = moduleAdapter;
      }
    }

    if (!adapter) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "NOT_YET_CONNECTED",
        error:
          `No execution adapter registered for ${request.capability}.`,
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    if (
      request.requiresApproval &&
      !request.approved
    ) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "WAITING_APPROVAL",
        error: "Explicit approval is required.",
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    if (adapter.status() !== "AVAILABLE") {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "NOT_YET_CONNECTED",
        error:
          `${request.capability} adapter is ${adapter.status()}.`,
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    if (!adapter.canExecute(request)) {
      return {
        id: crypto.randomUUID(),
        requestId: request.id,
        capability: request.capability,
        status: "BLOCKED",
        error:
          "Execution adapter rejected the request.",
        evidenceIds: [],
        startedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
    }

    let executionRequest =
      request;

    /*
     * Generic DATABASE requests receive authenticated
     * user scope and access-token injection here.
     *
     * HAPPY module requests already receive their complete
     * authenticated runtime context directly through
     * HappyModuleExecutionAdapter, so this generic injection
     * remains only for the non-module DATABASE path.
     */
    if (
      request.capability === "DATABASE" &&
      !isHappyModuleRequest &&
      runtimeContext.supabaseAccessToken
    ) {
      const databaseInput =
        (
          request.input &&
          typeof request.input === "object"
        )
          ? {
              ...(
                request.input as Record<
                  string,
                  unknown
                >
              ),
            }
          : {};

      const scope =
        (
          databaseInput.scope &&
          typeof databaseInput.scope === "object"
        )
          ? {
              ...(
                databaseInput.scope as Record<
                  string,
                  unknown
                >
              ),
            }
          : {};

      executionRequest = {
        ...request,
        input: {
          ...databaseInput,
          scope: {
            ...scope,
            ...(runtimeContext.authenticatedUserId
              ? {
                  userId:
                    runtimeContext.authenticatedUserId,
                }
              : {}),
          },
          auth: {
            accessToken:
              runtimeContext.supabaseAccessToken,
          },
        },
      };
    }

    return adapter.execute(
      executionRequest,
    );
  }
}
