export type RuntimeLifecycleStatus =
  | "PENDING"
  | "READY"
  | "RUNNING"
  | "WAITING_APPROVAL"
  | "VERIFYING"
  | "COMPLETED"
  | "PARTIAL"
  | "FAILED"
  | "BLOCKED"
  | "NOT_YET_CONNECTED"
  | "CANCELLED";

const ALLOWED_TRANSITIONS: Readonly<
  Record<
    RuntimeLifecycleStatus,
    ReadonlySet<RuntimeLifecycleStatus>
  >
> = {
  PENDING: new Set([
    "READY",
    "WAITING_APPROVAL",
    "BLOCKED",
    "CANCELLED",
  ]),

  READY: new Set([
    "RUNNING",
    "WAITING_APPROVAL",
    "BLOCKED",
    "CANCELLED",
  ]),

  RUNNING: new Set([
    "VERIFYING",
    "COMPLETED",
    "PARTIAL",
    "FAILED",
    "BLOCKED",
    "NOT_YET_CONNECTED",
    "CANCELLED",
  ]),

  WAITING_APPROVAL: new Set([
    "READY",
    "RUNNING",
    "CANCELLED",
    "BLOCKED",
  ]),

  VERIFYING: new Set([
    "COMPLETED",
    "PARTIAL",
    "FAILED",
    "BLOCKED",
  ]),

  COMPLETED: new Set(),
  PARTIAL: new Set(),
  FAILED: new Set(),
  BLOCKED: new Set(),
  NOT_YET_CONNECTED: new Set(),
  CANCELLED: new Set(),
};

export interface RetryDecision {
  retry: boolean;
  nextRetryCount: number;
  reason: string;
}

export function canTransitionRuntimeStatus(
  from: RuntimeLifecycleStatus,
  to: RuntimeLifecycleStatus,
): boolean {
  if (from === to) {
    return true;
  }

  return ALLOWED_TRANSITIONS[from].has(to);
}

export function assertRuntimeTransition(
  from: RuntimeLifecycleStatus,
  to: RuntimeLifecycleStatus,
): void {
  if (!canTransitionRuntimeStatus(from, to)) {
    throw new Error(
      `INVALID_RUNTIME_TRANSITION:${from}->${to}`,
    );
  }
}

export function isTerminalRuntimeStatus(
  status: RuntimeLifecycleStatus,
): boolean {
  return (
    status === "COMPLETED" ||
    status === "PARTIAL" ||
    status === "FAILED" ||
    status === "BLOCKED" ||
    status === "NOT_YET_CONNECTED" ||
    status === "CANCELLED"
  );
}

export function shouldRetry(
  status: RuntimeLifecycleStatus,
  retryCount: number,
  maxRetries: number,
): RetryDecision {
  const normalizedRetryCount = Math.max(
    0,
    Math.trunc(retryCount),
  );

  const normalizedMaxRetries = Math.max(
    0,
    Math.trunc(maxRetries),
  );

  if (status !== "FAILED") {
    return {
      retry: false,
      nextRetryCount: normalizedRetryCount,
      reason:
        "Only FAILED execution states are retryable.",
    };
  }

  if (
    normalizedRetryCount >=
    normalizedMaxRetries
  ) {
    return {
      retry: false,
      nextRetryCount: normalizedRetryCount,
      reason:
        "Maximum retry count has been reached.",
    };
  }

  return {
    retry: true,
    nextRetryCount:
      normalizedRetryCount + 1,
    reason:
      "FAILED execution is retryable within the configured limit.",
  };
}
