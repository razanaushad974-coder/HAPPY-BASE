﻿export type HappyRuntimeStatus =
    | "IDLE"
    | "UNDERSTANDING"
    | "PLANNING"
    | "WAITING_APPROVAL"
    | "EXECUTING"
    | "VERIFYING"
    | "PERSISTING"
    | "REMEMBERING"
    | "IMPROVING"
    | "BLOCKED"
    | "FAILED"
    | "NOT_YET_CONNECTED"
    | "COMPLETED";

export type HappyLifecycleStage =
    | "COMMAND"
    | "UNDERSTAND"
    | "PLAN"
    | "APPROVAL"
    | "EXECUTE"
    | "VERIFY"
    | "EVIDENCE"
    | "PERSIST"
    | "REMEMBER"
    | "IMPROVE";

export interface HappyRuntimeState {
    status: HappyRuntimeStatus;
    currentStage: HappyLifecycleStage;
    requestId: string | null;
    missionId: string | null;
    taskId: string | null;
    organizationId: string | null;
    workspaceId: string | null;
    userId: string | null;
    updatedAt: string;
}
