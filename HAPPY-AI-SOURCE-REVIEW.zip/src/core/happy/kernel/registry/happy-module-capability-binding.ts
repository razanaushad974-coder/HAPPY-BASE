﻿export type HappyCapabilityId =
    | "AI"
    | "CODE"
    | "FILE"
    | "API"
    | "BROWSER"
    | "DATABASE"
    | "DEPLOYMENT"
    | "PUBLISH"
    | "AUTOMATION"
    | "SHELL";

export type HappyCapabilityBindingStatus =
    | "AVAILABLE"
    | "NOT_YET_CONNECTED"
    | "BLOCKED";

export interface HappyBindableModule {
    readonly id: string;
    readonly number?: number;
    readonly name: string;
    readonly category?: string;
}

export interface HappyModuleCapabilityBinding {
    readonly moduleId: string;
    readonly moduleNumber?: number;
    readonly moduleName: string;
    readonly moduleCategory?: string;
    readonly action?: string;
    readonly capability: HappyCapabilityId | null;
    readonly status: HappyCapabilityBindingStatus;
    readonly reason: string;
}

function normalize(
    value: string | undefined,
): string {
    return (value ?? "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
}

function externalStatus(
    capability: HappyCapabilityId,
): HappyCapabilityBindingStatus {
    if (
        capability === "DEPLOYMENT" ||
        capability === "PUBLISH" ||
        capability === "AUTOMATION"
    ) {
        return "NOT_YET_CONNECTED";
    }

    if (capability === "SHELL") {
        return "BLOCKED";
    }

    return "AVAILABLE";
}

function inferCapability(
    module: HappyBindableModule,
    action?: string,
): {
    readonly capability: HappyCapabilityId | null;
    readonly reason: string;
} {
    const name = normalize(module.name);
    const category = normalize(module.category);
    const combined = `${name} ${category}`;
    const normalizedAction = normalize(action);

    if (normalizedAction === "deploy") {
        return {
            capability: "DEPLOYMENT",
            reason:
                "DEPLOY action requires the deployment boundary.",
        };
    }

    if (normalizedAction === "publish") {
        return {
            capability: "PUBLISH",
            reason:
                "PUBLISH action requires the publishing boundary.",
        };
    }

    if (normalizedAction === "automation") {
        return {
            capability: "AUTOMATION",
            reason:
                "Automation action requires the automation boundary.",
        };
    }

    if (normalizedAction === "execute" && combined.includes("shell")) {
        return {
            capability: "SHELL",
            reason:
                "Shell execution is intentionally blocked by HAPPY safety policy.",
        };
    }

    if (
        combined.includes("website") ||
        combined.includes("web app") ||
        combined.includes("mobile app") ||
        combined.includes("cross platform") ||
        combined.includes("dashboard builder") ||
        combined.includes("full stack") ||
        combined.includes("application builder") ||
        combined.includes("app builder") ||
        combined.includes("creator studio") ||
        combined.includes("code") ||
        combined.includes("developer")
    ) {
        return {
            capability: "CODE",
            reason:
                "Builder/developer module routes through the canonical CODE capability.",
        };
    }

    if (
        combined.includes("browser") ||
        combined.includes("web browser") ||
        combined.includes("communication") ||
        combined.includes("messaging") ||
        combined.includes("email") ||
        combined.includes("social")
    ) {
        return {
            capability: "BROWSER",
            reason:
                "Browser/communication workflow routes through the canonical BROWSER capability.",
        };
    }

    if (
        combined.includes("file") ||
        combined.includes("document") ||
        combined.includes("knowledge")
    ) {
        return {
            capability: "FILE",
            reason:
                "File/document/knowledge workflow routes through the canonical FILE capability.",
        };
    }

    if (
        combined.includes("crm") ||
        combined.includes("erp") ||
        combined.includes("finance") ||
        combined.includes("hrms") ||
        combined.includes("manufacturing") ||
        combined.includes("inventory") ||
        combined.includes("warehouse") ||
        combined.includes("logistics") ||
        combined.includes("dealer") ||
        combined.includes("distributor") ||
        combined.includes("customer") ||
        combined.includes("procurement") ||
        combined.includes("supplier") ||
        combined.includes("vendor")
    ) {
        return {
            capability: "DATABASE",
            reason:
                "Enterprise data workflow routes through the canonical DATABASE capability.",
        };
    }

    if (
        combined.includes("founder") ||
        combined.includes("ai core") ||
        combined.includes("artificial intelligence") ||
        combined.includes("digital human") ||
        combined.includes("reasoning") ||
        combined.includes("memory") ||
        combined.includes("intelligence") ||
        combined.includes("analytics") ||
        combined.includes("bi")
    ) {
        return {
            capability: "AI",
            reason:
                "AI/intelligence/control workflow routes through the canonical AI capability.",
        };
    }

    if (
        combined.includes("api") ||
        combined.includes("integration") ||
        combined.includes("security") ||
        combined.includes("access") ||
        combined.includes("permission") ||
        combined.includes("authentication") ||
        combined.includes("authorization")
    ) {
        return {
            capability: "API",
            reason:
                "Integration/security/control workflow routes through the canonical API capability.",
        };
    }

    if (
        combined.includes("automation")
    ) {
        return {
            capability: "AUTOMATION",
            reason:
                "Automation module routes through the canonical automation capability.",
        };
    }

    if (
        combined.includes("cloud") ||
        combined.includes("hosting") ||
        combined.includes("deployment")
    ) {
        return {
            capability: "DEPLOYMENT",
            reason:
                "Cloud/hosting/deployment workflow routes through the deployment boundary.",
        };
    }

    if (
        combined.includes("marketplace") ||
        combined.includes("publishing") ||
        combined.includes("publish")
    ) {
        return {
            capability: "PUBLISH",
            reason:
                "Publishing/marketplace workflow routes through the publishing boundary.",
        };
    }

    return {
        capability: null,
        reason:
            "No canonical execution capability has been safely mapped yet.",
    };
}

export class HappyModuleCapabilityBindingRegistry {
    bind(
        module: HappyBindableModule,
        action?: string,
    ): HappyModuleCapabilityBinding {
        const inferred =
            inferCapability(
                module,
                action,
            );

        if (inferred.capability === null) {
            return {
                moduleId: module.id,
                moduleNumber: module.number,
                moduleName: module.name,
                moduleCategory: module.category,
                action,
                capability: null,
                status: "NOT_YET_CONNECTED",
                reason: inferred.reason,
            };
        }

        return {
            moduleId: module.id,
            moduleNumber: module.number,
            moduleName: module.name,
            moduleCategory: module.category,
            action,
            capability: inferred.capability,
            status: externalStatus(
                inferred.capability,
            ),
            reason: inferred.reason,
        };
    }

    bindMany(
        modules: readonly HappyBindableModule[],
        action?: string,
    ): readonly HappyModuleCapabilityBinding[] {
        return modules.map(
            (module) =>
                this.bind(
                    module,
                    action,
                ),
        );
    }
}

export const happyModuleCapabilityBindingRegistry =
    new HappyModuleCapabilityBindingRegistry();
