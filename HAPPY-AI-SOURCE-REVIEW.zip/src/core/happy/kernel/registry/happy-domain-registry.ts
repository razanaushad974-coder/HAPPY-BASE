﻿export type HappyDomainStatus =
    | "IMPLEMENTED"
    | "PARTIAL"
    | "NOT_YET_CONNECTED"
    | "PLANNED";

export interface HappyDomainDefinition {
    id: string;
    name: string;
    status: HappyDomainStatus;
    description: string;
}

export const HAPPY_DOMAINS: readonly HappyDomainDefinition[] = [
    {
        id: "ai",
        name: "AI Core",
        status: "IMPLEMENTED",
        description:
            "Core intelligence, reasoning, planning and model routing.",
    },
    {
        id: "memory",
        name: "Memory & Context",
        status: "IMPLEMENTED",
        description:
            "Persistent memory, contextual references and project awareness.",
    },
    {
        id: "agents",
        name: "Agents",
        status: "PARTIAL",
        description:
            "AI worker and multi-agent execution architecture.",
    },
    {
        id: "computer",
        name: "Computer Control",
        status: "PARTIAL",
        description:
            "Computer and application control through execution capabilities.",
    },
    {
        id: "browser",
        name: "Browser Control",
        status: "PARTIAL",
        description:
            "Browser navigation and controlled web execution.",
    },
    {
        id: "builder",
        name: "Builder",
        status: "PARTIAL",
        description:
            "Web, app, game and software creation.",
    },
    {
        id: "digital-human",
        name: "Digital Human",
        status: "NOT_YET_CONNECTED",
        description:
            "Avatar, voice, video and digital-human capabilities.",
    },
    {
        id: "education",
        name: "Education",
        status: "PLANNED",
        description:
            "Learning, teaching, tutoring and educational workflows.",
    },
    {
        id: "business",
        name: "Business OS",
        status: "PARTIAL",
        description:
            "Business management and organizational operations.",
    },
    {
        id: "crm",
        name: "CRM",
        status: "PLANNED",
        description:
            "Leads, customers, sales pipeline and support.",
    },
    {
        id: "erp",
        name: "ERP",
        status: "PLANNED",
        description:
            "Finance, procurement, inventory and enterprise operations.",
    },
    {
        id: "hrms",
        name: "HRMS",
        status: "PLANNED",
        description:
            "People, employees, attendance, payroll and HR operations.",
    },
    {
        id: "creator",
        name: "Creator Studio",
        status: "PLANNED",
        description:
            "Media creation, content workflows and creator operations.",
    },
    {
        id: "workflow",
        name: "Workflow Engine",
        status: "PARTIAL",
        description:
            "Structured workflow and task orchestration.",
    },
    {
        id: "automation",
        name: "Automation",
        status: "NOT_YET_CONNECTED",
        description:
            "External and scheduled automation execution.",
    },
    {
        id: "publishing",
        name: "Publishing",
        status: "NOT_YET_CONNECTED",
        description:
            "Production publishing and distribution.",
    },
    {
        id: "research",
        name: "Research",
        status: "PARTIAL",
        description:
            "Research, knowledge retrieval and synthesis.",
    },
    {
        id: "enterprise",
        name: "Enterprise Control",
        status: "PARTIAL",
        description:
            "Tenant, policy, audit, registry and enterprise administration.",
    },
    {
        id: "founder",
        name: "Founder OS",
        status: "PARTIAL",
        description:
            "Privileged founder control plane and company operations.",
    },
    {
        id: "workspace",
        name: "User Workspace OS",
        status: "PARTIAL",
        description:
            "User command center, missions, tasks, evidence and settings.",
    },
    {
        id: "security",
        name: "Security",
        status: "PARTIAL",
        description:
            "Authentication, authorization, isolation, audit and safety.",
    },
    {
        id: "integrations",
        name: "Integrations",
        status: "PARTIAL",
        description:
            "External APIs, providers, services and connectors.",
    },
] as const;
