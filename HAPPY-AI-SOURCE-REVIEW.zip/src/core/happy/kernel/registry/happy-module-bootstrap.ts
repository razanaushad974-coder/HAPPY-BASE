﻿import {
    HAPPY_MAJOR_MODULE_CATALOG,
} from "./happy-major-module-catalog";

import {
    happyModuleRegistry,
} from "./happy-module-runtime";

export interface HappyModuleBootstrapResult {
    readonly success: boolean;
    readonly registered: number;
    readonly alreadyRegistered: number;
    readonly total: number;
}

export function bootstrapHappyMajorModules():
    HappyModuleBootstrapResult {

    let registered = 0;
    let alreadyRegistered = 0;

    for (
        const definition
            of HAPPY_MAJOR_MODULE_CATALOG
    ) {
        if (
            happyModuleRegistry.has(
                definition.id,
            )
        ) {
            alreadyRegistered += 1;
            continue;
        }

        happyModuleRegistry.register(
            definition,
        );

        registered += 1;
    }

    const total =
        happyModuleRegistry.list().length;

    if (
        total !==
        HAPPY_MAJOR_MODULE_CATALOG.length
    ) {
        throw new Error(
            `HAPPY module bootstrap mismatch: registry=${total}, catalog=${HAPPY_MAJOR_MODULE_CATALOG.length}`,
        );
    }

    return {
        success: true,
        registered,
        alreadyRegistered,
        total,
    };
}

export function assertHappyMajorModuleBootstrap():
    void {

    const result =
        bootstrapHappyMajorModules();

    if (!result.success) {
        throw new Error(
            "HAPPY module bootstrap failed.",
        );
    }

    if (
        result.total !== 502
    ) {
        throw new Error(
            `Expected 502 HAPPY modules in runtime registry, got ${result.total}.`,
        );
    }
}
