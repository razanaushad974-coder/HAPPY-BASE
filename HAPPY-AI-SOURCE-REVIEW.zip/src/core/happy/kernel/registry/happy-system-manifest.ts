﻿export type HappyVolumeStatus =
    | "ACTIVE"
    | "PARTIAL"
    | "NOT_YET_CONNECTED"
    | "PLANNED";

export interface HappySystemVolume {
    readonly number: number;
    readonly id: string;
    readonly name: string;
    readonly status: HappyVolumeStatus;
    readonly purpose: string;
    readonly domains: readonly string[];
}

export const HAPPY_SYSTEM_MANIFEST:
    readonly HappySystemVolume[] = [

    {
        number: 1,
        id: "company-vision-constitution",
        name: "Company Vision & Constitution",
        status: "ACTIVE",
        purpose:
            "Defines HAPPY identity, constitution, principles, ownership of system behavior and long-term direction.",
        domains: [
            "identity",
            "constitution",
            "governance",
        ],
    },

    {
        number: 2,
        id: "happy-kernel",
        name: "HAPPY Kernel",
        status: "ACTIVE",
        purpose:
            "Core system runtime, lifecycle, policies, registries and execution boundaries.",
        domains: [
            "kernel",
            "runtime",
            "policy",
            "registry",
        ],
    },

    {
        number: 3,
        id: "ai-brain",
        name: "AI Brain",
        status: "ACTIVE",
        purpose:
            "Reasoning, model routing, planning, intent understanding and intelligence orchestration.",
        domains: [
            "ai",
            "reasoning",
            "planning",
            "context",
        ],
    },

    {
        number: 4,
        id: "digital-human",
        name: "Digital Human",
        status: "NOT_YET_CONNECTED",
        purpose:
            "Digital human identity, avatar, voice, speech, video and multimodal interaction.",
        domains: [
            "avatar",
            "voice",
            "speech",
            "video",
            "multimodal",
        ],
    },

    {
        number: 5,
        id: "education-engine",
        name: "Education Engine",
        status: "PLANNED",
        purpose:
            "Teaching, learning, tutoring, assessment, educational planning and knowledge delivery.",
        domains: [
            "education",
            "learning",
            "assessment",
        ],
    },

    {
        number: 6,
        id: "religion-culture-engine",
        name: "Religion & Culture Engine",
        status: "PLANNED",
        purpose:
            "Cultural, linguistic, religious and regional knowledge experiences.",
        domains: [
            "culture",
            "languages",
            "regional",
            "religion",
        ],
    },

    {
        number: 7,
        id: "business-os",
        name: "Business OS",
        status: "PARTIAL",
        purpose:
            "Business operations, organizations, products, services, planning and management.",
        domains: [
            "business",
            "organization",
            "operations",
        ],
    },

    {
        number: 8,
        id: "creator-studio",
        name: "Creator Studio",
        status: "PLANNED",
        purpose:
            "Content creation, media production, creator workflows and publishing preparation.",
        domains: [
            "creator",
            "media",
            "content",
        ],
    },

    {
        number: 9,
        id: "community-marketplace",
        name: "Community & Marketplace",
        status: "PLANNED",
        purpose:
            "Community, discovery, marketplace, creators, services and ecosystem participation.",
        domains: [
            "community",
            "marketplace",
            "ecosystem",
        ],
    },

    {
        number: 10,
        id: "enterprise-control-center",
        name: "Enterprise Control Center",
        status: "PARTIAL",
        purpose:
            "Enterprise administration, tenant control, policies, organizations, audit and governance.",
        domains: [
            "enterprise",
            "tenancy",
            "governance",
            "audit",
        ],
    },

    {
        number: 11,
        id: "founder-dashboard",
        name: "Founder Dashboard",
        status: "PARTIAL",
        purpose:
            "Privileged Founder OS for commanding, monitoring and governing HAPPY and connected business systems.",
        domains: [
            "founder",
            "founder-os",
            "control-plane",
            "analytics",
        ],
    },

    {
        number: 12,
        id: "ui-ux-design-system",
        name: "UI/UX Design System",
        status: "PARTIAL",
        purpose:
            "Shared design language, workspace navigation, command surfaces and responsive HAPPY interfaces.",
        domains: [
            "ui",
            "ux",
            "design-system",
            "workspace",
        ],
    },

    {
        number: 13,
        id: "database-architecture",
        name: "Database Architecture",
        status: "PARTIAL",
        purpose:
            "Persistent system data, tenant isolation, memory, missions, tasks, evidence and enterprise records.",
        domains: [
            "database",
            "persistence",
            "memory",
            "tenant-isolation",
        ],
    },

    {
        number: 14,
        id: "api-architecture",
        name: "API Architecture",
        status: "PARTIAL",
        purpose:
            "Internal and external APIs, contracts, routing, authentication and integration boundaries.",
        domains: [
            "api",
            "contracts",
            "integrations",
            "routing",
        ],
    },

    {
        number: 15,
        id: "security-architecture",
        name: "Security Architecture",
        status: "PARTIAL",
        purpose:
            "Authentication, authorization, isolation, approval gates, execution safety and security auditing.",
        domains: [
            "security",
            "authentication",
            "authorization",
            "approvals",
            "safety",
        ],
    },

    {
        number: 16,
        id: "ai-training-knowledge-management",
        name: "AI Training & Knowledge Management",
        status: "PARTIAL",
        purpose:
            "Knowledge ingestion, retrieval, memory, embeddings, learning signals and model-support infrastructure.",
        domains: [
            "knowledge",
            "training",
            "retrieval",
            "embeddings",
            "learning",
        ],
    },

    {
        number: 17,
        id: "devops-cloud-infrastructure",
        name: "DevOps & Cloud Infrastructure",
        status: "PARTIAL",
        purpose:
            "Runtime infrastructure, workers, deployment, environments, observability and cloud operations.",
        domains: [
            "devops",
            "cloud",
            "workers",
            "deployment",
            "observability",
        ],
    },

    {
        number: 18,
        id: "testing-quality-assurance",
        name: "Testing & Quality Assurance",
        status: "PARTIAL",
        purpose:
            "Unit, integration, runtime, security, verification and regression quality controls.",
        domains: [
            "testing",
            "qa",
            "verification",
            "regression",
        ],
    },

    {
        number: 19,
        id: "deployment-maintenance",
        name: "Deployment & Maintenance",
        status: "PARTIAL",
        purpose:
            "Production deployment, release management, monitoring, recovery and maintenance.",
        domains: [
            "deployment",
            "release",
            "maintenance",
            "recovery",
        ],
    },

    {
        number: 20,
        id: "future-roadmap",
        name: "Future Roadmap 2026–2040",
        status: "PLANNED",
        purpose:
            "Long-term expansion of HAPPY capabilities, intelligence, ecosystem and enterprise reach.",
        domains: [
            "roadmap",
            "research",
            "expansion",
            "innovation",
        ],
    },
] as const;

export function getHappyVolume(
    id: string,
): HappySystemVolume | undefined {
    return HAPPY_SYSTEM_MANIFEST.find(
        (volume) => volume.id === id,
    );
}

export function getHappyVolumesByStatus(
    status: HappyVolumeStatus,
): readonly HappySystemVolume[] {
    return HAPPY_SYSTEM_MANIFEST.filter(
        (volume) => volume.status === status,
    );
}

export function getHappyVolumeCount(): number {
    return HAPPY_SYSTEM_MANIFEST.length;
}
