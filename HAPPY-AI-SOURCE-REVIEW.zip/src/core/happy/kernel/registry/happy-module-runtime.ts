﻿export type HappyModuleStatus =
    | "ACTIVE"
    | "PARTIAL"
    | "DISABLED"
    | "BLOCKED"
    | "NOT_YET_CONNECTED"
    | "PLANNED";

export type HappyModuleLifecycle =
    | "REGISTERED"
    | "INITIALIZING"
    | "READY"
    | "RUNNING"
    | "PAUSED"
    | "STOPPING"
    | "STOPPED"
    | "FAILED";

export type HappyModuleScope =
    | "SYSTEM"
    | "GLOBAL"
    | "TENANT"
    | "ORGANIZATION"
    | "WORKSPACE"
    | "USER"
    | "FOUNDER";

export interface HappyModuleDefinition {
    readonly id: string;
    readonly name: string;
    readonly number?: number;
    readonly volumeId?: string;
    readonly category: string;
    readonly status: HappyModuleStatus;
    readonly scope: HappyModuleScope;
    readonly version: string;
    readonly description: string;
    readonly dependencies: readonly string[];
    readonly capabilities: readonly string[];
    readonly permissions: readonly string[];
    readonly route?: string;
}

export interface HappyModuleRuntimeState {
    readonly moduleId: string;
    readonly lifecycle: HappyModuleLifecycle;
    readonly status: HappyModuleStatus;
    readonly initializedAt: string | null;
    readonly startedAt: string | null;
    readonly stoppedAt: string | null;
    readonly lastError: string | null;
    readonly invocationCount: number;
    readonly updatedAt: string;
}

export interface HappyModuleRegistry {
    register(
        definition: HappyModuleDefinition,
    ): void;

    has(
        moduleId: string,
    ): boolean;

    get(
        moduleId: string,
    ): HappyModuleDefinition | undefined;

    list(): readonly HappyModuleDefinition[];

    listByCategory(
        category: string,
    ): readonly HappyModuleDefinition[];

    listByStatus(
        status: HappyModuleStatus,
    ): readonly HappyModuleDefinition[];

    createRuntimeState(
        moduleId: string,
    ): HappyModuleRuntimeState;

    transition(
        state: HappyModuleRuntimeState,
        lifecycle: HappyModuleLifecycle,
        status?: HappyModuleStatus,
        error?: string,
    ): HappyModuleRuntimeState;

    incrementInvocation(
        state: HappyModuleRuntimeState,
    ): HappyModuleRuntimeState;
}

class InMemoryHappyModuleRegistry
    implements HappyModuleRegistry {

    private readonly modules =
        new Map<string, HappyModuleDefinition>();

    register(
        definition: HappyModuleDefinition,
    ): void {
        if (
            !definition.id ||
            !definition.id.trim()
        ) {
            throw new Error(
                "HAPPY module id is required.",
            );
        }

        if (
            !definition.name ||
            !definition.name.trim()
        ) {
            throw new Error(
                `HAPPY module ${definition.id} must have a name.`,
            );
        }

        if (
            this.modules.has(definition.id)
        ) {
            throw new Error(
                `HAPPY module already registered: ${definition.id}`,
            );
        }

        this.modules.set(
            definition.id,
            Object.freeze({
                ...definition,
                dependencies: [
                    ...definition.dependencies,
                ],
                capabilities: [
                    ...definition.capabilities,
                ],
                permissions: [
                    ...definition.permissions,
                ],
            }),
        );
    }

    has(
        moduleId: string,
    ): boolean {
        return this.modules.has(moduleId);
    }

    get(
        moduleId: string,
    ): HappyModuleDefinition | undefined {
        return this.modules.get(moduleId);
    }

    list(): readonly HappyModuleDefinition[] {
        return Array.from(
            this.modules.values(),
        );
    }

    listByCategory(
        category: string,
    ): readonly HappyModuleDefinition[] {
        return this.list().filter(
            (module) =>
                module.category === category,
        );
    }

    listByStatus(
        status: HappyModuleStatus,
    ): readonly HappyModuleDefinition[] {
        return this.list().filter(
            (module) =>
                module.status === status,
        );
    }

    createRuntimeState(
        moduleId: string,
    ): HappyModuleRuntimeState {
        if (!this.has(moduleId)) {
            throw new Error(
                `Unknown HAPPY module: ${moduleId}`,
            );
        }

        return {
            moduleId,
            lifecycle: "REGISTERED",
            status:
                this.get(moduleId)?.status ??
                "PLANNED",
            initializedAt: null,
            startedAt: null,
            stoppedAt: null,
            lastError: null,
            invocationCount: 0,
            updatedAt:
                new Date().toISOString(),
        };
    }

    transition(
        state: HappyModuleRuntimeState,
        lifecycle: HappyModuleLifecycle,
        status?: HappyModuleStatus,
        error?: string,
    ): HappyModuleRuntimeState {
        const now =
            new Date().toISOString();

        return {
            ...state,
            lifecycle,
            status:
                status ??
                state.status,
            initializedAt:
                lifecycle === "READY" &&
                state.initializedAt === null
                    ? now
                    : state.initializedAt,
            startedAt:
                lifecycle === "RUNNING" &&
                state.startedAt === null
                    ? now
                    : state.startedAt,
            stoppedAt:
                lifecycle === "STOPPED"
                    ? now
                    : state.stoppedAt,
            lastError:
                error ?? null,
            updatedAt: now,
        };
    }

    incrementInvocation(
        state: HappyModuleRuntimeState,
    ): HappyModuleRuntimeState {
        return {
            ...state,
            invocationCount:
                state.invocationCount + 1,
            updatedAt:
                new Date().toISOString(),
        };
    }
}

export const happyModuleRegistry:
    HappyModuleRegistry =
        new InMemoryHappyModuleRegistry();

