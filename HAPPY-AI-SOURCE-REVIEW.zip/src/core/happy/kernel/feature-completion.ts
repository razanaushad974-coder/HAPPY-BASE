export type HappyFeatureState =
    | "IMPLEMENTED"
    | "NOT_YET_CONNECTED"
    | "BLOCKED";
export interface HappyFeatureDefinition {
    id: string;
    name: string;
    module: string;
    state: HappyFeatureState;
    capability?: string;
    actions?: string[];
    dependencies?: string[];
    verificationRequired?: boolean;
}
const features = new Map<string, HappyFeatureDefinition>();
export function registerHappyFeature(
    feature: HappyFeatureDefinition,
): void {
    if (features.has(feature.id)) {
        throw new Error(`DUPLICATE_HAPPY_FEATURE_ID: ${feature.id}`);
    }
    features.set(feature.id, feature);
}
export function getHappyFeature(
    id: string,
): HappyFeatureDefinition | undefined {
    return features.get(id);
}
export function listHappyFeatures(): HappyFeatureDefinition[] {
    return [...features.values()];
}
export function getHappyFeatureState(
    id: string,
): HappyFeatureState {
    return features.get(id)?.state ?? "NOT_YET_CONNECTED";
}
export function hasHappyFeature(
    id: string,
): boolean {
    return features.has(id);
}
export function registerHappyFeatures(
    definitions: HappyFeatureDefinition[],
): void {
    const seen = new Set<string>();
    for (const feature of definitions) {
        if (seen.has(feature.id) || features.has(feature.id)) {
            throw new Error(
                `DUPLICATE_HAPPY_FEATURE_ID: ${feature.id}`,
            );
        }
        seen.add(feature.id);
    }
    for (const feature of definitions) {
        features.set(feature.id, feature);
    }
}
export function countHappyFeatures(): number {
    return features.size;
}
export function countHappyFeaturesByState(): Record<HappyFeatureState, number> {
    const counts: Record<HappyFeatureState, number> = {
        IMPLEMENTED: 0,
        NOT_YET_CONNECTED: 0,
        BLOCKED: 0,
    };
    for (const feature of features.values()) {
        counts[feature.state] += 1;
    }
    return counts;
}
export function getHappyFeaturesByModule(
    module: string,
): HappyFeatureDefinition[] {
    return [...features.values()].filter(
        (feature) => feature.module === module,
    );
}
export function getHappyFeaturesByCapability(
    capability: string,
): HappyFeatureDefinition[] {
    return [...features.values()].filter(
        (feature) => feature.capability === capability,
    );
}
export function updateHappyFeatureState(
    id: string,
    state: HappyFeatureState,
): HappyFeatureDefinition {
    const feature = features.get(id);
    if (!feature) {
        throw new Error(`HAPPY_FEATURE_NOT_FOUND: ${id}`);
    }
    const updated: HappyFeatureDefinition = {
        ...feature,
        state,
    };
    features.set(id, updated);
    return updated;
}
export function getHappyFeatureContract(id: string): HappyFeatureDefinition | undefined {
    const feature = features.get(id);
    return feature ? { ...feature, verificationRequired: feature.verificationRequired ?? false, actions: feature.actions ?? [], dependencies: feature.dependencies ?? [] } : undefined;
}

export function exportHappyFeatureRegistry(): string {
    return JSON.stringify(
        [...features.values()],
        null,
        2,
    );
}
export function clearHappyFeatureRegistry(): void {
    features.clear();
}











export function isHappyFeatureReady(id: string): boolean {
    const feature = features.get(id);
    if (!feature || feature.state !== "IMPLEMENTED") return false;
    return (feature.dependencies ?? []).every((dependency) => {
        const item = features.get(dependency);
        return Boolean(item && item.state === "IMPLEMENTED");
    });
}
export function isHappyFeatureVerificationRequired(id: string): boolean {
    return features.get(id)?.verificationRequired === true;
}
export function resolveHappyFeatureDependencyGraph(id: string): HappyFeatureDefinition[] {
    const result: HappyFeatureDefinition[] = [];
    const visited = new Set<string>();
    const visit = (featureId: string): void => {
        if (visited.has(featureId)) return;
        visited.add(featureId);
        const feature = features.get(featureId);
        if (!feature) return;
        for (const dependency of feature.dependencies ?? []) visit(dependency);
        result.push({ ...feature });
    };
    visit(id);
    return result;
}