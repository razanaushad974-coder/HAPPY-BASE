﻿import {
    HAPPY_IDENTITY,
} from "../contracts/happy-identity";

import type {
    HappyLifecycleStage,
    HappyRuntimeState,
    HappyRuntimeStatus,
} from "../contracts/happy-runtime";

import {
    HAPPY_DOMAINS,
} from "../registry/happy-domain-registry";

export interface HappyControlPlane {
    readonly identity:
        typeof HAPPY_IDENTITY;

    readonly domains:
        typeof HAPPY_DOMAINS;

    createRuntimeState(
        input: {
            requestId?: string;
            organizationId?: string;
            workspaceId?: string;
            userId?: string;
            missionId?: string;
            taskId?: string;
        },
    ): HappyRuntimeState;

    transition(
        state: HappyRuntimeState,
        stage: HappyLifecycleStage,
        status: HappyRuntimeStatus,
    ): HappyRuntimeState;
}

function statusForStage(
    stage: HappyLifecycleStage,
): HappyRuntimeStatus {
    switch (stage) {
        case "COMMAND":
            return "IDLE";

        case "UNDERSTAND":
            return "UNDERSTANDING";

        case "PLAN":
            return "PLANNING";

        case "APPROVAL":
            return "WAITING_APPROVAL";

        case "EXECUTE":
            return "EXECUTING";

        case "VERIFY":
        case "EVIDENCE":
            return "VERIFYING";

        case "PERSIST":
            return "PERSISTING";

        case "REMEMBER":
            return "REMEMBERING";

        case "IMPROVE":
            return "IMPROVING";
    }
}

export const happyControlPlane:
    HappyControlPlane = {

    identity: HAPPY_IDENTITY,

    domains: HAPPY_DOMAINS,

    createRuntimeState(input) {
        return {
            status: "IDLE",
            currentStage: "COMMAND",
            requestId:
                input.requestId ?? null,
            missionId:
                input.missionId ?? null,
            taskId:
                input.taskId ?? null,
            organizationId:
                input.organizationId ?? null,
            workspaceId:
                input.workspaceId ?? null,
            userId:
                input.userId ?? null,
            updatedAt:
                new Date().toISOString(),
        };
    },

    transition(
        state,
        stage,
        status,
    ) {
        return {
            ...state,
            currentStage: stage,
            status:
                status ??
                statusForStage(stage),
            updatedAt:
                new Date().toISOString(),
        };
    },
};
