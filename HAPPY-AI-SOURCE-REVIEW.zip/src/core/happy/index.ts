﻿export {
    HAPPY_IDENTITY,
} from "./kernel/contracts/happy-identity";

export type {
    HappyIdentity,
} from "./kernel/contracts/happy-identity";

export type {
    HappyRuntimeState,
    HappyRuntimeStatus,
    HappyLifecycleStage,
} from "./kernel/contracts/happy-runtime";

export {
    HAPPY_DOMAINS,
} from "./kernel/registry/happy-domain-registry";

export {
    HAPPY_SYSTEM_MANIFEST,
    getHappyVolume,
    getHappyVolumesByStatus,
    getHappyVolumeCount,
} from "./kernel/registry/happy-system-manifest";

export {
    happyControlPlane,
} from "./kernel/runtime/happy-control-plane";

export type {
    HappyModuleStatus,
    HappyModuleLifecycle,
    HappyModuleScope,
    HappyModuleDefinition,
    HappyModuleRuntimeState,
    HappyModuleRegistry,
} from "./kernel/registry/happy-module-runtime";

export {
    happyModuleRegistry,
} from "./kernel/registry/happy-module-runtime";

export {
    HAPPY_MAJOR_MODULE_CATALOG,
    HAPPY_MAJOR_MODULE_COUNT,
    getHappyMajorModule,
    getHappyMajorModulesByCategory,
} from "./kernel/registry/happy-major-module-catalog";

export {
    bootstrapHappyMajorModules,
    assertHappyMajorModuleBootstrap,
} from "./kernel/registry/happy-module-bootstrap";

export type {
    HappyModuleBootstrapResult,
} from "./kernel/registry/happy-module-bootstrap";

export type {
    HappyModuleResolutionStatus,
    HappyModuleAction,
    HappyModuleResolution,
    HappyModuleRouter,
} from "./kernel/runtime/happy-module-router";

export {
    happyModuleRouter,
} from "./kernel/runtime/happy-module-router";
export * from "./kernel/registry/happy-module-capability-binding";
export * from "./kernel/runtime/happy-execution-route";

