import type { FounderAccessRequest, FounderRole } from "./access-policy";

export interface TrustedFounderIdentity {
    userId: string;
    role: FounderRole;
    roleSource: "TRUSTED_SERVER";
    configuredFounderUserId: string;
}

export type FounderIdentityResolution =
    | {
        status: "ALLOW";
        identity: TrustedFounderIdentity;
        access: FounderAccessRequest;
    }
    | {
        status: "NOT_YET_CONNECTED";
        reason: string;
    };

const FOUNDER_USER_ID_ENV = "HAPPY_FOUNDER_USER_ID";

export function resolveTrustedFounderIdentity(
    authenticatedUserId?: string,
): FounderIdentityResolution {
    const configuredFounderUserId =
        process.env[FOUNDER_USER_ID_ENV]?.trim();

    if (!configuredFounderUserId) {
        return {
            status: "NOT_YET_CONNECTED",
            reason:
                "Founder identity registry is not configured. Set HAPPY_FOUNDER_USER_ID on the server.",
        };
    }

    if (!authenticatedUserId?.trim()) {
        return {
            status: "NOT_YET_CONNECTED",
            reason:
                "Authenticated user identity is required before Founder access can be evaluated.",
        };
    }

    if (authenticatedUserId !== configuredFounderUserId) {
        return {
            status: "NOT_YET_CONNECTED",
            reason:
                "Authenticated user is not the configured HAPPY Founder identity.",
        };
    }

    const identity: TrustedFounderIdentity = {
        userId: authenticatedUserId,
        role: "FOUNDER",
        roleSource: "TRUSTED_SERVER",
        configuredFounderUserId,
    };

    const access: FounderAccessRequest = {
        userId: authenticatedUserId,
        role: "FOUNDER",
        roleSource: "TRUSTED_SERVER",
        authenticated: true,
        configuredFounderUserId,
        action: "CONTROL_HAPPY",
    };

    return {
        status: "ALLOW",
        identity,
        access,
    };
}
