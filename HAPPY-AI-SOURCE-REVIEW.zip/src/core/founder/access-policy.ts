export type FounderRole =
  | "USER"
  | "ADMIN"
  | "SECURITY"
  | "FOUNDER";

export type FounderAction =
  | "VIEW_FOUNDER_DASHBOARD"
  | "CONTROL_HAPPY"
  | "MANAGE_CAPABILITIES"
  | "MANAGE_AGENTS"
  | "MANAGE_MEMORY"
  | "MANAGE_KNOWLEDGE"
  | "MANAGE_PROJECTS"
  | "MANAGE_AUTOMATION"
  | "MANAGE_BUSINESS"
  | "MANAGE_RESEARCH"
  | "MANAGE_DIGITAL_HUMAN"
  | "MANAGE_VOICE"
  | "MANAGE_USERS"
  | "MANAGE_ORGANIZATIONS"
  | "DEPLOY"
  | "PUBLISH"
  | "SECURITY_CHANGE"
  | "VIEW_AUDIT"
  | "VIEW_TELEMETRY"
  | "MANAGE_BILLING";

export type FounderAccessStatus =
  | "ALLOW"
  | "BLOCKED"
  | "NOT_YET_CONNECTED";

export interface FounderAccessRequest {
  userId?: string;
  role: FounderRole;
  roleSource:
    | "TRUSTED_SERVER"
    | "CLIENT";
  authenticated: boolean;
  configuredFounderUserId?: string;
  action: FounderAction;
}

export interface FounderAccessDecision {
  status: FounderAccessStatus;
  reason: string;
  action: FounderAction;
  userId?: string;
}

const FOUNDER_ACTIONS: ReadonlySet<FounderAction> =
  new Set<FounderAction>([
    "VIEW_FOUNDER_DASHBOARD",
    "CONTROL_HAPPY",
    "MANAGE_CAPABILITIES",
    "MANAGE_AGENTS",
    "MANAGE_MEMORY",
    "MANAGE_KNOWLEDGE",
    "MANAGE_PROJECTS",
    "MANAGE_AUTOMATION",
    "MANAGE_BUSINESS",
    "MANAGE_RESEARCH",
    "MANAGE_DIGITAL_HUMAN",
    "MANAGE_VOICE",
    "MANAGE_USERS",
    "MANAGE_ORGANIZATIONS",
    "DEPLOY",
    "PUBLISH",
    "SECURITY_CHANGE",
    "VIEW_AUDIT",
    "VIEW_TELEMETRY",
    "MANAGE_BILLING",
  ]);

export function isFounderAction(
  action: FounderAction,
): boolean {
  return FOUNDER_ACTIONS.has(action);
}

export function evaluateFounderAccess(
  request: FounderAccessRequest,
): FounderAccessDecision {
  if (!request.authenticated) {
    return {
      status: "BLOCKED",
      reason:
        "Founder access requires authentication.",
      action: request.action,
      userId: request.userId,
    };
  }

  if (
    request.roleSource !==
    "TRUSTED_SERVER"
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Founder privileges must come from a trusted server-side identity.",
      action: request.action,
      userId: request.userId,
    };
  }

  if (!request.userId?.trim()) {
    return {
      status: "BLOCKED",
      reason:
        "Authenticated user identity is required.",
      action: request.action,
    };
  }

  if (request.role !== "FOUNDER") {
    return {
      status: "BLOCKED",
      reason:
        "Founder action requires the FOUNDER role.",
      action: request.action,
      userId: request.userId,
    };
  }

  if (
    !request.configuredFounderUserId?.trim()
  ) {
    return {
      status: "NOT_YET_CONNECTED",
      reason:
        "Founder identity registry is not configured.",
      action: request.action,
      userId: request.userId,
    };
  }

  if (
    request.userId !==
    request.configuredFounderUserId
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Authenticated user is not registered as the Founder.",
      action: request.action,
      userId: request.userId,
    };
  }

  if (!isFounderAction(request.action)) {
    return {
      status: "BLOCKED",
      reason:
        "Requested action is outside the Founder action registry.",
      action: request.action,
      userId: request.userId,
    };
  }

  return {
    status: "ALLOW",
    reason:
      "Authenticated Founder identity is authorized for the requested Founder action.",
    action: request.action,
    userId: request.userId,
  };
}

export function canUseFounderAction(
  request: FounderAccessRequest,
): boolean {
  return (
    evaluateFounderAccess(
      request,
    ).status === "ALLOW"
  );
}

export function isFounderRole(
  role: FounderRole,
): boolean {
  return role === "FOUNDER";
}
