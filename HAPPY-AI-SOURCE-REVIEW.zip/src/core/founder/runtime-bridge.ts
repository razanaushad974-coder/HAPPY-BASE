import {
    evaluateFounderAccess,
    type FounderAccessRequest,
    type FounderAction,
} from "./access-policy";
import { FounderCommandEngine } from "./command-engine";
import type {
    FounderCommand,
    FounderCommandResult,
} from "./types";
import { HappyOrchestrationEngine } from "../orchestration/engine";
import type {
    HappyPipelineRequest,
    HappyPipelineResult,
} from "../orchestration/types";
import type { ExecutionRuntimeContext } from "../execution/runtime-context";

export interface FounderRuntimeBridgeRequest {
    rawCommand: string;
    access: FounderAccessRequest;
    action: FounderAction;
    organizationId: string;
    workspaceId: string;
    userId: string;
    runtimeContext?: ExecutionRuntimeContext;
    activeProjectId?: string;
    activeMissionId?: string;
    activeTaskId?: string;
}

export interface FounderRuntimeBridgeResult {
    command: FounderCommand;
    result: FounderCommandResult;
    pipeline?: HappyPipelineResult;
}

function mapPipelineStatus(
    status: string,
): FounderCommandResult["status"] {
    switch (status) {
        case "WAITING_APPROVAL":
            return "WAITING_APPROVAL";

        case "COMPLETED":
            return "COMPLETED";

        case "BLOCKED":
            return "BLOCKED";

        case "NOT_YET_CONNECTED":
            return "NOT_YET_CONNECTED";

        case "FAILED":
            return "FAILED";

        case "RUNNING":
        case "EXECUTING":
        case "VERIFYING":
            return "EXECUTING";

        default:
            return "FAILED";
    }
}

function mapPipelineResult(
    command: FounderCommand,
    pipeline: HappyPipelineResult,
): FounderCommandResult {
    const status = mapPipelineStatus(pipeline.status);

    const success =
        status === "COMPLETED";

    return {
        commandId: command.id,
        success,
        status,
        message:
            success
                ? "Founder command completed by HAPPY."
                : `Founder command ${status.toLowerCase().replaceAll("_", " ")}.`,
        nextAction:
            status === "WAITING_APPROVAL"
                ? "APPROVAL_REQUIRED"
                : status === "COMPLETED"
                    ? "DONE"
                    : status === "NOT_YET_CONNECTED"
                        ? "CONNECT_REQUIRED"
                        : status === "BLOCKED"
                            ? "REVIEW_REQUIRED"
                            : "REVIEW_REQUIRED",
    };
}

export class FounderRuntimeBridge {
    private readonly commandEngine: FounderCommandEngine;
    private readonly orchestration: HappyOrchestrationEngine;

    constructor(
        orchestration?: HappyOrchestrationEngine,
    ) {
        this.commandEngine =
            new FounderCommandEngine();

        this.orchestration =
            orchestration ??
            new HappyOrchestrationEngine();
    }

    async execute(
        request: FounderRuntimeBridgeRequest,
    ): Promise<FounderRuntimeBridgeResult> {
        const command =
            this.commandEngine.create(
                request.rawCommand,
            );

        const access =
            evaluateFounderAccess({
                ...request.access,
                userId:
                    request.userId,
                authenticated:
                    request.access.authenticated,
                action:
                    request.action,
                role:
                    request.access.role,
                roleSource:
                    request.access.roleSource,
                configuredFounderUserId:
                    request.access.configuredFounderUserId,
            });

        if (access.status !== "ALLOW") {
            const result: FounderCommandResult = {
                commandId: command.id,
                success: false,
                status:
                    access.status === "BLOCKED"
                        ? "BLOCKED"
                        : "NOT_YET_CONNECTED",
                message:
                    access.reason,
                nextAction:
                    access.status === "BLOCKED"
                        ? "REVIEW_REQUIRED"
                        : "CONNECT_REQUIRED",
            };

            return {
                command,
                result,
            };
        }

        const pipelineRequest: HappyPipelineRequest = {
            id: command.id,
            command: command.rawText,
            organizationId:
                request.organizationId,
            workspaceId:
                request.workspaceId,
            activeProjectId:
                request.activeProjectId,
            activeMissionId:
                request.activeMissionId,
            activeTaskId:
                request.activeTaskId,
            userId:
                request.userId,
            source: "FOUNDER",
            createdAt:
                command.createdAt,
            authorization: {
                role:
                    request.access.role,
                scope:
                    "FOUNDER",
                roleSource:
                    request.access.roleSource,
                authenticated:
                    request.access.authenticated,
            },
        };

        /*
         * IMPORTANT:
         * Do not force approved=true here.
         *
         * Founder commands enter the same canonical
         * approval policy used by the normal HAPPY runtime.
         */
        const pipeline =
            await this.orchestration.run(
                pipelineRequest,
                request.runtimeContext,
            );

        return {
            command,
            result:
                mapPipelineResult(
                    command,
                    pipeline,
                ),
            pipeline,
        };
    }
}
