import type {
  VerificationRequest,
  VerificationResult,
} from "./types";
import type { EvidenceService } from "../evidence/service";

export class VerificationEngine {
  constructor(private readonly evidence: EvidenceService) {}

  verify(
    request: VerificationRequest,
    observedEvidenceIds: string[],
  ): VerificationResult {
    if (request.criteria.length === 0) {
      return {
        id: `verification-result-${request.id}`,
        requestId: request.id,
        status: "BLOCKED",
        confidence: "UNKNOWN",
        passedCriteria: [],
        failedCriteria: [],
        partialCriteria: [],
        evidenceIds: [],
        summary: "Verification requires at least one criterion.",
        failureReason: "NO_CRITERIA",
        verifiedAt: new Date().toISOString(),
      };
    }

    const evidenceIds = observedEvidenceIds.filter(
      (id) => this.evidence.get(id) !== undefined,
    );

    if (request.requiresEvidence && evidenceIds.length === 0) {
      return {
        id: `verification-result-${request.id}`,
        requestId: request.id,
        status: "FAILED",
        confidence: "HIGH",
        passedCriteria: [],
        failedCriteria: request.criteria
          .filter((criterion) => criterion.required)
          .map((criterion) => criterion.id),
        partialCriteria: [],
        evidenceIds: [],
        summary: "Verification failed because required evidence is missing.",
        failureReason: "REQUIRED_EVIDENCE_MISSING",
        verifiedAt: new Date().toISOString(),
      };
    }

    const requiredCriteria = request.criteria.filter(
      (criterion) => criterion.required,
    );

    if (requiredCriteria.length === 0) {
      return {
        id: `verification-result-${request.id}`,
        requestId: request.id,
        status: "PARTIAL",
        confidence: "LOW",
        passedCriteria: [],
        failedCriteria: [],
        partialCriteria: request.criteria.map((criterion) => criterion.id),
        evidenceIds,
        summary:
          "Evidence was captured, but no required semantic verification criteria were evaluated.",
        verifiedAt: new Date().toISOString(),
      };
    }

    const passedCriteria: string[] = [];
    const failedCriteria: string[] = [];
    const partialCriteria: string[] = [];

    /*
     * Deterministic verifiers currently supported:
     *
     *   criterion.id === "execution-status"
     *   criterion.id === "changed-files-contains"
     *   criterion.id === "module-route-match"
     *
     * Orchestration captures COMMAND_OUTPUT evidence containing:
     *
     * {
     *   status,
     *   output,
     *   error
     * }
     *
     * The semantic criteria below only evaluate facts explicitly present
     * in the captured execution evidence. No real-world outcome is inferred.
     */

    for (const criterion of request.criteria) {
      if (criterion.id === "execution-status") {
        let observedStatus: string | undefined;

        for (const evidenceId of evidenceIds) {
          const evidenceRecord = this.evidence.get(evidenceId);

          if (!evidenceRecord || typeof evidenceRecord.content !== "string") {
            continue;
          }

          try {
            const parsed = JSON.parse(evidenceRecord.content) as {
              status?: unknown;
            };

            if (typeof parsed.status === "string") {
              observedStatus = parsed.status;
              break;
            }
          } catch {
            // Ignore unrelated/non-JSON evidence and continue searching.
          }
        }

        if (observedStatus === undefined) {
          partialCriteria.push(criterion.id);
          continue;
        }

        if (observedStatus === criterion.expected) {
          passedCriteria.push(criterion.id);
        } else {
          failedCriteria.push(criterion.id);
        }

        continue;
      }

      if (criterion.id === "changed-files-contains") {
        let observedChangedFiles: string[] | undefined;

        for (const evidenceId of evidenceIds) {
          const evidenceRecord = this.evidence.get(evidenceId);

          if (!evidenceRecord || typeof evidenceRecord.content !== "string") {
            continue;
          }

          try {
            const parsed = JSON.parse(evidenceRecord.content) as {
              output?: {
                changedFiles?: unknown;
              };
            };

            const changedFiles = parsed.output?.changedFiles;

            if (
              Array.isArray(changedFiles) &&
              changedFiles.every(
                (item): item is string =>
                  typeof item === "string",
              )
            ) {
              observedChangedFiles = changedFiles;
              break;
            }
          } catch {
            // Ignore unrelated/non-JSON evidence and continue searching.
          }
        }

        if (observedChangedFiles === undefined) {
          partialCriteria.push(criterion.id);
          continue;
        }

        if (
          criterion.expected.length > 0 &&
          observedChangedFiles.includes(criterion.expected)
        ) {
          passedCriteria.push(criterion.id);
        } else {
          failedCriteria.push(criterion.id);
        }

        continue;
      }

      if (criterion.id === "module-route-match") {
        let observedModuleNumber: number | undefined;
        let observedModuleAction: string | undefined;

        for (const evidenceId of evidenceIds) {
          const evidenceRecord = this.evidence.get(evidenceId);

          if (!evidenceRecord || typeof evidenceRecord.content !== "string") {
            continue;
          }

          try {
            const parsed = JSON.parse(evidenceRecord.content) as {
              happyModuleRoute?: {
                moduleNumber?: unknown;
                moduleAction?: unknown;
              };
            };

            const route = parsed.happyModuleRoute;

            if (!route || typeof route !== "object") {
              continue;
            }

            if (
              typeof route.moduleNumber === "number" &&
              Number.isInteger(route.moduleNumber)
            ) {
              observedModuleNumber = route.moduleNumber;
            }

            if (typeof route.moduleAction === "string") {
              observedModuleAction = route.moduleAction;
            }

            if (
              observedModuleNumber !== undefined &&
              observedModuleAction !== undefined
            ) {
              break;
            }
          } catch {
            // Ignore unrelated/non-JSON evidence and continue searching.
          }
        }

        if (
          observedModuleNumber === undefined ||
          observedModuleAction === undefined
        ) {
          partialCriteria.push(criterion.id);
          continue;
        }

        let expectedModuleNumber: number | undefined;
        let expectedModuleAction: string | undefined;

        try {
          const expected = JSON.parse(criterion.expected) as {
            moduleNumber?: unknown;
            moduleAction?: unknown;
          };

          if (
            typeof expected.moduleNumber === "number" &&
            Number.isInteger(expected.moduleNumber)
          ) {
            expectedModuleNumber = expected.moduleNumber;
          }

          if (typeof expected.moduleAction === "string") {
            expectedModuleAction = expected.moduleAction;
          }
        } catch {
          partialCriteria.push(criterion.id);
          continue;
        }

        if (
          expectedModuleNumber === undefined ||
          expectedModuleAction === undefined
        ) {
          partialCriteria.push(criterion.id);
          continue;
        }

        if (
          observedModuleNumber === expectedModuleNumber &&
          observedModuleAction === expectedModuleAction
        ) {
          passedCriteria.push(criterion.id);
        } else {
          failedCriteria.push(criterion.id);
        }

        continue;
      }

      partialCriteria.push(criterion.id);
    }

    const requiredFailed = request.criteria.some(
      (criterion) =>
        criterion.required && failedCriteria.includes(criterion.id),
    );

    const requiredPartial = request.criteria.some(
      (criterion) =>
        criterion.required && partialCriteria.includes(criterion.id),
    );

    const requiredPassed = request.criteria.every(
      (criterion) =>
        !criterion.required || passedCriteria.includes(criterion.id),
    );

    let status: VerificationResult["status"];
    let confidence: VerificationResult["confidence"];
    let summary: string;
    let failureReason: string | undefined;

    if (requiredFailed) {
      status = "FAILED";
      confidence = "HIGH";
      summary =
        "Verification failed because the observed execution status did not match the required status.";
      failureReason =
        failedCriteria.includes("execution-status")
          ? "EXECUTION_STATUS_MISMATCH"
          : "SEMANTIC_CRITERION_MISMATCH";
    } else if (requiredPassed) {
      status = "PASSED";
      confidence = "HIGH";
      summary =
        "Execution status evidence matched the required verification criterion.";
    } else if (requiredPartial) {
      status = "PARTIAL";
      confidence = "LOW";
      summary =
        "Evidence exists, but the required verification criterion could not be deterministically evaluated.";
      failureReason = "SEMANTIC_VERIFIER_NOT_CONNECTED";
    } else {
      status = "PARTIAL";
      confidence = "LOW";
      summary =
        "Evidence exists, but the verification result is incomplete.";
      failureReason = "VERIFICATION_INCOMPLETE";
    }

    return {
      id: `verification-result-${request.id}`,
      requestId: request.id,
      status,
      confidence,
      passedCriteria,
      failedCriteria,
      partialCriteria,
      evidenceIds,
      summary,
      ...(failureReason ? { failureReason } : {}),
      verifiedAt: new Date().toISOString(),
    };
  }
}
