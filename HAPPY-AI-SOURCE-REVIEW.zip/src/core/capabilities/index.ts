export {
    CAPABILITIES,
    getCapability,
    getCapabilityCounts,
    hasCapability,
    listCapabilities,
    listCapabilitiesByDomain,
    listCapabilitiesByStatus,
    requireCapability,
} from "./registry";

export type {
    CapabilityAction,
    CapabilityDefinition,
    CapabilityDomain,
    CapabilityStatus,
    ExecutionType,
    RiskLevel,
} from "./types";
