export type CapabilityStatus =
    | "AVAILABLE"
    | "NOT_YET_CONNECTED"
    | "BLOCKED";

export type CapabilityDomain =
    | "IDENTITY"
    | "AUTH"
    | "COMMAND"
    | "CONTEXT"
    | "PLANNING"
    | "MISSION"
    | "TASK"
    | "EXECUTION"
    | "FILE"
    | "API"
    | "BROWSER"
    | "DATABASE"
    | "AI"
    | "MEMORY"
    | "VERIFICATION"
    | "EVIDENCE"
    | "WORKSPACE"
    | "DEPLOYMENT"
    | "PUBLISH"
    | "AUTOMATION"
    | "SANDBOX";

export type ExecutionType =
    | "NONE"
    | "FILE"
    | "API"
    | "BROWSER"
    | "DATABASE"
    | "AI"
    | "SHELL"
    | "DEPLOYMENT"
    | "PUBLISH"
    | "AUTOMATION";

export type RiskLevel =
    | "LOW"
    | "MEDIUM"
    | "HIGH"
    | "CRITICAL";

export type CapabilityAction =
    | "READ"
    | "CREATE"
    | "MODIFY"
    | "COPY"
    | "MOVE"
    | "RENAME"
    | "DELETE"
    | "REQUEST"
    | "CALL"
    | "NAVIGATE"
    | "CLICK"
    | "FILL"
    | "EXTRACT"
    | "SCREENSHOT"
    | "GENERATE"
    | "EXECUTE"
    | "VERIFY"
    | "PERSIST"
    | "DEPLOY"
    | "PUBLISH"
    | "AUTOMATE"
    | "AUTHENTICATE"
    | "PLAN"
    | "REMEMBER";

export interface CapabilityDefinition {
    id: string;
    name: string;
    domain: CapabilityDomain;
    description: string;
    status: CapabilityStatus;
    executionTypes: ExecutionType[];
    actions: CapabilityAction[];
    permissions: string[];
    riskLevel: RiskLevel;
    requiresApproval: boolean;
    approvalReason?: string;
    verificationRequired: boolean;
    evidenceRequired: boolean;
    tenantScoped: boolean;
    implementedBy: string[];
    prerequisites: string[];
    tags: string[];
}
