import {
  closeSync,
  existsSync,
  mkdirSync,
  openSync,
  fstatSync,
  lstatSync,
  readFileSync,
  renameSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { randomUUID } from "node:crypto";
import { dirname, resolve } from "node:path";
import type { HappyState } from "../state";
import { createEmptyState } from "../state";
import { deserializeState, serializeState } from "../serialization";

export interface PersistentStateAdapter {
  load(): HappyState;
  save(state: HappyState): void;
  transact?<T>(
    mutator: (state: HappyState) => T,
  ): { result: T; state: HappyState };
}

export class JsonFileStateAdapter implements PersistentStateAdapter {
  constructor(private readonly filePath: string) {}

  load(): HappyState {
    const target = resolve(this.filePath);
    if (!existsSync(target)) return createEmptyState();
    return deserializeState(readFileSync(target, "utf8"));
  }

  save(state: HappyState): void {
    this.withLock(() => this.writeAtomic(state));
  }

  transact<T>(
    mutator: (state: HappyState) => T,
  ): { result: T; state: HappyState } {
    return this.withLock(() => {
      // Reload only after acquiring the inter-process lock.
      const state = this.load();
      const result = mutator(state);
      this.writeAtomic(state);
      return { result, state };
    });
  }

  private withLock<T>(operation: () => T): T {
    const target = resolve(this.filePath);
    mkdirSync(dirname(target), { recursive: true });

    const lockPath = `${target}.lock`;
    const deadline = Date.now() + 10_000;
    const waitCell = new Int32Array(new SharedArrayBuffer(4));
    const lockToken = randomUUID();

    let lockFd: number | undefined;
    let lockIdentity: { dev: number; ino: number } | undefined;

    const cleanupOwnLock = (requireToken: boolean): void => {
      if (!lockIdentity) return;

      try {
        const pathIdentity = lstatSync(lockPath);
        if (
          pathIdentity.dev !== lockIdentity.dev ||
          pathIdentity.ino !== lockIdentity.ino
        ) {
          return;
        }

        if (requireToken) {
          let metadata: { token?: unknown };
          try {
            metadata = JSON.parse(readFileSync(lockPath, "utf8")) as {
              token?: unknown;
            };
          } catch {
            return;
          }
          if (metadata.token !== lockToken) return;
        }

        unlinkSync(lockPath);
      } catch {
        // Preserve an unverified lock; operator recovery may be required.
      }
    };

    while (lockFd === undefined) {
      try {
        lockFd = openSync(lockPath, "wx");
        const identity = fstatSync(lockFd);
        lockIdentity = { dev: identity.dev, ino: identity.ino };

        writeFileSync(
          lockFd,
          JSON.stringify({
            token: lockToken,
            pid: process.pid,
            hostname: process.env.COMPUTERNAME ?? process.env.HOSTNAME ?? "unknown",
            createdAt: new Date().toISOString(),
          }),
          "utf8",
        );
      } catch (error) {
        if (lockFd !== undefined) {
          cleanupOwnLock(false);
          try {
            closeSync(lockFd);
          } finally {
            lockFd = undefined;
            lockIdentity = undefined;
          }
        }

        const code = (error as NodeJS.ErrnoException).code;
        if (code !== "EEXIST") throw error;

        if (Date.now() >= deadline) {
          let owner = "owner metadata unavailable";
          try {
            owner = readFileSync(lockPath, "utf8");
          } catch {}

          throw new Error(
            `PERSISTENCE_LOCK_TIMEOUT: ${lockPath}; refusing unsafe write. Owner: ${owner}`,
          );
        }

        Atomics.wait(waitCell, 0, 0, 10);
      }
    }

    try {
      return operation();
    } finally {
      try {
        closeSync(lockFd);
      } finally {
        cleanupOwnLock(true);
      }
    }
  }

  private writeAtomic(state: HappyState): void {
    const target = resolve(this.filePath);
    mkdirSync(dirname(target), { recursive: true });

    const temporary = `${target}.${process.pid}.${randomUUID()}.tmp`;
    try {
      writeFileSync(temporary, serializeState(state), {
        encoding: "utf8",
        flag: "wx",
      });
      renameSync(temporary, target);
    } finally {
      if (existsSync(temporary)) unlinkSync(temporary);
    }
  }
}
