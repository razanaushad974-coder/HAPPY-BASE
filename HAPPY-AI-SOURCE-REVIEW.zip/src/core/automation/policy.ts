export type AutomationStatus =
  | "READY"
  | "WAITING_APPROVAL"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

export interface AutomationRequest {
  id: string;
  workflowId: string;
  enabled: boolean;
  approved: boolean;
  trigger:
    | "MANUAL"
    | "SCHEDULE"
    | "EVENT"
    | "WEBHOOK"
    | "CONDITION";
}

export interface AutomationDecision {
  status: AutomationStatus;
  reason: string;
}

export function evaluateAutomation(
  request: AutomationRequest,
): AutomationDecision {
  if (!request.enabled) {
    return {
      status: "BLOCKED",
      reason: "Automation is not enabled.",
    };
  }

  if (!request.approved) {
    return {
      status: "WAITING_APPROVAL",
      reason: "Automation requires explicit approval.",
    };
  }

  return {
    status: "NOT_YET_CONNECTED",
    reason: "Automation workflow runtime is not yet connected.",
  };
}
