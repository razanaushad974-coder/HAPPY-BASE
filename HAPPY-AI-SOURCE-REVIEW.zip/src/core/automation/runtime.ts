import type {
    ExecutionRuntimeContext,
} from "../execution/runtime-context";

import type {
    HappyPipelineRequest,
    HappyPipelineResult,
} from "../orchestration/types";

import {
    HappyOrchestrationEngine,
} from "../orchestration/engine";

import type {
    AutomationRequest,
} from "./policy";

export interface AutomationPipelineRunner {
    run(
        request: HappyPipelineRequest,
        runtimeContext?: ExecutionRuntimeContext,
    ): Promise<HappyPipelineResult>;
}

export interface AutomationRunInput {
    request: AutomationRequest;
    command: string;
    organizationId: string;
    workspaceId: string;
    userId?: string;
    source?: HappyPipelineRequest["source"];
    approved?: boolean;
    runtimeContext?: ExecutionRuntimeContext;
}

export class AutomationRuntime {
    private readonly pipeline: AutomationPipelineRunner;

    constructor(
        pipeline?: AutomationPipelineRunner,
    ) {
        this.pipeline =
            pipeline ??
            new HappyOrchestrationEngine();
    }

    async run(
        input: AutomationRunInput,
    ): Promise<HappyPipelineResult> {
        if (!input.request.enabled) {
            throw new Error(
                "AUTOMATION_DISABLED",
            );
        }

        if (!input.request.approved) {
            throw new Error(
                "AUTOMATION_APPROVAL_REQUIRED",
            );
        }

        const pipelineRequest:
            HappyPipelineRequest = {
            id:
                input.request.id,
            command:
                input.command,
            organizationId:
                input.organizationId,
            workspaceId:
                input.workspaceId,
            userId:
                input.userId,
            source:
                input.source ??
                "AUTOMATION",
            approved:
                input.approved ??
                input.request.approved,
            createdAt:
                new Date().toISOString(),
        };

        return this.pipeline.run(
            pipelineRequest,
            input.runtimeContext,
        );
    }
}
