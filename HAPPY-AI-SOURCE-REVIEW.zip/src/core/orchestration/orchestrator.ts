import {
    HappyOrchestrationEngine,
} from "./engine";

import type {
    HappyPipelineRequest,
    HappyPipelineResult,
} from "./types";

export class HappyOrchestrator {
    private readonly engine:
        HappyOrchestrationEngine;

    constructor(
        persistenceFile?: string,
    ) {
        this.engine =
            new HappyOrchestrationEngine(
                persistenceFile,
            );
    }

    run(
        request: HappyPipelineRequest,
    ): Promise<HappyPipelineResult> {
        return this.engine.run(request);
    }

    resumeAfterApproval(
        requestId: string,
        approvalId: string,
        planId: string,
        organizationId: string,
        workspaceId: string,
        userId: string,
        runtimeContext?: import(
            "../execution/runtime-context"
        ).ExecutionRuntimeContext,
    ): Promise<HappyPipelineResult> {
        return this.engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            organizationId,
            workspaceId,
            userId,
            runtimeContext,
        );
    }
}

