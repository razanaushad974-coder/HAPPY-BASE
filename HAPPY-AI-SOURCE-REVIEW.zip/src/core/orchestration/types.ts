export type HappyPipelineStage =
    | "COMMAND"
    | "CONTEXT"
    | "MEMORY"
    | "REASON"
    | "PLAN"
    | "APPROVAL"
    | "MISSION"
    | "TASK_GRAPH"
    | "EXECUTION"
    | "VERIFICATION"
    | "EVIDENCE"
    | "PERSIST"
    | "COMPLETE"
    | "BLOCKED"
    | "NOT_YET_CONNECTED";

export type HappyPipelineStatus =
    | "RECEIVED"
    | "PROCESSING"
    | "WAITING_APPROVAL"
    | "RUNNING"
    | "VERIFYING"
    | "COMPLETED"
    | "PARTIAL"
    | "FAILED"
    | "BLOCKED"
    | "NOT_YET_CONNECTED";

export type HappyPipelineRole =
    | "USER"
    | "ADMIN"
    | "SECURITY"
    | "FOUNDER";

export type HappyPipelineScope =
    | "USER"
    | "WORKSPACE"
    | "ORGANIZATION"
    | "FOUNDER"
    | "SYSTEM";

export type HappyPipelineRoleSource =
    | "TRUSTED_SERVER"
    | "CLIENT";

export interface HappyPipelineAuthorizationContext {
    role: HappyPipelineRole;
    scope: HappyPipelineScope;
    roleSource: HappyPipelineRoleSource;
    authenticated: boolean;
}

export interface HappyPipelineRequest {
    id: string;
    command: string;
    organizationId: string;
    workspaceId: string;
    activeProjectId?: string;
    activeMissionId?: string;
    activeTaskId?: string;
    userId?: string;
    source:
        | "TEXT"
        | "VOICE"
        | "SYSTEM"
        | "API"
        | "AUTOMATION"
        | "FOUNDER";
    approved?: boolean;
    createdAt: string;

    /**
     * Authorization is trusted only when roleSource is TRUSTED_SERVER.
     * Client-provided role information must never grant access by itself.
     */
    authorization?: HappyPipelineAuthorizationContext;
}

export interface HappyPipelineStageResult {
    stage: HappyPipelineStage;
    status: HappyPipelineStatus;
    summary: string;
    referenceId?: string;
    error?: string;
}

export interface HappyPipelineTrace {
    requestId: string;
    stages: HappyPipelineStageResult[];
    currentStage: HappyPipelineStage;
    status: HappyPipelineStatus;
    startedAt: string;
    completedAt?: string;
}

export interface HappyPipelineResult {
    requestId: string;
    status: HappyPipelineStatus;
    currentStage: HappyPipelineStage;
    trace: HappyPipelineTrace;
    missionId?: string;
    planId?: string;
    executionRequestId?: string;
    verificationRequestId?: string;
    evidenceIds: string[];
    output?: unknown;
    persisted: boolean;
    runtimePersistence?: {
        status:
            | "AVAILABLE"
            | "NOT_YET_CONNECTED"
            | "ERROR";
        scopeKey: string;
        version?: number;
        error?: string;
    };
}
