import type {
    CapabilityAction,
    CapabilityStatus,
    RiskLevel,
} from "../capabilities/types";
import { evaluateFounderAccess, type FounderAction } from "../founder/access-policy";

export type HappyRole =
    | "USER"
    | "ADMIN"
    | "SECURITY"
    | "FOUNDER";

export type HappyAccessDecision =
    | "ALLOW"
    | "APPROVAL_REQUIRED"
    | "NOT_YET_CONNECTED"
    | "BLOCKED";

export type HappyScope =
    | "USER"
    | "WORKSPACE"
    | "ORGANIZATION"
    | "FOUNDER"
    | "SYSTEM";

export interface HappyFeatureAccessRequest {
    userId: string;
    role: HappyRole;
    scope: HappyScope;
    action: CapabilityAction;
    capabilityId?: string;
    capabilityStatus?: CapabilityStatus;
    riskLevel?: RiskLevel;
    requiresApproval?: boolean;
    approved?: boolean;
    verificationRequired?: boolean;
    allowedActions?: string[];
}

export interface HappyFeatureAccessDecision {
    decision: HappyAccessDecision;
    allowed: boolean;
    reason: string;
    userId: string;
    role: HappyRole;
    scope: HappyScope;
    action: CapabilityAction;
    capabilityId?: string;
}

const FOUNDER_ONLY_ACTIONS = new Set<CapabilityAction>([
    "DEPLOY",
    "PUBLISH",
]);

const SENSITIVE_ACTIONS = new Set<CapabilityAction>([
    "DELETE",
    "MODIFY",
    "MOVE",
    "DEPLOY",
    "PUBLISH",
    "AUTOMATE",
]);

function mapCapabilityActionToFounderAction(
  action: CapabilityAction,
): FounderAction | undefined {
  switch (action) {
    case "DEPLOY":
      return "DEPLOY";
    case "PUBLISH":
      return "PUBLISH";
    case "DELETE":
      return "CONTROL_HAPPY";
    case "MODIFY":
      return "CONTROL_HAPPY";
    case "MOVE":
      return "CONTROL_HAPPY";
    case "AUTOMATE":
      return "MANAGE_AUTOMATION";
    default:
      return undefined;
  }
}
export function evaluateHappyFeatureAccess(
    request: HappyFeatureAccessRequest,
): HappyFeatureAccessDecision {
    const base = {
        userId:
            request.userId,
        role:
            request.role,
        scope:
            request.scope,
        action:
            request.action,
        capabilityId:
            request.capabilityId,
    };
       const founderAction =
        mapCapabilityActionToFounderAction(
            request.action,
        );

    if (
        founderAction !== undefined &&
        request.role === "FOUNDER"
    ) {
        const founderDecision =
            evaluateFounderAccess({
                userId:
                    request.userId,
                role:
                    request.role,
                roleSource:
                    "TRUSTED_SERVER",
                authenticated:
                    true,
                configuredFounderUserId:
                    process.env.HAPPY_FOUNDER_USER_ID,
                action:
                    founderAction,
            });

        if (
            founderDecision.status !==
            "ALLOW"
        ) {
            return {
                ...base,
                decision:
                    founderDecision.status ===
                    "NOT_YET_CONNECTED"
                        ? "NOT_YET_CONNECTED"
                        : "BLOCKED",
                allowed:
                    false,
                reason:
                    founderDecision.reason,
            };
        }
    }

    if (!request.userId.trim()) {
        return {
            ...base,
            decision: "BLOCKED",
            allowed: false,
            reason: "Authenticated user identity is required.",
        };
    }

    if (request.allowedActions?.length && !request.allowedActions.includes(request.action)) {
        return {
            ...base,
            decision: "BLOCKED",
            allowed: false,
            reason: "The requested action is not declared by the feature contract.",
        };
    }

    if (request.capabilityStatus === "BLOCKED") {
        return {
            ...base,
            decision: "BLOCKED",
            allowed: false,
            reason: "The requested capability is blocked.",
        };
    }

    if (request.capabilityStatus === "NOT_YET_CONNECTED") {
        return {
            ...base,
            decision: "NOT_YET_CONNECTED",
            allowed: false,
            reason: "The requested capability is not yet connected.",
        };
    }

    if (
        FOUNDER_ONLY_ACTIONS.has(request.action) &&
        request.role !== "FOUNDER"
    ) {
        return {
            ...base,
            decision: "BLOCKED",
            allowed: false,
            reason: "This action is restricted to the Founder.",
        };
    }

    if (
        request.scope === "FOUNDER" &&
        request.role !== "FOUNDER"
    ) {
        return {
            ...base,
            decision: "BLOCKED",
            allowed: false,
            reason: "Founder scope requires the FOUNDER role.",
        };
    }

    const approvalRequired =
        request.requiresApproval === true ||
        SENSITIVE_ACTIONS.has(request.action) ||
        request.riskLevel === "HIGH" ||
        request.riskLevel === "CRITICAL";

    if (approvalRequired && request.approved !== true) {
        return {
            ...base,
            decision: "APPROVAL_REQUIRED",
            allowed: false,
            reason: "Explicit approval is required before this action can execute.",
        };
    }

    return {
        ...base,
        decision: "ALLOW",
        allowed: true,
        reason: "Role, scope, capability status, and action policy allow the request.",
    };
}





