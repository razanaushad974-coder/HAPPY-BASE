export type ModuleDataValue = Record<string, unknown>;

export interface ModuleRecord<T extends ModuleDataValue = ModuleDataValue> {
  id: string;
  tenantId: string;
  moduleNumber: number;
  data: T;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateModuleRecordInput<T extends ModuleDataValue = ModuleDataValue> {
  id: string;
  tenantId: string;
  moduleNumber: number;
  data: T;
}

export interface UpdateModuleRecordInput<T extends ModuleDataValue = ModuleDataValue> {
  tenantId: string;
  moduleNumber: number;
  id: string;
  expectedVersion: number;
  data: T;
}

export class ModuleDataStore {
  private readonly records = new Map<string, ModuleRecord>();

  create<T extends ModuleDataValue>(
    input: CreateModuleRecordInput<T>,
  ): ModuleRecord<T> {
    this.validateTenant(input.tenantId);
    this.validateModuleNumber(input.moduleNumber);

    const key = this.key(input.tenantId, input.moduleNumber, input.id);
    if (this.records.has(key)) {
      throw new Error("Module record already exists");
    }

    const now = new Date().toISOString();
    const record: ModuleRecord<T> = {
      id: input.id,
      tenantId: input.tenantId,
      moduleNumber: input.moduleNumber,
      data: structuredClone(input.data),
      version: 1,
      createdAt: now,
      updatedAt: now,
    };

    this.records.set(key, record);
    return structuredClone(record);
  }

  get<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
    id: string,
  ): ModuleRecord<T> | null {
    this.validateTenant(tenantId);
    this.validateModuleNumber(moduleNumber);

    const record = this.records.get(this.key(tenantId, moduleNumber, id));
    return record ? structuredClone(record as ModuleRecord<T>) : null;
  }

  list<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
  ): ModuleRecord<T>[] {
    this.validateTenant(tenantId);
    this.validateModuleNumber(moduleNumber);

    const prefix = `${tenantId}:${moduleNumber}:`;
    return [...this.records.entries()]
      .filter(([key]) => key.startsWith(prefix))
      .map(([, value]) => structuredClone(value as ModuleRecord<T>));
  }

  update<T extends ModuleDataValue>(
    input: UpdateModuleRecordInput<T>,
  ): ModuleRecord<T> {
    this.validateTenant(input.tenantId);
    this.validateModuleNumber(input.moduleNumber);

    const key = this.key(
      input.tenantId,
      input.moduleNumber,
      input.id,
    );

    const existing = this.records.get(key);
    if (!existing) {
      throw new Error("Module record not found");
    }

    if (existing.version !== input.expectedVersion) {
      throw new Error("Module record version conflict");
    }

    const updated: ModuleRecord<T> = {
      ...existing,
      data: structuredClone(input.data),
      version: existing.version + 1,
      updatedAt: new Date().toISOString(),
    };

    this.records.set(key, updated);
    return structuredClone(updated as ModuleRecord<T>);
  }

  delete(
    tenantId: string,
    moduleNumber: number,
    id: string,
    expectedVersion: number,
  ): void {
    this.validateTenant(tenantId);
    this.validateModuleNumber(moduleNumber);

    const key = this.key(tenantId, moduleNumber, id);
    const existing = this.records.get(key);

    if (!existing) {
      throw new Error("Module record not found");
    }

    if (existing.version !== expectedVersion) {
      throw new Error("Module record version conflict");
    }

    this.records.delete(key);
  }

  count(tenantId: string, moduleNumber: number): number {
    return this.list(tenantId, moduleNumber).length;
  }

  private key(
    tenantId: string,
    moduleNumber: number,
    id: string,
  ): string {
    return `${tenantId}:${moduleNumber}:${id}`;
  }

  private validateTenant(tenantId: string): void {
    if (!tenantId.trim()) {
      throw new Error("tenantId is required");
    }
  }

  private validateModuleNumber(moduleNumber: number): void {
    if (
      !Number.isInteger(moduleNumber) ||
      moduleNumber < 1 ||
      moduleNumber > 502
    ) {
      throw new Error("moduleNumber must be an integer from 1 to 502");
    }
  }
}
