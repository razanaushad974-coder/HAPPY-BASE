import {
  ModuleDataValue,
  ModuleRecord,
} from "../data/module-data-store";
import {
  InMemoryModulePersistenceAdapter,
  ModulePersistenceAdapter,
} from "../data/module-persistence";
import { bootstrapHappyModuleRuntimeBridge } from "./happy-module-runtime-bridge";

export interface CreateModuleDataInput<T extends ModuleDataValue> {
  tenantId: string;
  moduleNumber: number;
  recordId: string;
  data: T;
}

export interface UpdateModuleDataInput<T extends ModuleDataValue> {
  tenantId: string;
  moduleNumber: number;
  recordId: string;
  expectedVersion: number;
  data: T;
}

export class HappyModuleDataService {
  private readonly bridge =
    bootstrapHappyModuleRuntimeBridge();

  private readonly persistence:
    ModulePersistenceAdapter;

  constructor(
    persistence?: ModulePersistenceAdapter,
  ) {
    this.persistence =
      persistence ??
      new InMemoryModulePersistenceAdapter();
  }

  persistenceKind(): ModulePersistenceAdapter["kind"] {
    return this.persistence.kind;
  }

  persistenceConnected(): boolean {
    return this.persistence.connected;
  }

  async create<T extends ModuleDataValue>(
    input: CreateModuleDataInput<T>,
  ): Promise<ModuleRecord<T>> {
    this.requireModule(input.moduleNumber);

    const now = new Date().toISOString();

    const record: ModuleRecord<T> = {
      id: input.recordId,
      tenantId: input.tenantId,
      moduleNumber: input.moduleNumber,
      data: structuredClone(input.data),
      version: 1,
      createdAt: now,
      updatedAt: now,
    };

    return this.persistence.create(record);
  }

  async get<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): Promise<ModuleRecord<T> | null> {
    this.requireModule(moduleNumber);

    return this.persistence.get<T>(
      tenantId,
      moduleNumber,
      recordId,
    );
  }

  async list<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
  ): Promise<ModuleRecord<T>[]> {
    this.requireModule(moduleNumber);

    return this.persistence.list<T>(
      tenantId,
      moduleNumber,
    );
  }

  async update<T extends ModuleDataValue>(
    input: UpdateModuleDataInput<T>,
  ): Promise<ModuleRecord<T>> {
    this.requireModule(input.moduleNumber);

    const existing =
      await this.persistence.get<T>(
        input.tenantId,
        input.moduleNumber,
        input.recordId,
      );

    if (!existing) {
      throw new Error(
        "Module record not found",
      );
    }

    if (
      existing.version !==
      input.expectedVersion
    ) {
      throw new Error(
        "Module record version conflict",
      );
    }

    const updated: ModuleRecord<T> = {
      ...existing,
      data: structuredClone(input.data),
      version: existing.version + 1,
      updatedAt: new Date().toISOString(),
    };

    return this.persistence.update(
      updated,
    );
  }

  async delete(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
    expectedVersion: number,
  ): Promise<void> {
    this.requireModule(moduleNumber);

    const existing =
      await this.persistence.get(
        tenantId,
        moduleNumber,
        recordId,
      );

    if (!existing) {
      throw new Error(
        "Module record not found",
      );
    }

    if (
      existing.version !==
      expectedVersion
    ) {
      throw new Error(
        "Module record version conflict",
      );
    }

    await this.persistence.delete(
      tenantId,
      moduleNumber,
      recordId,
      expectedVersion,
    );
  }

  async count(
    tenantId: string,
    moduleNumber: number,
  ): Promise<number> {
    return (
      await this.list(
        tenantId,
        moduleNumber,
      )
    ).length;
  }

  private requireModule(
    moduleNumber: number,
  ) {
    const runtime =
      this.bridge.registry.get(
        moduleNumber,
      );

    if (!runtime) {
      throw new Error(
        `HAPPY module ${moduleNumber} is not registered`,
      );
    }

    return runtime;
  }
}
