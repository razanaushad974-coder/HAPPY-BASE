import { bootstrapHappyMajorModules } from "../../happy/kernel/registry/happy-module-bootstrap";
import {
  HappyModuleDefinition,
  happyModuleRegistry,
} from "../../happy/kernel/registry/happy-module-runtime";
import {
  ModuleRuntimeDescriptor,
  ModuleRuntimeRegistry,
} from "./module-runtime-registry";

const canonicalStatusToRuntimeStatus = (
  status: HappyModuleDefinition["status"],
): ModuleRuntimeDescriptor["runtimeStatus"] => {
  if (status === "BLOCKED") {
    return "BLOCKED";
  }

  if (status === "NOT_YET_CONNECTED") {
    return "NOT_YET_CONNECTED";
  }

  return "ROUTING_ONLY";
};

export interface HappyModuleRuntimeBridge {
  registry: ModuleRuntimeRegistry;
  canonicalCount: number;
  runtimeCount: number;
  statuses: ReturnType<ModuleRuntimeRegistry["statuses"]>;
}

export function bootstrapHappyModuleRuntimeBridge(): HappyModuleRuntimeBridge {
  const bootstrap = bootstrapHappyMajorModules();
  const canonicalModules = happyModuleRegistry.list();

  if (canonicalModules.length !== 502) {
    throw new Error(
      `Canonical HAPPY module registry must contain 502 modules, got ${canonicalModules.length}`,
    );
  }

  const registry = new ModuleRuntimeRegistry();

  const descriptors: ModuleRuntimeDescriptor[] =
    canonicalModules.map((module) => {
      const number = module.number;

      if (
        typeof number !== "number" ||
        !Number.isInteger(number) ||
        number < 1 ||
        number > 502
      ) {
        throw new Error(
          `Canonical module ${module.id} has invalid number`,
        );
      }

      return {
        number,
        id: module.id,
        name: module.name,
        capability: module.capabilities.join(","),
        runtimeStatus: canonicalStatusToRuntimeStatus(module.status),
      };
    });

  registry.registerMany(descriptors);

  if (registry.count() !== 502) {
    throw new Error(
      `Runtime registry mismatch: ${registry.count()} instead of 502`,
    );
  }

  return {
    registry,
    canonicalCount: bootstrap.total,
    runtimeCount: registry.count(),
    statuses: registry.statuses(),
  };
}
