import type {
  ExecutionCapability,
} from "../execution/types";

export type AgentStatus =
  | "AVAILABLE"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

export type AgentRole =
  | "REASONER"
  | "PLANNER"
  | "BUILDER"
  | "FILE_OPERATOR"
  | "API_OPERATOR"
  | "BROWSER_OPERATOR"
  | "DATABASE_OPERATOR"
  | "VERIFIER"
  | "AUTOMATION"
  | "DEPLOYMENT"
  | "PUBLISHING"
  | "SAFE_SHELL";

export interface AgentDefinition {
  id: string;
  role: AgentRole;
  name: string;
  status: AgentStatus;
  capabilities: ExecutionCapability[];
  description: string;
}

const AGENTS: readonly AgentDefinition[] = [
  {
    id: "reasoner",
    role: "REASONER",
    name: "HAPPY Reasoner",
    status: "AVAILABLE",
    capabilities: ["AI"],
    description:
      "Understands goals and produces structured reasoning.",
  },
  {
    id: "planner",
    role: "PLANNER",
    name: "HAPPY Planner",
    status: "AVAILABLE",
    capabilities: ["AI"],
    description:
      "Converts goals into ordered executable steps.",
  },
  {
    id: "builder",
    role: "BUILDER",
    name: "HAPPY Builder",
    status: "AVAILABLE",
    capabilities: ["CODE", "FILE"],
    description:
      "Builds and modifies code and project assets.",
  },
  {
    id: "file-operator",
    role: "FILE_OPERATOR",
    name: "HAPPY File Operator",
    status: "AVAILABLE",
    capabilities: ["FILE"],
    description:
      "Performs approved workspace file operations.",
  },
  {
    id: "api-operator",
    role: "API_OPERATOR",
    name: "HAPPY API Operator",
    status: "AVAILABLE",
    capabilities: ["API"],
    description:
      "Performs approved API operations.",
  },
  {
    id: "browser-operator",
    role: "BROWSER_OPERATOR",
    name: "HAPPY Browser Operator",
    status: "AVAILABLE",
    capabilities: ["BROWSER"],
    description:
      "Performs approved browser operations.",
  },
  {
    id: "database-operator",
    role: "DATABASE_OPERATOR",
    name: "HAPPY Database Operator",
    status: "AVAILABLE",
    capabilities: ["DATABASE"],
    description:
      "Performs approved database operations.",
  },
  {
    id: "verifier",
    role: "VERIFIER",
    name: "HAPPY Verifier",
    status: "AVAILABLE",
    capabilities: ["AI"],
    description:
      "Evaluates outcomes and verification evidence.",
  },
  {
    id: "automation",
    role: "AUTOMATION",
    name: "HAPPY Automation Agent",
    status: "NOT_YET_CONNECTED",
    capabilities: ["AUTOMATION"],
    description:
      "Automation runtime is reserved for connected workflow execution.",
  },
  {
    id: "deployment",
    role: "DEPLOYMENT",
    name: "HAPPY Deployment Agent",
    status: "NOT_YET_CONNECTED",
    capabilities: ["DEPLOYMENT"],
    description:
      "Deployment runtime is not yet connected.",
  },
  {
    id: "publishing",
    role: "PUBLISHING",
    name: "HAPPY Publishing Agent",
    status: "NOT_YET_CONNECTED",
    capabilities: ["PUBLISH"],
    description:
      "Publishing runtime is not yet connected.",
  },
  {
    id: "safe-shell",
    role: "SAFE_SHELL",
    name: "HAPPY Safe Shell Agent",
    status: "BLOCKED",
    capabilities: ["SHELL"],
    description:
      "Shell execution remains explicitly gated.",
  },
];

export function listAgents(): AgentDefinition[] {
  return AGENTS.map(
    (agent) => ({
      ...agent,
      capabilities: [...agent.capabilities],
    }),
  );
}

export function getAgent(
  id: string,
): AgentDefinition | undefined {
  return listAgents().find(
    (agent) => agent.id === id,
  );
}

export function findAgentForCapability(
  capability: ExecutionCapability,
): AgentDefinition | undefined {
  return listAgents().find(
    (agent) =>
      agent.capabilities.includes(
        capability,
      ),
  );
}
