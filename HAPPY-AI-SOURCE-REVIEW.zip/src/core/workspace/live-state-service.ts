import type {
  PersistenceService,
} from "../persistence/service";

import {
  createHappyStateStore,
} from "../state/factory";

export interface WorkspaceLiveStateRequest {
  organizationId: string;
  workspaceId: string;
  userId?: string;
}

export interface WorkspaceLiveStateCounts {
  commands: number;
  missions: number;
  tasks: number;
  executions: number;
  verifications: number;
  evidence: number;
  memories: number;
  approvals: number;
  auditEvents: number;
}

export interface WorkspaceLiveState {
  organizationId: string;
  workspaceId: string;
  userId?: string;

  counts: WorkspaceLiveStateCounts;

  recentCommands: unknown[];
  activeMissions: unknown[];
  recentTasks: unknown[];
  recentExecutions: unknown[];
  recentVerifications: unknown[];
  recentEvidence: unknown[];
  pendingApprovals: unknown[];
  recentAuditEvents: unknown[];

  generatedAt: string;
}

export class WorkspaceLiveStateService {
  constructor(
    private readonly persistence: PersistenceService,
  ) {}

  async getState(
    request: WorkspaceLiveStateRequest,
  ): Promise<WorkspaceLiveState> {
    if (!request.organizationId.trim()) {
      throw new Error(
        "organizationId is required.",
      );
    }

    if (!request.workspaceId.trim()) {
      throw new Error(
        "workspaceId is required.",
      );
    }

    const state =
      createHappyStateStore(
        this.persistence,
        request.organizationId.trim(),
        request.workspaceId.trim(),
        request.userId?.trim(),
      );

    const commands =
      await state.repository("COMMAND").list();

    const missions =
      await state.repository("MISSION").list();

    const tasks =
      await state.repository("TASK").list();

    const executions =
      await state.repository("EXECUTION").list();

    const verifications =
      await state.repository("VERIFICATION").list();

    const evidence =
      await state.repository("EVIDENCE").list();

    const memories =
      await state.repository("MEMORY").list();

    const approvals =
      await state.repository("APPROVAL").list();

    const auditEvents =
      await state.repository("AUDIT_EVENT").list();

    const recent = <T>(
      records: Array<{
        updatedAt?: string;
        createdAt?: string;
        data: T;
      }>,
      limit = 10,
    ): T[] =>
      [...records]
        .sort(
          (a, b) =>
            new Date(
              b.updatedAt ??
                b.createdAt ??
                0,
            ).getTime() -
            new Date(
              a.updatedAt ??
                a.createdAt ??
                0,
            ).getTime(),
        )
        .slice(0, limit)
        .map(
          (record) => record.data,
        );

    const pendingApprovals =
      approvals.filter(
        (record) => {
          const data =
            record.data as {
              status?: string;
            };

          return (
            data.status ===
            "WAITING_APPROVAL" ||
            data.status ===
            "PENDING"
          );
        },
      );

    const activeMissions =
      missions.filter(
        (record) => {
          const data =
            record.data as {
              status?: string;
            };

          return ![
            "COMPLETED",
            "FAILED",
            "CANCELLED",
          ].includes(
            data.status ?? "",
          );
        },
      );

    return {
      organizationId:
        request.organizationId.trim(),

      workspaceId:
        request.workspaceId.trim(),

      userId:
        request.userId?.trim(),

      counts: {
        commands:
          commands.length,
        missions:
          missions.length,
        tasks:
          tasks.length,
        executions:
          executions.length,
        verifications:
          verifications.length,
        evidence:
          evidence.length,
        memories:
          memories.length,
        approvals:
          approvals.length,
        auditEvents:
          auditEvents.length,
      },

      recentCommands:
        recent(commands),

      activeMissions:
        recent(
          activeMissions,
        ),

      recentTasks:
        recent(tasks),

      recentExecutions:
        recent(executions),

      recentVerifications:
        recent(verifications),

      recentEvidence:
        recent(evidence),

      pendingApprovals:
        recent(
          pendingApprovals,
        ),

      recentAuditEvents:
        recent(
          auditEvents,
        ),

      generatedAt:
        new Date().toISOString(),
    };
  }
}
