import type { EntityType } from "../persistence/types";
import type { ScopedRecord } from "../state/types";
import type {
    WorkspaceMemorySummary,
    WorkspaceMissionSummary,
    WorkspaceTaskSummary,
    WorkspaceTimelineEvent,
    WorkspaceVerificationSummary,
} from "./types";

type UnknownRecord = Record<string, unknown>;

export interface LiveWorkspaceTenant {
    organizationId: string;
    workspaceId: string;
    userId: string;
}

export interface LiveWorkspaceMetrics {
    commandCount: number;
    missionCount: number;
    activeMissionCount: number;
    taskCount: number;
    completedTaskCount: number;
    readyTaskCount: number;
    executionCount: number;
    verificationCount: number;
    passedVerificationCount: number;
    evidenceCount: number;
    memoryCount: number;
    approvalCount: number;
}

export interface LiveWorkspaceDashboard {
    source: "FILE_PERSISTENCE";
    durable: true;
    tenant: LiveWorkspaceTenant;
    metrics: LiveWorkspaceMetrics;
    currentMission?: WorkspaceMissionSummary;
    missionQueue: WorkspaceMissionSummary[];
    readyTasks: WorkspaceTaskSummary[];
    timeline: WorkspaceTimelineEvent[];
    memory: WorkspaceMemorySummary;
    verifications: WorkspaceVerificationSummary[];
    generatedAt: string;
}

function asRecord(
    value: unknown,
): UnknownRecord | undefined {
    if (
        typeof value !== "object" ||
        value === null
    ) {
        return undefined;
    }

    return value as UnknownRecord;
}

function text(
    value: unknown,
    ...keys: string[]
): string | undefined {
    const record = asRecord(value);

    if (!record) {
        return undefined;
    }

    for (const key of keys) {
        const candidate = record[key];

        if (
            typeof candidate === "string" &&
            candidate.trim()
        ) {
            return candidate.trim();
        }
    }

    return undefined;
}

function numberValue(
    value: unknown,
    ...keys: string[]
): number | undefined {
    const record = asRecord(value);

    if (!record) {
        return undefined;
    }

    for (const key of keys) {
        const candidate = record[key];

        if (typeof candidate === "number" &&
            Number.isFinite(candidate)) {
            return candidate;
        }
    }

    return undefined;
}

function arrayValue(
    value: unknown,
    ...keys: string[]
): unknown[] {
    const record = asRecord(value);

    if (!record) {
        return [];
    }

    for (const key of keys) {
        const candidate = record[key];

        if (Array.isArray(candidate)) {
            return candidate;
        }
    }

    return [];
}

function recordTimestamp(
    record: ScopedRecord,
): string {
    return (
        record.updatedAt ||
        record.createdAt
    );
}

function recordStatus(
    record: ScopedRecord,
): string {
    return (
        text(
            record.data,
            "status",
            "state",
        ) ??
        "UNKNOWN"
    );
}

function recordTitle(
    record: ScopedRecord,
    fallback: string,
): string {
    return (
        text(
            record.data,
            "title",
            "goal",
            "command",
            "action",
            "description",
            "name",
            "eventType",
            "kind",
        ) ??
        fallback
    );
}

const TERMINAL_MISSION_STATUSES =
    new Set([
        "COMPLETED",
        "COMPLETE",
        "FAILED",
        "BLOCKED",
    ]);

const READY_TASK_STATUSES =
    new Set([
        "READY",
    ]);

const PASSED_VERIFICATION_STATUSES =
    new Set([
        "PASSED",
    ]);

function taskMissionId(
    record: ScopedRecord,
): string {
    return (
        text(
            record.data,
            "missionId",
            "activeMissionId",
        ) ??
        ""
    );
}

function buildTaskSummaries(
    tasks: ScopedRecord[],
): WorkspaceTaskSummary[] {
    return tasks
        .map((record, index) => {
            const dependencies =
                arrayValue(
                    record.data,
                    "dependencies",
                    "dependencyIds",
                );

            return {
                taskId: record.id,
                missionId:
                    taskMissionId(record),
                title:
                    recordTitle(
                        record,
                        `Task ${index + 1}`,
                    ),
                status:
                    recordStatus(record),
                order:
                    numberValue(
                        record.data,
                        "order",
                        "sequence",
                    ) ??
                    index,
                dependencyCount:
                    numberValue(
                        record.data,
                        "dependencyCount",
                    ) ??
                    dependencies.length,
            };
        })
        .sort(
            (a, b) =>
                a.order - b.order,
        );
}

function buildMissionSummaries(
    missions: ScopedRecord[],
    tasks: WorkspaceTaskSummary[],
): WorkspaceMissionSummary[] {
    return missions
        .map((record) => {
            const missionTasks =
                tasks.filter(
                    (task) =>
                        task.missionId ===
                        record.id,
                );

            const completedTaskCount =
                missionTasks.filter(
                    (task) =>
                        task.status ===
                            "COMPLETED" ||
                        task.status ===
                            "COMPLETE",
                ).length;

            const failedTaskCount =
                missionTasks.filter(
                    (task) =>
                        task.status ===
                        "FAILED",
                ).length;

            const blockedTaskCount =
                missionTasks.filter(
                    (task) =>
                        task.status ===
                        "BLOCKED",
                ).length;

            const explicitProgress =
                numberValue(
                    record.data,
                    "progressPercent",
                );

            const derivedProgress =
                missionTasks.length > 0
                    ? Math.round(
                        (
                            completedTaskCount /
                            missionTasks.length
                        ) *
                        100,
                    )
                    : 0;

            return {
                missionId:
                    record.id,
                goal:
                    recordTitle(
                        record,
                        "Untitled mission",
                    ),
                status:
                    recordStatus(record),
                progressPercent:
                    Math.max(
                        0,
                        Math.min(
                            100,
                            Math.round(
                                explicitProgress ??
                                derivedProgress,
                            ),
                        ),
                    ),
                taskCount:
                    missionTasks.length,
                completedTaskCount,
                failedTaskCount,
                blockedTaskCount,
            };
        })
        .sort(
            (a, b) =>
                b.progressPercent -
                a.progressPercent,
        );
}

function buildVerificationSummaries(
    verifications: ScopedRecord[],
): WorkspaceVerificationSummary[] {
    return verifications
        .map((record) => {
            const evidenceIds =
                arrayValue(
                    record.data,
                    "evidenceIds",
                );

            return {
                verificationId:
                    record.id,
                missionId:
                    text(
                        record.data,
                        "missionId",
                    ) ??
                    "",
                taskId:
                    text(
                        record.data,
                        "taskId",
                    ),
                status:
                    recordStatus(record),
                confidence:
                    text(
                        record.data,
                        "confidence",
                    ),
                evidenceCount:
                    numberValue(
                        record.data,
                        "evidenceCount",
                    ) ??
                    evidenceIds.length,
            };
        })
        .sort(
            (a, b) =>
                a.verificationId.localeCompare(
                    b.verificationId,
                ),
        );
}

function buildTimeline(
    collections: Array<{
        type: WorkspaceTimelineEvent["type"];
        records: ScopedRecord[];
    }>,
): WorkspaceTimelineEvent[] {
    const events: WorkspaceTimelineEvent[] =
        [];

    for (const collection of collections) {
        for (const record of collection.records) {
            events.push({
                id: record.id,
                type: collection.type,
                title:
                    recordTitle(
                        record,
                        record.entityType,
                    ),
                description:
                    text(
                        record.data,
                        "description",
                        "message",
                        "error",
                    ),
                timestamp:
                    recordTimestamp(record),
                status:
                    recordStatus(record),
                referenceId:
                    record.id,
            });
        }
    }

    return events
        .sort(
            (a, b) =>
                b.timestamp.localeCompare(
                    a.timestamp,
                ),
        )
        .slice(0, 25);
}

function buildMemorySummary(
    memories: ScopedRecord[],
): WorkspaceMemorySummary {
    const summary: WorkspaceMemorySummary =
        {
            total: memories.length,
            user: 0,
            project: 0,
            mission: 0,
            task: 0,
            session: 0,
        };

    for (const memory of memories) {
        const scope =
            (
                text(
                    memory.data,
                    "scope",
                    "memoryScope",
                    "type",
                ) ??
                ""
            ).toUpperCase();

        if (scope === "USER") {
            summary.user += 1;
        }

        if (scope === "PROJECT") {
            summary.project += 1;
        }

        if (scope === "MISSION") {
            summary.mission += 1;
        }

        if (scope === "TASK") {
            summary.task += 1;
        }

        if (scope === "SESSION") {
            summary.session += 1;
        }
    }

    return summary;
}

function countEntity(
    records: ScopedRecord[],
    predicate?: (
        record: ScopedRecord,
    ) => boolean,
): number {
    if (!predicate) {
        return records.length;
    }

    return records.filter(
        predicate,
    ).length;
}

export function buildLiveWorkspaceDashboard(
    tenant: LiveWorkspaceTenant,
    collections: {
        commands: ScopedRecord[];
        missions: ScopedRecord[];
        tasks: ScopedRecord[];
        executions: ScopedRecord[];
        verifications: ScopedRecord[];
        evidence: ScopedRecord[];
        memories: ScopedRecord[];
        approvals: ScopedRecord[];
        auditEvents: ScopedRecord[];
    },
): LiveWorkspaceDashboard {
    const taskSummaries =
        buildTaskSummaries(
            collections.tasks,
        );

    const missionSummaries =
        buildMissionSummaries(
            collections.missions,
            taskSummaries,
        );

    const activeMissions =
        missionSummaries.filter(
            (mission) =>
                !TERMINAL_MISSION_STATUSES.has(
                    mission.status,
                ),
        );

    const currentMission =
        activeMissions[0];

    const readyTasks =
        taskSummaries.filter(
            (task) =>
                READY_TASK_STATUSES.has(
                    task.status,
                ),
        );

    const passedVerifications =
        collections.verifications.filter(
            (record) =>
                PASSED_VERIFICATION_STATUSES.has(
                    recordStatus(record),
                ),
        );

    const pendingApprovals =
        countEntity(
            collections.approvals,
            (record) =>
                new Set([
                    "WAITING_APPROVAL",
                    "PENDING",
                    "REQUESTED",
                ]).has(
                    recordStatus(record),
                ),
        );

    const timeline =
        buildTimeline([
            {
                type: "COMMAND",
                records:
                    collections.commands,
            },
            {
                type: "MISSION",
                records:
                    collections.missions,
            },
            {
                type: "TASK",
                records:
                    collections.tasks,
            },
            {
                type: "EXECUTION",
                records:
                    collections.executions,
            },
            {
                type: "VERIFICATION",
                records:
                    collections.verifications,
            },
            {
                type: "MEMORY",
                records:
                    collections.memories,
            },
            {
                type: "SYSTEM",
                records:
                    collections.auditEvents,
            },
        ]);

    return {
        source: "FILE_PERSISTENCE",
        durable: true,
        tenant,
        metrics: {
            commandCount:
                collections.commands.length,
            missionCount:
                collections.missions.length,
            activeMissionCount:
                activeMissions.length,
            taskCount:
                collections.tasks.length,
            completedTaskCount:
                countEntity(
                    collections.tasks,
                    (record) => {
                        const status =
                            recordStatus(record);

                        return (
                            status === "COMPLETED" ||
                            status === "COMPLETE"
                        );
                    },
                ),
            readyTaskCount:
                readyTasks.length,
            executionCount:
                collections.executions.length,
            verificationCount:
                collections.verifications.length,
            passedVerificationCount:
                passedVerifications.length,
            evidenceCount:
                collections.evidence.length,
            memoryCount:
                collections.memories.length,
            approvalCount:
                pendingApprovals,
        },
        currentMission,
        missionQueue:
            missionSummaries,
        readyTasks,
        timeline,
        memory:
            buildMemorySummary(
                collections.memories,
            ),
        verifications:
            buildVerificationSummaries(
                collections.verifications,
            ),
        generatedAt:
            new Date().toISOString(),
    };
}

export function entityTypeForTimeline(
    entityType: EntityType,
): WorkspaceTimelineEvent["type"] {
    if (entityType === "COMMAND") {
        return "COMMAND";
    }

    if (entityType === "MISSION") {
        return "MISSION";
    }

    if (entityType === "TASK") {
        return "TASK";
    }

    if (entityType === "EXECUTION") {
        return "EXECUTION";
    }

    if (entityType === "VERIFICATION") {
        return "VERIFICATION";
    }

    if (entityType === "MEMORY") {
        return "MEMORY";
    }

    return "SYSTEM";
}
