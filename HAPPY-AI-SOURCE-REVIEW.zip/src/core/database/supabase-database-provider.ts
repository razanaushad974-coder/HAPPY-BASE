import {
  createClient,
} from "@supabase/supabase-js";

import type {
  AdapterStatus,
} from "../execution/types";

import type {
  DatabaseExecutionInput,
  DatabaseProvider,
} from "../execution/database-execution-adapter";

import {
  getSupabaseServerConfig,
} from "./supabase-server-config";

const SAFE_IDENTIFIER =
  /^[A-Za-z_][A-Za-z0-9_]*$/;

function validateResource(
  resource: string,
): string {
  const normalized = resource.trim();

  if (!SAFE_IDENTIFIER.test(normalized)) {
    throw new Error(
      `Invalid database resource identifier: ${resource}`,
    );
  }

  return normalized;
}

export class SupabaseDatabaseProvider
  implements DatabaseProvider
{
  private readonly url: string;
  private readonly publishableKey?: string;
  private readonly secretKey?: string;

  constructor() {
    const config =
      getSupabaseServerConfig();

    this.url = config.url;
    this.publishableKey =
      config.publishableKey;
    this.secretKey =
      config.secretKey;
  }

  status(): AdapterStatus {
    if (
      !this.url ||
      !this.publishableKey
    ) {
      return "NOT_YET_CONNECTED";
    }

    return "AVAILABLE";
  }

  private createUserClient(
    accessToken: string,
  ) {
    return createClient(
      this.url,
      this.publishableKey!,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
        global: {
          headers: {
            Authorization:
              `Bearer ${accessToken}`,
          },
        },
      },
    );
  }

  async execute(
    input: DatabaseExecutionInput,
  ): Promise<unknown> {
    if (!this.url) {
      throw new Error(
        "Supabase URL is not configured.",
      );
    }

    if (
      !this.publishableKey &&
      this.secretKey
    ) {
      throw new Error(
        "SUPABASE_SECRET_KEY is reserved for trusted server operations and cannot be used by the user database provider because it bypasses normal RLS enforcement.",
      );
    }

    if (!this.publishableKey) {
      throw new Error(
        "Supabase publishable key is not configured.",
      );
    }

    const accessToken =
      input.auth?.accessToken?.trim();

    if (!accessToken) {
      throw new Error(
        "Authenticated Supabase access token is required for DATABASE execution.",
      );
    }

    const client =
      this.createUserClient(
        accessToken,
      );

    const userResult =
      await client.auth.getUser(
        accessToken,
      );

    if (userResult.error) {
      throw new Error(
        `Supabase authentication failed: ${userResult.error.message}`,
      );
    }

    const authenticatedUser =
      userResult.data.user;

    if (!authenticatedUser) {
      throw new Error(
        "Supabase authentication returned no user.",
      );
    }

    if (
      !input.scope ||
      typeof input.scope !== "object"
    ) {
      throw new Error(
        "Database tenant scope is required for DATABASE execution.",
      );
    }

    if (
      input.scope.userId &&
      input.scope.userId !==
        authenticatedUser.id
    ) {
      throw new Error(
        "Database tenant user scope does not match the authenticated Supabase user.",
      );
    }

    const resource =
      validateResource(
        input.resource,
      );

    switch (input.action) {
      case "DB_SELECT": {
        let query = client
          .from(resource)
          .select("*");

        if (input.filter) {
          for (
            const [key, value]
            of Object.entries(
              input.filter,
            )
          ) {
            if (
              typeof value === "string" ||
              typeof value === "number" ||
              typeof value === "boolean"
            ) {
              query = query.eq(
                key,
                value,
              );
            }
          }
        }

        if (
          typeof input.limit === "number" &&
          input.limit > 0
        ) {
          query = query.limit(
            Math.min(
              Math.floor(input.limit),
              1000,
            ),
          );
        }

        const {
          data,
          error,
        } = await query;

        if (error) {
          throw new Error(
            `Supabase SELECT failed: ${error.message}`,
          );
        }

        return {
          rows: data ?? [],
          rowCount:
            Array.isArray(data)
              ? data.length
              : 0,
        };
      }

      case "DB_INSERT": {
        const {
          data,
          error,
        } = await client
          .from(resource)
          .insert(
            input.values ?? {},
          )
          .select();

        if (error) {
          throw new Error(
            `Supabase INSERT failed: ${error.message}`,
          );
        }

        return {
          rows: data ?? [],
          rowCount:
            Array.isArray(data)
              ? data.length
              : 0,
        };
      }

      case "DB_UPDATE": {
        let query = client
          .from(resource)
          .update(
            input.values ?? {},
          );

        if (input.filter) {
          for (
            const [key, value]
            of Object.entries(
              input.filter,
            )
          ) {
            if (
              typeof value === "string" ||
              typeof value === "number" ||
              typeof value === "boolean"
            ) {
              query = query.eq(
                key,
                value,
              );
            }
          }
        }

        const {
          data,
          error,
        } = await query.select();

        if (error) {
          throw new Error(
            `Supabase UPDATE failed: ${error.message}`,
          );
        }

        return {
          rows: data ?? [],
          rowCount:
            Array.isArray(data)
              ? data.length
              : 0,
        };
      }

      case "DB_DELETE": {
        let query = client
          .from(resource)
          .delete();

        if (input.filter) {
          for (
            const [key, value]
            of Object.entries(
              input.filter,
            )
          ) {
            if (
              typeof value === "string" ||
              typeof value === "number" ||
              typeof value === "boolean"
            ) {
              query = query.eq(
                key,
                value,
              );
            }
          }
        }

        const {
          data,
          error,
        } = await query.select();

        if (error) {
          throw new Error(
            `Supabase DELETE failed: ${error.message}`,
          );
        }

        return {
          rows: data ?? [],
          rowCount:
            Array.isArray(data)
              ? data.length
              : 0,
        };
      }

      case "DB_QUERY":
        throw new Error(
          "Raw DB_QUERY is intentionally unavailable until the approved query/RLS layer is implemented.",
        );

      case "DB_TRANSACTION":
        throw new Error(
          "DB_TRANSACTION is intentionally unavailable until the transactional provider layer is implemented.",
        );

      default:
        throw new Error(
          `Unsupported database action: ${input.action}`,
        );
    }
  }
}

