export interface SupabaseServerConfig {
  url: string;
  secretKey?: string;
  publishableKey?: string;
}

export function getSupabaseServerConfig(): SupabaseServerConfig {
  return {
    url:
      process.env.SUPABASE_URL ??
      process.env.NEXT_PUBLIC_SUPABASE_URL ??
      "",
    secretKey:
      process.env.SUPABASE_SECRET_KEY ||
      undefined,
    publishableKey:
      process.env.SUPABASE_PUBLISHABLE_KEY ||
      process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
      undefined,
  };
}
