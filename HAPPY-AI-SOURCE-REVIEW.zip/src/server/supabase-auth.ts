import {
  createClient,
  type SupabaseClient,
  type User,
} from "@supabase/supabase-js";

export type SupabaseAuthStatus =
  | "AVAILABLE"
  | "NOT_YET_CONNECTED"
  | "UNAUTHENTICATED"
  | "ERROR";

export interface AuthenticatedUser {
  id: string;
  email?: string;
  role?: string;
  metadata: Record<string, unknown>;
}

export interface AuthenticatedScopeInput {
  organizationId: string;
  workspaceId: string;
  userId: string;
}

function readSupabaseUrl(
  env: NodeJS.ProcessEnv = process.env,
): string | undefined {
  return (
    env.NEXT_PUBLIC_SUPABASE_URL?.trim() ||
    env.SUPABASE_URL?.trim()
  );
}

function readSupabaseKey(
  env: NodeJS.ProcessEnv = process.env,
): string | undefined {
  return (
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim() ||
    env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY?.trim() ||
    env.SUPABASE_PUBLISHABLE_KEY?.trim()
  );
}

export function isSupabaseAuthConfigured(
  env: NodeJS.ProcessEnv = process.env,
): boolean {
  return Boolean(
    readSupabaseUrl(env) &&
      readSupabaseKey(env),
  );
}

export function createServerSupabaseAuthClient(
  env: NodeJS.ProcessEnv = process.env,
): SupabaseClient | undefined {
  const url = readSupabaseUrl(env);
  const key = readSupabaseKey(env);

  if (!url || !key) {
    return undefined;
  }

  return createClient(url, key, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
      detectSessionInUrl: false,
    },
  });
}

export function extractBearerToken(
  authorizationHeader: string | null,
): string | undefined {
  if (!authorizationHeader) {
    return undefined;
  }

  const value = authorizationHeader.trim();

  if (!value) {
    return undefined;
  }

  const match =
    /^Bearer\s+(.+)$/i.exec(value);

  if (!match) {
    return undefined;
  }

  const token = match[1]?.trim();

  return token || undefined;
}

function mapUser(user: User): AuthenticatedUser {
  const rawRole = user.role;

  return {
    id: user.id,
    email: user.email,
    role:
      typeof rawRole === "string"
        ? rawRole
        : undefined,
    metadata:
      user.user_metadata &&
      typeof user.user_metadata === "object"
        ? user.user_metadata
        : {},
  };
}

export async function resolveSupabaseUser(
  accessToken: string,
  client?: SupabaseClient,
): Promise<AuthenticatedUser> {
  if (!accessToken.trim()) {
    throw new Error("UNAUTHENTICATED");
  }

  const supabase =
    client ??
    createServerSupabaseAuthClient();

  if (!supabase) {
    throw new Error("NOT_YET_CONNECTED");
  }

  const { data, error } =
    await supabase.auth.getUser(
      accessToken,
    );

  if (error || !data.user) {
    throw new Error(
      `UNAUTHENTICATED:${error?.message ?? "No user returned."}`,
    );
  }

  return mapUser(data.user);
}

export async function requireSupabaseUser(
  authorizationHeader: string | null,
  client?: SupabaseClient,
): Promise<AuthenticatedUser> {
  const accessToken =
    extractBearerToken(
      authorizationHeader,
    );

  if (!accessToken) {
    throw new Error("UNAUTHENTICATED");
  }

  return resolveSupabaseUser(
    accessToken,
    client,
  );
}

export function assertAuthenticatedScope(
  scope: AuthenticatedScopeInput,
  authenticatedUserId: string,
): void {
  if (!scope.organizationId.trim()) {
    throw new Error("organizationId is required");
  }

  if (!scope.workspaceId.trim()) {
    throw new Error("workspaceId is required");
  }

  if (!scope.userId.trim()) {
    throw new Error("userId is required");
  }

  if (
    scope.userId !==
    authenticatedUserId
  ) {
    throw new Error(
      "USER_SCOPE_VIOLATION",
    );
  }
}

export function classifySupabaseAuthError(
  error: unknown,
): SupabaseAuthStatus {
  const message =
    error instanceof Error
      ? error.message
      : String(error);

  if (
    message === "NOT_YET_CONNECTED"
  ) {
    return "NOT_YET_CONNECTED";
  }

  if (
    message === "UNAUTHENTICATED" ||
    message.startsWith("UNAUTHENTICATED:")
  ) {
    return "UNAUTHENTICATED";
  }

  return "ERROR";
}
