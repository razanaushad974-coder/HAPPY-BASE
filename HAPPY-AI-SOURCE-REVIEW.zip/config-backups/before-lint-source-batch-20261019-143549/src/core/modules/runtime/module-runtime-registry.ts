import { ModuleDataStore } from "../data/module-data-store";

export type ModuleRuntimeStatus =
  | "DATA_READY"
  | "ROUTING_ONLY"
  | "NOT_YET_CONNECTED"
  | "BLOCKED";

export interface ModuleRuntimeDescriptor {
  number: number;
  id: string;
  name: string;
  capability: string;
  runtimeStatus: ModuleRuntimeStatus;
}

export interface ModuleRuntimeRecord {
  module: ModuleRuntimeDescriptor;
  dataStore: ModuleDataStore;
}

export class ModuleRuntimeRegistry {
  private readonly records = new Map<number, ModuleRuntimeRecord>();

  register(module: ModuleRuntimeDescriptor): void {
    if (
      !Number.isInteger(module.number) ||
      module.number < 1 ||
      module.number > 502
    ) {
      throw new Error("Module number must be within 1..502");
    }

    if (this.records.has(module.number)) {
      throw new Error(`Module ${module.number} already registered`);
    }

    this.records.set(module.number, {
      module: { ...module },
      dataStore: new ModuleDataStore(),
    });
  }

  registerMany(modules: ModuleRuntimeDescriptor[]): void {
    for (const module of modules) {
      this.register(module);
    }
  }

  get(moduleNumber: number): ModuleRuntimeRecord | null {
    return this.records.get(moduleNumber) ?? null;
  }

  has(moduleNumber: number): boolean {
    return this.records.has(moduleNumber);
  }

  count(): number {
    return this.records.size;
  }

  statuses(): Record<ModuleRuntimeStatus, number> {
    const result: Record<ModuleRuntimeStatus, number> = {
      DATA_READY: 0,
      ROUTING_ONLY: 0,
      NOT_YET_CONNECTED: 0,
      BLOCKED: 0,
    };

    for (const { module } of this.records.values()) {
      result[module.runtimeStatus] += 1;
    }

    return result;
  }

  all(): ModuleRuntimeDescriptor[] {
    return [...this.records.values()].map(({ module }) => ({ ...module }));
  }
}
