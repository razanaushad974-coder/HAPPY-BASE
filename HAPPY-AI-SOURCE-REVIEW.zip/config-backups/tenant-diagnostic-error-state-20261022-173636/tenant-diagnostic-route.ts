import { NextResponse } from "next/server";
import { getAuthenticatedExecutionRuntimeContext } from "@/core/auth/supabase-runtime-context";
import { resolveTrustedFounderIdentity } from "@/core/founder/identity";
import { createSupabaseServerClient } from "../../../../lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        if (!runtimeContext.authenticatedUserId) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    authenticated: false,
                    error: "Authenticated Founder session is required.",
                },
                { status: 401 },
            );
        }

        const founderIdentity = resolveTrustedFounderIdentity(
            runtimeContext.authenticatedUserId,
        );

        if (founderIdentity.status !== "ALLOW") {
            return NextResponse.json(
                {
                    status: founderIdentity.status,
                    authenticated: true,
                    error: "Trusted Founder authorization is required.",
                },
                { status: 403 },
            );
        }

        const supabase = await createSupabaseServerClient();
        const userId = runtimeContext.authenticatedUserId;

        const [
            { data: organizations, error: organizationsError },
            { data: workspaces, error: workspacesError },
        ] = await Promise.all([
            supabase
                .from("organizations")
                .select("id,name,slug,owner_user_id,created_at,updated_at")
                .eq("owner_user_id", userId),
            supabase
                .from("workspaces")
                .select("id,organization_id,name,slug,owner_user_id,created_at,updated_at")
                .eq("owner_user_id", userId),
        ]);

        if (organizationsError || workspacesError) {
            return NextResponse.json(
                {
                    status: "LIVE_TENANT_READ_ERROR",
                    authenticated: true,
                    error: "Tenant diagnostic query failed.",
                    organizationsError: Boolean(organizationsError),
                    workspacesError: Boolean(workspacesError),
                },
                { status: 502 },
            );
        }

        return NextResponse.json({
            status: "LIVE_TENANT_READ",
            authenticated: true,
            userId,
            organizations: organizations ?? [],
            organizationsError: null,
            workspaces: workspaces ?? [],
            workspacesError: null,
        });
    } catch {
        return NextResponse.json(
            {
                status: "LIVE_TENANT_DIAGNOSTIC_ERROR",
                authenticated: false,
                error: "Tenant diagnostic failed.",
            },
            { status: 500 },
        );
    }
}
