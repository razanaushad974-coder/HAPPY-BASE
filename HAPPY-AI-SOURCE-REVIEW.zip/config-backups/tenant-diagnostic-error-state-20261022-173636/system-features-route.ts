import { NextResponse } from "next/server";
import { getAuthenticatedExecutionRuntimeContext } from "@/core/auth/supabase-runtime-context";
import { resolveTrustedFounderIdentity } from "@/core/founder/identity";
import {
    countHappyFeatures,
    countHappyFeaturesByState,
    getHappyFeature,
    getHappyFeatureState,
    getHappyFeatureContract,
    isHappyFeatureReady,
    isHappyFeatureVerificationRequired,
    listHappyFeatures,
    resolveHappyFeatureDependencyGraph,
} from "@/core/happy/kernel/feature-registry";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();
        const userId = runtimeContext.authenticatedUserId;

        if (!userId) {
            return NextResponse.json(
                { status: "UNAUTHENTICATED", error: "Authentication required." },
                { status: 401 },
            );
        }

        const founderIdentity = resolveTrustedFounderIdentity(userId);

        if (founderIdentity.status !== "ALLOW") {
            const statusCode =
                founderIdentity.status === "NOT_YET_CONNECTED" ? 503 : 403;

            return NextResponse.json(
                {
                    status: founderIdentity.status,
                    error:
                        statusCode === 503
                            ? "Founder authorization is not configured."
                            : "Founder access required.",
                },
                { status: statusCode },
            );
        }

        const featureId = new URL(request.url).searchParams.get("id");

        return NextResponse.json({
            status: "AVAILABLE",
            system: "HAPPY AI",
            total: countHappyFeatures(),
            byState: countHappyFeaturesByState(),
            features: listHappyFeatures(),
            dependencyGraph: featureId
                ? resolveHappyFeatureDependencyGraph(featureId)
                : [],
            requestedFeature: featureId ? getHappyFeature(featureId) ?? null : null,
            requestedFeatureState: featureId ? getHappyFeatureState(featureId) : null,
            requestedFeatureContract: featureId
                ? getHappyFeatureContract(featureId) ?? null
                : null,
            requestedFeatureReady: featureId
                ? isHappyFeatureReady(featureId)
                : false,
            requestedFeatureVerificationRequired: featureId
                ? isHappyFeatureVerificationRequired(featureId)
                : false,
        });
    } catch {
        return NextResponse.json(
            { status: "ERROR", error: "Feature catalog request failed." },
            { status: 500 },
        );
    }
}
