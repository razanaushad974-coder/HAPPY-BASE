import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
    getRuntime: vi.fn(),
    resolveFounder: vi.fn(),
    createSupabase: vi.fn(),
    from: vi.fn(),
    orgEq: vi.fn(),
    workspaceEq: vi.fn(),
}));

vi.mock("@/core/auth/supabase-runtime-context", () => ({
    getAuthenticatedExecutionRuntimeContext: mocks.getRuntime,
}));

vi.mock("@/core/founder/identity", () => ({
    resolveTrustedFounderIdentity: mocks.resolveFounder,
}));

vi.mock("@/lib/supabase/server", () => ({
    createSupabaseServerClient: mocks.createSupabase,
}));

import { GET } from "@/app/api/system/tenant-diagnostic/route";

describe("GET /api/system/tenant-diagnostic security", () => {
    beforeEach(() => {
        vi.clearAllMocks();

        mocks.getRuntime.mockResolvedValue({
            authenticatedUserId: "founder-test-user",
        });
        mocks.resolveFounder.mockReturnValue({ status: "ALLOW" });

        mocks.orgEq.mockResolvedValue({
            data: [{ id: "org-test", owner_user_id: "founder-test-user" }],
            error: null,
        });
        mocks.workspaceEq.mockResolvedValue({
            data: [{ id: "workspace-test", owner_user_id: "founder-test-user" }],
            error: null,
        });

        mocks.from.mockImplementation((table: string) => ({
            select: vi.fn(() => ({
                eq: table === "organizations" ? mocks.orgEq : mocks.workspaceEq,
            })),
        }));

        mocks.createSupabase.mockResolvedValue({ from: mocks.from });
    });

    it("returns 401 and performs no database reads when unauthenticated", async () => {
        mocks.getRuntime.mockResolvedValue({});
        const response = await GET();

        expect(response.status).toBe(401);
        expect(mocks.resolveFounder).not.toHaveBeenCalled();
        expect(mocks.createSupabase).not.toHaveBeenCalled();
    });

    it("returns 403 and performs no database reads for a non-Founder", async () => {
        mocks.resolveFounder.mockReturnValue({ status: "DENY" });
        const response = await GET();

        expect(response.status).toBe(403);
        expect(mocks.createSupabase).not.toHaveBeenCalled();
    });

    it("returns tenant data for an authorized Founder using owner-scoped reads", async () => {
        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body.status).toBe("LIVE_TENANT_READ");
        expect(body.userId).toBe("founder-test-user");
        expect(body.organizations[0].id).toBe("org-test");
        expect(body.workspaces[0].id).toBe("workspace-test");
        expect(mocks.from).toHaveBeenCalledWith("organizations");
        expect(mocks.from).toHaveBeenCalledWith("workspaces");
        expect(mocks.orgEq).toHaveBeenCalledWith("owner_user_id", "founder-test-user");
        expect(mocks.workspaceEq).toHaveBeenCalledWith("owner_user_id", "founder-test-user");
    });

    it("sanitizes database query errors", async () => {
        mocks.orgEq.mockResolvedValue({
            data: null,
            error: { message: "sensitive backend detail" },
        });

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(502);
        expect(body.error).toBe("Tenant diagnostic query failed.");
        expect(JSON.stringify(body)).not.toContain("sensitive backend detail");
    });

    it("returns a generic error when the diagnostic unexpectedly throws", async () => {
        mocks.createSupabase.mockRejectedValue(
            new Error("sensitive connection detail"),
        );

        const response = await GET();
        const body = await response.json();

        expect(response.status).toBe(500);
        expect(body.error).toBe("Tenant diagnostic failed.");
        expect(JSON.stringify(body)).not.toContain("sensitive connection detail");
    });
});
