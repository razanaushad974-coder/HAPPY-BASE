import assert from "node:assert/strict";

import {
  evaluateSafeShellRequest,
  getSafeShellAllowlist,
  getSafeShellMaxTimeoutMs,
} from "../../../core/execution/safe-shell-policy";
import {
  SafeShellExecutionAdapter,
  type SafeShellRunner,
} from "../../../core/execution/safe-shell-adapter";

function makeRequest(
  input: unknown,
): any {
  return {
    id: "shell-request-test",
    capability: "SHELL",
    action: "EXECUTE_SHELL",
    input,
    requiresApproval: false,
    approved: true,
  };
}

async function main(): Promise<void> {
  const workspaceRoot =
    process.cwd();

  const allowlist =
    getSafeShellAllowlist();

  assert.ok(
    allowlist.includes("node"),
  );

  assert.ok(
    allowlist.includes("npm.cmd"),
  );

  assert.equal(
    getSafeShellMaxTimeoutMs(),
    30000,
  );

  const safeReadOnly =
    evaluateSafeShellRequest({
      executable: "node",
      args: ["--version"],
      workspaceRoot,
    });

  assert.equal(
    safeReadOnly.status,
    "ALLOWED",
  );

  const mutationWithoutApproval =
    evaluateSafeShellRequest({
      executable: "npm",
      args: ["install", "some-package"],
      workspaceRoot,
      approved: false,
    });

  assert.equal(
    mutationWithoutApproval.status,
    "WAITING_APPROVAL",
  );

  const blockedExecutable =
    evaluateSafeShellRequest({
      executable: "curl",
      args: ["https://example.com"],
      workspaceRoot,
      approved: true,
    });

  assert.equal(
    blockedExecutable.status,
    "BLOCKED",
  );

  const blockedSyntax =
    evaluateSafeShellRequest({
      executable: "node",
      args: [
        "-e",
        "console.log(1); console.log(2)",
      ],
      workspaceRoot,
      approved: true,
    });

  assert.equal(
    blockedSyntax.status,
    "BLOCKED",
  );

  const outsideWorkspace =
    evaluateSafeShellRequest({
      executable: "node",
      args: ["--version"],
      cwd:
        require("node:path").resolve(
          workspaceRoot,
          "..",
        ),
      workspaceRoot,
    });

  assert.equal(
    outsideWorkspace.status,
    "BLOCKED",
  );

  const timeoutBound =
    evaluateSafeShellRequest({
      executable: "node",
      args: ["--version"],
      workspaceRoot,
      timeoutMs: 999999,
    });

  assert.equal(
    timeoutBound.timeoutMs,
    30000,
  );

  let captured:
    | {
        executable: string;
        args: string[];
        shell: boolean | undefined;
        timeout: number | undefined;
      }
    | undefined;

  const fakeRunner:
    SafeShellRunner =
    async (
      executable,
      args,
      options,
    ) => {
      captured = {
        executable,
        args,
        shell: typeof options.shell === "boolean" ? options.shell : undefined,
        timeout:
          typeof options.timeout ===
          "number"
            ? options.timeout
            : undefined,
      };

      return {
        stdout: "FAKE_SHELL_OK",
        stderr: "",
      };
    };

  const disabledAdapter =
    new SafeShellExecutionAdapter(
      fakeRunner,
      false,
    );

  assert.equal(
    disabledAdapter.status(),
    "BLOCKED",
  );

  const blockedResult =
    await disabledAdapter.execute(
      makeRequest({
        executable: "node",
        args: ["--version"],
        workspaceRoot,
      }),
    );

  assert.equal(
    (blockedResult as any).status,
    "BLOCKED",
  );

  const enabledAdapter =
    new SafeShellExecutionAdapter(
      fakeRunner,
      true,
    );

  assert.equal(
    enabledAdapter.status(),
    "AVAILABLE",
  );

  const completedResult =
    await enabledAdapter.execute(
      makeRequest({
        executable: "node",
        args: ["--version"],
        workspaceRoot,
        timeoutMs: 5000,
      }),
    );

  assert.equal(
    (completedResult as any).status,
    "COMPLETED",
  );

  assert.ok(captured);

  assert.equal(
    captured?.executable,
    "node",
  );

  assert.deepEqual(
    captured?.args,
    ["--version"],
  );

  assert.equal(
    captured?.shell,
    false,
  );

  assert.equal(
    captured?.timeout,
    5000,
  );

  console.log(
    "Safe-shell executable allowlist: PASS",
  );

  console.log(
    "Read-only shell classification: PASS",
  );

  console.log(
    "Approval requirement for mutating commands: PASS",
  );

  console.log(
    "Shell metacharacter rejection: PASS",
  );

  console.log(
    "Workspace-bound working directory: PASS",
  );

  console.log(
    "30-second maximum timeout: PASS",
  );

  console.log(
    "Explicit safe-shell enable gate: PASS",
  );

  console.log(
    "shell:false enforcement: PASS",
  );

  console.log(
    "Injected-runner execution contract: PASS",
  );

  console.log(
    "#24 safe-shell execution test: PASS",
  );
}

main().catch(
  (error: unknown) => {
    console.error(error);
    throw error;
  },
);
