import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";

export default defineConfig({
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
  },
  test: {
    include: ["src/tests/core/workspace/supabase-tenant-resolver-readonly.test.ts"],
    environment: "node",
    reporters: ["basic"],
    maxWorkers: 1,
    minWorkers: 1,
  },
});
