import {
  execFile,
  type ExecFileOptions,
} from "node:child_process";
import type {
  AdapterStatus,
  ExecutionRequest,
  ExecutionResult,
  ExecutionStatus,
} from "./types";
import {
  evaluateSafeShellRequest,
  type SafeShellRequest,
} from "./safe-shell-policy";

export type SafeShellExecutionInput = SafeShellRequest;

export interface SafeShellExecutionOutput {
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number;
}

export type SafeShellRunner = (
  executable: string,
  args: string[],
  options: ExecFileOptions,
) => Promise<{
  stdout: string;
  stderr: string;
}>;

function now(): string {
  return new Date().toISOString();
}

function createResult(
  request: ExecutionRequest,
  status: ExecutionStatus,
  startedAt: string,
  output?: unknown,
  error?: string,
): ExecutionResult {
  return {
    id: crypto.randomUUID(),
    requestId: request.id,
    capability: "SHELL",
    status,
    output,
    error,
    evidenceIds: [],
    startedAt,
    completedAt: now(),
  };
}

function defaultRunner(
  executable: string,
  args: string[],
  options: ExecFileOptions,
): Promise<{
  stdout: string;
  stderr: string;
}> {
  return new Promise(
    (resolve, reject) => {
      execFile(
        executable,
        args,
        {
          ...options,
          shell: false,
          windowsHide: true,
        },
        (
          error,
          stdout,
          stderr,
        ) => {
          if (error) {
            const enriched =
              Object.assign(
                error,
                {
                  stdout,
                  stderr,
                },
              );

            reject(enriched);
            return;
          }

          resolve({
            stdout: String(stdout),
            stderr: String(stderr),
          });
        },
      );
    },
  );
}

function parseInput(
  value: unknown,
): SafeShellExecutionInput | undefined {
  if (
    !value ||
    typeof value !== "object"
  ) {
    return undefined;
  }

  const input =
    value as Partial<SafeShellExecutionInput>;

  if (
    typeof input.executable !== "string" ||
    typeof input.workspaceRoot !== "string"
  ) {
    return undefined;
  }

  if (
    input.args !== undefined &&
    !Array.isArray(input.args)
  ) {
    return undefined;
  }

  return {
    executable:
      input.executable,
    args:
      input.args?.map(String),
    cwd:
      input.cwd,
    timeoutMs:
      input.timeoutMs,
    approved:
      input.approved,
    workspaceRoot:
      input.workspaceRoot,
  };
}

export class SafeShellExecutionAdapter {
  readonly capability =
    "SHELL" as const;

  constructor(
    private readonly runner:
      SafeShellRunner = defaultRunner,
    private readonly enabled =
      process.env.HAPPY_ENABLE_SAFE_SHELL ===
      "true",
  ) {}

  status(): AdapterStatus {
    return this.enabled
      ? "AVAILABLE"
      : "BLOCKED";
  }

  canExecute(
    request: ExecutionRequest,
  ): boolean {
    const input =
      parseInput(request.input);

    if (!input) {
      return false;
    }

    const decision =
      evaluateSafeShellRequest(
        input,
      );

    return (
      this.enabled &&
      decision.status === "ALLOWED"
    );
  }

  async execute(
    request: ExecutionRequest,
  ): Promise<ExecutionResult> {
    const startedAt = now();

    const input =
      parseInput(request.input);

    if (!input) {
      return createResult(
        request,
        "BLOCKED",
        startedAt,
        undefined,
        "Invalid SAFE SHELL input.",
      );
    }

    if (!this.enabled) {
      return createResult(
        request,
        "BLOCKED",
        startedAt,
        undefined,
        "Safe SHELL execution is not explicitly enabled.",
      );
    }

    const decision =
      evaluateSafeShellRequest(
        input,
      );

    if (
      decision.status ===
      "WAITING_APPROVAL"
    ) {
      return createResult(
        request,
        "WAITING_APPROVAL",
        startedAt,
        undefined,
        decision.reason,
      );
    }

    if (
      decision.status !== "ALLOWED"
    ) {
      return createResult(
        request,
        "BLOCKED",
        startedAt,
        undefined,
        decision.reason,
      );
    }

    try {
      const started =
        Date.now();

      const result =
        await this.runner(
          decision.executable!,
          decision.normalizedArgs,
          {
            cwd: decision.cwd,
            timeout:
              decision.timeoutMs,
            shell: false,
            windowsHide: true,
            maxBuffer:
              2 * 1024 * 1024,
          },
        );

      return createResult(
        request,
        "COMPLETED",
        startedAt,
        {
          ...result,
          exitCode: 0,
          durationMs:
            Date.now() - started,
        },
      );
    } catch (error: unknown) {
      const enriched =
        error as {
          message?: string;
          stdout?: string;
          stderr?: string;
          code?: number;
        };

      return createResult(
        request,
        "FAILED",
        startedAt,
        {
          stdout:
            enriched.stdout ?? "",
          stderr:
            enriched.stderr ?? "",
          exitCode:
            typeof enriched.code ===
            "number"
              ? enriched.code
              : null,
        },
        enriched.message ??
          String(error),
      );
    }
  }
}
