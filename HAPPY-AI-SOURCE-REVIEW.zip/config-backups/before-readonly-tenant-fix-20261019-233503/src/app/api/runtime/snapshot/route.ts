import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

import {
    SupabaseRuntimeSnapshotStore,
} from "../../../../core/persistence/adapters/supabase-runtime-snapshot";

import {
    resolveRuntimeStateSource,
} from "../../../../core/integration/runtime-state-source";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function scopeKey(
    organizationId: string,
    workspaceId: string,
    userId: string,
): string {
    return [
        organizationId,
        workspaceId,
        userId,
    ].join("|");
}

async function getAuthenticatedSnapshotContext() {
    const runtimeContext =
        await getAuthenticatedExecutionRuntimeContext();

    if (
        !runtimeContext.authenticatedUserId ||
        !runtimeContext.supabaseAccessToken
    ) {
        return {
            kind: "unauthenticated" as const,
            response:
                NextResponse.json(
                    {
                        status:
                            "UNAUTHENTICATED",
                        error:
                            "Authenticated Supabase session is required.",
                    },
                    {
                        status: 401,
                    },
                ),
        };
    }

    const workspace =
        createAuthenticatedWorkspaceState(
            runtimeContext.authenticatedUserId,
        );

    const tenant =
        workspace.tenant;

    const supabase =
        await createSupabaseServerClient();

    const store =
        new SupabaseRuntimeSnapshotStore(
            supabase,
        );

    const localState =
        await workspace.store.snapshot();

    const source =
        resolveRuntimeStateSource(
            {
                authenticated: true,
                supabaseConfigured: true,
                localStateAvailable: true,
            },
        );

    return {
        kind: "authenticated" as const,
        runtimeContext,
        workspace,
        tenant,
        supabase,
        store,
        localState,
        source,
    };
}

function localFallbackResponse(
    context: {
        tenant: {
            organizationId: string;
            workspaceId: string;
            userId: string;
        };
        localState: unknown;
    },
    reason: string,
) {
    return NextResponse.json(
        {
            status: "LOCAL_FALLBACK",
            scopeKey:
                scopeKey(
                    context.tenant.organizationId,
                    context.tenant.workspaceId,
                    context.tenant.userId,
                ),
            version: null,
            createdAt: null,
            updatedAt: null,
            remotePersistence: "NOT_YET_CONNECTED",
            reason,
            snapshot:
                context.localState,
        },
        {
            status: 200,
        },
    );
}

export async function GET(): Promise<Response> {
    try {
        const context =
            await getAuthenticatedSnapshotContext();

        if (context.kind === "unauthenticated") {
            return context.response;
        }

        if (
            context.source.source ===
            "NOT_YET_CONNECTED"
        ) {
            return localFallbackResponse(
                context,
                context.source.reason,
            );
        }

        try {
            const snapshot =
                await context.store.load(
                    {
                        organizationId:
                            context.tenant.organizationId,
                        workspaceId:
                            context.tenant.workspaceId,
                        userId:
                            context.tenant.userId,
                    },
                );

            if (snapshot) {
                return NextResponse.json(
                    {
                        status: "AVAILABLE",
                        scopeKey:
                            snapshot.scopeKey,
                        version:
                            snapshot.version,
                        createdAt:
                            snapshot.createdAt,
                        updatedAt:
                            snapshot.updatedAt,
                        snapshot:
                            snapshot.state,
                    },
                    {
                        status: 200,
                    },
                );
            }

            return localFallbackResponse(
                context,
                "Remote snapshot not found; authenticated local state retained.",
            );
        }
        catch (remoteError: unknown) {
            const message =
                remoteError instanceof Error
                    ? remoteError.message
                    : "Remote runtime snapshot read failed.";

            return localFallbackResponse(
                context,
                "Remote runtime snapshot unavailable; local file-backed state retained. " +
                message,
            );
        }
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "Runtime snapshot read failed.";

        if (
            message.startsWith(
                "NOT_YET_CONNECTED",
            )
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_YET_CONNECTED",
                    error: message,
                },
                {
                    status: 503,
                },
            );
        }

        return NextResponse.json(
            {
                status: "ERROR",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}

export async function POST(): Promise<Response> {
    try {
        const context =
            await getAuthenticatedSnapshotContext();

        if (context.kind === "unauthenticated") {
            return context.response;
        }

        const state =
            context.localState;

        try {
            const snapshot =
                await context.store.save(
                    {
                        organizationId:
                            context.tenant.organizationId,
                        workspaceId:
                            context.tenant.workspaceId,
                        userId:
                            context.tenant.userId,
                    },
                    state,
                    1,
                );

            return NextResponse.json(
                {
                    status: "AVAILABLE",
                    scopeKey:
                        snapshot.scopeKey,
                    version:
                        snapshot.version,
                    createdAt:
                        snapshot.createdAt,
                    updatedAt:
                        snapshot.updatedAt,
                    remotePersistence:
                        "SUPABASE",
                    snapshot:
                        snapshot.state,
                },
                {
                    status: 200,
                },
            );
        }
        catch (remoteError: unknown) {
            const message =
                remoteError instanceof Error
                    ? remoteError.message
                    : "Remote runtime snapshot save failed.";

            return localFallbackResponse(
                context,
                "Remote runtime snapshot save unavailable; local file-backed state retained. " +
                message,
            );
        }
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "Runtime snapshot save failed.";

        if (
            message.startsWith(
                "NOT_YET_CONNECTED",
            )
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_YET_CONNECTED",
                    error: message,
                },
                {
                    status: 503,
                },
            );
        }

        return NextResponse.json(
            {
                status: "ERROR",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}