import { strict as assert } from "node:assert";

import {
    compareRuntimeStateSnapshots,
    resolveRuntimeStateSource,
} from "../../../core/integration/runtime-state-source";

function main(): void {
    const authenticatedRemote =
        resolveRuntimeStateSource(
            {
                authenticated: true,
                supabaseConfigured: true,
                localStateAvailable: true,
            },
        );

    assert.equal(
        authenticatedRemote.source,
        "SUPABASE",
    );

    assert.equal(
        authenticatedRemote.status,
        "REMOTE_PRIMARY",
    );

    const localFallback =
        resolveRuntimeStateSource(
            {
                authenticated: true,
                supabaseConfigured: false,
                localStateAvailable: true,
            },
        );

    assert.equal(
        localFallback.source,
        "FILE",
    );

    assert.equal(
        localFallback.status,
        "REMOTE_UNAVAILABLE",
    );

    const unauthenticatedLocal =
        resolveRuntimeStateSource(
            {
                authenticated: false,
                supabaseConfigured: true,
                localStateAvailable: true,
            },
        );

    assert.equal(
        unauthenticatedLocal.source,
        "FILE",
    );

    const disconnected =
        resolveRuntimeStateSource(
            {
                authenticated: false,
                supabaseConfigured: false,
                localStateAvailable: false,
            },
        );

    assert.equal(
        disconnected.source,
        "NOT_YET_CONNECTED",
    );

    const sharedMetadata = {
        version: 1,
        createdAt:
            "2026-09-20T00:00:00.000Z",
        updatedAt:
            "2026-09-20T00:05:00.000Z",
        scopeKey:
            "org-1|workspace-1|user-1",
    };

    const equalComparison =
        compareRuntimeStateSnapshots(
            sharedMetadata,
            sharedMetadata,
        );

    assert.equal(
        equalComparison.equal,
        true,
    );

    const driftedComparison =
        compareRuntimeStateSnapshots(
            sharedMetadata,
            {
                ...sharedMetadata,
                version: 2,
            },
        );

    assert.equal(
        driftedComparison.equal,
        false,
    );

    assert.equal(
        driftedComparison.reason.includes(
            "reconciliation is required",
        ),
        true,
    );

    const remoteOnlyComparison =
        compareRuntimeStateSnapshots(
            sharedMetadata,
            null,
        );

    assert.equal(
        remoteOnlyComparison.remoteAvailable,
        true,
    );

    assert.equal(
        remoteOnlyComparison.localAvailable,
        false,
    );

    const localOnlyComparison =
        compareRuntimeStateSnapshots(
            null,
            sharedMetadata,
        );

    assert.equal(
        localOnlyComparison.remoteAvailable,
        false,
    );

    assert.equal(
        localOnlyComparison.localAvailable,
        true,
    );

    console.log(
        "Authenticated Supabase primary source: PASS",
    );

    console.log(
        "Authenticated local fallback: PASS",
    );

    console.log(
        "Unauthenticated local safety boundary: PASS",
    );

    console.log(
        "NOT_YET_CONNECTED boundary: PASS",
    );

    console.log(
        "Equal snapshot reconciliation: PASS",
    );

    console.log(
        "Drift detection: PASS",
    );

    console.log(
        "Remote-only state detection: PASS",
    );

    console.log(
        "Local-only state detection: PASS",
    );

    console.log(
        "Runtime state reconciliation test: PASS",
    );
}

try {
    main();
} catch (error: unknown) {
    console.error(error);
    process.exitCode = 1;
}