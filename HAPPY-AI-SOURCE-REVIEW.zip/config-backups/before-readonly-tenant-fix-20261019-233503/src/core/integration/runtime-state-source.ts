export type RuntimeStateSourceKind =
    | "SUPABASE"
    | "FILE"
    | "NOT_YET_CONNECTED";

export type RuntimeStateReconciliationStatus =
    | "REMOTE_PRIMARY"
    | "LOCAL_FALLBACK"
    | "REMOTE_UNAVAILABLE"
    | "REQUIRES_RECONCILIATION";

export interface RuntimeStateSourceResolution {
    source: RuntimeStateSourceKind;
    status: RuntimeStateReconciliationStatus;
    authenticated: boolean;
    supabaseConfigured: boolean;
    localStateAvailable: boolean;
    reason: string;
}

export interface RuntimeStateSnapshotMetadata {
    version: number;
    createdAt: string;
    updatedAt: string;
    scopeKey: string;
}

export interface RuntimeStateComparison {
    equal: boolean;
    remoteAvailable: boolean;
    localAvailable: boolean;
    remoteUpdatedAt?: string;
    localUpdatedAt?: string;
    reason: string;
}

export function resolveRuntimeStateSource(
    input: {
        authenticated: boolean;
        supabaseConfigured: boolean;
        localStateAvailable: boolean;
    },
): RuntimeStateSourceResolution {
    if (
        input.authenticated &&
        input.supabaseConfigured
    ) {
        return {
            source: "SUPABASE",
            status: "REMOTE_PRIMARY",
            authenticated: true,
            supabaseConfigured: true,
            localStateAvailable:
                input.localStateAvailable,
            reason:
                "Authenticated Supabase runtime snapshots are the primary runtime source.",
        };
    }

    if (input.localStateAvailable) {
        return {
            source: "FILE",
            status:
                input.authenticated &&
                !input.supabaseConfigured
                    ? "REMOTE_UNAVAILABLE"
                    : "LOCAL_FALLBACK",
            authenticated:
                input.authenticated,
            supabaseConfigured:
                input.supabaseConfigured,
            localStateAvailable: true,
            reason:
                "Local file-backed state remains available as a safe fallback.",
        };
    }

    return {
        source: "NOT_YET_CONNECTED",
        status: "REMOTE_UNAVAILABLE",
        authenticated:
            input.authenticated,
        supabaseConfigured:
            input.supabaseConfigured,
        localStateAvailable: false,
        reason:
            "No authenticated remote state and no local state are available.",
    };
}

export function compareRuntimeStateSnapshots(
    remote:
        | RuntimeStateSnapshotMetadata
        | null,
    local:
        | RuntimeStateSnapshotMetadata
        | null,
): RuntimeStateComparison {
    if (!remote && !local) {
        return {
            equal: true,
            remoteAvailable: false,
            localAvailable: false,
            reason:
                "Neither remote nor local runtime snapshot exists.",
        };
    }

    if (!remote) {
        return {
            equal: false,
            remoteAvailable: false,
            localAvailable: true,
            localUpdatedAt:
                local!.updatedAt,
            reason:
                "Local runtime snapshot exists without remote counterpart.",
        };
    }

    if (!local) {
        return {
            equal: false,
            remoteAvailable: true,
            localAvailable: false,
            remoteUpdatedAt:
                remote.updatedAt,
            reason:
                "Remote runtime snapshot exists without local counterpart.",
        };
    }

    const equal =
        remote.scopeKey === local.scopeKey &&
        remote.version === local.version &&
        remote.updatedAt === local.updatedAt;

    if (equal) {
        return {
            equal: true,
            remoteAvailable: true,
            localAvailable: true,
            remoteUpdatedAt:
                remote.updatedAt,
            localUpdatedAt:
                local.updatedAt,
            reason:
                "Remote and local runtime snapshot metadata agree.",
        };
    }

    return {
        equal: false,
        remoteAvailable: true,
        localAvailable: true,
        remoteUpdatedAt:
            remote.updatedAt,
        localUpdatedAt:
            local.updatedAt,
        reason:
            "Remote and local runtime snapshot metadata differ; reconciliation is required.",
    };
}