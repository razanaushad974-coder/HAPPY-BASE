import type { SupabaseClient } from "@supabase/supabase-js";
import type { HappyState } from "../state";

export type SupabaseRuntimePersistenceStatus =
  | "AVAILABLE"
  | "NOT_YET_CONNECTED"
  | "ERROR";

export interface RuntimeSnapshotScope {
  organizationId: string;
  workspaceId: string;
  userId: string;
}

export interface RuntimeSnapshotRecord {
  scopeKey: string;
  organizationId: string;
  workspaceId: string;
  userId: string;
  state: HappyState;
  version: number;
  createdAt?: string;
  updatedAt?: string;
}

interface RuntimeSnapshotRow {
  scope_key: string;
  organization_id: string;
  workspace_id: string;
  user_id: string;
  state: HappyState;
  version: number;
  created_at?: string;
  updated_at?: string;
}

const DEFAULT_TABLE = "happy_runtime_snapshots";

function requireUuidScope(scope: RuntimeSnapshotScope): void {
  requireScope(scope);

  const uuidPattern =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  if (!uuidPattern.test(scope.organizationId)) {
    throw new Error("INVALID_SUPABASE_SCOPE: organizationId must be UUID-formatted.");
  }
  if (!uuidPattern.test(scope.workspaceId)) {
    throw new Error("INVALID_SUPABASE_SCOPE: workspaceId must be UUID-formatted.");
  }
  if (!uuidPattern.test(scope.userId)) {
    throw new Error("INVALID_SUPABASE_SCOPE: userId must be UUID-formatted.");
  }
}
function requireScope(scope: RuntimeSnapshotScope): void {
  if (!scope.organizationId.trim()) {
    throw new Error("organizationId is required");
  }

  if (!scope.workspaceId.trim()) {
    throw new Error("workspaceId is required");
  }

  if (!scope.userId.trim()) {
    throw new Error("userId is required");
  }
}

export function createRuntimeScopeKey(
  scope: RuntimeSnapshotScope,
): string {
  requireScope(scope);

  return [
    scope.organizationId,
    scope.workspaceId,
    scope.userId,
  ].join("|");
}

export function isSupabaseRuntimePersistenceConfigured(
  env: NodeJS.ProcessEnv = process.env,
): boolean {
  return Boolean(
    env.NEXT_PUBLIC_SUPABASE_URL?.trim() &&
      (
        env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim() ||
        env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY?.trim() ||
        env.SUPABASE_PUBLISHABLE_KEY?.trim()
      ),
  );
}

function mapRow(
  row: RuntimeSnapshotRow,
): RuntimeSnapshotRecord {
  return {
    scopeKey: row.scope_key,
    organizationId: row.organization_id,
    workspaceId: row.workspace_id,
    userId: row.user_id,
    state: structuredClone(row.state),
    version: Number(row.version),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export class SupabaseRuntimeSnapshotStore {
  constructor(
    private readonly client?: SupabaseClient,
    private readonly tableName: string = DEFAULT_TABLE,
  ) {}

  status(): SupabaseRuntimePersistenceStatus {
    return this.client
      ? "AVAILABLE"
      : "NOT_YET_CONNECTED";
  }

  async save(
    scope: RuntimeSnapshotScope,
    state: HappyState,
    version: number = 1,
  ): Promise<RuntimeSnapshotRecord> {
    if (!this.client) {
      throw new Error(
        "NOT_YET_CONNECTED: Supabase runtime persistence client is not connected.",
      );
    }

    requireUuidScope(scope);
    const scopeKey = createRuntimeScopeKey(scope);

    const row = {
      scope_key: scopeKey,
      organization_id: scope.organizationId,
      workspace_id: scope.workspaceId,
      user_id: scope.userId,
      state: structuredClone(state),
      version: Math.max(1, Math.trunc(version)),
    };

    const { data, error } = await this.client
      .from(this.tableName)
      .upsert(row, {
        onConflict: "scope_key",
      })
      .select("*")
      .single();

    if (error) {
      throw new Error(
        `SUPABASE_RUNTIME_SAVE_FAILED:${error.message}`,
      );
    }

    return mapRow(data as RuntimeSnapshotRow);
  }

  async load(
    scope: RuntimeSnapshotScope,
  ): Promise<RuntimeSnapshotRecord | undefined> {
    if (!this.client) {
      throw new Error(
        "NOT_YET_CONNECTED: Supabase runtime persistence client is not connected.",
      );
    }

    requireUuidScope(scope);
    const scopeKey = createRuntimeScopeKey(scope);

    const { data, error } = await this.client
      .from(this.tableName)
      .select("*")
      .eq("scope_key", scopeKey)
      .maybeSingle();

    if (error) {
      throw new Error(
        `SUPABASE_RUNTIME_LOAD_FAILED:${error.message}`,
      );
    }

    if (!data) {
      return undefined;
    }

    return mapRow(data as RuntimeSnapshotRow);
  }

  async clear(
    scope: RuntimeSnapshotScope,
  ): Promise<boolean> {
    if (!this.client) {
      throw new Error(
        "NOT_YET_CONNECTED: Supabase runtime persistence client is not connected.",
      );
    }

    requireUuidScope(scope);
    const scopeKey = createRuntimeScopeKey(scope);

    const { error } = await this.client
      .from(this.tableName)
      .delete()
      .eq("scope_key", scopeKey);

    if (error) {
      throw new Error(
        `SUPABASE_RUNTIME_DELETE_FAILED:${error.message}`,
      );
    }

    return true;
  }
}

