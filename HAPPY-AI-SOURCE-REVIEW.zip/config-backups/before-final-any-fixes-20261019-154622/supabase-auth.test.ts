import assert from "node:assert/strict";

import {
  assertAuthenticatedScope,
  classifySupabaseAuthError,
  createServerSupabaseAuthClient,
  extractBearerToken,
  isSupabaseAuthConfigured,
  requireSupabaseUser,
  resolveSupabaseUser,
} from "../../server/supabase-auth";

class FakeSupabaseClient {
  readonly auth = {
    getUser: async (token: string) => {
      if (token === "valid-test-token") {
        return {
          data: {
            user: {
              id: "supabase-user-1",
              email: "test@example.com",
              role: "authenticated",
              user_metadata: {
                name: "HAPPY Test",
              },
            },
          },
          error: null,
        };
      }

      return {
        data: {
          user: null,
        },
        error: {
          message: "Invalid JWT",
        },
      };
    },
  };
}

async function main(): Promise<void> {
  assert.equal(
    extractBearerToken(null),
    undefined,
  );

  assert.equal(
    extractBearerToken(""),
    undefined,
  );

  assert.equal(
    extractBearerToken(
      "Basic abc",
    ),
    undefined,
  );

  assert.equal(
    extractBearerToken(
      "Bearer valid-test-token",
    ),
    "valid-test-token",
  );

  assert.equal(
    isSupabaseAuthConfigured({
      NODE_ENV: "test",
    } as NodeJS.ProcessEnv),
    false,
  );

  assert.equal(
    isSupabaseAuthConfigured({
      NODE_ENV: "test",
      NEXT_PUBLIC_SUPABASE_URL:
        "https://example.supabase.co",
      NEXT_PUBLIC_SUPABASE_ANON_KEY:
        "test-key",
    } as NodeJS.ProcessEnv),
    true,
  );

  const noClient =
    createServerSupabaseAuthClient({
      NODE_ENV: "test",
    } as NodeJS.ProcessEnv);

  assert.equal(
    noClient,
    undefined,
  );

  const fakeClient =
    new FakeSupabaseClient();

  const resolved =
    await resolveSupabaseUser(
      "valid-test-token",
      fakeClient as any,
    );

  assert.equal(
    resolved.id,
    "supabase-user-1",
  );

  assert.equal(
    resolved.email,
    "test@example.com",
  );

  assert.equal(
    resolved.role,
    "authenticated",
  );

  assert.equal(
    resolved.metadata.name,
    "HAPPY Test",
  );

  const required =
    await requireSupabaseUser(
      "Bearer valid-test-token",
      fakeClient as any,
    );

  assert.equal(
    required.id,
    "supabase-user-1",
  );

  let unauthenticatedCaught =
    false;

  try {
    await requireSupabaseUser(
      null,
      fakeClient as any,
    );
  } catch (error) {
    unauthenticatedCaught =
      error instanceof Error &&
      error.message ===
        "UNAUTHENTICATED";
  }

  assert.equal(
    unauthenticatedCaught,
    true,
  );

  let invalidTokenCaught =
    false;

  try {
    await resolveSupabaseUser(
      "invalid-test-token",
      fakeClient as any,
    );
  } catch (error) {
    invalidTokenCaught =
      error instanceof Error &&
      error.message.startsWith(
        "UNAUTHENTICATED:",
      );
  }

  assert.equal(
    invalidTokenCaught,
    true,
  );

  assert.equal(
    classifySupabaseAuthError(
      new Error(
        "UNAUTHENTICATED",
      ),
    ),
    "UNAUTHENTICATED",
  );

  assert.equal(
    classifySupabaseAuthError(
      new Error(
        "NOT_YET_CONNECTED",
      ),
    ),
    "NOT_YET_CONNECTED",
  );

  assert.equal(
    classifySupabaseAuthError(
      new Error("other"),
    ),
    "ERROR",
  );

  assert.doesNotThrow(() => {
    assertAuthenticatedScope(
      {
        organizationId:
          "org-test",
        workspaceId:
          "workspace-test",
        userId:
          "supabase-user-1",
      },
      "supabase-user-1",
    );
  });

  let forgedScopeCaught =
    false;

  try {
    assertAuthenticatedScope(
      {
        organizationId:
          "org-test",
        workspaceId:
          "workspace-test",
        userId:
          "another-user",
      },
      "supabase-user-1",
    );
  } catch (error) {
    forgedScopeCaught =
      error instanceof Error &&
      error.message ===
        "USER_SCOPE_VIOLATION";
  }

  assert.equal(
    forgedScopeCaught,
    true,
  );

  console.log(
    "Bearer token extraction: PASS",
  );

  console.log(
    "Supabase configuration detection: PASS",
  );

  console.log(
    "Server Supabase client safety: PASS",
  );

  console.log(
    "Supabase authenticated-user resolution: PASS",
  );

  console.log(
    "Authenticated request boundary: PASS",
  );

  console.log(
    "Invalid token rejection: PASS",
  );

  console.log(
    "Unauthenticated request rejection: PASS",
  );

  console.log(
    "Authenticated user scope assertion: PASS",
  );

  console.log(
    "Forged user-scope rejection: PASS",
  );

  console.log(
    "#23 Supabase auth boundary test: PASS",
  );
}

main().catch((error: unknown) => {
  console.error(error);
  throw error;
});
