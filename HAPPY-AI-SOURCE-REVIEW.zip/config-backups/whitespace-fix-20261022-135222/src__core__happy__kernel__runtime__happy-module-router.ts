
import {
    bootstrapHappyMajorModules,
} from "../registry/happy-module-bootstrap";

import {
    HAPPY_MAJOR_MODULE_CATALOG,
    getHappyMajorModule,
} from "../registry/happy-major-module-catalog";

import {
    happyModuleRegistry,
    type HappyModuleDefinition,
} from "../registry/happy-module-runtime";

export type HappyModuleResolutionStatus =
    | "RESOLVED"
    | "NOT_FOUND"
    | "NOT_YET_CONNECTED";

export type HappyModuleAction =
    | "OPEN"
    | "READ"
    | "CREATE"
    | "UPDATE"
    | "DELETE"
    | "GENERATE"
    | "ANALYZE"
    | "EXECUTE"
    | "BUILD"
    | "TEST"
    | "CONNECT"
    | "CONFIGURE";

export interface HappyModuleResolution {
    readonly status:
        HappyModuleResolutionStatus;
    readonly module:
        HappyModuleDefinition | null;
    readonly action:
        HappyModuleAction;
    readonly confidence:
        number;
    readonly matchedBy:
        | "ID"
        | "NUMBER"
        | "NAME"
        | "CATEGORY"
        | "KEYWORD"
        | null;
    readonly query:
        string;
}

export interface HappyModuleRouter {
    resolve(
        query: string,
    ): HappyModuleResolution;

    resolveById(
        moduleId: string,
    ): HappyModuleResolution;

    resolveByNumber(
        moduleNumber: number,
    ): HappyModuleResolution;

    resolveByName(
        name: string,
    ): HappyModuleResolution;

    listMatching(
        query: string,
    ): readonly HappyModuleDefinition[];
}

function normalize(
    value: string,
): string {
    return value
        .trim()
        .toLowerCase()
        .replace(
            /[^a-z0-9]+/g,
            " ",
        )
        .replace(
            /\s+/g,
            " ",
        );
}

function inferAction(
    query: string,
): HappyModuleAction {
    const normalized =
        normalize(query);

    if (
        /\b(open|show|view|dashboard)\b/
            .test(normalized)
    ) {
        return "OPEN";
    }

    if (
        /\b(read|get|fetch|find|search|list|check)\b/
            .test(normalized)
    ) {
        return "READ";
    }

    if (
        /\b(delete|remove|destroy)\b/
            .test(normalized)
    ) {
        return "DELETE";
    }

    if (
        /\b(update|edit|modify|change)\b/
            .test(normalized)
    ) {
        return "UPDATE";
    }

    if (
        /\b(create|add|new|register)\b/
            .test(normalized)
    ) {
        return "CREATE";
    }

    if (
        /\b(generate|make|produce|design)\b/
            .test(normalized)
    ) {
        return "GENERATE";
    }

    if (
        /\b(analyze|analyse|insight|forecast)\b/
            .test(normalized)
    ) {
        return "ANALYZE";
    }

    if (
        /\b(build|develop|code)\b/
            .test(normalized)
    ) {
        return "BUILD";
    }

    if (
        /\b(test|validate|verify)\b/
            .test(normalized)
    ) {
        return "TEST";
    }

    if (
        /\b(connect|integrate|integration)\b/
            .test(normalized)
    ) {
        return "CONNECT";
    }

    if (
        /\b(configure|settings|setup)\b/
            .test(normalized)
    ) {
        return "CONFIGURE";
    }

    return "EXECUTE";
}

function resolved(
    module: HappyModuleDefinition,
    query: string,
    matchedBy:
        HappyModuleResolution["matchedBy"],
    confidence: number,
): HappyModuleResolution {
    return {
        status:
            module.status ===
            "NOT_YET_CONNECTED"
                ? "NOT_YET_CONNECTED"
                : "RESOLVED",
        module,
        action:
            inferAction(query),
        confidence,
        matchedBy,
        query,
    };
}

class InMemoryHappyModuleRouter
    implements HappyModuleRouter {

    constructor() {
        bootstrapHappyMajorModules();
    }

    resolve(
        query: string,
    ): HappyModuleResolution {
        const raw =
            query.trim();

        if (!raw) {
            return {
                status: "NOT_FOUND",
                module: null,
                action: "EXECUTE",
                confidence: 0,
                matchedBy: null,
                query,
            };
        }

        const directId =
            getHappyMajorModule(raw);

        if (directId) {
            return resolved(
                directId,
                query,
                "ID",
                1,
            );
        }

        const numberMatch =
            raw.match(
                /^(?:module\s*)?(\d{1,3})$/i,
            );

        if (numberMatch) {
            return this.resolveByNumber(
                Number(numberMatch[1]),
            );
        }

        const normalized =
            normalize(raw);

        const exactName =
            HAPPY_MAJOR_MODULE_CATALOG.find(
                (module) =>
                    normalize(
                        module.name,
                    ) === normalized,
            );

        if (exactName) {
            return resolved(
                exactName,
                query,
                "NAME",
                1,
            );
        }

        const exactCategory =
            HAPPY_MAJOR_MODULE_CATALOG.find(
                (module) =>
                    normalize(
                        module.category,
                    ) === normalized,
            );

        if (exactCategory) {
            return resolved(
                exactCategory,
                query,
                "CATEGORY",
                0.95,
            );
        }

        const matches =
            this.listMatching(raw);

        if (matches.length > 0) {
            return resolved(
                matches[0],
                query,
                "KEYWORD",
                Math.max(
                    0.5,
                    1 -
                        (
                            matches
                                .indexOf(
                                    matches[0],
                                ) *
                            0.05
                        ),
                ),
            );
        }

        return {
            status: "NOT_FOUND",
            module: null,
            action:
                inferAction(query),
            confidence: 0,
            matchedBy: null,
            query,
        };
    }

    resolveById(
        moduleId: string,
    ): HappyModuleResolution {
        const moduleDefinition =
            happyModuleRegistry.get(
                moduleId,
            );

        if (!moduleDefinition) {
            return {
                status: "NOT_FOUND",
                module: null,
                action: "EXECUTE",
                confidence: 0,
                matchedBy: null,
                query: moduleId,
            };
        }

        return resolved(
            moduleDefinition,
            moduleId,
            "ID",
            1,
        );
    }

    resolveByNumber(
        moduleNumber: number,
    ): HappyModuleResolution {
        const moduleDefinition =
            HAPPY_MAJOR_MODULE_CATALOG.find(
                (item) =>
                    item.number ===
                    moduleNumber,
            );

        if (!moduleDefinition) {
            return {
                status: "NOT_FOUND",
                module: null,
                action: "EXECUTE",
                confidence: 0,
                matchedBy: null,
                query:
                    String(moduleNumber),
            };
        }

        return resolved(
            moduleDefinition,
            String(moduleNumber),
            "NUMBER",
            1,
        );
    }

    resolveByName(
        name: string,
    ): HappyModuleResolution {
        const normalized =
            normalize(name);

        const moduleDefinition =
            HAPPY_MAJOR_MODULE_CATALOG.find(
                (item) =>
                    normalize(
                        item.name,
                    ) === normalized,
            );

        if (!moduleDefinition) {
            return {
                status: "NOT_FOUND",
                module: null,
                action:
                    inferAction(name),
                confidence: 0,
                matchedBy: null,
                query: name,
            };
        }

        return resolved(
            moduleDefinition,
            name,
            "NAME",
            1,
        );
    }

    listMatching(
        query: string,
    ): readonly HappyModuleDefinition[] {
        const stopWords =
            new Set([
                "a",
                "an",
                "and",
                "are",
                "be",
                "does",
                "exist",
                "for",
                "from",
                "happy",
                "in",
                "is",
                "it",
                "me",
                "module",
                "of",
                "please",
                "show",
                "the",
                "this",
                "to",
                "what",
                "with",
            ]);

        const tokenize =
            (value: string): string[] =>
                normalize(value)
                    .split(" ")
                    .filter(
                        (token) =>
                            token.length > 1 &&
                            !stopWords.has(token),
                    );

        const tokens =
            tokenize(query);

        if (tokens.length === 0) {
            return [];
        }

        const tokenMatches =
            (
                queryToken: string,
                candidateToken: string,
            ): boolean => {

                if (
                    queryToken ===
                    candidateToken
                ) {
                    return true;
                }

                if (
                    queryToken.length >= 4 &&
                    candidateToken.length >= 4
                ) {
                    if (
                        candidateToken.startsWith(
                            queryToken,
                        ) ||
                        queryToken.startsWith(
                            candidateToken,
                        )
                    ) {
                        return true;
                    }
                }

                const aliases:
                    Record<string, string> = {
                        app: "application",
                        application: "app",

                        generate: "generator",
                        generator: "generate",
                        generating: "generate",
                        generated: "generate",

                        build: "builder",
                        builder: "build",
                        building: "build",

                        create: "creator",
                        creator: "create",
                        creating: "create",

                        analyze: "analytics",
                        analytics: "analyze",
                        analyse: "analytics",
                        analysis: "analytics",

                        optimize: "optimizer",
                        optimizer: "optimize",

                        publish: "publishing",
                        publishing: "publish",

                        automate: "automation",
                        automation: "automate",
                    };

                return (
                    aliases[queryToken] ===
                        candidateToken ||
                    aliases[candidateToken] ===
                        queryToken
                );
            };

        const scored =
            HAPPY_MAJOR_MODULE_CATALOG
                .map((module) => {

                    const candidateTokens =
                        tokenize(
                            [
                                module.name,
                                module.category,
                                module.id,
                                module.description,
                            ].join(" "),
                        );

                    const lexicalScore =
                        tokens.reduce(
                            (
                                total,
                                queryToken,
                            ) => {

                                const matched =
                                    candidateTokens.some(
                                        (
                                            candidateToken,
                                        ) =>
                                            tokenMatches(
                                                queryToken,
                                                candidateToken,
                                            ),
                                    );

                                return (
                                    total +
                                    (
                                        matched
                                            ? 1
                                            : 0
                                    )
                                );
                            },
                            0,
                        );

                    const action =
                        inferAction(query);

                    const normalizedName =
                        normalize(module.name);

                    let actionBonus = 0;

                    if (
                        action === "OPEN" &&
                        normalizedName.includes(
                            "dashboard",
                        )
                    ) {
                        actionBonus += 3;
                    }

                    if (
                        action === "BUILD" &&
                        (
                            normalizedName.includes(
                                "builder",
                            ) ||
                            normalizedName.includes(
                                "build",
                            )
                        )
                    ) {
                        actionBonus += 4;
                    }

                    if (
                        action === "GENERATE" &&
                        (
                            normalizedName.includes(
                                "generator",
                            ) ||
                            normalizedName.includes(
                                "generate",
                            )
                        )
                    ) {
                        actionBonus += 4;
                    }

                    if (
                        action === "CREATE" &&
                        normalizedName.includes(
                            "registration",
                        )
                    ) {
                        actionBonus += 5;
                    }

                    if (
                        action === "CREATE" &&
                        normalizedName.includes(
                            "management",
                        )
                    ) {
                        actionBonus += 2;
                    }

                    if (
                        action !== "OPEN" &&
                        normalizedName.includes(
                            "dashboard",
                        )
                    ) {
                        actionBonus -= 2;
                    }

                    const normalizedQuery =
                        normalize(query);

                    const broadMobileBuildIntent =
                        action === "BUILD" &&
                        (
                            normalizedQuery.includes("mobile") ||
                            normalizedQuery.includes("application") ||
                            normalizedQuery.includes("app")
                        ) &&
                        !(
                            normalizedQuery.includes("android") ||
                            normalizedQuery.includes("ios") ||
                            normalizedQuery.includes("iphone") ||
                            normalizedQuery.includes("ipad")
                        );

                    if (
                        broadMobileBuildIntent &&
                        normalizedName.includes(
                            "cross platform builder",
                        )
                    ) {
                        actionBonus += 10;
                    }

                    const score =
                        lexicalScore +
                        actionBonus;

                    return {
                        module,
                        score,
                    };
                })
                .filter(
                    (item) =>
                        item.score > 0,
                )
                .sort(
                    (a, b) =>
                        b.score -
                        a.score ||
                        (a.module.number ?? Number.MAX_SAFE_INTEGER) -
                        (b.module.number ?? Number.MAX_SAFE_INTEGER),
                );

        return scored.map(
            (item) =>
                item.module,
        );
    }
}

export const happyModuleRouter:
    HappyModuleRouter =
        new InMemoryHappyModuleRouter();







