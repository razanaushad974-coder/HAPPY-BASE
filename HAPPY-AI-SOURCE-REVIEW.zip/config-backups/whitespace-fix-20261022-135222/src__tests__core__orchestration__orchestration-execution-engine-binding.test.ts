import {
  mkdtempSync,
  rmSync,
} from "node:fs";

import {
  tmpdir,
} from "node:os";

import {
  join,
} from "node:path";

import {
  HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import {
  resolveExecutionCapability,
} from "../../../core/execution/capability-resolver";

import type {
  ExecutionRequest,
  ExecutionResult,
} from "../../../core/execution/types";

import type {
  ExecutionRuntimeContext,
} from "../../../core/execution/runtime-context";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

class RecordingExecutionEngine {
  public calls = 0;

  public lastRequest:
    | ExecutionRequest
    | undefined;

  public lastRuntimeContext:
    | ExecutionRuntimeContext
    | undefined;

  async execute(
    request: ExecutionRequest,
    runtimeContext: ExecutionRuntimeContext = {},
  ): Promise<ExecutionResult> {
    this.calls += 1;
    this.lastRequest = request;
    this.lastRuntimeContext = runtimeContext;

    return {
      id:
        `recorded-execution-${request.id}`,
      requestId:
        request.id,
      capability:
        request.capability,
      status:
        "COMPLETED",
      output: {
        runtimeBinding:
          "RECORDED_EXECUTION_ENGINE",
      },
      evidenceIds: [],
      startedAt:
        new Date().toISOString(),
      completedAt:
        new Date().toISOString(),
    };
  }
}

async function main(): Promise<void> {
  const tempDirectory =
    mkdtempSync(
      join(
        tmpdir(),
        "happy-20l-",
      ),
    );

  const persistenceFile =
    join(
      tempDirectory,
      "orchestration-state.json",
    );

  try {
    const orchestration =
      new HappyOrchestrationEngine(
        persistenceFile,
      );

    const recorder =
      new RecordingExecutionEngine();

    (
      orchestration as unknown as {
        execution:
          RecordingExecutionEngine;
      }
    ).execution = recorder;

    const request = {
      id:
        `runtime-binding-${Date.now()}`,
      command:
        "build a simple test component",
      organizationId:
        "runtime-binding-org",
      workspaceId:
        "runtime-binding-workspace",
      userId:
        "runtime-binding-user",
      source:
        "TEXT" as const,
      authorization: {
        role:
          "USER" as const,
        scope:
          "WORKSPACE" as const,
        roleSource:
          "TRUSTED_SERVER" as const,
        authenticated:
          true,
      },
      approved:
        true,
      createdAt:
        new Date().toISOString(),
    };

    const result =
      await orchestration.run(
        request,
      );

    const blockedRequest = {
      ...request,
      id:
        `runtime-binding-client-${Date.now()}`,
      authorization: {
        role:
          "USER" as const,
        scope:
          "WORKSPACE" as const,
        roleSource:
          "CLIENT" as const,
        authenticated:
          true,
      },
    };

    let blockedError:
      unknown;

    try {
      await orchestration.run(
        blockedRequest,
      );
    } catch (error) {
      blockedError = error;
    }

    assert(
      blockedError instanceof Error &&
        blockedError.message ===
          "TRUSTED_SERVER_AUTHORIZATION_REQUIRED",
      "Expected client authorization to be rejected by the trusted-server gate",
    );

    assert(
      recorder.calls === 5,
      `Expected blocked request to avoid execution, got ${recorder.calls} calls`,
    );

    assert(
      recorder.calls >= 1,
      `ExecutionEngine was expected to receive at least one delegated call, received ${recorder.calls}.`,
    );

    const delegatedRequest =
      recorder.lastRequest;

    if (delegatedRequest === undefined) {
      throw new Error(
        "Orchestration did not forward an execution request.",
      );
    }

    const expectedCapability =
      resolveExecutionCapability(
        delegatedRequest.action,
        delegatedRequest.targetReference,
      );

    assert(
      delegatedRequest.capability ===
        expectedCapability,
      `Orchestration capability does not match canonical resolver result. Delegated=${delegatedRequest.capability}, Resolver=${expectedCapability}.`,
    );

    assert(
      typeof delegatedRequest.taskId ===
        "string" &&
      delegatedRequest.taskId.length > 0,
      "Execution request is missing taskId.",
    );

    assert(
      typeof delegatedRequest.missionId ===
        "string" &&
      delegatedRequest.missionId.length > 0,
      "Execution request is missing missionId.",
    );

    const delegatedInput =
      delegatedRequest.input as {
        command?: unknown;
      };

    assert(
      delegatedInput.command ===
        request.command,
      "Original command was not forwarded into execution input.",
    );

    assert(
      result.executionRequestId ===
        delegatedRequest.id,
      "Pipeline result executionRequestId does not match delegated execution request.",
    );

    assert(
      result.output !== undefined,
      "Pipeline result did not propagate execution output.",
    );

    const outputCandidates =
      Array.isArray(result.output)
        ? result.output
        : [
            result.output,
          ];

    const recordedOutput =
      outputCandidates.find(
        (value) =>
          value &&
          typeof value === "object" &&
          "runtimeBinding" in value &&
          (
            value as {
              runtimeBinding?: unknown;
            }
          ).runtimeBinding ===
            "RECORDED_EXECUTION_ENGINE",
      ) as {
        runtimeBinding?: unknown;
      } | undefined;

    assert(
      recordedOutput !== undefined,
      "Execution output was not propagated from the delegated ExecutionEngine.",
    );

    assert(
      recordedOutput?.runtimeBinding ===
        "RECORDED_EXECUTION_ENGINE",
      "Recorded delegated execution output binding was not preserved.",
    );

    assert(
      recorder.lastRuntimeContext !==
        undefined,
      "Runtime context was not forwarded to ExecutionEngine.",
    );

    console.log(
      "Orchestration → ExecutionEngine runtime binding test: PASS",
    );

    console.log({
      executionEngineCalls:
        recorder.calls,
      delegatedAction:
        delegatedRequest.action,
      resolvedCapability:
        expectedCapability,
      delegatedCapability:
        delegatedRequest.capability,
      executionRequestId:
        delegatedRequest.id,
      resultExecutionRequestId:
        result.executionRequestId,
      taskIdPresent:
        typeof delegatedRequest.taskId === "string" &&
        delegatedRequest.taskId.length > 0,
      missionIdPresent:
        typeof delegatedRequest.missionId === "string" &&
        delegatedRequest.missionId.length > 0,
      commandForwarded:
        delegatedInput.command === request.command,
      outputPropagated:
        recordedOutput?.runtimeBinding ===
        "RECORDED_EXECUTION_ENGINE",
      runtimeContextForwarded:
        true,
      noRealAdapterExecuted:
        true,
    });
  } finally {
    rmSync(
      tempDirectory,
      {
        recursive: true,
        force: true,
      },
    );
  }
}

main().catch(
  (error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  },
);







