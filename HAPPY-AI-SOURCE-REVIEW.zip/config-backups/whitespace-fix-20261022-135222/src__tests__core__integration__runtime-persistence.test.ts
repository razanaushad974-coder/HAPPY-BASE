import { strict as assert } from "node:assert";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";

import {
    persistAuthenticatedRuntimeSnapshot
} from "../../../core/integration/runtime-persistence";

type StoredRow = {
    scope_key: string;
    organization_id: string;
    workspace_id: string;
    user_id: string;
    state: unknown;
    version: number;
};

async function main(): Promise<void> {
    const rows: StoredRow[] = [];

    const fakeClient = {
        from(table: string) {
            assert.equal(
                table,
                "happy_runtime_snapshots"
            );

            return {
                upsert(row: StoredRow) {
                    rows.push(row);

                    return {
                        select() {
                            return {
                                single() {
                                    return Promise.resolve({
                                        data: {
                                            ...row,
                                            created_at:
                                                new Date().toISOString(),
                                            updated_at:
                                                new Date().toISOString()
                                        },
                                        error: null
                                    });
                                }
                            };
                        }
                    };
                }
            };
        }
    } as never;

    const stateFile =
        `.happy-state/test-runtime-persistence-${Date.now()}-${Math.random()
            .toString(36)
            .slice(2)}.json`;

    const persistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile
            )
        );

    const store =
        createHappyStateStore(
            persistence,
            "11111111-1111-4111-8111-111111111111",
            "22222222-2222-4222-8222-222222222222",
            "33333333-3333-4333-8333-333333333333"
        );

    await store.command().create(
        "runtime-command",
        {
            command:
                "persist this runtime"
        },
        "33333333-3333-4333-8333-333333333333"
    );

    const outcome =
        await persistAuthenticatedRuntimeSnapshot(
            fakeClient,
            store,
            {
                organizationId:
                    "11111111-1111-4111-8111-111111111111",
                workspaceId:
                    "22222222-2222-4222-8222-222222222222",
                userId:
                    "33333333-3333-4333-8333-333333333333"
            },
            1
        );

    assert.equal(
        outcome.status,
        "AVAILABLE"
    );

    assert.equal(
        rows.length,
        1
    );

    assert.equal(
        rows[0]?.scope_key,
        "11111111-1111-4111-8111-111111111111|22222222-2222-4222-8222-222222222222|33333333-3333-4333-8333-333333333333"
    );

    assert.equal(
        rows[0]?.organization_id,
        "11111111-1111-4111-8111-111111111111"
    );

    assert.equal(
        rows[0]?.workspace_id,
        "22222222-2222-4222-8222-222222222222"
    );

    assert.equal(
        rows[0]?.user_id,
        "33333333-3333-4333-8333-333333333333"
    );

    const savedState =
        rows[0]?.state as {
            commands?: Array<{
                id: string;
            }>;
        };

    assert.equal(
        savedState.commands?.length,
        1
    );

    assert.equal(
        savedState.commands?.[0]?.id,
        "runtime-command"
    );

    const disconnected =
        await persistAuthenticatedRuntimeSnapshot(
            undefined,
            store,
            {
                organizationId:
                    "11111111-1111-4111-8111-111111111111",
                workspaceId:
                    "22222222-2222-4222-8222-222222222222",
                userId:
                    "33333333-3333-4333-8333-333333333333"
            }
        );

    assert.equal(
        disconnected.status,
        "NOT_YET_CONNECTED"
    );

    let invalidScopeClientCalls = 0;

    const invalidScopeClient = {
        from() {
            invalidScopeClientCalls += 1;
            throw new Error("Supabase must not be called for an invalid scope.");
        }
    } as never;

    const invalidScopeOutcome =
        await persistAuthenticatedRuntimeSnapshot(
            invalidScopeClient,
            store,
            {
                organizationId: "demo-org",
                workspaceId: "workspace-test",
                userId: "user-test"
            }
        );

    assert.equal(invalidScopeOutcome.status, "NOT_YET_CONNECTED");
    assert.match(
        invalidScopeOutcome.error ?? "",
        /tenant scope is not UUID-formatted/
    );
    assert.equal(invalidScopeClientCalls, 0);

    console.log("Invalid UUID scope blocked before Supabase access: PASS");
    console.log(
        "Authenticated runtime persistence bridge: PASS"
    );

    console.log(
        "RLS-bound scope contract: PASS"
    );

    console.log(
        "NOT_YET_CONNECTED fallback: PASS"
    );
}

main().catch(
    (error: unknown) => {
        console.error(
            "Runtime persistence test: FAIL",
            error
        );

        process.exitCode = 1;
    }
);


