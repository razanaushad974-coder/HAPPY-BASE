import {
  ModuleDataValue,
  ModuleRecord,
} from "../data/module-data-store";

export interface ModulePersistenceAdapter {
  readonly kind: "IN_MEMORY" | "SUPABASE" | "CUSTOM";
  readonly connected: boolean;

  create<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>>;

  get<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): Promise<ModuleRecord<T> | null>;

  list<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
  ): Promise<ModuleRecord<T>[]>;

  update<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>>;

  delete(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
    expectedVersion: number,
  ): Promise<void>;
}

export class InMemoryModulePersistenceAdapter
  implements ModulePersistenceAdapter
{
  readonly kind = "IN_MEMORY" as const;
  readonly connected = true;

  private readonly records = new Map<string, ModuleRecord>();

  async create<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    const key = this.key(
      record.tenantId,
      record.moduleNumber,
      record.id,
    );

    if (this.records.has(key)) {
      throw new Error("Persistent module record already exists");
    }

    const clone = structuredClone(record);
    this.records.set(key, clone);

    return structuredClone(clone);
  }

  async get<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): Promise<ModuleRecord<T> | null> {
    const record = this.records.get(
      this.key(tenantId, moduleNumber, recordId),
    );

    return record
      ? structuredClone(record as ModuleRecord<T>)
      : null;
  }

  async list<T extends ModuleDataValue>(
    tenantId: string,
    moduleNumber: number,
  ): Promise<ModuleRecord<T>[]> {
    const prefix = `${tenantId}:${moduleNumber}:`;

    return [...this.records.entries()]
      .filter(([key]) => key.startsWith(prefix))
      .map(([, value]) =>
        structuredClone(value as ModuleRecord<T>),
      );
  }

  async update<T extends ModuleDataValue>(
    record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    const key = this.key(
      record.tenantId,
      record.moduleNumber,
      record.id,
    );

    if (!this.records.has(key)) {
      throw new Error("Persistent module record not found");
    }

    const clone = structuredClone(record);
    this.records.set(key, clone);

    return structuredClone(clone);
  }

  async delete(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): Promise<void> {
    this.records.delete(
      this.key(tenantId, moduleNumber, recordId),
    );
  }

  private key(
    tenantId: string,
    moduleNumber: number,
    recordId: string,
  ): string {
    return `${tenantId}:${moduleNumber}:${recordId}`;
  }
}

/* eslint-disable @typescript-eslint/no-unused-vars -- Parameters preserve the adapter contract while Supabase remains NOT_YET_CONNECTED. */
export class SupabaseModulePersistenceAdapter
  implements ModulePersistenceAdapter
{
  readonly kind = "SUPABASE" as const;
  readonly connected = false;

  private unavailable(): never {
    throw new Error(
      "Supabase module persistence is NOT_YET_CONNECTED",
    );
  }

  async create<T extends ModuleDataValue>(
    _record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    return this.unavailable();
  }

  async get<T extends ModuleDataValue>(
    _tenantId: string,
    _moduleNumber: number,
    _recordId: string,
  ): Promise<ModuleRecord<T> | null> {
    return this.unavailable();
  }

  async list<T extends ModuleDataValue>(
    _tenantId: string,
    _moduleNumber: number,
  ): Promise<ModuleRecord<T>[]> {
    return this.unavailable();
  }

  async update<T extends ModuleDataValue>(
    _record: ModuleRecord<T>,
  ): Promise<ModuleRecord<T>> {
    return this.unavailable();
  }

  async delete(
    _tenantId: string,
    _moduleNumber: number,
    _recordId: string,
  ): Promise<void> {
    return this.unavailable();
  }
}
/* eslint-enable @typescript-eslint/no-unused-vars */

