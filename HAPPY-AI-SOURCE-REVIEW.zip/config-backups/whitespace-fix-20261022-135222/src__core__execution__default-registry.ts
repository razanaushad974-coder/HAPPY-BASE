import {
  ContractExecutionAdapter,
} from "./contract-adapter";
import {
  ExecutionAdapterRegistry,
} from "./registry";
import {
  AIExecutionAdapter,
} from "./ai-execution-adapter";
import {
  CodeExecutionAdapter,
} from "./code-execution-adapter";
import {
  FileExecutionAdapter,
} from "./file-execution-adapter";
import {
  ApiExecutionAdapter,
} from "./api-execution-adapter";
import {
  BrowserExecutionAdapter,
} from "./browser-execution-adapter";
import {
  DatabaseExecutionAdapter,
} from "./database-execution-adapter";
import {
  SupabaseDatabaseProvider,
} from "../database/supabase-database-provider";
import {
  SafeShellExecutionAdapter,
} from "./safe-shell-adapter";
import {
  AutomationExecutionAdapter,
  type AutomationPipelineRunner,
} from "./automation-execution-adapter";

const disconnectedCapabilities = [
  "DEPLOYMENT",
  "PUBLISH",
] as const;

export function createDefaultExecutionRegistry(
  automationPipeline?: AutomationPipelineRunner,
): ExecutionAdapterRegistry {
  const registry = new ExecutionAdapterRegistry();

  registry.register(new CodeExecutionAdapter());
  registry.register(new FileExecutionAdapter());
  registry.register(new ApiExecutionAdapter());
  registry.register(new BrowserExecutionAdapter());
  registry.register(
    new DatabaseExecutionAdapter(
      new SupabaseDatabaseProvider(),
    ),
  );
  registry.register(new AIExecutionAdapter());
  registry.register(new SafeShellExecutionAdapter());

  if (automationPipeline) {
    registry.register(
      new AutomationExecutionAdapter(
        automationPipeline,
      ),
    );
  } else {
    registry.register(
      new ContractExecutionAdapter(
        "AUTOMATION",
        "NOT_YET_CONNECTED",
      ),
    );
  }

  for (const capability of disconnectedCapabilities) {
    registry.register(
      new ContractExecutionAdapter(
        capability,
        "NOT_YET_CONNECTED",
      ),
    );
  }

  return registry;
}

