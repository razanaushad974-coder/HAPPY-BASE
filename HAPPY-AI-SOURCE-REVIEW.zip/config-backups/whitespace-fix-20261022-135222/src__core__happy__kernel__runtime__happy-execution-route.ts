import { hasHappyFeature, getHappyFeatureContract, isHappyFeatureReady } from "../feature-registry";
import type {
    ExecutionCapability,
} from "../../../execution/types";

import {
    resolveExecutionCapability,
} from "../../../execution/capability-resolver";

import {
    happyModuleRouter,
    type HappyModuleResolutionStatus,
} from "./happy-module-router";

import {
    happyModuleCapabilityBindingRegistry,
    type HappyModuleCapabilityBinding,
} from "../registry/happy-module-capability-binding";

export type HappyExecutionRouteSource =
    | "MODULE_BINDING"
    | "CANONICAL_ACTION_FALLBACK";

export interface HappyExecutionRoute {
    readonly status: HappyModuleResolutionStatus;
    readonly source: HappyExecutionRouteSource;
    readonly moduleId?: string;
    readonly moduleNumber?: number;
    readonly moduleName?: string;
    readonly moduleCategory?: string;
    readonly moduleAction?: string;
    readonly featureId?: string;
    readonly binding: HappyModuleCapabilityBinding | null;
    readonly executionCapability: ExecutionCapability;
    readonly reason: string;
}

function normalize(
    value: string,
): string {
    return value
        .trim()
        .toLowerCase()
        .replace(
            /[^a-z0-9]+/g,
            " ",
        )
        .replace(
            /\s+/g,
            " ",
        );
}
function hasExplicitModuleIntent(
    command: string,
    module: {
        readonly name: string;
    },
): boolean {
    const queryTokens =
        normalize(command)
            .split(" ")
            .filter(Boolean);

    const actionWords = new Set([
        "open",
        "show",
        "view",
        "read",
        "get",
        "fetch",
        "find",
        "search",
        "list",
        "check",
        "delete",
        "remove",
        "destroy",
        "update",
        "edit",
        "modify",
        "change",
        "create",
        "add",
        "new",
        "register",
        "generate",
        "make",
        "produce",
        "design",
        "analyze",
        "analyse",
        "insight",
        "forecast",
        "build",
        "develop",
        "code",
        "test",
        "validate",
        "verify",
        "connect",
        "integrate",
        "integration",
        "configure",
        "settings",
        "setup",
    ]);

    const semanticQueryTokens =
        queryTokens.filter(
            (token) =>
                !actionWords.has(token) &&
                token.length > 1,
        );

    const ignoredModuleWords = new Set([
        "builder",
        "generator",
        "creator",
        "manager",
        "management",
        "system",
        "platform",
    ]);

    const moduleTokens =
        normalize(module.name)
            .split(" ")
            .filter(
                (token) =>
                    token.length > 1 &&
                    !ignoredModuleWords.has(token),
            );

    const aliases: Record<string, string[]> = {
        app: ["application"],
        application: ["app"],
        ai: ["artificial"],
        artificial: ["ai"],
        website: ["web"],
        web: ["website"],
        customer: ["client"],
    };

    const tokenMatches =
        (
            queryToken: string,
            moduleToken: string,
        ): boolean => {
            if (queryToken === moduleToken) {
                return true;
            }

            if (
                queryToken.length >= 4 &&
                moduleToken.length >= 4 &&
                (
                    queryToken.startsWith(moduleToken) ||
                    moduleToken.startsWith(queryToken)
                )
            ) {
                return true;
            }

            return (
                aliases[queryToken]?.includes(moduleToken) === true ||
                aliases[moduleToken]?.includes(queryToken) === true
            );
        };

    const semanticMatch =
        semanticQueryTokens.some(
            (queryToken) =>
                moduleTokens.some(
                    (moduleToken) =>
                        tokenMatches(
                            queryToken,
                            moduleToken,
                        ),
                ),
        );

    const normalizedCommand = normalize(command);

    const broadMobileBuildIntent =
        /\bmobile\b/.test(normalizedCommand) &&
        /\b(?:app|application)\b/.test(normalizedCommand);

    const isCrossPlatformBuilder =
        normalize(module.name) ===
        "cross platform builder";

    return (
        semanticMatch ||
        (
            broadMobileBuildIntent &&
            isCrossPlatformBuilder
        )
    );
}
export function isHappyFeatureConnected(featureId: string): boolean {
    return hasHappyFeature(featureId) || featureId.startsWith("HAPPY-MODULE-");
}

export function getHappyExecutionFeatureContract(featureId: string) {
    return getHappyFeatureContract(featureId);
}

export function isHappyExecutionFeatureReady(featureId: string): boolean {
    return featureId.startsWith("HAPPY-MODULE-") || isHappyFeatureReady(featureId);
}

export function resolveHappyModuleExecutionRoute(
    command: string,
    action: string,
    targetReference?: import(
        "../../../context/types"
    ).ResolvedReference,
    moduleCrud?: {
        moduleNumber?: number;
        moduleId?: string;
        action?: string;
    },
): HappyExecutionRoute {
    /*
     * Explicit HAPPY module CRUD intent is authoritative.
     *
     * CRUD is a database-bound module operation and must not
     * fall through to generic BUILD/VERIFY/AI capability
     * resolution. Normal HAPPY command routing remains unchanged
     * when moduleCrud is absent.
     */
    if (
        typeof moduleCrud?.moduleNumber === "number"
    ) {
        const moduleResolution =
            happyModuleRouter.resolveByNumber(
                moduleCrud.moduleNumber,
            );

        if (
            moduleResolution.status === "RESOLVED" &&
            moduleResolution.module
        ) {
            const crudAction =
                (
                    moduleCrud.action ??
                    action
                ).trim().toUpperCase();

            const crudBinding =
                happyModuleCapabilityBindingRegistry.bind(
                    {
                        id:
                            moduleResolution.module.id,
                        number:
                            moduleResolution.module.number,
                        name:
                            moduleResolution.module.name,
                        category:
                            moduleResolution.module.category,
                    },
                    crudAction,
                );

            return {
                status:
                    moduleResolution.status,
                source:
                    "MODULE_BINDING",
                moduleId:
                    moduleResolution.module.id,
                moduleNumber:
                    moduleResolution.module.number,
                moduleName:
                    moduleResolution.module.name,
                moduleCategory:
                    moduleResolution.module.category,
                moduleAction: crudAction,
                featureId: `HAPPY-MODULE-${moduleResolution.module.number}`,
                binding:
                    crudBinding,
                executionCapability:
                    "DATABASE",
                reason:
                    `Explicit HAPPY module CRUD intent routed to module ${moduleResolution.module.number} through the DATABASE execution boundary.`,
            };
        }
    }

    const resolution =
        happyModuleRouter.resolve(
            command,
        );

    const canonicalCapability =
        resolveExecutionCapability(
            action,
            targetReference,
        );

    if (
        resolution.status !== "RESOLVED" ||
        !resolution.module
    ) {
        return {
            status:
                resolution.status,
            source:
                "CANONICAL_ACTION_FALLBACK",
            binding:
                null,
            executionCapability:
                canonicalCapability,
            reason:
                resolution.status === "NOT_FOUND"
                    ? "No HAPPY major module matched the command; canonical execution-action resolution was preserved."
                    : "HAPPY module resolution did not produce an executable module; canonical execution-action resolution was preserved.",
        };
    }

    const normalizedAction =
        action.trim().toUpperCase();

    /*
     * Certain execution actions are authoritative at the
     * canonical capability layer and must never be replaced
     * by a generic module/domain binding.
     *
     * Cognitive actions belong to AI.
     * External boundary actions belong to their dedicated
     * execution boundaries.
     */
    const canonicalActionMustWin =
        new Set([
            "UNDERSTAND",
            "RESEARCH",
            "VERIFY",
            "CONTROL",
            "DEPLOY",
            "PUBLISH",
            "AUTOMATE",
        ]).has(
            normalizedAction,
        );

    const binding =
        happyModuleCapabilityBindingRegistry.bind(
            {
                id:
                    resolution.module.id,
                number:
                    resolution.module.number,
                name:
                    resolution.module.name,
                category:
                    resolution.module.category,
            },
            canonicalActionMustWin
                ? action
                : (
                    resolution.action ??
                    action
                ),
        );

    if (
        canonicalActionMustWin
    ) {
        return {
            status:
                resolution.status,
            source:
                "CANONICAL_ACTION_FALLBACK",
            moduleId:
                resolution.module.id,
            moduleNumber:
                resolution.module.number,
            moduleName:
                resolution.module.name,
            moduleCategory:
                resolution.module.category,
            moduleAction: resolution.action,
            featureId: `HAPPY-MODULE-${resolution.module.number}`,
            
            binding,
            executionCapability:
                canonicalCapability,
            reason:
                `Canonical execution action ${normalizedAction} takes precedence over generic module capability binding.`,
        };
    }

    if (
        binding.capability === null
    ) {
        return {
            status:
                resolution.status,
            source:
                "CANONICAL_ACTION_FALLBACK",
            moduleId:
                resolution.module.id,
            moduleNumber:
                resolution.module.number,
            moduleName:
                resolution.module.name,
            moduleCategory:
                resolution.module.category,
            moduleAction: resolution.action,
            featureId: `HAPPY-MODULE-${resolution.module.number}`,
            
            binding,
            executionCapability:
                canonicalCapability,
            reason:
                binding.reason,
        };
    }

    const bindingMayOverrideCanonical =
        binding.capability !== null &&
        (
            binding.capability === canonicalCapability ||
            hasExplicitModuleIntent(
                command,
                resolution.module,
            )
        );

    if (!bindingMayOverrideCanonical) {
        return {
            status:
                resolution.status,
            source:
                "CANONICAL_ACTION_FALLBACK",
            moduleId:
                resolution.module.id,
            moduleNumber:
                resolution.module.number,
            moduleName:
                resolution.module.name,
            moduleCategory:
                resolution.module.category,
            moduleAction: resolution.action,
            featureId: `HAPPY-MODULE-${resolution.module.number}`,
            
            binding,
            executionCapability:
                canonicalCapability,
            reason:
                "Canonical execution resolver retained because the module keyword match was not explicit enough to override the existing execution contract.",
        };
    }

    return {
        status:
            resolution.status,
        source:
            "MODULE_BINDING",
        moduleId:
            resolution.module.id,
        moduleNumber:
            resolution.module.number,
        moduleName:
            resolution.module.name,
        moduleCategory:
            resolution.module.category,
        moduleAction: resolution.action,
            featureId: `HAPPY-MODULE-${resolution.module.number}`,
            
            binding,
        executionCapability:
            binding.capability,
        reason:
            binding.reason,
    };
}










