import type {
    CapabilityDefinition,
} from "./types";

import type {
    ExecutionCapability,
} from "../execution/types";

const CAPABILITIES: CapabilityDefinition[] = [
    {
        id: "identity.happy",
        name: "HAPPY Identity",
        domain: "IDENTITY",
        description:
            "Single HAPPY identity, voice, runtime and intelligence boundary.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: ["READ", "PERSIST"],
        permissions: ["identity:read"],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: false,
        evidenceRequired: false,
        tenantScoped: true,
        implementedBy: [
            "src/config/happy.ts",
        ],
        prerequisites: [],
        tags: [
            "core",
            "identity",
            "single-intelligence",
        ],
    },
    {
        id: "auth.supabase-session",
        name: "Supabase Authentication Session",
        domain: "AUTH",
        description:
            "Authenticated Supabase user session boundary used by runtime routes.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: ["AUTHENTICATE", "READ"],
        permissions: [
            "auth:session",
            "auth:user",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/auth/supabase-runtime-context.ts",
            "src/lib",
        ],
        prerequisites: [],
        tags: [
            "auth",
            "supabase",
            "session",
        ],
    },
    {
        id: "command.accept",
        name: "Command Intake",
        domain: "COMMAND",
        description:
            "Accept a natural-language HAPPY command as the beginning of an execution flow.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: ["READ"],
        permissions: [
            "command:submit",
        ],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: false,
        evidenceRequired: false,
        tenantScoped: true,
        implementedBy: [
            "src/core/orchestration",
            "src/app/api/execute/route.ts",
        ],
        prerequisites: [
            "identity.happy",
            "auth.supabase-session",
        ],
        tags: [
            "command",
            "natural-language",
        ],
    },
    {
        id: "context.resolve",
        name: "Context Resolution",
        domain: "CONTEXT",
        description:
            "Resolve contextual references such as this, that, task, project and mission.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: ["READ"],
        permissions: [
            "context:read",
        ],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: false,
        evidenceRequired: false,
        tenantScoped: true,
        implementedBy: [
            "src/core/context/resolver.ts",
        ],
        prerequisites: [
            "command.accept",
        ],
        tags: [
            "context",
            "resolution",
        ],
    },
    {
        id: "planning.generate",
        name: "Mission Planning",
        domain: "PLANNING",
        description:
            "Convert a HAPPY goal into an actionable execution plan.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: ["PLAN"],
        permissions: [
            "planning:create",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/planning",
            "src/core/mission",
        ],
        prerequisites: [
            "context.resolve",
        ],
        tags: [
            "planning",
            "mission",
            "dag",
        ],
    },
    {
        id: "file.read",
        name: "Read File",
        domain: "FILE",
        description:
            "Safely read an approved file reference inside the execution boundary.",
        status: "AVAILABLE",
        executionTypes: ["FILE"],
        actions: ["READ"],
        permissions: [
            "file:read",
        ],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/file-execution-adapter.ts",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "file",
            "read",
            "safe-execution",
        ],
    },
    {
        id: "file.write",
        name: "Write File",
        domain: "FILE",
        description:
            "Create or modify files through the safe file execution boundary.",
        status: "AVAILABLE",
        executionTypes: ["FILE"],
        actions: [
            "CREATE",
            "MODIFY",
        ],
        permissions: [
            "file:create",
            "file:modify",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: true,
        approvalReason:
            "Writing project or user files can change persistent state.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/file-execution-adapter.ts",
        ],
        prerequisites: [
            "file.read",
        ],
        tags: [
            "file",
            "write",
            "approval",
        ],
    },
    {
        id: "file.manage",
        name: "Manage Files",
        domain: "FILE",
        description:
            "Copy, move, rename and delete approved files through the execution boundary.",
        status: "AVAILABLE",
        executionTypes: ["FILE"],
        actions: [
            "COPY",
            "MOVE",
            "RENAME",
            "DELETE",
        ],
        permissions: [
            "file:manage",
        ],
        riskLevel: "HIGH",
        requiresApproval: true,
        approvalReason:
            "File management can alter or remove persistent content.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/file-execution-adapter.ts",
        ],
        prerequisites: [
            "file.read",
        ],
        tags: [
            "file",
            "manage",
            "destructive",
        ],
    },
    {
        id: "api.http",
        name: "HTTP API Execution",
        domain: "API",
        description:
            "Call approved HTTP or HTTPS endpoints through the API execution boundary.",
        status: "AVAILABLE",
        executionTypes: ["API"],
        actions: [
            "REQUEST",
            "CALL",
        ],
        permissions: [
            "api:request",
        ],
        riskLevel: "HIGH",
        requiresApproval: true,
        approvalReason:
            "External API calls can create external side effects.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/api-execution-adapter.ts",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "api",
            "http",
            "allowlist",
            "approval",
        ],
    },
    {
        id: "browser.playwright",
        name: "Browser Automation",
        domain: "BROWSER",
        description:
            "Navigate and interact with approved websites using Playwright.",
        status: "AVAILABLE",
        executionTypes: ["BROWSER"],
        actions: [
            "NAVIGATE",
            "CLICK",
            "FILL",
            "EXTRACT",
            "SCREENSHOT",
        ],
        permissions: [
            "browser:navigate",
            "browser:interact",
        ],
        riskLevel: "HIGH",
        requiresApproval: true,
        approvalReason:
            "Browser actions can cause external side effects.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/browser-execution-adapter.ts",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "browser",
            "playwright",
            "web",
            "automation",
        ],
    },
    {
        id: "database.boundary",
        name: "Database Execution Boundary",
        domain: "DATABASE",
        description:
            "Database provider abstraction with explicit connection status and tenant boundary.",
        status: "AVAILABLE",
        executionTypes: ["DATABASE"],
        actions: [
            "READ",
            "CREATE",
            "MODIFY",
            "DELETE",
        ],
        permissions: [
            "database:execute",
        ],
        riskLevel: "CRITICAL",
        requiresApproval: true,
        approvalReason:
            "Database operations can modify persistent application state.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/execution/database-execution-adapter.ts",
            "src/core/database/supabase-database-provider.ts",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "database",
            "provider",
            "tenant",
            "safety",
        ],
    },
    {
        id: "database.external-persistence",
        name: "External Database Persistence",
        domain: "DATABASE",
        description:
            "Real external database-backed persistence for HAPPY orchestration records.",
        status: "NOT_YET_CONNECTED",
        executionTypes: ["DATABASE"],
        actions: [
            "READ",
            "CREATE",
            "MODIFY",
            "DELETE",
            "PERSIST",
        ],
        permissions: [
            "database:persist",
        ],
        riskLevel: "CRITICAL",
        requiresApproval: true,
        approvalReason:
            "External persistent database mutations require an explicit production-safe connection.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [],
        prerequisites: [
            "database.boundary",
        ],
        tags: [
            "database",
            "persistence",
            "not-yet-connected",
        ],
    },
    {
        id: "ai.gemini.generate",
        name: "Gemini Generation",
        domain: "AI",
        description:
            "Generate AI output through the configured Gemini adapter.",
        status: "AVAILABLE",
        executionTypes: ["AI"],
        actions: [
            "GENERATE",
        ],
        permissions: [
            "ai:generate",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/ai/gemini-adapter.ts",
        ],
        prerequisites: [
            "context.resolve",
        ],
        tags: [
            "ai",
            "gemini",
            "generation",
        ],
    },
    {
        id: "verification.result",
        name: "Execution Verification",
        domain: "VERIFICATION",
        description:
            "Verify whether an execution result satisfies its expected outcome.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: [
            "VERIFY",
        ],
        permissions: [
            "verification:read",
            "verification:write",
        ],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: false,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/verification/engine.ts",
        ],
        prerequisites: [],
        tags: [
            "verification",
            "result",
        ],
    },
    {
        id: "evidence.capture",
        name: "Evidence Capture",
        domain: "EVIDENCE",
        description:
            "Persist evidence supporting execution and verification outcomes.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: [
            "READ",
            "CREATE",
            "PERSIST",
        ],
        permissions: [
            "evidence:read",
            "evidence:write",
        ],
        riskLevel: "LOW",
        requiresApproval: false,
        verificationRequired: false,
        evidenceRequired: false,
        tenantScoped: true,
        implementedBy: [
            "src/core/evidence/repository.ts",
        ],
        prerequisites: [
            "verification.result",
        ],
        tags: [
            "evidence",
            "audit",
            "proof",
        ],
    },
    {
        id: "memory.persist",
        name: "Persistent Memory",
        domain: "MEMORY",
        description:
            "Store durable HAPPY memory records within the tenant boundary.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: [
            "READ",
            "CREATE",
            "PERSIST",
            "REMEMBER",
        ],
        permissions: [
            "memory:read",
            "memory:write",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/state",
            "src/core/persistence",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "memory",
            "persistence",
            "tenant",
        ],
    },
    {
        id: "workspace.tenant-bootstrap",
        name: "Authenticated Tenant Bootstrap",
        domain: "WORKSPACE",
        description:
            "Create or resolve a file-backed workspace tenant for an authenticated user.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: [
            "READ",
            "CREATE",
            "PERSIST",
        ],
        permissions: [
            "workspace:tenant",
        ],
        riskLevel: "HIGH",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/workspace/file-backed-state.ts",
        ],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "tenant",
            "workspace",
            "bootstrap",
        ],
    },
    {
        id: "workspace.live-state",
        name: "Live Workspace State",
        domain: "WORKSPACE",
        description:
            "Expose tenant-scoped runtime state to the authenticated Workspace UI.",
        status: "AVAILABLE",
        executionTypes: ["NONE"],
        actions: [
            "READ",
            "PERSIST",
        ],
        permissions: [
            "workspace:read",
        ],
        riskLevel: "MEDIUM",
        requiresApproval: false,
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [
            "src/core/workspace/live-dashboard.ts",
            "src/app/api/workspace/state/route.ts",
        ],
        prerequisites: [
            "workspace.tenant-bootstrap",
        ],
        tags: [
            "workspace",
            "live-state",
            "dashboard",
        ],
    },
    {
        id: "deployment.execute",
        name: "Deployment Execution",
        domain: "DEPLOYMENT",
        description:
            "Deploy HAPPY projects or generated applications to an approved deployment target.",
        status: "NOT_YET_CONNECTED",
        executionTypes: ["DEPLOYMENT"],
        actions: [
            "DEPLOY",
        ],
        permissions: [
            "deployment:execute",
        ],
        riskLevel: "CRITICAL",
        requiresApproval: true,
        approvalReason:
            "Deployment creates or changes externally accessible software.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "deployment",
            "not-yet-connected",
        ],
    },
    {
        id: "publish.execute",
        name: "Publishing",
        domain: "PUBLISH",
        description:
            "Publish approved HAPPY content or generated assets to an external destination.",
        status: "NOT_YET_CONNECTED",
        executionTypes: ["PUBLISH"],
        actions: [
            "PUBLISH",
        ],
        permissions: [
            "publish:execute",
        ],
        riskLevel: "CRITICAL",
        requiresApproval: true,
        approvalReason:
            "Publishing creates externally visible side effects.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "publish",
            "external-side-effect",
            "not-yet-connected",
        ],
    },
    {
        id: "automation.execute",
        name: "Workflow Automation",
        domain: "AUTOMATION",
        description:
            "Run registered multi-step HAPPY workflows and automations.",
        status: "NOT_YET_CONNECTED",
        executionTypes: ["AUTOMATION"],
        actions: [
            "AUTOMATE",
            "EXECUTE",
        ],
        permissions: [
            "automation:execute",
        ],
        riskLevel: "HIGH",
        requiresApproval: true,
        approvalReason:
            "Automations can perform multiple external actions.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [],
        prerequisites: [
            "planning.generate",
            "verification.result",
            "evidence.capture",
        ],
        tags: [
            "automation",
            "workflow",
            "not-yet-connected",
        ],
    },
    {
        id: "sandbox.execute",
        name: "Sandbox Execution",
        domain: "SANDBOX",
        description:
            "Execute isolated arbitrary sandbox workloads.",
        status: "BLOCKED",
        executionTypes: ["SHELL"],
        actions: [
            "EXECUTE",
        ],
        permissions: [
            "sandbox:execute",
        ],
        riskLevel: "CRITICAL",
        requiresApproval: true,
        approvalReason:
            "Arbitrary sandbox execution requires a hardened isolated runtime boundary.",
        verificationRequired: true,
        evidenceRequired: true,
        tenantScoped: true,
        implementedBy: [],
        prerequisites: [
            "auth.supabase-session",
        ],
        tags: [
            "sandbox",
            "security",
            "blocked",
        ],
    },
];

export type ExecutionCapabilityDefinition = {
    capability: ExecutionCapability;
    status: CapabilityDefinition["status"];
    description: string;
    linkedCapabilityIds: string[];
    implementedBy: string[];
};

const EXECUTION_CAPABILITIES: ExecutionCapabilityDefinition[] = [
    {
        capability: "CODE",
        status: "AVAILABLE",
        description:
            "Code execution boundary used for creation, modification, building and testing work.",
        linkedCapabilityIds: [],
        implementedBy: [
            "src/core/execution/code-execution-adapter.ts",
        ],
    },
    {
        capability: "FILE",
        status: "AVAILABLE",
        description:
            "Safe file execution boundary for approved file operations.",
        linkedCapabilityIds: [
            "file.read",
            "file.write",
            "file.manage",
        ],
        implementedBy: [
            "src/core/execution/file-execution-adapter.ts",
        ],
    },
    {
        capability: "API",
        status: "AVAILABLE",
        description:
            "Approved HTTP and HTTPS API execution boundary.",
        linkedCapabilityIds: [
            "api.http",
        ],
        implementedBy: [
            "src/core/execution/api-execution-adapter.ts",
        ],
    },
    {
        capability: "BROWSER",
        status: "AVAILABLE",
        description:
            "Playwright browser execution boundary for approved web interactions.",
        linkedCapabilityIds: [
            "browser.playwright",
        ],
        implementedBy: [
            "src/core/execution/browser-execution-adapter.ts",
        ],
    },
    {
        capability: "SHELL",
        status: "BLOCKED",
        description:
            "Arbitrary shell or sandbox execution remains explicitly blocked.",
        linkedCapabilityIds: [
            "sandbox.execute",
        ],
        implementedBy: [],
    },
    {
        capability: "DATABASE",
        status: "AVAILABLE",
        description:
            "Database execution boundary with explicit tenant and provider controls.",
        linkedCapabilityIds: [
            "database.boundary",
            "database.external-persistence",
        ],
        implementedBy: [
            "src/core/execution/database-execution-adapter.ts",
        ],
    },
    {
        capability: "AI",
        status: "AVAILABLE",
        description:
            "AI execution boundary for configured AI generation and reasoning adapters.",
        linkedCapabilityIds: [
            "ai.gemini.generate",
        ],
        implementedBy: [
            "src/core/execution/ai-execution-adapter.ts",
        ],
    },
    {
        capability: "DEPLOYMENT",
        status: "NOT_YET_CONNECTED",
        description:
            "Deployment execution remains explicitly NOT_YET_CONNECTED until a production-safe deployment adapter is connected.",
        linkedCapabilityIds: [
            "deployment.execute",
        ],
        implementedBy: [],
    },
    {
        capability: "PUBLISH",
        status: "NOT_YET_CONNECTED",
        description:
            "External publishing remains explicitly NOT_YET_CONNECTED until a publishing adapter is connected.",
        linkedCapabilityIds: [
            "publish.execute",
        ],
        implementedBy: [],
    },
    {
        capability: "AUTOMATION",
        status: "NOT_YET_CONNECTED",
        description:
            "Workflow automation remains explicitly NOT_YET_CONNECTED until an automation adapter is connected.",
        linkedCapabilityIds: [
            "automation.execute",
        ],
        implementedBy: [],
    },
];

function validateExecutionCapabilityRegistry(): void {
    const capabilityIds =
        new Set<string>();

    const executionTypes =
        new Set<string>();

    for (
        const executionCapability
        of EXECUTION_CAPABILITIES
    ) {
        if (
            executionTypes.has(
                executionCapability.capability,
            )
        ) {
            throw new Error(
                `DUPLICATE_EXECUTION_CAPABILITY:${executionCapability.capability}`,
            );
        }

        executionTypes.add(
            executionCapability.capability,
        );

        for (
            const linkedCapabilityId
            of executionCapability.linkedCapabilityIds
        ) {
            if (
                capabilityIds.has(
                    linkedCapabilityId,
                )
            ) {
                continue;
            }

            capabilityIds.add(
                linkedCapabilityId,
            );

            if (
                !CAPABILITIES.some(
                    (
                        capability,
                    ) =>
                        capability.id ===
                        linkedCapabilityId,
                )
            ) {
                throw new Error(
                    `EXECUTION_REGISTRY_LINK_NOT_FOUND:${executionCapability.capability}:${linkedCapabilityId}`,
                );
            }
        }

        if (
            executionCapability.status ===
                "NOT_YET_CONNECTED" &&
            executionCapability.implementedBy.length >
                0
        ) {
            throw new Error(
                `EXECUTION_NOT_YET_CONNECTED_IMPLEMENTATION_CONFLICT:${executionCapability.capability}`,
            );
        }

        if (
            executionCapability.status ===
                "BLOCKED" &&
            executionCapability.implementedBy.length >
                0
        ) {
            throw new Error(
                `EXECUTION_BLOCKED_IMPLEMENTATION_CONFLICT:${executionCapability.capability}`,
            );
        }
    }

    if (
        executionTypes.size !== 10
    ) {
        throw new Error(
            `EXECUTION_REGISTRY_COUNT_INVALID:${executionTypes.size}`,
        );
    }
}

validateExecutionCapabilityRegistry();

export function listExecutionCapabilities(): ExecutionCapabilityDefinition[] {
    return EXECUTION_CAPABILITIES.map(
        (
            executionCapability,
        ) => ({
            ...executionCapability,
            linkedCapabilityIds: [
                ...executionCapability.linkedCapabilityIds,
            ],
            implementedBy: [
                ...executionCapability.implementedBy,
            ],
        }),
    );
}

export function getExecutionCapabilityDefinition(
    capability: ExecutionCapability,
): ExecutionCapabilityDefinition | undefined {
    return listExecutionCapabilities().find(
        (
            executionCapability,
        ) =>
            executionCapability.capability ===
            capability,
    );
}

export function requireExecutionCapabilityDefinition(
    capability: ExecutionCapability,
): ExecutionCapabilityDefinition {
    const definition =
        getExecutionCapabilityDefinition(
            capability,
        );

    if (!definition) {
        throw new Error(
            `EXECUTION_CAPABILITY_NOT_REGISTERED:${capability}`,
        );
    }

    return definition;
}
function validateCapability(
    capability: CapabilityDefinition,
): void {
    if (
        !capability.id.trim() ||
        !capability.name.trim()
    ) {
        throw new Error(
            "CAPABILITY_ID_AND_NAME_REQUIRED",
        );
    }

    if (
        capability.status ===
            "NOT_YET_CONNECTED" &&
        capability.implementedBy.length >
            0
    ) {
        throw new Error(
            `NOT_YET_CONNECTED_IMPLEMENTATION_CONFLICT:${capability.id}`,
        );
    }

    if (
        capability.status ===
            "BLOCKED" &&
        capability.implementedBy.length >
            0
    ) {
        throw new Error(
            `BLOCKED_IMPLEMENTATION_CONFLICT:${capability.id}`,
        );
    }

    if (
        capability.requiresApproval &&
        !capability.approvalReason
    ) {
        throw new Error(
            `APPROVAL_REASON_REQUIRED:${capability.id}`,
        );
    }

    if (
        capability.verificationRequired &&
        !capability.evidenceRequired
    ) {
        throw new Error(
            `EVIDENCE_REQUIRED_FOR_VERIFICATION:${capability.id}`,
        );
    }
}

function validateRegistry(
    capabilities: CapabilityDefinition[],
): void {
    const ids =
        new Set<string>();

    for (
        const capability
        of capabilities
    ) {
        validateCapability(
            capability,
        );

        if (
            ids.has(
                capability.id,
            )
        ) {
            throw new Error(
                `DUPLICATE_CAPABILITY_ID:${capability.id}`,
            );
        }

        ids.add(
            capability.id,
        );
    }
}

validateRegistry(
    CAPABILITIES,
);

export function listCapabilities(): CapabilityDefinition[] {
    return CAPABILITIES.map(
        (
            capability,
        ) => ({
            ...capability,
            executionTypes: [
                ...capability.executionTypes,
            ],
            actions: [
                ...capability.actions,
            ],
            permissions: [
                ...capability.permissions,
            ],
            implementedBy: [
                ...capability.implementedBy,
            ],
            prerequisites: [
                ...capability.prerequisites,
            ],
            tags: [
                ...capability.tags,
            ],
        }),
    );
}

export function getCapability(
    id: string,
): CapabilityDefinition | undefined {
    return listCapabilities().find(
        (
            capability,
        ) =>
            capability.id ===
            id,
    );
}

export function requireCapability(
    id: string,
): CapabilityDefinition {
    const capability =
        getCapability(
            id,
        );

    if (!capability) {
        throw new Error(
            `CAPABILITY_NOT_FOUND:${id}`,
        );
    }

    return capability;
}

export function listCapabilitiesByStatus(
    status: CapabilityDefinition["status"],
): CapabilityDefinition[] {
    return listCapabilities().filter(
        (
            capability,
        ) =>
            capability.status ===
            status,
    );
}

export function listCapabilitiesByDomain(
    domain: CapabilityDefinition["domain"],
): CapabilityDefinition[] {
    return listCapabilities().filter(
        (
            capability,
        ) =>
            capability.domain ===
            domain,
    );
}

export function hasCapability(
    id: string,
): boolean {
    return Boolean(
        getCapability(
            id,
        ),
    );
}

export function getCapabilityCounts(): Record<
    CapabilityDefinition["status"],
    number
> {
    const counts: Record<
        CapabilityDefinition["status"],
        number
    > = {
        AVAILABLE: 0,
        NOT_YET_CONNECTED: 0,
        BLOCKED: 0,
    };

    for (
        const capability
        of CAPABILITIES
    ) {
        counts[
            capability.status
        ] += 1;
    }

    return counts;
}

export {
    CAPABILITIES,
};




