import { strict as assert } from "node:assert";

import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";

import {
    persistAuthenticatedRuntimeSnapshot
} from "../../../core/integration/runtime-persistence";

type StoredRow = {
    scope_key: string;
    organization_id: string;
    workspace_id: string;
    user_id: string;
    state: unknown;
    version: number;
};

async function main(): Promise<void> {
    const rows: StoredRow[] = [];

    const fakeClient = {
        from(table: string) {
            assert.equal(
                table,
                "happy_runtime_snapshots"
            );

            return {
                upsert(row: StoredRow) {
                    rows.push(row);

                    return {
                        select() {
                            return {
                                single() {
                                    return Promise.resolve({
                                        data: {
                                            ...row,
                                            created_at:
                                                new Date().toISOString(),
                                            updated_at:
                                                new Date().toISOString()
                                        },
                                        error: null
                                    });
                                }
                            };
                        }
                    };
                }
            };
        }
    } as never;

    const stateFile =
        `.happy-state/test-runtime-persistence-${Date.now()}-${Math.random()
            .toString(36)
            .slice(2)}.json`;

    const persistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile
            )
        );

    const store =
        createHappyStateStore(
            persistence,
            "org-test",
            "workspace-test",
            "user-test"
        );

    await store.command().create(
        "runtime-command",
        {
            command:
                "persist this runtime"
        },
        "user-test"
    );

    const outcome =
        await persistAuthenticatedRuntimeSnapshot(
            fakeClient,
            store,
            {
                organizationId:
                    "org-test",
                workspaceId:
                    "workspace-test",
                userId:
                    "user-test"
            },
            1
        );

    assert.equal(
        outcome.status,
        "AVAILABLE"
    );

    assert.equal(
        rows.length,
        1
    );

    assert.equal(
        rows[0]?.scope_key,
        "org-test|workspace-test|user-test"
    );

    assert.equal(
        rows[0]?.organization_id,
        "org-test"
    );

    assert.equal(
        rows[0]?.workspace_id,
        "workspace-test"
    );

    assert.equal(
        rows[0]?.user_id,
        "user-test"
    );

    const savedState =
        rows[0]?.state as {
            commands?: Array<{
                id: string;
            }>;
        };

    assert.equal(
        savedState.commands?.length,
        1
    );

    assert.equal(
        savedState.commands?.[0]?.id,
        "runtime-command"
    );

    const disconnected =
        await persistAuthenticatedRuntimeSnapshot(
            undefined,
            store,
            {
                organizationId:
                    "org-test",
                workspaceId:
                    "workspace-test",
                userId:
                    "user-test"
            }
        );

    assert.equal(
        disconnected.status,
        "NOT_YET_CONNECTED"
    );

    console.log(
        "Authenticated runtime persistence bridge: PASS"
    );

    console.log(
        "RLS-bound scope contract: PASS"
    );

    console.log(
        "NOT_YET_CONNECTED fallback: PASS"
    );
}

main().catch(
    (error: unknown) => {
        console.error(
            "Runtime persistence test: FAIL",
            error
        );

        process.exitCode = 1;
    }
);