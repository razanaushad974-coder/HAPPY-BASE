import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  sessionResult: {
    data: {
      session: {
        access_token: "test-access-token",
      },
    },
    error: null as { message: string } | null,
  },
  resolverError: null as Error | null,
  resolveCalls: [] as Array<{
    token: string;
    options?: { allowProvisioning?: boolean };
  }>,
  tenant: {
    organizationId: "123e4567-e89b-42d3-a456-426614174000",
    organizationName: "HAPPY AI",
    organizationSlug: "happy-ai",
    workspaceId: "123e4567-e89b-42d3-a456-426614174001",
    workspaceName: "HAPPY Workspace",
    workspaceSlug: "happy-workspace",
    userId: "user-test-123",
  },
}));

vi.mock("@/lib/supabase/server", () => ({
  createSupabaseServerClient: async () => ({
    auth: {
      getSession: async () => state.sessionResult,
    },
  }),
}));

vi.mock("@/core/workspace/supabase-tenant-resolver", () => ({
  resolveCanonicalSupabaseTenant: async (
    token: string,
    options?: { allowProvisioning?: boolean },
  ) => {
    state.resolveCalls.push({ token, options });
    if (state.resolverError) throw state.resolverError;
    return state.tenant;
  },
}));

import { GET } from "@/app/api/system/canonical-tenant-diagnostic/route";

describe("canonical tenant diagnostic GET route", () => {
  beforeEach(() => {
    state.sessionResult = {
      data: {
        session: {
          access_token: "test-access-token",
        },
      },
      error: null,
    };
    state.resolverError = null;
    state.resolveCalls.length = 0;
  });

  it("returns 401 with a safe message and does not resolve tenant without a session", async () => {
    state.sessionResult = {
      data: { session: null as never },
      error: { message: "SECRET_PROVIDER_DETAIL" },
    };

    const response = await GET();
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.status).toBe("UNAUTHENTICATED");
    expect(body.error).toBe("No authenticated Supabase session.");
    expect(JSON.stringify(body)).not.toContain("SECRET_PROVIDER_DETAIL");
    expect(state.resolveCalls).toHaveLength(0);
  });

  it("returns a safe 500 message when the tenant is not provisioned", async () => {
    state.resolverError = new Error("CANONICAL_TENANT_NOT_PROVISIONED");

    const response = await GET();
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.verified).toBe(false);
    expect(body.error).toBe("Canonical tenant is not provisioned.");
    expect(state.resolveCalls).toHaveLength(1);
    expect(state.resolveCalls[0].options).toEqual({
      allowProvisioning: false,
    });
  });

  it("does not expose unexpected internal error details", async () => {
    state.resolverError = new Error("SECRET_PROVIDER_DETAIL");

    const response = await GET();
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("Canonical tenant resolution failed.");
    expect(JSON.stringify(body)).not.toContain("SECRET_PROVIDER_DETAIL");
  });

  it("returns the tenant payload and requests read-only resolution on success", async () => {
    const response = await GET();
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.status).toBe("LIVE_CANONICAL_TENANT_RESOLVED");
    expect(body.verified).toBe(true);
    expect(body.organizationId).toBe(state.tenant.organizationId);
    expect(body.workspaceId).toBe(state.tenant.workspaceId);
    expect(body.organizationIdLooksUuid).toBe(true);
    expect(body.workspaceIdLooksUuid).toBe(true);
    expect(state.resolveCalls).toEqual([
      {
        token: "test-access-token",
        options: { allowProvisioning: false },
      },
    ]);
  });
});
