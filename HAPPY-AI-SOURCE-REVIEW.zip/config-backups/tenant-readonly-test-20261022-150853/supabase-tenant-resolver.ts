import "server-only";

import {
    createClient,
    type SupabaseClient,
} from "@supabase/supabase-js";

import {
    getSupabaseServerConfig,
} from "../database/supabase-server-config";

export interface CanonicalSupabaseTenant {
    organizationId: string;
    organizationName: string;
    organizationSlug: string;
    workspaceId: string;
    workspaceName: string;
    workspaceSlug: string;
    userId: string;
}

interface OrganizationRow {
    id: string;
    name: string;
    slug: string;
    owner_user_id: string;
}

interface WorkspaceRow {
    id: string;
    organization_id: string;
    name: string;
    slug: string;
    owner_user_id: string;
}

const DEFAULT_ORGANIZATION_NAME =
    "HAPPY AI";

const DEFAULT_WORKSPACE_NAME =
    "HAPPY Workspace";

function normalizeRequired(
    value: string,
    field: string,
): string {
    const normalized =
        value.trim();

    if (!normalized) {
        throw new Error(
            `${field}_REQUIRED`,
        );
    }

    return normalized;
}

function slugify(
    value: string,
): string {
    const normalized =
        value
            .trim()
            .toLowerCase()
            .replace(
                /[^a-z0-9]+/g,
                "-",
            )
            .replace(
                /^-+|-+$/g,
                "",
            );

    if (!normalized) {
        throw new Error(
            "TENANT_SLUG_GENERATION_FAILED",
        );
    }

    return normalized;
}

function organizationSlugForUser(
    userId: string,
): string {
    const suffix =
        userId
            .replace(
                /-/g,
                "",
            )
            .slice(
                0,
                12,
            );

    return slugify(
        `${DEFAULT_ORGANIZATION_NAME}-${suffix}`,
    );
}

function createAuthenticatedClient(
    accessToken: string,
): SupabaseClient {
    const config =
        getSupabaseServerConfig();

    if (!config.url) {
        throw new Error(
            "SUPABASE_URL_NOT_CONFIGURED",
        );
    }

    if (!config.publishableKey) {
        throw new Error(
            "SUPABASE_PUBLISHABLE_KEY_NOT_CONFIGURED",
        );
    }

    const normalizedToken =
        normalizeRequired(
            accessToken,
            "SUPABASE_ACCESS_TOKEN",
        );

    return createClient(
        config.url,
        config.publishableKey,
        {
            auth: {
                autoRefreshToken: false,
                persistSession: false,
            },
            global: {
                headers: {
                    Authorization:
                        `Bearer ${normalizedToken}`,
                },
            },
        },
    );
}

async function resolveAuthenticatedUser(
    client: SupabaseClient,
    accessToken: string,
): Promise<string> {
    const result =
        await client.auth.getUser(
            accessToken,
        );

    if (result.error) {
        throw new Error(
            `SUPABASE_AUTHENTICATION_FAILED: ${result.error.message}`,
        );
    }

    if (!result.data.user) {
        throw new Error(
            "SUPABASE_AUTHENTICATED_USER_NOT_FOUND",
        );
    }

    return result.data.user.id;
}

async function findOwnedOrganizations(
    client: SupabaseClient,
    userId: string,
): Promise<OrganizationRow[]> {
    const result =
        await client
            .from("organizations")
            .select(
                "id,name,slug,owner_user_id",
            )
            .eq(
                "owner_user_id",
                userId,
            )
            .order(
                "created_at",
                {
                    ascending: true,
                },
            );

    if (result.error) {
        throw new Error(
            `SUPABASE_ORGANIZATION_READ_FAILED: ${result.error.message}`,
        );
    }

    return (
        result.data ?? []
    ) as OrganizationRow[];
}

async function findOwnedWorkspaces(
    client: SupabaseClient,
    userId: string,
    organizationId: string,
): Promise<WorkspaceRow[]> {
    const result =
        await client
            .from("workspaces")
            .select(
                "id,organization_id,name,slug,owner_user_id",
            )
            .eq(
                "organization_id",
                organizationId,
            )
            .eq(
                "owner_user_id",
                userId,
            )
            .order(
                "created_at",
                {
                    ascending: true,
                },
            );

    if (result.error) {
        throw new Error(
            `SUPABASE_WORKSPACE_READ_FAILED: ${result.error.message}`,
        );
    }

    return (
        result.data ?? []
    ) as WorkspaceRow[];
}

async function createOrganization(
    client: SupabaseClient,
    userId: string,
): Promise<OrganizationRow> {
    const name =
        DEFAULT_ORGANIZATION_NAME;

    const slug =
        organizationSlugForUser(
            userId,
        );

    const result =
        await client
            .from("organizations")
            .insert({
                name,
                slug,
                owner_user_id:
                    userId,
            })
            .select(
                "id,name,slug,owner_user_id",
            )
            .single();

    if (result.error) {
        throw new Error(
            `SUPABASE_ORGANIZATION_CREATE_FAILED: ${result.error.message}`,
        );
    }

    return result.data as OrganizationRow;
}

async function ensureOrganizationMembership(
    client: SupabaseClient,
    organizationId: string,
    userId: string,
): Promise<void> {
    const result =
        await client
            .from("organization_members")
            .insert({
                organization_id:
                    organizationId,
                user_id:
                    userId,
                role:
                    "owner",
            });

    if (
        result.error &&
        result.error.code !== "23505"
    ) {
        throw new Error(
            `SUPABASE_ORGANIZATION_MEMBERSHIP_CREATE_FAILED: ${result.error.message}`,
        );
    }
}

async function createWorkspace(
    client: SupabaseClient,
    userId: string,
    organizationId: string,
): Promise<WorkspaceRow> {
    const name =
        DEFAULT_WORKSPACE_NAME;

    const slug =
        slugify(name);

    const result =
        await client
            .from("workspaces")
            .insert({
                organization_id:
                    organizationId,
                name,
                slug,
                owner_user_id:
                    userId,
            })
            .select(
                "id,organization_id,name,slug,owner_user_id",
            )
            .single();

    if (result.error) {
        throw new Error(
            `SUPABASE_WORKSPACE_CREATE_FAILED: ${result.error.message}`,
        );
    }

    return result.data as WorkspaceRow;
}

async function ensureWorkspaceMembership(
    client: SupabaseClient,
    workspaceId: string,
    userId: string,
): Promise<void> {
    const result =
        await client
            .from("workspace_members")
            .insert({
                workspace_id:
                    workspaceId,
                user_id:
                    userId,
                role:
                    "owner",
            });

    if (
        result.error &&
        result.error.code !== "23505"
    ) {
        throw new Error(
            `SUPABASE_WORKSPACE_MEMBERSHIP_CREATE_FAILED: ${result.error.message}`,
        );
    }
}

export async function resolveCanonicalSupabaseTenant(
    accessToken: string,
    options: { allowProvisioning?: boolean } = {},
): Promise<CanonicalSupabaseTenant> {
    const client =
        createAuthenticatedClient(
            accessToken,
        );

    const allowProvisioning = options.allowProvisioning !== false;

    const userId =
        await resolveAuthenticatedUser(
            client,
            accessToken,
        );

    const organizations =
        await findOwnedOrganizations(
            client,
            userId,
        );

    if (
        organizations.length > 1
    ) {
        throw new Error(
            "AMBIGUOUS_SUPABASE_ORGANIZATION",
        );
    }

    let organization =
        organizations[0];

    if (!organization) {
        if (!allowProvisioning) {
            throw new Error("CANONICAL_TENANT_NOT_PROVISIONED");
        }

        try {
            organization =
                await createOrganization(
                    client,
                    userId,
                );
        }
        catch (error: unknown) {
            const message =
                error instanceof Error
                    ? error.message
                    : "";

            if (
                !message.includes(
                    "duplicate key",
                )
            ) {
                throw error;
            }

            const recovered =
                await findOwnedOrganizations(
                    client,
                    userId,
                );

            if (
                recovered.length !==
                1
            ) {
                throw new Error(
                    "SUPABASE_ORGANIZATION_CREATE_RACE_UNRESOLVED",
                );
            }

            organization =
                recovered[0];
        }
    }

    if (allowProvisioning) {
        await ensureOrganizationMembership(
            client,
            organization.id,
            userId,
        );
    }

    const workspaces =
        await findOwnedWorkspaces(
            client,
            userId,
            organization.id,
        );

    if (
        workspaces.length > 1
    ) {
        throw new Error(
            "AMBIGUOUS_SUPABASE_WORKSPACE",
        );
    }

    let workspace =
        workspaces[0];

    if (!workspace) {
        if (!allowProvisioning) {
            throw new Error("CANONICAL_TENANT_NOT_PROVISIONED");
        }

        try {
            workspace =
                await createWorkspace(
                    client,
                    userId,
                    organization.id,
                );
        }
        catch (error: unknown) {
            const message =
                error instanceof Error
                    ? error.message
                    : "";

            if (
                !message.includes(
                    "duplicate key",
                )
            ) {
                throw error;
            }

            const recovered =
                await findOwnedWorkspaces(
                    client,
                    userId,
                    organization.id,
                );

            if (
                recovered.length !==
                1
            ) {
                throw new Error(
                    "SUPABASE_WORKSPACE_CREATE_RACE_UNRESOLVED",
                );
            }

            workspace =
                recovered[0];
        }
    }

    if (allowProvisioning) {
        await ensureWorkspaceMembership(
            client,
            workspace.id,
            userId,
        );
    }

    return {
        organizationId:
            organization.id,
        organizationName:
            organization.name,
        organizationSlug:
            organization.slug,
        workspaceId:
            workspace.id,
        workspaceName:
            workspace.name,
        workspaceSlug:
            workspace.slug,
        userId,
    };
}

