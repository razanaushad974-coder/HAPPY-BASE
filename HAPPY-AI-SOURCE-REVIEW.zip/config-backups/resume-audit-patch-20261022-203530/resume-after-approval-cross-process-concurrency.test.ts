import { appendFileSync, readFileSync } from "node:fs";
import { mkdtemp } from "node:fs/promises";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { spawn } from "node:child_process";

import { HappyOrchestrationEngine } from "../../../core/orchestration/engine";
import { JsonFileStateAdapter } from "../../../core/persistence/adapters/json-file-adapter";
import { PersistenceService } from "../../../core/persistence/service";
import { createHappyStateStore } from "../../../core/state/factory";
import type { ExecutionRequest, ExecutionResult } from "../../../core/execution/types";
import type { ExecutionPlan } from "../../../core/reasoning/types";

const requestId = "cross-process-resume-request";
const approvalId = "cross-process-resume-approval";
const planId = "cross-process-resume-plan";
const orgId = "cross-process-org";
const workspaceId = "cross-process-workspace";
const userId = "cross-process-user";

function assert(condition: boolean, message: string): void {
    if (!condition) throw new Error(message);
}

class SharedLogExecution {
    constructor(private readonly logFile: string) {}

    async execute(request: ExecutionRequest): Promise<ExecutionResult> {
        appendFileSync(this.logFile, `${request.id}\n`, "utf8");
        const now = new Date().toISOString();
        return {
            id: `cross-process-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: { recorded: true, action: request.action, taskId: request.taskId },
            startedAt: now,
            completedAt: now,
        };
    }
}

async function worker(stateFile: string, logFile: string): Promise<void> {
    const engine = new HappyOrchestrationEngine(stateFile);
    (engine as unknown as { execution: SharedLogExecution }).execution =
        new SharedLogExecution(logFile);

    process.stdout.write("WORKER_READY\n");
    await new Promise<void>((resolveReady) => {
        process.stdin.setEncoding("utf8");
        process.stdin.once("data", () => resolveReady());
    });

    try {
        const result = await engine.resumeAfterApproval(
            requestId, approvalId, planId, orgId, workspaceId, userId,
        );
        process.stdout.write(`WORKER_RESULT:${JSON.stringify({
            outcome: "resolved",
            status: result.status,
            missionId: result.missionId,
            persisted: result.persisted,
        })}\n`);
    } catch (error) {
        process.stdout.write(`WORKER_RESULT:${JSON.stringify({
            outcome: "rejected",
            error: error instanceof Error ? error.message : String(error),
        })}\n`);
    }
}

type ChildResult = {
    outcome: "resolved" | "rejected";
    status?: string;
    missionId?: string;
    persisted?: boolean;
    error?: string;
};

async function main(): Promise<void> {
    const dir = await mkdtemp(join(tmpdir(), "happy-cross-process-resume-"));
    const stateFile = join(dir, "state.json");
    const logFile = join(dir, "execution-calls.log");
    const persistence = new PersistenceService(new JsonFileStateAdapter(stateFile));
    const store = createHappyStateStore(persistence, orgId, workspaceId, userId);

    const actions = ["UNDERSTAND", "BUILD", "TEST", "VERIFY", "CONTROL"] as const;
    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId: "cross-process-reasoning",
        goal: "Verify cross-process resume claim safety",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps: actions.map((action, index) => ({
            id: `cross-process-step-${index + 1}`,
            order: index + 1,
            action,
            title: `${action} task`,
            description: `Cross-process concurrency test: ${action}`,
            dependencies: index === 0 ? [] : [`cross-process-step-${index}`],
            requiresApproval: false,
            risk: "LOW",
            verificationRequired: true,
        })),
        expectedOutputs: ["Five completed tasks"],
        failureConditions: ["A task executes more than once"],
        verificationRequirements: ["Execution evidence is persisted"],
        createdAt: new Date().toISOString(),
    };

    await store.mission().create(planId, plan, userId);
    await store.approval().create(approvalId, {
        requestId,
        planId,
        status: "APPROVED",
        createdAt: new Date().toISOString(),
        approvedAt: new Date().toISOString(),
        decision: "APPROVED",
        decisionId: "cross-process-decision",
        approverId: userId,
        decidedAt: new Date().toISOString(),
        decisionReason: "Approved for deterministic concurrency regression test",
    }, userId);

    const testFile = resolve(process.argv[1] ?? __filename);

    function launch(): {
        child: ReturnType<typeof spawn>;
        ready: Promise<void>;
        finished: Promise<{ code: number | null; output: string }>;
    } {
        const child = spawn(
            process.execPath,
            ["--import", "tsx", testFile, "--worker", stateFile, logFile],
            { cwd: process.cwd(), stdio: ["pipe", "pipe", "pipe"] },
        );

        let output = "";
        let stderr = "";
        let readyResolve!: () => void;
        let readyReject!: (error: Error) => void;
        let wasReady = false;

        const ready = new Promise<void>((resolveReady, rejectReady) => {
            readyResolve = resolveReady;
            readyReject = rejectReady;
        });

        child.stdout.setEncoding("utf8");
        child.stderr.setEncoding("utf8");
        child.stdout.on("data", (chunk: string) => {
            output += chunk;
            if (!wasReady && output.includes("WORKER_READY")) {
                wasReady = true;
                readyResolve();
            }
        });
        child.stderr.on("data", (chunk: string) => { stderr += chunk; });
        child.on("error", (error) => readyReject(error));

        const finished = new Promise<{ code: number | null; output: string }>((resolveFinished) => {
            child.on("close", (code) => {
                if (!wasReady) readyReject(new Error(`Worker exited before ready: ${stderr}`));
                resolveFinished({ code, output: output + stderr });
            });
        });

        return { child, ready, finished };
    }

    const workers = [launch(), launch()];
    const children = await Promise.all(workers);
    await Promise.all(children.map((item) => item.ready));

    // Release both independent processes only after both report ready.
    for (const item of children) {
        if (!item.child.stdin) throw new Error("Worker stdin unavailable");
        item.child.stdin.end("GO\n");
    }

    const completed = await Promise.all(children.map((item) => item.finished));
    assert(completed.every((item) => item.code === 0),
        `Worker process failed: ${completed.map((item) => item.output).join("\n---\n")}`);

    const results: ChildResult[] = [];
    for (const item of completed) {
        const line = item.output.split(/\r?\n/).find((entry) => entry.startsWith("WORKER_RESULT:"));
        assert(Boolean(line), `Missing worker result: ${item.output}`);
        results.push(JSON.parse(line!.slice("WORKER_RESULT:".length)) as ChildResult);
    }

    assert(
        results.every((result) =>
            result.outcome === "resolved" ||
            result.error === "RESUME_RECOVERY_RECONCILIATION_REQUIRED"
        ),
        `Expected race loser to fail closed with reconciliation error: ${JSON.stringify(results)}`,
    );
    const calls = readFileSync(logFile, "utf8")
        .split(/\r?\n/)
        .filter(Boolean);

    const freshStore = createHappyStateStore(
        new PersistenceService(new JsonFileStateAdapter(stateFile)),
        orgId, workspaceId, userId,
    );
    const audit = await freshStore.audit<Record<string, unknown>>().get(`audit-resume-${requestId}`);

    assert(calls.length === 5,
        `Expected exactly 5 total execution calls across both processes; got ${calls.length}. Calls: ${calls.join(", ")}`);
    assert(new Set(calls).size === 5,
        `Expected five unique execution IDs; got ${new Set(calls).size}.`);
    assert(results.some((result) => result.outcome === "resolved" && result.status === "COMPLETED"),
        `Expected at least one completed resume result: ${JSON.stringify(results)}`);
    assert(audit?.data.requestId === requestId &&
        audit?.data.approvalId === approvalId &&
        audit?.data.planId === planId,
        `Resume audit linkage mismatch: ${JSON.stringify(audit?.data)}`);

    process.stdout.write(`${JSON.stringify({
        test: "resume-after-approval-cross-process-concurrency",
        workerResults: results,
        totalExecutionCalls: calls.length,
        uniqueExecutionCalls: new Set(calls).size,
        auditEvent: audit?.data.event,
        auditLinkageValid: true,
        status: "PASS",
    }, null, 2)}\n`);
}

if (process.argv[2] === "--worker") {
    void worker(process.argv[3], process.argv[4]).catch((error) => {
        process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
        process.exitCode = 1;
    });
} else {
    void main().catch((error) => {
        process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`);
        process.exitCode = 1;
    });
}
