import { join } from "node:path";
import { tmpdir } from "node:os";
import { mkdtemp } from "node:fs/promises";

import {
    HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import {
    JsonFileStateAdapter,
} from "../../../core/persistence/adapters/json-file-adapter";

import {
    PersistenceService,
} from "../../../core/persistence/service";

import {
    createHappyStateStore,
} from "../../../core/state/factory";

import type {
    ExecutionRequest,
    ExecutionResult,
} from "../../../core/execution/types";

import type {
    ExecutionPlan,
} from "../../../core/reasoning/types";

class RecordingExecutionEngine {
    public readonly calls: ExecutionRequest[] = [];

    async execute(
        request: ExecutionRequest,
    ): Promise<ExecutionResult> {
        this.calls.push(request);

        if (this.calls.length === 2) {
            throw new Error("INJECTED_EXECUTION_FAILURE");
        }

        const now = new Date().toISOString();

        return {
            id: `recorded-result-${request.id}`,
            requestId: request.id,
            capability: request.capability,
            status: "COMPLETED",
            evidenceIds: [],
            output: {
                recorded: true,
                action: request.action,
                taskId: request.taskId,
            },
            startedAt: now,
            completedAt: now,
        };
    }
}

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

async function main(): Promise<void> {
    const stateDir = await mkdtemp(
        join(tmpdir(), "happy-step9d-crash-recovery-test-"),
    );

    const stateFile =
        join(
            stateDir,
            "orchestration-state.json",
        );

    const persistence =
        new PersistenceService(
            new JsonFileStateAdapter(
                stateFile,
            ),
        );

    const store =
        createHappyStateStore(
            persistence,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );

    const requestId =
        "resume-9b-request";

    const approvalId =
        "approval-resume-9b";

    const planId =
        "plan-resume-9b";

    const actions = [
        "UNDERSTAND",
        "BUILD",
        "TEST",
        "VERIFY",
        "CONTROL",
    ] as const;

    const plan: ExecutionPlan = {
        id: planId,
        reasoningRequestId:
            "reasoning-resume-9b",
        goal:
            "Resume a five-task mission after approval",
        status: "WAITING_APPROVAL",
        risk: "HIGH",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps:
            actions.map(
                (action, index) => ({
                    id:
                        `plan-step-resume-9b-${index + 1}`,
                    order:
                        index + 1,
                    action,
                    title:
                        `${action} task`,
                    description:
                        `Deterministic ${action} task for resume testing.`,
                    dependencies:
                        index === 0
                            ? []
                            : [
                                `plan-step-resume-9b-${index}`,
                            ],
                    requiresApproval:
                        false,
                    risk:
                        "LOW",
                    verificationRequired:
                        true,
                }),
            ),
        expectedOutputs: [
            "Five completed tasks",
            "Five verification results",
            "Five evidence records",
        ],
        failureConditions: [
            "Any task fails.",
            "Any task is skipped.",
            "Any task executes more than once.",
        ],
        verificationRequirements: [
            "Every task execution must complete.",
            "Evidence must be persisted for every task.",
        ],
        createdAt:
            new Date().toISOString(),
    };

    await store.mission().create(
        planId,
        plan,
        "user-9b",
    );

    await store.approval().create(
        approvalId,
        {
            requestId,
            planId,
            status:
                "APPROVED",
            createdAt:
                new Date().toISOString(),
            approvedAt:
                new Date().toISOString(),
            decision:
                "APPROVED",
            decisionId:
                "decision-resume-9b",
            approverId:
                "user-9b",
            decidedAt:
                new Date().toISOString(),
            decisionReason:
                "Deterministic multi-task resume regression test.",
        },
        "user-9b",
    );

    const engine =
        new HappyOrchestrationEngine(
            stateFile,
        );

    const recorder =
        new RecordingExecutionEngine();

    (
        engine as unknown as {
            execution:
                RecordingExecutionEngine;
        }
    ).execution =
        recorder;

    let initialError = "";

    try {
        await engine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );
    } catch (error) {
        initialError = error instanceof Error ? error.message : String(error);
    }

    assert(
        initialError.includes("INJECTED_EXECUTION_FAILURE"),
        `Expected injected failure on execution 2, got: ${initialError}`,
    );

    assert(
        recorder.calls.length === 2,
        `Expected failure on call 2, got ${recorder.calls.length} calls.`,
    );

    // Reload persisted state to simulate a fresh runtime.
    const freshPersistence = new PersistenceService(
        new JsonFileStateAdapter(stateFile),
    );

    const freshStore = createHappyStateStore(
        freshPersistence,
        "org-9b",
        "workspace-9b",
        "user-9b",
    );

    const audit = await freshStore
        .audit<Record<string, unknown>>()
        .get(`audit-resume-${requestId}`);

    assert(
        audit?.data.event === "PIPELINE_RESUME_OUTCOME_UNKNOWN",
        `Expected unknown-outcome audit; got: ${String(audit?.data.event)}`,
    );

    assert(
        audit?.data.reconciliationRequired === true,
        "Expected persisted reconciliation flag.",
    );

    assert(
        audit?.data.outcomeUnknown === true,
        "Expected explicit unknown-outcome marker.",
    );

    assert(
        typeof audit?.data.executionRequestId === "string",
        "Expected persisted execution request ID.",
    );

    let retryError = "";

    try {
        const freshEngine = new HappyOrchestrationEngine(stateFile);
        await freshEngine.resumeAfterApproval(
            requestId,
            approvalId,
            planId,
            "org-9b",
            "workspace-9b",
            "user-9b",
        );
    } catch (error) {
        retryError = error instanceof Error ? error.message : String(error);
    }

    assert(
        retryError === "RESUME_RECOVERY_RECONCILIATION_REQUIRED",
        `Expected fail-closed recovery guard, got: ${retryError}`,
    );

    assert(
        recorder.calls.length === 2,
        `Retry replayed execution; expected 2 calls, got ${recorder.calls.length}.`,
    );

    const persistedExecutions = await freshStore.execution().list();
    const persistedTasks = await freshStore.task().list();

    console.log("");
    console.log("================ STEP 9D RESULT ================");
    console.log(JSON.stringify({
        injectedFailure: initialError,
        retryError,
        executionCalls: recorder.calls.length,
        persistedAuditEvent: audit?.data.event,
        persistedExecutionRecords: persistedExecutions.length,
        persistedTaskRecords: persistedTasks.length,
    }, null, 2));

    console.log("");
    console.log("=== STEP 9D: FAIL-CLOSED RECOVERY VERIFIED ===");
}

main().catch(
    (error) => {
        console.error(error);
        process.exit(1);
    },
);





