import { NextResponse } from "next/server";

import {
    getAuthenticatedExecutionRuntimeContext,
} from "../../../../core/auth/supabase-runtime-context";

import {
    createAuthenticatedWorkspaceState,
} from "../../../../core/workspace/file-backed-state";

import {
    buildLiveWorkspaceDashboard,
} from "../../../../core/workspace/live-dashboard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
    try {
        const runtimeContext =
            await getAuthenticatedExecutionRuntimeContext();

        const localDevAuthenticated =
            process.env.HAPPY_LOCAL_DEV_MODE === "true" &&
            Boolean(
                runtimeContext.authenticatedUserId,
            ) &&
            !runtimeContext.supabaseAccessToken;

        if (
            !runtimeContext.authenticatedUserId ||
            (
                !runtimeContext.supabaseAccessToken &&
                !localDevAuthenticated
            )
        ) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    error:
                        "Authenticated Supabase user session is required.",
                },
                {
                    status: 401,
                },
            );
        }

        const authenticated =
            createAuthenticatedWorkspaceState(
                runtimeContext.authenticatedUserId,
            );

        const dashboard =
            buildLiveWorkspaceDashboard(
                authenticated.tenant,
                {
                    commands:
                        await authenticated.store
                            .command()
                            .list(),

                    missions:
                        await authenticated.store
                            .mission()
                            .list(),

                    tasks:
                        await authenticated.store
                            .task()
                            .list(),

                    executions:
                        await authenticated.store
                            .execution()
                            .list(),

                    verifications:
                        await authenticated.store
                            .verification()
                            .list(),

                    evidence:
                        await authenticated.store
                            .evidence()
                            .list(),

                    memories:
                        await authenticated.store
                            .memory()
                            .list(),

                    approvals:
                        await authenticated.store
                            .approval()
                            .list(),

                    auditEvents:
                        await authenticated.store
                            .audit()
                            .list(),
                },
            );

        return NextResponse.json(
            dashboard,
            {
                status: 200,
                headers: {
                    "Cache-Control":
                        "private, no-store",
                },
            },
        );
    }
    catch (error: unknown) {
        const message =
            error instanceof Error
                ? error.message
                : "HAPPY workspace state request failed.";

        if (
            message ===
            "WORKSPACE_TENANT_NOT_FOUND"
        ) {
            return NextResponse.json(
                {
                    status:
                        "WORKSPACE_NOT_INITIALIZED",
                    error:
                        "No persisted HAPPY workspace tenant exists for the authenticated user.",
                },
                {
                    status: 404,
                },
            );
        }

        if (
            message ===
            "AMBIGUOUS_WORKSPACE_TENANT"
        ) {
            return NextResponse.json(
                {
                    status:
                        "AMBIGUOUS_WORKSPACE_TENANT",
                    error:
                        "More than one persisted workspace tenant matches the authenticated user.",
                },
                {
                    status: 409,
                },
            );
        }

        if (
            message ===
            "Supabase server client is not configured."
        ) {
            return NextResponse.json(
                {
                    status:
                        "NOT_YET_CONNECTED",
                    error: message,
                },
                {
                    status: 503,
                },
            );
        }

        console.error(
            "HAPPY /api/workspace/state error:",
            error,
        );

        return NextResponse.json(
            {
                status: "FAILED",
                error: message,
            },
            {
                status: 500,
            },
        );
    }
}
