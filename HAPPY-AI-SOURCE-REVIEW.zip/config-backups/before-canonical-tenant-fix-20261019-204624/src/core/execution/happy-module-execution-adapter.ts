import type {
    ExecutionAdapter,
    ExecutionRequest,
    ExecutionResult,
} from "./types";
import type { ExecutionRuntimeContext } from "./runtime-context";
import {
    RealSupabaseModulePersistenceAdapter,
} from "../modules/data/real-supabase-module-persistence";
import {
    HappyModuleDataService,
} from "../modules/runtime/happy-module-data-service";

type ModuleCrudAction =
    | "CREATE"
    | "GET"
    | "READ"
    | "LIST"
    | "UPDATE"
    | "MODIFY"
    | "DELETE";

type ModuleCrudInput = {
    moduleNumber?: number;
    moduleId?: string;
    action?: ModuleCrudAction;
    recordId?: string;
    data?: Record<string, unknown>;
    expectedVersion?: number;
};

export class HappyModuleExecutionAdapter implements ExecutionAdapter {
    readonly capability = "DATABASE" as const;

    constructor(
        private readonly runtimeContext: ExecutionRuntimeContext,
    ) {}

    status(): "AVAILABLE" | "NOT_YET_CONNECTED" {
        const {
            organizationId,
            workspaceId,
            authenticatedUserId,
            supabaseAccessToken,
        } = this.runtimeContext;

        return organizationId &&
            workspaceId &&
            authenticatedUserId &&
            supabaseAccessToken
            ? "AVAILABLE"
            : "NOT_YET_CONNECTED";
    }

    canExecute(request: ExecutionRequest): boolean {
        if (request.capability !== "DATABASE") {
            return false;
        }

        const input =
            request.input as Record<string, unknown> | undefined;

        const route =
            input?.happyModuleRoute as
                | Record<string, unknown>
                | undefined;

        if (typeof route?.moduleNumber !== "number" || route.moduleNumber < 1 || route.moduleNumber > 502 || !Number.isInteger(route.moduleNumber)) {
            return false;
        }

        const crudInput =
            (input?.moduleCrud as ModuleCrudInput | undefined) ??
            (input as ModuleCrudInput);

        const action = String(
            crudInput.action ??
            route.moduleAction ??
            input?.action ??
            request.action ??
            "",
        ).toUpperCase();
        return ["CREATE", "GET", "READ", "LIST", "UPDATE", "MODIFY", "DELETE"].includes(action);
    }

    async execute(
        request: ExecutionRequest,
    ): Promise<ExecutionResult> {
        const startedAt = new Date().toISOString();

        const finish = (
            status: ExecutionResult["status"],
            output?: unknown,
            error?: string,
        ): ExecutionResult => ({
            id: crypto.randomUUID(),
            requestId: request.id,
            capability: "DATABASE",
            status,
            output,
            error,
            evidenceIds: [],
            startedAt,
            completedAt: new Date().toISOString(),
        });

        if (this.status() !== "AVAILABLE") {
            return finish(
                "NOT_YET_CONNECTED",
                undefined,
                "Authenticated Supabase module persistence context is unavailable.",
            );
        }

        const input =
            request.input as Record<string, unknown> | undefined;

        const route =
            input?.happyModuleRoute as
                | Record<string, unknown>
                | undefined;

        const moduleNumberValue = route?.moduleNumber;

        if (typeof moduleNumberValue !== "number" || !Number.isInteger(moduleNumberValue) || moduleNumberValue < 1 || moduleNumberValue > 502) {
            return finish(
                "BLOCKED",
                undefined,
                "HAPPY module number must be an integer between 1 and 502.",
            );
        }

        const moduleNumber: number = moduleNumberValue;
const crudInput =
            (input?.moduleCrud as ModuleCrudInput | undefined) ??
            (input as ModuleCrudInput);

        const action = String(
            crudInput.action ??
            route?.moduleAction ??
            input?.action ??
            request.action ??
            "",
        ).toUpperCase() as ModuleCrudAction;

        if (!["CREATE", "GET", "READ", "LIST", "UPDATE", "MODIFY", "DELETE"].includes(action)) {
            return finish(
                "BLOCKED",
                undefined,
                "Unsupported HAPPY module CRUD action.",
            );
        }
        const tenantId =
            this.runtimeContext.workspaceId!;

        try {
            const persistence =
                new RealSupabaseModulePersistenceAdapter({
                    organizationId:
                        this.runtimeContext.organizationId!,
                    workspaceId:
                        this.runtimeContext.workspaceId!,
                    userId:
                        this.runtimeContext.authenticatedUserId,
                    accessToken:
                        this.runtimeContext.supabaseAccessToken,
                });

            const service =
                new HappyModuleDataService(persistence);

            if (!service.persistenceConnected()) {
                return finish(
                    "NOT_YET_CONNECTED",
                    undefined,
                    "Real HAPPY module Supabase persistence is not connected.",
                );
            }

            switch (action) {
                case "CREATE": {
                    if (!crudInput.data) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "CREATE requires module data.",
                        );
                    }

                    const recordId =
                        crudInput.recordId ??
                        crypto.randomUUID();

                    const record =
                        await service.create({
                            recordId,
                            tenantId,
                            moduleNumber,
                            data: crudInput.data,
                        });

                    return finish("COMPLETED", record);
                }

                case "GET":
                case "READ": {
                    if (!crudInput.recordId) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "GET/READ requires recordId.",
                        );
                    }

                    const record =
                        await service.get(
                            tenantId,
                            moduleNumber,
                            crudInput.recordId,
                        );

                    return finish("COMPLETED", record);
                }

                case "LIST": {
                    const records =
                        await service.list(
                            tenantId,
                            moduleNumber,
                        );

                    return finish("COMPLETED", records);
                }

                case "UPDATE":
                case "MODIFY": {
                    if (!crudInput.recordId) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "UPDATE/MODIFY requires recordId.",
                        );
                    }

                    if (!crudInput.data) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "UPDATE/MODIFY requires module data.",
                        );
                    }

                    if (
                        typeof crudInput.expectedVersion !==
                        "number"
                    ) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "UPDATE/MODIFY requires expectedVersion.",
                        );
                    }

                    const record =
                        await service.update({
                            tenantId,
                            moduleNumber,
                            recordId:
                                crudInput.recordId,
                            data: crudInput.data,
                            expectedVersion:
                                crudInput.expectedVersion,
                        });

                    return finish("COMPLETED", record);
                }

                case "DELETE": {
                    if (!crudInput.recordId) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "DELETE requires recordId.",
                        );
                    }

                    if (
                        typeof crudInput.expectedVersion !==
                        "number"
                    ) {
                        return finish(
                            "BLOCKED",
                            undefined,
                            "DELETE requires expectedVersion.",
                        );
                    }

                    await service.delete(
                        tenantId,
                        moduleNumber,
                        crudInput.recordId,
                        crudInput.expectedVersion,
                    );

                    const remaining =
                        await service.get(
                            tenantId,
                            moduleNumber,
                            crudInput.recordId,
                        );

                    if (remaining !== null) {
                        return finish(
                            "FAILED",
                            undefined,
                            "DELETE verification failed: record still exists.",
                        );
                    }

                    return finish(
                        "COMPLETED",
                        {
                            deleted: true,
                            recordId:
                                crudInput.recordId,
                            verified: true,
                        },
                    );
                }

                default:
                    return finish(
                        "BLOCKED",
                        undefined,
                        `Unsupported HAPPY module CRUD action: ${action || "UNKNOWN"}.`,
                    );
            }
        } catch (error) {
            return finish(
                "FAILED",
                undefined,
                error instanceof Error
                    ? error.message
                    : String(error),
            );
        }
    }
}










