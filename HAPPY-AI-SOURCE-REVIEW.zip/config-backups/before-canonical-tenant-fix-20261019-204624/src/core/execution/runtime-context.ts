﻿export interface ExecutionRuntimeContext {
  supabaseAccessToken?: string;
  authenticatedUserId?: string;
  organizationId?: string;
  workspaceId?: string;
}
