﻿import "server-only";

import { cookies } from "next/headers";
import { createSupabaseServerClient } from "../../lib/supabase/server";
import type { ExecutionRuntimeContext } from "../execution/runtime-context";

const LOCAL_DEV_COOKIE = "happy_local_dev_session";

export async function getAuthenticatedExecutionRuntimeContext(): Promise<ExecutionRuntimeContext> {
  try {
    const supabase = await createSupabaseServerClient();

    const claimsResult = await supabase.auth.getClaims();

    if (!claimsResult.error && claimsResult.data?.claims?.sub) {
      const sessionResult = await supabase.auth.getSession();

      if (!sessionResult.error && sessionResult.data.session) {
        return {
          supabaseAccessToken: sessionResult.data.session.access_token,
          authenticatedUserId: claimsResult.data.claims.sub,
        };
      }
    }
  } catch {
    // Supabase is optional during local development.
  }

  if (process.env.HAPPY_LOCAL_DEV_MODE === "true") {
    const cookieStore = await cookies();

    if (cookieStore.get(LOCAL_DEV_COOKIE)?.value === "1") {
      return {
        authenticatedUserId: "local-dev-user",
      };
    }
  }

  return {};
}
