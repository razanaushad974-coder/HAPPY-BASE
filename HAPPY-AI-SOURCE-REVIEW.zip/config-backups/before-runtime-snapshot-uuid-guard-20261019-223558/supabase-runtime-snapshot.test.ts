import assert from "node:assert/strict";
import type { SupabaseClient } from "@supabase/supabase-js";

import type { HappyState } from "../../../core/persistence/state";
import {
  createRuntimeScopeKey,
  isSupabaseRuntimePersistenceConfigured,
  SupabaseRuntimeSnapshotStore,
  type RuntimeSnapshotScope,
} from "../../../core/persistence/adapters/supabase-runtime-snapshot";

function createEmptyState(): HappyState {
  return {
    users: [],
    workspaces: [],
    projects: [],
    commands: [],
    missions: [],
    tasks: [],
    executions: [],
    verifications: [],
    evidence: [],
    memories: [],
    approvals: [],
    auditEvents: [],
  };
}

type FakeRow = {
  scope_key: string;
  organization_id: string;
  workspace_id: string;
  user_id: string;
  state: HappyState;
  version: number;
  created_at: string;
  updated_at: string;
};

class FakeQueryBuilder {
  private filterKey: string | undefined;
  private filterValue: string | undefined;
  private deleteMode = false;

  constructor(
    private readonly rows: Map<string, FakeRow>,
  ) {}

  upsert(row: FakeRow): FakeQueryBuilder {
    this.rows.set(row.scope_key, {
      ...row,
      created_at:
        this.rows.get(row.scope_key)?.created_at ??
        new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    return this;
  }

  select(): FakeQueryBuilder {
    return this;
  }

  eq(
    key: string,
    value: string,
  ): FakeQueryBuilder {
    this.filterKey = key;
    this.filterValue = value;

    if (
      this.deleteMode &&
      key === "scope_key" &&
      value
    ) {
      this.rows.delete(value);
    }

    return this;
  }

  single(): {
    data: FakeRow;
    error: null;
  } {
    const row = this.resolve();

    assert.ok(row);

    return {
      data: row,
      error: null,
    };
  }

  maybeSingle(): {
    data: FakeRow | null;
    error: null;
  } {
    return {
      data: this.resolve() ?? null,
      error: null,
    };
  }

  delete(): FakeQueryBuilder {
    this.deleteMode = true;
    return this;
  }

  private resolve(): FakeRow | undefined {
    if (
      this.filterKey === "scope_key" &&
      this.filterValue
    ) {
      return this.rows.get(this.filterValue);
    }

    const first = this.rows.values().next();

    return first.done
      ? undefined
      : first.value;
  }
}

class FakeSupabaseClient {
  readonly rows = new Map<string, FakeRow>();

  from(): FakeQueryBuilder {
    return new FakeQueryBuilder(this.rows);
  }
}

function fakeClient(): SupabaseClient {
  return new FakeSupabaseClient() as unknown as SupabaseClient;
}

async function main(): Promise<void> {
  const scope: RuntimeSnapshotScope = {
    organizationId: "org-test",
    workspaceId: "workspace-test",
    userId: "user-test",
  };

  assert.equal(
    createRuntimeScopeKey(scope),
    "org-test|workspace-test|user-test",
  );

  const emptyEnv = {
    NODE_ENV: "test",
  } as NodeJS.ProcessEnv;

  assert.equal(
    isSupabaseRuntimePersistenceConfigured(
      emptyEnv,
    ),
    false,
  );

  const configuredEnv = {
    NODE_ENV: "test",
    NEXT_PUBLIC_SUPABASE_URL:
      "https://example.supabase.co",
    NEXT_PUBLIC_SUPABASE_ANON_KEY:
      "test-key",
  } as NodeJS.ProcessEnv;

  assert.equal(
    isSupabaseRuntimePersistenceConfigured(
      configuredEnv,
    ),
    true,
  );

  const disconnected =
    new SupabaseRuntimeSnapshotStore();

  assert.equal(
    disconnected.status(),
    "NOT_YET_CONNECTED",
  );

  const client = fakeClient();

  const connected =
    new SupabaseRuntimeSnapshotStore(
      client,
    );

  assert.equal(
    connected.status(),
    "AVAILABLE",
  );

  const state = createEmptyState();

  state.commands.push({
    id: "command-test",
    entityType: "COMMAND",
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    data: {
      text: "Persist this runtime state.",
    },
  });

  const saved =
    await connected.save(
      scope,
      state,
      7,
    );

  assert.equal(
    saved.scopeKey,
    "org-test|workspace-test|user-test",
  );

  assert.equal(
    saved.organizationId,
    "org-test",
  );

  assert.equal(
    saved.workspaceId,
    "workspace-test",
  );

  assert.equal(
    saved.userId,
    "user-test",
  );

  assert.equal(
    saved.version,
    7,
  );

  assert.equal(
    saved.state.commands.length,
    1,
  );

  const loaded =
    await connected.load(scope);

  assert.ok(loaded);
  assert.equal(
    loaded.version,
    7,
  );

  assert.equal(
    loaded.state.commands[0]?.id,
    "command-test",
  );

  await connected.clear(scope);

  const afterClear =
    await connected.load(scope);

  assert.equal(
    afterClear,
    undefined,
  );

  console.log(
    "Supabase runtime scope-key safety: PASS",
  );

  console.log(
    "Supabase configuration detection: PASS",
  );

  console.log(
    "NOT_YET_CONNECTED protection: PASS",
  );

  console.log(
    "Supabase snapshot save mapping: PASS",
  );

  console.log(
    "Supabase snapshot load mapping: PASS",
  );

  console.log(
    "Supabase snapshot clear mapping: PASS",
  );

  console.log(
    "#22 persistence adapter test: PASS",
  );
}

main().catch((error: unknown) => {
  console.error(error);
  throw error;
});
