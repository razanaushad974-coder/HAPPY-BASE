﻿import {
    bootstrapHappyMajorModules,
} from "../../../core/happy/kernel/registry/happy-module-bootstrap";

import {
    HAPPY_MAJOR_MODULE_CATALOG,
} from "../../../core/happy/kernel/registry/happy-major-module-catalog";

import {
    happyModuleRegistry,
} from "../../../core/happy/kernel/registry/happy-module-runtime";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

async function main(): Promise<void> {

    const before =
        happyModuleRegistry.list().length;

    const first =
        bootstrapHappyMajorModules();

    assert(
        first.success,
        "HAPPY module bootstrap must succeed.",
    );

    assert(
        first.total === 502,
        `Expected 502 registered modules, got ${first.total}.`,
    );

    assert(
        first.registered +
            first.alreadyRegistered ===
            502,
        "Bootstrap accounting must equal 502.",
    );

    const after =
        happyModuleRegistry.list().length;

    assert(
        after === 502,
        `Runtime registry must contain 502 modules, got ${after}.`,
    );

    assert(
        HAPPY_MAJOR_MODULE_CATALOG.length ===
            502,
        "Source catalog must contain 502 modules.",
    );

    const second =
        bootstrapHappyMajorModules();

    assert(
        second.total === 502,
        "Bootstrap must be idempotent.",
    );

    assert(
        second.registered === 0,
        "Second bootstrap must not duplicate registrations.",
    );

    assert(
        second.alreadyRegistered === 502,
        "Second bootstrap must recognize all existing modules.",
    );

    assert(
        happyModuleRegistry.has(
            "m001-happy-ai-core",
        ),
        "Module 001 missing from runtime registry.",
    );

    assert(
        happyModuleRegistry.has(
            "m041-founder-dashboard",
        ),
        "Module 041 missing from runtime registry.",
    );

    assert(
        happyModuleRegistry.has(
            "m322-ai-website-generator",
        ),
        "Module 322 missing from runtime registry.",
    );

    assert(
        happyModuleRegistry.has(
            "m500-plugin-marketplace",
        ),
        "Module 500 missing from runtime registry.",
    );

    assert(
        happyModuleRegistry.has(
            "m502-system-administration",
        ),
        "Module 502 missing from runtime registry.",
    );

    const founder =
        happyModuleRegistry.get(
            "m041-founder-dashboard",
        );

    assert(
        founder !== undefined,
        "Founder Dashboard runtime definition missing.",
    );

    assert(
        founder?.name ===
            "Founder Dashboard",
        "Founder Dashboard name mismatch.",
    );

    console.log(
        "STEP 5 HAPPY 502 MODULE RUNTIME BOOTSTRAP: PASS",
    );

    console.log({
        catalogModules:
            HAPPY_MAJOR_MODULE_CATALOG.length,
        runtimeModules:
            after,
        initiallyRegistered:
            first.registered,
        initiallyAlreadyRegistered:
            first.alreadyRegistered,
        idempotentSecondRun:
            second.registered === 0 &&
            second.alreadyRegistered === 502,
        module001:
            happyModuleRegistry.has(
                "m001-happy-ai-core",
            ),
        founderDashboard:
            happyModuleRegistry.has(
                "m041-founder-dashboard",
            ),
        websiteGenerator:
            happyModuleRegistry.has(
                "m322-ai-website-generator",
            ),
        pluginMarketplace:
            happyModuleRegistry.has(
                "m500-plugin-marketplace",
            ),
        systemAdministration:
            happyModuleRegistry.has(
                "m502-system-administration",
            ),
    });
}

main().catch((error) => {
    console.error(error);
    process.exit(1);
});
