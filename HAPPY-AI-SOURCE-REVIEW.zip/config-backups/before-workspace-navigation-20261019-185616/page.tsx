"use client";

import {
    useEffect,
    useState,
} from "react";

type LiveMissionSummary = {
    missionId: string;
    goal: string;
    status: string;
    progressPercent: number;
    taskCount: number;
    completedTaskCount: number;
    failedTaskCount: number;
    blockedTaskCount: number;
};

type LiveTimelineEvent = {
    id: string;
    type: string;
    title: string;
    description?: string;
    timestamp: string;
    status?: string;
    referenceId?: string;
};

type LiveCapabilityStatus = "READY" | "PARTIAL" | "BLOCKED" | "NOT_YET_CONNECTED" | "UNKNOWN";
type LiveReadinessCheck = { id: string; status: LiveCapabilityStatus; reason?: string };
type LiveWorkspaceState = {
    source?: string;
    durable?: boolean;
    tenant?: {
        organizationId?: string;
        workspaceId?: string;
        userId?: string;
    };
    metrics?: {
        commandCount: number;
        missionCount: number;
        activeMissionCount: number;
        taskCount: number;
        completedTaskCount: number;
        readyTaskCount: number;
        executionCount: number;
        verificationCount: number;
        passedVerificationCount: number;
        evidenceCount: number;
        memoryCount: number;
        approvalCount: number;
    };
    currentMission?: LiveMissionSummary;
    missionQueue?: LiveMissionSummary[];
    readyTasks?: Array<{
        taskId: string;
        missionId: string;
        title: string;
        status: string;
        order: number;
        dependencyCount: number;
    }>;
    timeline?: LiveTimelineEvent[];
    memory?: {
        total: number;
        user: number;
        project: number;
        mission: number;
        task: number;
        session: number;
    };
    verifications?: Array<{
        verificationId: string;
        missionId: string;
        taskId?: string;
        status: string;
        confidence?: string;
        evidenceCount: number;
    }>;
    generatedAt?: string;
};

export default function WorkspacePage() {
    const [command, setCommand] = useState("");
    const [commandStatus, setCommandStatus] =
        useState("");
    const [commandResult, setCommandResult] =
        useState("");
    const [executionTrace, setExecutionTrace] =
        useState<{
            stages?: Array<{
                stage?: string;
                status?: string;
            }>;
            currentStage?: string;
            status?: string;
        } | null>(null);
    const [workspaceState, setWorkspaceState] =
        useState<LiveWorkspaceState | null>(null);
    const [readinessChecks, setReadinessChecks] = useState<LiveReadinessCheck[]>([]);
    const [readinessError, setReadinessError] = useState("");

    const [workspaceLoading, setWorkspaceLoading] =
        useState(true);

    const [workspaceError, setWorkspaceError] =
        useState("");

    const [running, setRunning] =
        useState(false);

    async function loadWorkspaceState(): Promise<void> {
        setWorkspaceLoading(true);
        setWorkspaceError("");

        try {
            const response =
                await fetch(
                    "/api/workspace/state",
                    {
                        method: "GET",
                        cache: "no-store",
                    },
                );

            const payload =
                (await response.json()) as
                    LiveWorkspaceState & {
                        status?: string;
                        error?: string;
                    };

            if (!response.ok) {
                setWorkspaceState(null);
                setWorkspaceError(
                    payload.error ??
                        payload.status ??
                        `HTTP_${response.status}`,
                );
                return;
            }

            setWorkspaceState(payload);
        }
        catch (error: unknown) {
            setWorkspaceState(null);

            setWorkspaceError(
                error instanceof Error
                    ? error.message
                    : "Unable to load live Workspace state.",
            );
        }
        finally {
            setWorkspaceLoading(false);
        }
    }

    useEffect(() => {
        const timer = window.setTimeout(() => {
            void loadWorkspaceState();
        }, 0);

        return () =>
            window.clearTimeout(timer);
    }, []);

    useEffect(() => {
        let active = true;

        fetch("/api/system/readiness", { cache: "no-store" })
            .then(async (response) => {
                if (!response.ok) throw new Error(`Readiness request failed (${response.status})`);
                return response.json();
            })
            .then((payload: { checks?: LiveReadinessCheck[] }) => {
                if (!active) return;
                setReadinessChecks(Array.isArray(payload.checks) ? payload.checks : []);
                setReadinessError("");
            })
            .catch(() => {
                if (active) setReadinessError("Readiness unavailable");
            });

        return () => {
            active = false;
        };
    }, []);
    async function runCommand(): Promise<void> {
        const trimmed =
            command.trim();

        if (!trimmed || running) {
            return;
        }

        setRunning(true);
        setCommandStatus("SENDING");
        setCommandResult("");
        setExecutionTrace(null);

        try {
            const response =
                await fetch("/api/execute", {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json",
                    },
                    body: JSON.stringify({
                        command: trimmed,
                        organizationId:
                            "demo-org",
                        workspaceId:
                            "demo-workspace",
                        source:
                            "API",
                    }),
                });

            const payload =
                (await response.json()) as {
                    status?: string;
                    error?: string;
                    currentStage?: string;
                    trace?: {
                        stages?: Array<{
                            stage?: string;
                            status?: string;
                        }>;
                        currentStage?: string;
                        status?: string;
                    };
                    output?: unknown;
                };

            if (!response.ok) {
                setCommandStatus(
                    payload.status ??
                        `HTTP_${response.status}`,
                );

                setCommandResult(
                    payload.error ??
                        "HAPPY request was not accepted.",
                );

                return;
            }

            setCommandStatus(
                payload.status ??
                    "COMPLETED",
            );

            setExecutionTrace(
                payload.trace ?? null,
            );
            const returnedOutput =
                typeof payload.output === "object" &&
                payload.output !== null
                    ? payload.output as {
                        provider?: string;
                        model?: string;
                        content?: string;
                    }
                    : undefined;

            const aiContent =
                typeof returnedOutput?.content === "string"
                    ? returnedOutput.content.trim()
                    : "";

            const resultMessage =
                payload.currentStage
                    ? `Current stage: ${payload.currentStage}`
                    : "HAPPY returned an execution result.";

            setCommandResult(
                aiContent
                    ? `${resultMessage} • AI output: ${aiContent}`
                    : resultMessage,
            );

            void loadWorkspaceState();
        }
        catch (error: unknown) {
            setCommandStatus("FAILED");

            setCommandResult(
                error instanceof Error
                    ? error.message
                    : "Unable to reach HAPPY.",
            );
        }
        finally {
            setRunning(false);
        }
    }

    type FlowState =
        "DONE" |
        "RUNNING" |
        "WAITING" |
        "BLOCKED";

    function flowStateFor(
        group:
            | "COMMAND"
            | "UNDERSTAND"
            | "PLAN"
            | "EXECUTE"
            | "VERIFY",
    ): FlowState {
        if (!executionTrace) {
            return group === "COMMAND" ||
                group === "UNDERSTAND"
                ? "DONE"
                : group === "PLAN"
                    ? "RUNNING"
                    : "WAITING";
        }

        const pipelineStatus =
            executionTrace.status;

        const currentStage =
            executionTrace.currentStage;

        if (pipelineStatus === "COMPLETED") {
            return "DONE";
        }

        if (
            pipelineStatus === "FAILED" ||
            pipelineStatus === "BLOCKED" ||
            pipelineStatus === "NOT_YET_CONNECTED"
        ) {
            const blockedStages = new Set([
                "BLOCKED",
                "NOT_YET_CONNECTED",
            ]);

            const currentGroup =
                currentStage === "COMMAND"
                    ? "COMMAND"
                    : [
                        "CONTEXT",
                        "MEMORY",
                        "REASON",
                    ].includes(currentStage ?? "")
                        ? "UNDERSTAND"
                        : currentStage === "PLAN"
                            ? "PLAN"
                            : [
                                "APPROVAL",
                                "MISSION",
                                "TASK_GRAPH",
                                "EXECUTION",
                            ].includes(currentStage ?? "")
                                ? "EXECUTE"
                                : [
                                    "VERIFICATION",
                                    "EVIDENCE",
                                ].includes(currentStage ?? "")
                                    ? "VERIFY"
                                    : undefined;

            if (currentGroup === group) {
                return blockedStages.has(
                    pipelineStatus,
                )
                    ? "BLOCKED"
                    : "RUNNING";
            }

            const order = {
                COMMAND: 0,
                UNDERSTAND: 1,
                PLAN: 2,
                EXECUTE: 3,
                VERIFY: 4,
            } as const;

            if (
                currentGroup !== undefined &&
                order[group] < order[currentGroup]
            ) {
                return "DONE";
            }

            return "WAITING";
        }

        if (
            pipelineStatus === "WAITING_APPROVAL"
        ) {
            const order = {
                COMMAND: 0,
                UNDERSTAND: 1,
                PLAN: 2,
                EXECUTE: 3,
                VERIFY: 4,
            } as const;

            if (group === "EXECUTE") {
                return "WAITING";
            }

            const currentOrder =
                order.EXECUTE;

            return order[group] < currentOrder
                ? "DONE"
                : "WAITING";
        }

        const currentGroup =
            currentStage === "COMMAND"
                ? "COMMAND"
                : [
                    "CONTEXT",
                    "MEMORY",
                    "REASON",
                ].includes(currentStage ?? "")
                    ? "UNDERSTAND"
                    : currentStage === "PLAN"
                        ? "PLAN"
                        : [
                            "APPROVAL",
                            "MISSION",
                            "TASK_GRAPH",
                            "EXECUTION",
                        ].includes(currentStage ?? "")
                            ? "EXECUTE"
                            : [
                                "VERIFICATION",
                                "EVIDENCE",
                            ].includes(currentStage ?? "")
                                ? "VERIFY"
                                : undefined;

        if (currentGroup === undefined) {
            return "WAITING";
        }

        const order = {
            COMMAND: 0,
            UNDERSTAND: 1,
            PLAN: 2,
            EXECUTE: 3,
            VERIFY: 4,
        } as const;

        if (order[group] < order[currentGroup]) {
            return "DONE";
        }

        if (order[group] === order[currentGroup]) {
            return "RUNNING";
        }

        return "WAITING";
    }

    const commandFlowState =
        flowStateFor("COMMAND");

    const understandFlowState =
        flowStateFor("UNDERSTAND");

    const planFlowState =
        flowStateFor("PLAN");

    const executeFlowState =
        flowStateFor("EXECUTE");

    const verifyFlowState =
        flowStateFor("VERIFY");

    return (
        <main className="shell">
            <aside className="sidebar">
                <div className="brand">
                    <div className="logo">H</div>
                    <div>
                        <div className="name">HAPPY</div>
                        <div className="sub">WORKSPACE OS</div>
                    </div>
                </div>

                <div className="section">COMMAND CENTER</div>
                <div className="nav active">Overview</div>
                <div className="nav">Missions</div>
                <div className="nav">Tasks</div>
                <div className="nav">Activity</div>

                <div className="section">SYSTEM</div>
                <div className="nav">Memory</div>
                <div className="nav">Projects</div>
                <div className="nav">Workflows</div>
                <div className="nav">Capabilities</div>

                <div className="section">CONTROL</div>
                <a className="nav" href="/workspace/approvals">Approvals</a>
                <div className="nav">Evidence</div>
                <div className="nav">Settings</div>

                <div className="runtime">
                    <div className="dot" />
                    <div>
                        <b>HAPPY Runtime</b>
                        <span>Core foundation active</span>
                    </div>
                </div>
            </aside>

            <section className="main">
                <header className="header">
                    <div>
                        <div className="eyebrow">
                            WORKSPACE OS / LIVE
                        </div>

                        <h1>
                            Good to see you,
                            <em> boss.</em>
                        </h1>

                        <p>
                            Command, plan, execute, verify and persist
                            from one HAPPY workspace.
                        </p>
                    </div>

                    <div className="avatar">MR</div>
                </header>

                <section className="command">
                    <div className="label">COMMAND CENTER</div>

                    <div className="commandRow">
                        <input
                            value={command}
                            onChange={(e) =>
                                setCommand(e.target.value)
                            }
                            placeholder="Tell HAPPY what you want to accomplish..."
                        />

                        <button className="mic">â—‰</button>

                        <button
                            className="run"
                            onClick={runCommand}
                            disabled={
                                running ||
                                !command.trim()
                            }
                        >
                            {
                                running
                                    ? "Running..."
                                    : "Run Command"
                            }
                        </button>
                    </div>

                    <div className="chips">
                        <span>Try:</span>

                        <button
                            onClick={() =>
                                setCommand(
                                    "Show my current mission status"
                                )
                            }
                        >
                            mission status
                        </button>

                        <button
                            onClick={() =>
                                setCommand(
                                    "Plan my next development tasks"
                                )
                            }
                        >
                            plan next tasks
                        </button>

                        <button
                            onClick={() =>
                                setCommand(
                                    "Review recent activity"
                                )
                            }
                        >
                            review activity
                        </button>
                    </div>
                </section>

                {commandStatus && (
                    <section className="commandResult">
                        <div className="resultLabel">
                            HAPPY EXECUTION
                        </div>

                        <div className="resultStatus">
                            {commandStatus}
                        </div>

                        <div className="resultMessage">
                            {commandResult}
                        </div>
                    </section>
                )}
                <section className="metrics">
                    <Metric
                        title="ACTIVE MISSIONS"
                        value={
                            workspaceLoading
                                ? "—"
                                : String(
                                    workspaceState
                                        ?.metrics
                                        ?.activeMissionCount ??
                                    0,
                                ).padStart(2, "0")
                        }
                        detail={
                            workspaceLoading
                                ? "Loading live state"
                                : `${
                                    workspaceState
                                        ?.metrics
                                        ?.missionCount ??
                                    0
                                } total missions`
                        }
                    />

                    <Metric
                        title="TASKS"
                        value={
                            workspaceLoading
                                ? "—"
                                : String(
                                    workspaceState
                                        ?.metrics
                                        ?.taskCount ??
                                    0,
                                )
                        }
                        detail={
                            workspaceLoading
                                ? "Loading live state"
                                : `${
                                    workspaceState
                                        ?.metrics
                                        ?.completedTaskCount ??
                                    0
                                } completed`
                        }
                    />

                    <Metric
                        title="APPROVALS"
                        value={
                            workspaceLoading
                                ? "—"
                                : String(
                                    workspaceState
                                        ?.metrics
                                        ?.approvalCount ??
                                    0,
                                ).padStart(2, "0")
                        }
                        detail={
                            workspaceLoading
                                ? "Loading live state"
                                : "Pending approvals"
                        }
                    />

                    <Metric
                        title="EVIDENCE"
                        value={
                            workspaceLoading
                                ? "—"
                                : String(
                                    workspaceState
                                        ?.metrics
                                        ?.evidenceCount ??
                                    0,
                                )
                        }
                        detail={
                            workspaceLoading
                                ? "Loading live state"
                                : `${
                                    workspaceState
                                        ?.metrics
                                        ?.passedVerificationCount ??
                                    0
                                } passed verifications`
                        }
                    />
                </section>

                <section className="two">
                    <Panel title="Current Mission">
                        {workspaceLoading && (
                            <Mission
                                title="Loading persisted HAPPY mission..."
                                progress={0}
                                status="LOADING"
                            />
                        )}

                        {!workspaceLoading &&
                            workspaceError && (
                                <Mission
                                    title="Workspace state unavailable"
                                    progress={0}
                                    status="NOT_YET_CONNECTED"
                                />
                            )}

                        {!workspaceLoading &&
                            !workspaceError &&
                            workspaceState?.currentMission && (
                                <Mission
                                    title={
                                        workspaceState
                                            .currentMission
                                            .goal
                                    }
                                    progress={
                                        workspaceState
                                            .currentMission
                                            .progressPercent
                                    }
                                    status={
                                        workspaceState
                                            .currentMission
                                            .status
                                    }
                                />
                            )}

                        {!workspaceLoading &&
                            !workspaceError &&
                            !workspaceState?.currentMission && (
                                <Mission
                                    title="No active persisted mission"
                                    progress={0}
                                    status="EMPTY"
                                />
                            )}
                    </Panel>

                    <Panel title="Recent Activity">
                        {workspaceLoading && (
                            <Activity
                                text="Loading live HAPPY activity..."
                                time="Now"
                            />
                        )}

                        {!workspaceLoading &&
                            workspaceError && (
                                <Activity
                                    text={
                                        workspaceError
                                    }
                                    time="Live state"
                                />
                            )}

                        {!workspaceLoading &&
                            !workspaceError &&
                            (
                                workspaceState
                                    ?.timeline ??
                                []
                            )
                                .slice(0, 5)
                                .map(
                                    (event) => (
                                        <Activity
                                            key={
                                                `${event.type}-${event.id}`
                                            }
                                            text={
                                                event.title
                                            }
                                            time={
                                                event.timestamp
                                            }
                                        />
                                    ),
                                )}

                        {!workspaceLoading &&
                            !workspaceError &&
                            (
                                workspaceState
                                    ?.timeline
                                    ?.length ??
                                0
                            ) === 0 && (
                                <Activity
                                    text="No persisted activity yet"
                                    time="Live state"
                                />
                            )}
                    </Panel>
                </section>

                <section className="two">
                    <Panel title="Task Flow">
                        <div className="flow">
                            <Node
                                text="COMMAND"
                                state={commandFlowState}
                            />
                            <Arrow />
                            <Node
                                text="UNDERSTAND"
                                state={understandFlowState}
                            />
                            <Arrow />
                            <Node
                                text="PLAN"
                                state={planFlowState}
                            />
                            <Arrow />
                            <Node
                                text="EXECUTE"
                                state={executeFlowState}
                            />
                            <Arrow />
                            <Node
                                text="VERIFY"
                                state={verifyFlowState}
                            />
                        </div>
                    </Panel>

                    <Panel title="Capabilities">
                        <div className="capabilities">
                            <Capability text="CODE" status={readinessChecks.find((item) => item.id === "execution.code")?.status ?? "UNKNOWN"} />
                            <Capability text="FILE" status={readinessChecks.find((item) => item.id === "execution.file")?.status ?? "UNKNOWN"} />
                            <Capability text="API" status={readinessChecks.find((item) => item.id === "execution.api")?.status ?? "UNKNOWN"} />
                            <Capability text="BROWSER" status={readinessChecks.find((item) => item.id === "execution.browser")?.status ?? "UNKNOWN"} />
                            <Capability text="SHELL" status={readinessChecks.find((item) => item.id === "execution.shell")?.status ?? "UNKNOWN"} />
                            <Capability text="DATABASE" status={readinessChecks.find((item) => item.id === "execution.database")?.status ?? "UNKNOWN"} />
                            <Capability text="AI" status={readinessChecks.find((item) => item.id === "execution.ai")?.status ?? "UNKNOWN"} />
                            <Capability text="DEPLOYMENT" status={readinessChecks.find((item) => item.id === "execution.deployment")?.status ?? "UNKNOWN"} />
                            <Capability text="PUBLISH" status={readinessChecks.find((item) => item.id === "execution.publish")?.status ?? "UNKNOWN"} />
                            <Capability text="AUTOMATION" status={readinessChecks.find((item) => item.id === "execution.automation")?.status ?? "UNKNOWN"} />
                            {readinessError && <div className="capState unknown">{readinessError}</div>}
                        </div>
                    </Panel>
                </section>

                <footer>
                    HAPPY AI • Workspace OS
                    <span>Authenticated live state • persisted runtime</span>
                </footer>
            </section>

            <style jsx>{`
                :global(*) {
                    box-sizing: border-box;
                }

                :global(body) {
                    margin: 0;
                    background: #070707;
                    color: #f5efdf;
                    font-family:
                        Inter,
                        ui-sans-serif,
                        system-ui,
                        -apple-system,
                        BlinkMacSystemFont,
                        "Segoe UI",
                        sans-serif;
                }

                .shell {
                    min-height: 100vh;
                    display: flex;
                    background:
                        radial-gradient(
                            circle at 78% 8%,
                            rgba(206, 169, 74, 0.09),
                            transparent 27%
                        ),
                        #070707;
                }

                .sidebar {
                    width: 245px;
                    min-height: 100vh;
                    padding: 24px 16px;
                    border-right: 1px solid #28241c;
                    background: #0b0b0a;
                    display: flex;
                    flex-direction: column;
                }

                .brand {
                    display: flex;
                    gap: 11px;
                    align-items: center;
                    padding: 4px 8px 25px;
                }

                .logo {
                    width: 42px;
                    height: 42px;
                    border-radius: 12px;
                    display: grid;
                    place-items: center;
                    color: #090806;
                    font-size: 21px;
                    font-weight: 900;
                    background:
                        linear-gradient(145deg,#e0c26c,#997327);
                    box-shadow:
                        0 0 25px rgba(210,175,83,.15);
                }

                .name {
                    font-weight: 900;
                    letter-spacing: .16em;
                    font-size: 18px;
                }

                .sub {
                    color: #777166;
                    font-size: 9px;
                    letter-spacing: .16em;
                    margin-top: 3px;
                }

                .section {
                    margin: 19px 8px 7px;
                    color: #686259;
                    font-size: 9px;
                    font-weight: 800;
                    letter-spacing: .16em;
                }

                .nav {
                    padding: 10px 12px;
                    border-radius: 10px;
                    color: #9b9588;
                    font-size: 13px;
                    margin-bottom: 3px;
                }

                .nav.active {
                    color: #f0dfaa;
                    background: rgba(201,163,70,.11);
                    border: 1px solid rgba(201,163,70,.14);
                }

                .runtime {
                    margin-top: auto;
                    border: 1px solid #28251f;
                    border-radius: 12px;
                    background: #10100e;
                    padding: 12px;
                    display: flex;
                    align-items: center;
                    gap: 9px;
                }

                .runtime b {
                    display: block;
                    font-size: 10px;
                }

                .runtime span {
                    display: block;
                    margin-top: 3px;
                    color: #6e685d;
                    font-size: 9px;
                }

                .dot {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: #c4a451;
                    box-shadow: 0 0 10px rgba(196,164,81,.7);
                }

                .main {
                    width: calc(100% - 245px);
                    padding: 34px;
                }

                .header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                }

                .eyebrow,
                .label {
                    color: #ac9049;
                    font-size: 10px;
                    font-weight: 800;
                    letter-spacing: .18em;
                }

                h1 {
                    margin: 8px 0 6px;
                    font-size: clamp(32px, 4vw, 52px);
                    line-height: 1;
                    letter-spacing: -.04em;
                }

                h1 em {
                    color: #d6b65d;
                    font-style: normal;
                }

                .header p {
                    margin: 0;
                    color: #837d71;
                    font-size: 14px;
                }

                .avatar {
                    width: 44px;
                    height: 44px;
                    border-radius: 12px;
                    display: grid;
                    place-items: center;
                    color: #ddc47e;
                    border: 1px solid #3a321f;
                    background: #12110e;
                    font-size: 11px;
                    font-weight: 900;
                }

                .command {
                    margin-top: 30px;
                    padding: 21px;
                    border-radius: 17px;
                    border: 1px solid #342d1e;
                    background:
                        linear-gradient(
                            135deg,
                            rgba(208,169,75,.08),
                            #0d0d0c 38%
                        );
                }

                .commandRow {
                    display: flex;
                    gap: 9px;
                    margin-top: 10px;
                }

                input {
                    min-width: 0;
                    flex: 1;
                    color: #eee3cc;
                    background: #090908;
                    border: 1px solid #322e26;
                    border-radius: 11px;
                    padding: 14px 16px;
                    outline: none;
                    font-size: 14px;
                }

                input:focus {
                    border-color: #8c702c;
                }

                button {
                    font-family: inherit;
                }

                .run:disabled {
                    opacity: .45;
                    cursor: not-allowed;
                }
                .mic,
                .run {
                    border-radius: 11px;
                    font-weight: 800;
                    cursor: pointer;
                }

                .mic {
                    width: 46px;
                    border: 1px solid #3d341f;
                    color: #d1b15c;
                    background: #15130f;
                }

                .run {
                    padding: 0 18px;
                    border: 0;
                    color: #0b0906;
                    background:
                        linear-gradient(145deg,#dfc06b,#a37827);
                }

                .chips {
                    margin-top: 11px;
                    display: flex;
                    flex-wrap: wrap;
                    gap: 8px;
                    align-items: center;
                    color: #6e685d;
                    font-size: 10px;
                }

                .chips button {
                    border: 1px solid #28251f;
                    color: #9d9588;
                    background: #0e0e0d;
                    border-radius: 999px;
                    padding: 6px 9px;
                    cursor: pointer;
                }

                .commandResult {
                    margin-top: 12px;
                    padding: 14px 16px;
                    border-radius: 13px;
                    border: 1px solid #302d25;
                    background: #0c0c0b;
                }

                .resultLabel {
                    color: #8f7a43;
                    font-size: 9px;
                    font-weight: 800;
                    letter-spacing: .14em;
                }

                .resultStatus {
                    margin-top: 5px;
                    color: #d2bd7e;
                    font-size: 12px;
                    font-weight: 800;
                }

                .resultMessage {
                    margin-top: 8px;
                    color: #8f897d;
                    font-size: 11px;
                    line-height: 1.5;
                }
                .metrics {
                    display: grid;
                    grid-template-columns: repeat(4,1fr);
                    gap: 13px;
                    margin-top: 15px;
                }

                .metric {
                    padding: 15px;
                    border-radius: 14px;
                    border: 1px solid #24221d;
                    background: #0d0d0c;
                }

                .metricTitle {
                    color: #716b60;
                    font-size: 9px;
                    letter-spacing: .12em;
                    font-weight: 800;
                }

                .metricValue {
                    margin-top: 7px;
                    font-size: 27px;
                    font-weight: 900;
                }

                .metricDetail {
                    color: #6d675c;
                    margin-top: 2px;
                    font-size: 10px;
                }

                .two {
                    display: grid;
                    grid-template-columns: 1.1fr .9fr;
                    gap: 14px;
                    margin-top: 14px;
                }

                .panel {
                    padding: 18px;
                    border-radius: 15px;
                    background: #0d0d0c;
                    border: 1px solid #24221d;
                }

                .panelTitle {
                    color: #ddd3be;
                    font-size: 13px;
                    font-weight: 850;
                    margin-bottom: 14px;
                }

                .mission {
                    border-top: 1px solid #211f1a;
                    padding: 13px 0;
                }

                .mission:first-of-type {
                    border-top: 0;
                    padding-top: 0;
                }

                .missionTop {
                    display: flex;
                    justify-content: space-between;
                    gap: 10px;
                }

                .missionName {
                    font-size: 12px;
                    font-weight: 700;
                    color: #cfc4ae;
                }

                .status {
                    font-size: 8px;
                    letter-spacing: .08em;
                    color: #bda35a;
                    padding: 5px 7px;
                    border-radius: 99px;
                    border: 1px solid #43391f;
                }

                .planned {
                    color: #767065;
                    border-color: #2b2822;
                }

                .track {
                    height: 5px;
                    margin-top: 10px;
                    border-radius: 99px;
                    background: #191814;
                    overflow: hidden;
                }

                .fill {
                    height: 100%;
                    border-radius: inherit;
                    background: linear-gradient(90deg,#98782f,#d4b45f);
                }

                .percent {
                    display: flex;
                    justify-content: space-between;
                    color: #69645a;
                    font-size: 9px;
                    margin-top: 6px;
                }

                .activity {
                    padding: 10px 0;
                    border-top: 1px solid #201e19;
                    display: flex;
                    gap: 9px;
                }

                .activity:first-of-type {
                    border-top: 0;
                    padding-top: 0;
                }

                .activityDot {
                    width: 7px;
                    height: 7px;
                    min-width: 7px;
                    border-radius: 50%;
                    margin-top: 4px;
                    background: #c8a651;
                }

                .activityText {
                    color: #c0b7a7;
                    font-size: 10px;
                }

                .activityTime {
                    color: #656057;
                    font-size: 9px;
                    margin-top: 3px;
                }

                .flow {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    overflow-x: auto;
                }

                .node {
                    min-width: 105px;
                    padding: 10px;
                    border-radius: 10px;
                    border: 1px solid #27241e;
                    background: #11110f;
                }

                .node.running {
                    border-color: #715b29;
                    box-shadow: 0 0 18px rgba(196,161,70,.08);
                }

                .nodeName {
                    font-size: 8px;
                    font-weight: 850;
                    letter-spacing: .1em;
                }

                .nodeState {
                    color: #69645b;
                    font-size: 8px;
                    margin-top: 5px;
                }

                .arrow {
                    color: #5c574d;
                }

                .capabilities {
                    display: grid;
                    grid-template-columns: repeat(2,1fr);
                    gap: 8px;
                }

                .cap {
                    padding: 10px;
                    border-radius: 9px;
                    background: #10100f;
                    border: 1px solid #211f1a;
                }

                .capName {
                    font-size: 10px;
                    font-weight: 850;
                }

                .capState {
                    margin-top: 4px;
                    font-size: 8px;
                }

                .ready {
                    color: #baa15a;
                }

                .notReady {
                    color: #625d54;
                }

                footer {
                    display: flex;
                    justify-content: space-between;
                    color: #57534d;
                    font-size: 9px;
                    margin-top: 18px;
                    padding-bottom: 5px;
                }

                footer span {
                    color: #44413c;
                }

                @media (max-width: 1000px) {
                    .sidebar {
                        width: 200px;
                    }

                    .main {
                        width: calc(100% - 200px);
                        padding: 24px;
                    }

                    .commandResult {
                    margin-top: 12px;
                    padding: 14px 16px;
                    border-radius: 13px;
                    border: 1px solid #302d25;
                    background: #0c0c0b;
                }

                .resultLabel {
                    color: #8f7a43;
                    font-size: 9px;
                    font-weight: 800;
                    letter-spacing: .14em;
                }

                .resultStatus {
                    margin-top: 5px;
                    color: #d2bd7e;
                    font-size: 12px;
                    font-weight: 800;
                }

                .resultMessage {
                    margin-top: 8px;
                    color: #8f897d;
                    font-size: 11px;
                    line-height: 1.5;
                }
                .metrics {
                        grid-template-columns: repeat(2,1fr);
                    }
                }

                @media (max-width: 780px) {
                    .shell {
                        display: block;
                    }

                    .sidebar {
                        width: 100%;
                        min-height: auto;
                        border-right: 0;
                        border-bottom: 1px solid #24221d;
                    }

                    .runtime {
                        display: none;
                    }

                    .main {
                        width: 100%;
                        padding: 18px;
                    }

                    .two {
                        grid-template-columns: 1fr;
                    }
                }
            `}</style>
        </main>
    );
}

function Metric({
    title,
    value,
    detail,
}: {
    title: string;
    value: string;
    detail: string;
}) {
    return (
        <div className="metric">
            <div className="metricTitle">{title}</div>
            <div className="metricValue">{value}</div>
            <div className="metricDetail">{detail}</div>
        </div>
    );
}

function Panel({
    title,
    children,
}: {
    title: string;
    children: React.ReactNode;
}) {
    return (
        <div className="panel">
            <div className="panelTitle">{title}</div>
            {children}
        </div>
    );
}

function Mission({
    title,
    progress,
    status,
}: {
    title: string;
    progress: number;
    status: string;
}) {
    return (
        <div className="mission">
            <div className="missionTop">
                <div className="missionName">{title}</div>
                <div className={status === "PLANNED" ? "status planned" : "status"}>
                    {status}
                </div>
            </div>

            <div className="track">
                <div
                    className="fill"
                    style={{ width: `${progress}%` }}
                />
            </div>

            <div className="percent">
                <span>{progress}% complete</span>
                <span>{status === "RUNNING" ? "Live" : "Queued"}</span>
            </div>
        </div>
    );
}

function Activity({
    text,
    time,
}: {
    text: string;
    time: string;
}) {
    return (
        <div className="activity">
            <div className="activityDot" />

            <div>
                <div className="activityText">{text}</div>
                <div className="activityTime">{time}</div>
            </div>
        </div>
    );
}

function Node({
    text,
    state,
}: {
    text: string;
    state: "DONE" | "RUNNING" | "WAITING" | "BLOCKED";
}) {
    return (
        <div className={state === "RUNNING" ? "node running" : "node"}>
            <div className="nodeName">{text}</div>
            <div className="nodeState">{state}</div>
        </div>
    );
}

function Arrow() {
    return <div className="arrow">â†’</div>;
}

function Capability({
    text,
    status = "UNKNOWN",
}: {
    text: string;
    status?: LiveCapabilityStatus;
}) {
    return (
        <div className="cap">
            <div className="capName">{text}</div>
            <div className={`capState ${status.toLowerCase()}`}>
                {status}
            </div>
        </div>
    );
}









