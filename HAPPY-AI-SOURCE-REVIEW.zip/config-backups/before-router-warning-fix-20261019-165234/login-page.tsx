"use client";

import {
    FormEvent,
    useState,
} from "react";

import {
    createSupabaseBrowserClient,
} from "../../lib/supabase/client";

export default function LoginPage() {
    const [email, setEmail] =
        useState("");

    const [password, setPassword] =
        useState("");

    const [mode, setMode] =
        useState<"signin" | "signup">("signin");

    const [status, setStatus] =
        useState("");

    const [message, setMessage] =
        useState("");

    const [busy, setBusy] =
        useState(false);

    async function submit(
        event: FormEvent<HTMLFormElement>,
    ): Promise<void> {
        event.preventDefault();

        const cleanEmail =
            email.trim();

        if (
            !cleanEmail ||
            !password
        ) {
            setStatus("INVALID_REQUEST");
            setMessage(
                "Email and password are required.",
            );
            return;
        }

        setBusy(true);
        setStatus(
            mode === "signin"
                ? "SIGNING_IN"
                : "CREATING_ACCOUNT",
        );
        setMessage("");

        try {
            const supabase =
                createSupabaseBrowserClient();

            if (mode === "signin") {
                const result =
                    await supabase.auth.signInWithPassword({
                        email: cleanEmail,
                        password,
                    });

                if (result.error) {
                    setStatus("AUTH_FAILED");
                    setMessage(
                        result.error.message,
                    );
                    return;
                }

                setStatus("AUTHENTICATED");
                setMessage(
                    "Authentication successful. Redirecting to HAPPY Workspace...",
                );

                window.location.href =
                    "/workspace";

                return;
            }

            const result =
                await supabase.auth.signUp({
                    email: cleanEmail,
                    password,
                });

            if (result.error) {
                setStatus("SIGNUP_FAILED");
                setMessage(
                    result.error.message,
                );
                return;
            }

            setStatus("ACCOUNT_CREATED");

            if (
                result.data.session
            ) {
                setMessage(
                    "Account created. Opening HAPPY Workspace...",
                );

                window.location.href =
                    "/workspace";
            }
            else {
                setMessage(
                    "Account created. Check your email if confirmation is required, then sign in.",
                );
            }
        }
        catch (error: unknown) {
            setStatus("NOT_YET_CONNECTED");

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Supabase authentication is not configured.",
            );
        }
        finally {
            setBusy(false);
        }
    }

    return (
        <main className="page">
            <section className="card">
                <div className="brand">
                    <div className="logo">
                        H
                    </div>

                    <div>
                        <div className="name">
                            HAPPY
                        </div>

                        <div className="sub">
                            AI WORKSPACE OS
                        </div>
                    </div>
                </div>

                <div className="eyebrow">
                    SECURE ACCESS
                </div>

                <h1>
                    {mode === "signin"
                        ? "Welcome back."
                        : "Create your HAPPY account."}
                </h1>

                <p className="intro">
                    {mode === "signin"
                        ? "Sign in to continue to your authenticated HAPPY Workspace."
                        : "Create an account for authenticated HAPPY Workspace access."}
                </p>

                <form
                    onSubmit={submit}
                    className="form"
                >
                    <label>
                        Email
                        <input
                            type="email"
                            autoComplete="email"
                            value={email}
                            onChange={(event) =>
                                setEmail(
                                    event.target.value,
                                )
                            }
                            placeholder="you@example.com"
                        />
                    </label>

                    <label>
                        Password
                        <input
                            type="password"
                            autoComplete={
                                mode === "signin"
                                    ? "current-password"
                                    : "new-password"
                            }
                            value={password}
                            onChange={(event) =>
                                setPassword(
                                    event.target.value,
                                )
                            }
                            placeholder="Enter your password"
                        />
                    </label>

                    <button
                        type="submit"
                        disabled={busy}
                    >
                        {busy
                            ? "Please wait..."
                            : mode === "signin"
                                ? "Sign In"
                                : "Create Account"}
                    </button>
                </form>

                {status && (
                    <div className="result">
                        <div className="resultLabel">
                            {status}
                        </div>

                        <div className="resultMessage">
                            {message}
                        </div>
                    </div>
                )}

                <button
                    type="button"
                    className="switch"
                    onClick={() => {
                        setMode(
                            mode === "signin"
                                ? "signup"
                                : "signin",
                        );

                        setStatus("");
                        setMessage("");
                    }}
                >
                    {mode === "signin"
                        ? "Need an account? Create one"
                        : "Already have an account? Sign in"}
                </button>

                <div className="security">
                    <div className="securityDot" />
                    <span>
                        Authentication handled by Supabase SSR session.
                    </span>
                </div>
            </section>

            <style jsx>{`
                :global(*) {
                    box-sizing: border-box;
                }

                :global(body) {
                    margin: 0;
                    min-height: 100vh;
                    background: #070707;
                    color: #f4eddd;
                    font-family:
                        Inter,
                        ui-sans-serif,
                        system-ui,
                        -apple-system,
                        BlinkMacSystemFont,
                        "Segoe UI",
                        sans-serif;
                }

                .page {
                    min-height: 100vh;
                    display: grid;
                    place-items: center;
                    padding: 24px;
                    background:
                        radial-gradient(
                            circle at 50% 10%,
                            rgba(204, 168, 76, .10),
                            transparent 35%
                        ),
                        #070707;
                }

                .card {
                    width: min(100%, 460px);
                    padding: 32px;
                    border-radius: 20px;
                    border: 1px solid #302b20;
                    background:
                        linear-gradient(
                            150deg,
                            rgba(201, 164, 71, .07),
                            #0d0d0c 38%
                        );
                    box-shadow:
                        0 30px 100px rgba(0, 0, 0, .45);
                }

                .brand {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    margin-bottom: 42px;
                }

                .logo {
                    width: 44px;
                    height: 44px;
                    border-radius: 12px;
                    display: grid;
                    place-items: center;
                    color: #090806;
                    background:
                        linear-gradient(
                            145deg,
                            #e1c36c,
                            #9c7427
                        );
                    font-size: 22px;
                    font-weight: 900;
                }

                .name {
                    font-size: 19px;
                    font-weight: 900;
                    letter-spacing: .16em;
                }

                .sub {
                    margin-top: 3px;
                    color: #746e62;
                    font-size: 9px;
                    letter-spacing: .16em;
                }

                .eyebrow {
                    color: #a98d45;
                    font-size: 9px;
                    letter-spacing: .17em;
                    font-weight: 800;
                }

                h1 {
                    margin: 8px 0;
                    font-size: 32px;
                    letter-spacing: -.035em;
                }

                .intro {
                    margin: 0 0 24px;
                    color: #80796c;
                    font-size: 13px;
                    line-height: 1.6;
                }

                .form {
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                }

                label {
                    display: flex;
                    flex-direction: column;
                    gap: 7px;
                    color: #a39c8f;
                    font-size: 11px;
                    font-weight: 700;
                }

                input {
                    width: 100%;
                    padding: 13px 14px;
                    border-radius: 10px;
                    border: 1px solid #302c24;
                    background: #090908;
                    color: #eee4d0;
                    outline: none;
                    font: inherit;
                }

                input:focus {
                    border-color: #8b6d2c;
                    box-shadow:
                        0 0 0 3px
                        rgba(188, 151, 67, .08);
                }

                form button {
                    margin-top: 4px;
                    border: 0;
                    border-radius: 10px;
                    padding: 13px 16px;
                    background:
                        linear-gradient(
                            145deg,
                            #dfc16b,
                            #a57928
                        );
                    color: #0a0907;
                    font-weight: 850;
                    cursor: pointer;
                }

                form button:disabled {
                    opacity: .5;
                    cursor: not-allowed;
                }

                .result {
                    margin-top: 16px;
                    padding: 13px 14px;
                    border-radius: 11px;
                    border: 1px solid #292620;
                    background: #10100f;
                }

                .resultLabel {
                    color: #c4a65b;
                    font-size: 9px;
                    font-weight: 800;
                    letter-spacing: .11em;
                }

                .resultMessage {
                    margin-top: 6px;
                    color: #8b8579;
                    font-size: 11px;
                    line-height: 1.5;
                }

                .switch {
                    width: 100%;
                    margin-top: 15px;
                    border: 1px solid #2a2822;
                    border-radius: 10px;
                    padding: 11px 13px;
                    background: #10100e;
                    color: #afa696;
                    cursor: pointer;
                    font-size: 11px;
                }

                .security {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    margin-top: 22px;
                    padding-top: 17px;
                    border-top: 1px solid #201f1a;
                    color: #625e56;
                    font-size: 9px;
                    line-height: 1.4;
                }

                .securityDot {
                    width: 7px;
                    height: 7px;
                    min-width: 7px;
                    border-radius: 50%;
                    background: #b99b51;
                }
            `}</style>
        </main>
    );
}