﻿"use client";

import { useState } from "react";

export default function LocalDevPage() {
  const [status, setStatus] = useState("");

  async function enterLocalDevMode() {
    setStatus("Starting local development session...");

    try {
      const response = await fetch("/api/auth/local-dev", {
        method: "POST",
      });

      const data = await response.json();

      if (!response.ok) {
        setStatus(data?.error || "Local development mode is unavailable.");
        return;
      }

      window.location.href = "/workspace";
    } catch {
      setStatus("Could not start local development session.");
    }
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#050505",
        color: "#f5f5f5",
        display: "grid",
        placeItems: "center",
        padding: 24,
        fontFamily: "Arial, sans-serif",
      }}
    >
      <section
        style={{
          width: "100%",
          maxWidth: 520,
          border: "1px solid #2d2d2d",
          borderRadius: 20,
          padding: 32,
          background: "#0b0b0b",
        }}
      >
        <div style={{ fontSize: 14, color: "#d4af37", marginBottom: 10 }}>
          HAPPY AI
        </div>

        <h1 style={{ margin: 0, fontSize: 32 }}>
          Local Development Mode
        </h1>

        <p style={{ color: "#aaa", lineHeight: 1.6 }}>
          This mode is for local development only. It does not replace
          production authentication and does not require Supabase credentials.
        </p>

        <button
          onClick={enterLocalDevMode}
          style={{
            marginTop: 20,
            width: "100%",
            padding: "14px 18px",
            borderRadius: 12,
            border: "1px solid #d4af37",
            background: "#d4af37",
            color: "#050505",
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Enter HAPPY Workspace
        </button>

        {status && (
          <p style={{ marginTop: 16, color: "#aaa" }}>
            {status}
          </p>
        )}
      </section>
    </main>
  );
}
