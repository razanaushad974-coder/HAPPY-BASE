import { NextResponse } from "next/server";
import {
    countHappyFeatures,
    countHappyFeaturesByState,
    getHappyFeature,
    getHappyFeatureState,
    getHappyFeatureContract,
    isHappyFeatureReady,
    isHappyFeatureVerificationRequired,
    listHappyFeatures,
    resolveHappyFeatureDependencyGraph,
} from "@/core/happy/kernel/feature-registry";
export async function GET(request: Request) {
    const featureId = new URL(request.url).searchParams.get("id");
    return NextResponse.json({
        status: "AVAILABLE",
        system: "HAPPY AI",
        total: countHappyFeatures(),
        byState: countHappyFeaturesByState(),
        features: listHappyFeatures(),
        dependencyGraph: featureId ? resolveHappyFeatureDependencyGraph(featureId) : [],
        requestedFeature: featureId ? getHappyFeature(featureId) ?? null : null,
        requestedFeatureState: featureId ? getHappyFeatureState(featureId) : null,
        requestedFeatureContract: featureId ? getHappyFeatureContract(featureId) ?? null : null,
        requestedFeatureReady: featureId ? isHappyFeatureReady(featureId) : false,
        requestedFeatureVerificationRequired: featureId ? isHappyFeatureVerificationRequired(featureId) : false,
    });
}



