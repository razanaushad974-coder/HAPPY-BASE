import assert from "node:assert/strict";

import {
    getCapability,
    getCapabilityCounts,
    hasCapability,
    listCapabilities,
    listCapabilitiesByDomain,
    listCapabilitiesByStatus,
    requireCapability,
} from "../../../core/capabilities";

function main(): void {
    const all =
        listCapabilities();

    assert.ok(
        all.length >= 20,
        "Registry must contain the initial HAPPY capability set",
    );

    const ids =
        all.map(
            (
                capability,
            ) =>
                capability.id,
        );

    assert.equal(
        new Set(ids).size,
        ids.length,
        "Capability IDs must be unique",
    );

    for (
        const capability
        of all
    ) {
        assert.ok(
            capability.id.length > 0,
            `Capability ID missing: ${capability.name}`,
        );

        assert.ok(
            capability.domain.length > 0,
            `Capability domain missing: ${capability.id}`,
        );

        if (
            capability.requiresApproval
        ) {
            assert.ok(
                Boolean(
                    capability.approvalReason,
                ),
                `Approval reason missing: ${capability.id}`,
            );
        }

        if (
            capability.verificationRequired
        ) {
            assert.ok(
                capability.evidenceRequired,
                `Evidence must accompany verification: ${capability.id}`,
            );
        }

        if (
            capability.status ===
                "NOT_YET_CONNECTED"
        ) {
            assert.equal(
                capability.implementedBy.length,
                0,
                `NOT_YET_CONNECTED capability cannot claim implementation: ${capability.id}`,
            );
        }

        if (
            capability.status ===
                "BLOCKED"
        ) {
            assert.equal(
                capability.implementedBy.length,
                0,
                `BLOCKED capability cannot claim implementation: ${capability.id}`,
            );
        }
    }

    const fileCapability =
        requireCapability(
            "file.read",
        );

    assert.equal(
        fileCapability.domain,
        "FILE",
    );

    assert.equal(
        fileCapability.status,
        "AVAILABLE",
    );

    assert.ok(
        fileCapability.executionTypes.includes(
            "FILE",
        ),
    );

    const browserCapability =
        requireCapability(
            "browser.playwright",
        );

    assert.equal(
        browserCapability.status,
        "AVAILABLE",
    );

    assert.ok(
        browserCapability.actions.includes(
            "NAVIGATE",
        ),
    );

    const geminiCapability =
        requireCapability(
            "ai.gemini.generate",
        );

    assert.equal(
        geminiCapability.status,
        "AVAILABLE",
    );

    const externalDb =
        requireCapability(
            "database.external-persistence",
        );

    assert.equal(
        externalDb.status,
        "NOT_YET_CONNECTED",
    );

    const sandbox =
        requireCapability(
            "sandbox.execute",
        );

    assert.equal(
        sandbox.status,
        "BLOCKED",
    );

    assert.equal(
        hasCapability(
            "file.read",
        ),
        true,
    );

    assert.equal(
        hasCapability(
            "does.not.exist",
        ),
        false,
    );

    assert.throws(
        () =>
            requireCapability(
                "does.not.exist",
            ),
        /CAPABILITY_NOT_FOUND/,
    );

    const executionCapabilities =
        listCapabilitiesByDomain(
            "FILE",
        );

    assert.ok(
        executionCapabilities.length >=
            3,
    );

    const available =
        listCapabilitiesByStatus(
            "AVAILABLE",
        );

    const notConnected =
        listCapabilitiesByStatus(
            "NOT_YET_CONNECTED",
        );

    const blocked =
        listCapabilitiesByStatus(
            "BLOCKED",
        );

    assert.ok(
        available.length > 0,
    );

    assert.ok(
        notConnected.length > 0,
    );

    assert.ok(
        blocked.length > 0,
    );

    const counts =
        getCapabilityCounts();

    assert.equal(
        counts.AVAILABLE,
        available.length,
    );

    assert.equal(
        counts.NOT_YET_CONNECTED,
        notConnected.length,
    );

    assert.equal(
        counts.BLOCKED,
        blocked.length,
    );

    console.log(
        "Total capabilities:",
        all.length,
    );

    console.log(
        "AVAILABLE:",
        counts.AVAILABLE,
    );

    console.log(
        "NOT_YET_CONNECTED:",
        counts.NOT_YET_CONNECTED,
    );

    console.log(
        "BLOCKED:",
        counts.BLOCKED,
    );

    console.log(
        "File capability:",
        fileCapability.id,
        fileCapability.status,
    );

    console.log(
        "Browser capability:",
        browserCapability.id,
        browserCapability.status,
    );

    console.log(
        "Gemini capability:",
        geminiCapability.id,
        geminiCapability.status,
    );

    console.log(
        "External DB capability:",
        externalDb.id,
        externalDb.status,
    );

    console.log(
        "Sandbox capability:",
        sandbox.id,
        sandbox.status,
    );

    console.log(
        "RESULT: PASS",
    );
}

main();
