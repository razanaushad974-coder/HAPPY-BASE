﻿import { NextResponse } from "next/server";

import {
    createSupabaseServerClient,
} from "../../../../lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
    try {
        const supabase =
            await createSupabaseServerClient();

        const {
            data: userResult,
            error: userError,
        } =
            await supabase.auth.getUser();

        if (userError || !userResult.user) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    authenticated: false,
                    error:
                        userError?.message ??
                        "Authenticated Supabase user is required.",
                },
                {
                    status: 401,
                },
            );
        }

        const userId =
            userResult.user.id;

        const {
            data: organizations,
            error: organizationsError,
        } =
            await supabase
                .from("organizations")
                .select(
                    "id,name,slug,owner_user_id,created_at,updated_at",
                )
                .eq(
                    "owner_user_id",
                    userId,
                );

        const {
            data: workspaces,
            error: workspacesError,
        } =
            await supabase
                .from("workspaces")
                .select(
                    "id,organization_id,name,slug,owner_user_id,created_at,updated_at",
                )
                .eq(
                    "owner_user_id",
                    userId,
                );

        return NextResponse.json(
            {
                status:
                    organizationsError ||
                    workspacesError
                        ? "LIVE_TENANT_READ_ERROR"
                        : "LIVE_TENANT_READ",
                authenticated: true,
                userId,
                organizations:
                    organizations ?? [],
                organizationsError:
                    organizationsError?.message ??
                    null,
                workspaces:
                    workspaces ?? [],
                workspacesError:
                    workspacesError?.message ??
                    null,
            },
            {
                status:
                    organizationsError ||
                    workspacesError
                        ? 502
                        : 200,
            },
        );
    } catch (error: unknown) {
        return NextResponse.json(
            {
                status: "LIVE_TENANT_DIAGNOSTIC_ERROR",
                authenticated: false,
                error:
                    error instanceof Error
                        ? error.message
                        : "Tenant diagnostic failed.",
            },
            {
                status: 500,
            },
        );
    }
}
