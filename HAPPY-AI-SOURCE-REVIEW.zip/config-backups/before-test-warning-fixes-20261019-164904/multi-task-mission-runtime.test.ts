import {
    existsSync,
    mkdtempSync,
    rmSync,
} from "node:fs";

import {
    join,
} from "node:path";

import {
    HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import type {
    ExecutionPlan,
} from "../../../core/reasoning/types";

import type {
    ExecutionRequest,
    ExecutionResult,
} from "../../../core/execution/types";

import type {
    ExecutionRuntimeContext,
} from "../../../core/execution/runtime-context";

function assert(
    condition: boolean,
    message: string,
): void {
    if (!condition) {
        throw new Error(message);
    }
}

class RecordingExecutionEngine {
    public calls: ExecutionRequest[] = [];

    async execute(
        request: ExecutionRequest,
        _runtimeContext: ExecutionRuntimeContext = {},
    ): Promise<ExecutionResult> {
        this.calls.push(request);

        return {
            id:
                `recorded-${request.id}`,
            requestId:
                request.id,
            capability:
                request.capability,
            status:
                "COMPLETED",
            output: {
                taskId:
                    request.taskId,
                action:
                    request.action,
            },
            evidenceIds: [],
            startedAt:
                new Date().toISOString(),
            completedAt:
                new Date().toISOString(),
        };
    }
}

function buildFiveTaskPlan(): ExecutionPlan {
    const now =
        new Date().toISOString();

    const missionPlanId =
        `multi-task-plan-${Date.now()}`;

    const steps = [
        "UNDERSTAND",
        "BUILD",
        "TEST",
        "VERIFY",
        "CONTROL",
    ] as const;

    return {
        id:
            missionPlanId,
        reasoningRequestId:
            `reasoning-${missionPlanId}`,
        goal:
            "Execute a five-step HAPPY mission completely.",
        status:
            "READY",
        risk:
            "LOW",
        resolvedReferences: [],
        assumptions: [],
        unresolvedQuestions: [],
        requiredCapabilities: [],
        steps:
            steps.map(
                (action, index) => ({
                    id:
                        `${missionPlanId}-step-${index + 1}`,
                    order:
                        index + 1,
                    action,
                    title:
                        `Mission step ${index + 1}`,
                    description:
                        `Deterministic multi-task test step ${index + 1}.`,
                    dependencies:
                        index === 0
                            ? []
                            : [
                                  `${missionPlanId}-step-${index}`,
                              ],
                    requiresApproval:
                        false,
                    risk:
                        "LOW",
                    verificationRequired:
                        true,
                }),
            ),
        expectedOutputs: [
            "Five verified task executions.",
        ],
        failureConditions: [],
        verificationRequirements: [
            "Every task must execute and verify.",
        ],
        createdAt:
            now,
    };
}

async function main(): Promise<void> {
    const tempDirectory =
        mkdtempSync(
            join(
                process.cwd(),
                ".happy-step9-red-",
            ),
        );

    const persistenceFile =
        join(
            tempDirectory,
            "orchestration-state.json",
        );

    try {
        const orchestration =
            new HappyOrchestrationEngine(
                persistenceFile,
            );

        const recorder =
            new RecordingExecutionEngine();

        (
            orchestration as unknown as {
                execution:
                    RecordingExecutionEngine;
                reasoning: {
                    createAIExecutionPlan:
                        (
                            input: {
                                goal: string;
                            },
                        ) => Promise<ExecutionPlan>;
                };
            }
        ).execution =
            recorder;

        (
            orchestration as unknown as {
                reasoning: {
                    createAIExecutionPlan:
                        (
                            input: {
                                goal: string;
                            },
                        ) => Promise<ExecutionPlan>;
                };
            }
        ).reasoning = {
            async createAIExecutionPlan() {
                return buildFiveTaskPlan();
            },
        };

        const result =
            await orchestration.run({
                id:
                    "step9-multi-task-red",
                command:
                    "execute a five-step HAPPY mission completely",
                organizationId:
                    "step9-org",
                workspaceId:
                    "step9-workspace",
                userId:
                    "step9-user",
                source:
                    "SYSTEM",
                authorization: {
                    role: "USER" as const,
                    scope: "WORKSPACE" as const,
                    roleSource: "TRUSTED_SERVER" as const,
                    authenticated: true,
                },
                approved:
                    true,
                createdAt:
                    new Date().toISOString(),
            });

        console.log({
            executionCalls:
                recorder.calls.length,
            taskIds:
                recorder.calls.map(
                    (request) =>
                        request.taskId,
                ),
            actions:
                recorder.calls.map(
                    (request) =>
                        request.action,
                ),
            finalStatus:
                result.status,
            finalStage:
                result.currentStage,
        });

        /*
         * RED acceptance contract:
         *
         * A TRUE multi-task mission must execute all 5 tasks.
         * The current engine is expected to fail this assertion
         * because it currently executes only the first ready task.
         */

        assert(
            recorder.calls.length === 5,
            `Expected 5 execution calls for 5 mission tasks, received ${recorder.calls.length}.`,
        );

        assert(
            new Set(
                recorder.calls.map(
                    (request) =>
                        request.taskId,
                ),
            ).size === 5,
            "Expected five distinct mission task executions.",
        );

        assert(
            result.status ===
                "COMPLETED",
            `Expected mission result COMPLETED after all verified tasks, received ${result.status}.`,
        );

        assert(
            result.currentStage ===
                "COMPLETE",
            `Expected final stage COMPLETE, received ${result.currentStage}.`,
        );

        assert(
            existsSync(persistenceFile),
            "Mission persistence file was not created.",
        );

        console.log(
            "STEP 9A MULTI-TASK: VERIFIED PASS",
        );
    } finally {
        if (existsSync(tempDirectory)) {
            rmSync(
                tempDirectory,
                {
                    recursive:
                        true,
                    force:
                        true,
                },
            );
        }
    }
}

main().catch(
    (error: unknown) => {
        console.error(error);
        process.exitCode = 1;
    },
);

