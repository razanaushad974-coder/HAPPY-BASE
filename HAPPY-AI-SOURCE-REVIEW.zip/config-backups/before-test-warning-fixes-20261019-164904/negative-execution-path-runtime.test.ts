import {
  mkdtempSync,
  readFileSync,
  rmSync,
} from "node:fs";

import {
  tmpdir,
} from "node:os";

import {
  join,
} from "node:path";

import {
  HappyOrchestrationEngine,
} from "../../../core/orchestration/engine";

import type {
  ExecutionRequest,
  ExecutionResult,
} from "../../../core/execution/types";

import type {
  ExecutionRuntimeContext,
} from "../../../core/execution/runtime-context";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(message);
  }
}

function assertDefined<T>(
  value: T | undefined,
  message: string,
): asserts value is T {
  if (value === undefined) {
    throw new Error(message);
  }
}

type NegativeStatus =
  | "FAILED"
  | "BLOCKED"
  | "WAITING_APPROVAL"
  | "NOT_YET_CONNECTED";

interface NegativeCaseResult {
  status: NegativeStatus;
  executionCalls: number;
  finalStatus: string;
  finalStage: string;
  executionStage?: string;
  verificationStage?: string;
  evidenceCount: number;
  verificationRequestPresent: boolean;
  persistedExecution: boolean;
  persistedVerification: boolean;
  persistedEvidence: boolean;
  persistedApproval: boolean;
}

class NegativeExecutionEngine {
  public calls = 0;

  public lastRequest:
    | ExecutionRequest
    | undefined;

  constructor(
    private readonly resultStatus: NegativeStatus,
  ) {}

  async execute(
    request: ExecutionRequest,
    _runtimeContext: ExecutionRuntimeContext = {},
  ): Promise<ExecutionResult> {
    this.calls += 1;
    this.lastRequest = request;

    return {
      id:
        `negative-execution-${this.resultStatus.toLowerCase()}-${request.id}`,
      requestId:
        request.id,
      capability:
        request.capability,
      status:
        this.resultStatus,
      error:
        `${this.resultStatus} test execution result`,
      evidenceIds: [],
      startedAt:
        new Date().toISOString(),
      completedAt:
        new Date().toISOString(),
    };
  }
}

async function runCase(
  status: NegativeStatus,
): Promise<NegativeCaseResult> {
  const tempDirectory =
    mkdtempSync(
      join(
        tmpdir(),
        `happy-20n-${status.toLowerCase()}-`,
      ),
    );

  const persistenceFile =
    join(
      tempDirectory,
      "orchestration-state.json",
    );

  try {
    const orchestration =
      new HappyOrchestrationEngine(
        persistenceFile,
      );

    const negativeEngine =
      new NegativeExecutionEngine(
        status,
      );

    (
      orchestration as unknown as {
        execution:
          NegativeExecutionEngine;
      }
    ).execution = negativeEngine;

    const request = {
      id:
        `negative-${status.toLowerCase()}-${Date.now()}`,
      command:
        status === "WAITING_APPROVAL"
          ? "delete file approval-test.txt"
          : `test negative execution state ${status}`,
      organizationId:
        "runtime-20n-org",
      workspaceId:
        "runtime-20n-workspace",
      userId:
        "runtime-20n-user",
      source:
        "TEXT" as const,
      authorization: {
          role: "USER" as const,
          scope: "WORKSPACE" as const,
          roleSource: "TRUSTED_SERVER" as const,
          authenticated: true,
      },
      approved:
        status !== "WAITING_APPROVAL",
      createdAt:
        new Date().toISOString(),
    };

    const result =
      await orchestration.run(
        request,
      );

    const persisted =
      readFileSync(
        persistenceFile,
        "utf8",
      );

    const executionStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "EXECUTION",
      );

    const verificationStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "VERIFICATION",
      );

    const approvalStage =
      result.trace.stages.find(
        (stage) =>
          stage.stage === "APPROVAL",
      );

    // Wait for approval is an intentional early return.
    if (status === "WAITING_APPROVAL") {
      assert(
        negativeEngine.calls === 0,
        "WAITING_APPROVAL must stop before ExecutionEngine.",
      );

      assert(
        result.status ===
          "WAITING_APPROVAL",
        `WAITING_APPROVAL final status changed to ${result.status}.`,
      );

      assert(
        result.currentStage ===
          "APPROVAL",
        `WAITING_APPROVAL final stage changed to ${result.currentStage}.`,
      );

      assert(
        executionStage === undefined,
        "WAITING_APPROVAL incorrectly created an EXECUTION stage.",
      );

      assert(
        verificationStage === undefined,
        "WAITING_APPROVAL incorrectly reached VERIFICATION.",
      );

      assert(
        result.evidenceIds.length === 0,
        "WAITING_APPROVAL incorrectly produced execution evidence.",
      );

      assert(
        result.verificationRequestId ===
          undefined,
        "WAITING_APPROVAL incorrectly created a verification request.",
      );

      assertDefined(
        approvalStage,
        "WAITING_APPROVAL approval stage is missing.",
      );

      assert(
        approvalStage.status ===
          "WAITING_APPROVAL",
        `Approval stage was expected to remain WAITING_APPROVAL, received ${approvalStage.status}.`,
      );

      assert(
        persisted.includes(
          `approval-${request.id}`,
        ),
        "WAITING_APPROVAL approval record was not persisted.",
      );

      assert(
        persisted.includes(
          request.id,
        ),
        "WAITING_APPROVAL request was not persisted.",
      );

      return {
        status,
        executionCalls:
          negativeEngine.calls,
        finalStatus:
          result.status,
        finalStage:
          result.currentStage,
        executionStage:
          executionStage?.status,
        verificationStage:
          verificationStage?.status,
        evidenceCount:
          result.evidenceIds.length,
        verificationRequestPresent:
          result.verificationRequestId !== undefined,
        persistedExecution:
          persisted.includes(
            request.id,
          ),
        persistedVerification:
          false,
        persistedEvidence:
          false,
        persistedApproval:
          persisted.includes(
            `approval-${request.id}`,
          ),
      };
    }

    // All other negative states must reach execution exactly once.
    assert(
      negativeEngine.calls === 1,
      `${status}: expected one execution call, received ${negativeEngine.calls}.`,
    );

    assertDefined(
      negativeEngine.lastRequest,
      `${status}: execution request missing.`,
    );

    assertDefined(
      executionStage,
      `${status}: EXECUTION stage missing.`,
    );

    assertDefined(
      verificationStage,
      `${status}: VERIFICATION stage missing.`,
    );

    assert(
      result.executionRequestId ===
        negativeEngine.lastRequest.id,
      `${status}: executionRequestId mismatch.`,
    );

    assert(
      result.status !==
        "COMPLETED",
      `${status}: negative execution incorrectly became COMPLETED.`,
    );

    assert(
      result.currentStage !==
        "COMPLETE",
      `${status}: negative execution incorrectly became COMPLETE.`,
    );

    assert(
      result.evidenceIds.length === 1,
      `${status}: expected one execution evidence record, received ${result.evidenceIds.length}.`,
    );

    const evidenceId =
      result.evidenceIds[0];

    assert(
      typeof evidenceId === "string" &&
      evidenceId.length > 0,
      `${status}: evidence ID is invalid.`,
    );

    assert(
      verificationStage.status !==
        "COMPLETED",
      `${status}: verification incorrectly succeeded.`,
    );

    if (status === "FAILED") {
      assert(
        executionStage.status ===
          "FAILED",
        "FAILED: execution stage should be FAILED.",
      );

      assert(
        verificationStage.status ===
          "FAILED",
        "FAILED: verification stage should be FAILED.",
      );

      assert(
        result.status ===
          "FAILED",
        "FAILED: final status should be FAILED.",
      );

      assert(
        result.currentStage ===
          "BLOCKED",
        "FAILED: final stage should be BLOCKED.",
      );
    }

    if (status === "BLOCKED") {
      assert(
        executionStage.status ===
          "BLOCKED",
        "BLOCKED: execution stage should be BLOCKED.",
      );

      assert(
        verificationStage.status ===
          "FAILED",
        "BLOCKED: verification should not succeed.",
      );

      assert(
        result.status ===
          "BLOCKED",
        "BLOCKED: final status should be BLOCKED.",
      );

      assert(
        result.currentStage ===
          "BLOCKED",
        "BLOCKED: final stage should be BLOCKED.",
      );
    }

    if (status === "NOT_YET_CONNECTED") {
      assert(
        executionStage.status ===
          "NOT_YET_CONNECTED",
        "NOT_YET_CONNECTED execution stage was not preserved.",
      );

      assert(
        result.status ===
          "NOT_YET_CONNECTED",
        "NOT_YET_CONNECTED final status was not preserved.",
      );

      assert(
        result.currentStage ===
          "NOT_YET_CONNECTED",
        "NOT_YET_CONNECTED final stage was not preserved.",
      );

      assert(
        verificationStage.status ===
          "FAILED",
        "NOT_YET_CONNECTED should not produce successful verification.",
      );
    }

    assert(
      typeof result.verificationRequestId ===
        "string" &&
      result.verificationRequestId.length > 0,
      `${status}: verification request ID missing.`,
    );

    assertDefined(
      result.verificationRequestId,
      "Verification request ID is required for executed negative-path cases.",
    );

    const verificationRequestId =
      result.verificationRequestId;

    assert(
      persisted.includes(
        request.id,
      ),
      `${status}: execution request was not persisted.`,
    );

    assert(
      persisted.includes(
        verificationRequestId,
      ),
      `${status}: verification request/result was not persisted.`,
    );

    assert(
      persisted.includes(
        evidenceId,
      ),
      `${status}: evidence was not persisted.`,
    );

    return {
      status,
      executionCalls:
        negativeEngine.calls,
      finalStatus:
        result.status,
      finalStage:
        result.currentStage,
      executionStage:
        executionStage.status,
      verificationStage:
        verificationStage.status,
      evidenceCount:
        result.evidenceIds.length,
      verificationRequestPresent:
        verificationRequestId !== undefined,
      persistedExecution:
        true,
      persistedVerification:
        true,
      persistedEvidence:
        true,
      persistedApproval:
        false,
    };
  } finally {
    rmSync(
      tempDirectory,
      {
        recursive: true,
        force: true,
      },
    );
  }
}

async function main(): Promise<void> {
  const statuses:
    NegativeStatus[] = [
      "FAILED",
      "BLOCKED",
      "WAITING_APPROVAL",
      "NOT_YET_CONNECTED",
    ];

  const results:
    NegativeCaseResult[] = [];

  for (const status of statuses) {
    results.push(
      await runCase(status),
    );
  }

  for (const result of results) {
    console.log(
      `Negative-path case ${result.status}: PASS`,
    );

    console.log(result);
  }

  assert(
    results.every(
      (result) => {
        if (
          result.status ===
          "WAITING_APPROVAL"
        ) {
          return (
            result.executionCalls === 0 &&
            result.finalStatus ===
              "WAITING_APPROVAL" &&
            result.finalStage ===
              "APPROVAL" &&
            result.evidenceCount === 0 &&
            !result.verificationRequestPresent &&
            result.persistedApproval
          );
        }

        return (
          result.executionCalls === 1 &&
          result.finalStatus !==
            "COMPLETED" &&
          result.finalStage !==
            "COMPLETE" &&
          result.evidenceCount === 1 &&
          result.verificationRequestPresent &&
          result.persistedExecution &&
          result.persistedVerification &&
          result.persistedEvidence
        );
      },
    ),
    "One or more negative-path cases violated the canonical failure/approval contract.",
  );

  console.log(
    "Negative execution-path safety test: PASS",
  );

  console.log({
    totalCases:
      results.length,
    failedCaseSafe:
      results.find(
        (result) =>
          result.status === "FAILED",
      )?.finalStatus === "FAILED",
    blockedCaseSafe:
      (() => {
        const blocked =
          results.find(
            (result) =>
              result.status ===
              "BLOCKED",
          );

        return (
          blocked !== undefined &&
          blocked.executionCalls === 1 &&
          blocked.finalStatus ===
            "BLOCKED" &&
          blocked.finalStage ===
            "BLOCKED" &&
          blocked.executionStage ===
            "BLOCKED" &&
          blocked.verificationStage ===
            "FAILED" &&
          blocked.evidenceCount ===
            1 &&
          blocked.verificationRequestPresent ===
            true &&
          blocked.persistedExecution ===
            true &&
          blocked.persistedVerification ===
            true &&
          blocked.persistedEvidence ===
            true
        );
      })(),    waitingApprovalEarlyStop:
      results.find(
        (result) =>
          result.status ===
          "WAITING_APPROVAL",
      )?.executionCalls === 0,
    notYetConnectedPreserved:
      results.find(
        (result) =>
          result.status ===
          "NOT_YET_CONNECTED",
      )?.finalStatus ===
        "NOT_YET_CONNECTED",
    falseCompletionPrevented:
      results.every(
        (result) =>
          result.finalStatus !==
          "COMPLETED",
      ),
    falseCompleteStagePrevented:
      results.every(
        (result) =>
          result.finalStage !==
          "COMPLETE",
      ),
    verificationFalseSuccessPrevented:
      results
        .filter(
          (result) =>
            result.status !==
            "WAITING_APPROVAL",
        )
        .every(
          (result) =>
            result.verificationStage !==
            "COMPLETED",
        ),
    evidenceCapturedForExecutedNegativeCases:
      results
        .filter(
          (result) =>
            result.status !==
            "WAITING_APPROVAL",
        )
        .every(
          (result) =>
            result.evidenceCount === 1,
        ),
    approvalPersisted:
      results.find(
        (result) =>
          result.status ===
          "WAITING_APPROVAL",
      )?.persistedApproval === true,
    noRealExternalAdapterExecuted:
      true,
  });
}

main().catch(
  (error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  },
);




