"use client";

import {
    useCallback,
    useEffect,
    useState,
} from "react";

type ApprovalItem = {
    id: string;
    requestId: string | null;
    planId: string | null;
    status: string | null;
    createdAt: string;
    updatedAt: string;
};

type ApprovalResponse = {
    status?: string;
    scopeKey?: string;
    count?: number;
    approvals?: ApprovalItem[];
    approvalId?: string;
    requestId?: string | null;
    planId?: string | null;
    decisionId?: string;
    auditEventId?: string;
    decision?: "APPROVED" | "REJECTED";
    approverId?: string;
    reason?: string;
    decidedAt?: string;
    version?: number;
    updatedAt?: string;
    error?: string;
    verified?: boolean;
};

export default function WorkspaceApprovalsPage() {
    const [approvals, setApprovals] =
        useState<ApprovalItem[]>([]);

    const [loading, setLoading] =
        useState(true);

    const [busyId, setBusyId] =
        useState<string | null>(null);

    const [message, setMessage] =
        useState("");

    const [error, setError] =
        useState("");

    const loadApprovals =
        useCallback(async () => {
            setLoading(true);
            setError("");

            try {
                const response =
                    await fetch(
                        "/api/approvals/decision",
                        {
                            method: "GET",
                            credentials: "include",
                            cache: "no-store",
                        },
                    );

                const data: ApprovalResponse =
                    await response.json();

                if (!response.ok) {
                    throw new Error(
                        data.error ||
                            `Approval query failed (${response.status}).`,
                    );
                }

                setApprovals(
                    data.approvals || [],
                );
            } catch (requestError) {
                setError(
                    requestError instanceof Error
                        ? requestError.message
                        : "Unable to load approvals.",
                );
            } finally {
                setLoading(false);
            }
        }, []);

    useEffect(() => {
        void loadApprovals();
    }, [loadApprovals]);

    const decide = async (
        approvalId: string,
        decision:
            | "APPROVED"
            | "REJECTED",
    ) => {
        setBusyId(approvalId);
        setError("");
        setMessage("");

        try {
            const response =
                await fetch(
                    "/api/approvals/decision",
                    {
                        method: "POST",
                        credentials: "include",
                        headers: {
                            "Content-Type":
                                "application/json",
                        },
                        body: JSON.stringify({
                            approvalId,
                            decision,
                        }),
                    },
                );

            const data: ApprovalResponse =
                await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error ||
                        `Approval decision failed (${response.status}).`,
                );
            }

            setMessage(
                `${decision} persisted successfully. Decision: ${data.decisionId || "created"}`,
            );

            await loadApprovals();
        } catch (requestError) {
            setError(
                requestError instanceof Error
                    ? requestError.message
                    : "Approval decision failed.",
            );
        } finally {
            setBusyId(null);
        }
    };

    return (
        <main
            style={{
                minHeight: "100vh",
                background:
                    "#050505",
                color: "#f5f5f5",
                padding: "40px",
                fontFamily:
                    "Arial, sans-serif",
            }}
        >
            <div
                style={{
                    maxWidth: "1100px",
                    margin: "0 auto",
                }}
            >
                <div
                    style={{
                        display: "flex",
                        justifyContent:
                            "space-between",
                        alignItems: "center",
                        gap: "20px",
                        marginBottom: "30px",
                    }}
                >
                    <div>
                        <div
                            style={{
                                fontSize: "12px",
                                letterSpacing:
                                    "0.18em",
                                opacity: 0.55,
                                marginBottom:
                                    "8px",
                            }}
                        >
                            HAPPY / WORKSPACE OS
                        </div>

                        <h1
                            style={{
                                margin: 0,
                                fontSize: "36px",
                            }}
                        >
                            Approvals
                        </h1>

                        <p
                            style={{
                                marginTop:
                                    "10px",
                                opacity: 0.65,
                            }}
                        >
                            Authenticated approval
                            control center
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            void loadApprovals()
                        }
                        disabled={loading}
                        style={{
                            padding:
                                "12px 18px",
                            borderRadius:
                                "10px",
                            border:
                                "1px solid #333",
                            background:
                                "#111",
                            color: "#fff",
                            cursor:
                                loading
                                    ? "default"
                                    : "pointer",
                        }}
                    >
                        Refresh
                    </button>
                </div>

                {message && (
                    <div
                        style={{
                            padding: "14px 16px",
                            marginBottom: "18px",
                            borderRadius: "10px",
                            background:
                                "rgba(40,140,80,0.14)",
                            border:
                                "1px solid rgba(80,180,110,0.35)",
                        }}
                    >
                        {message}
                    </div>
                )}

                {error && (
                    <div
                        style={{
                            padding: "14px 16px",
                            marginBottom: "18px",
                            borderRadius: "10px",
                            background:
                                "rgba(180,60,60,0.14)",
                            border:
                                "1px solid rgba(220,90,90,0.35)",
                        }}
                    >
                        {error}
                    </div>
                )}

                <section
                    style={{
                        padding: "20px",
                        borderRadius: "14px",
                        border:
                            "1px solid #202020",
                        background:
                            "#0a0a0a",
                    }}
                >
                    <div
                        style={{
                            marginBottom:
                                "18px",
                            fontSize: "14px",
                            opacity: 0.7,
                        }}
                    >
                        Pending approvals:{" "}
                        <strong>
                            {approvals.length}
                        </strong>
                    </div>

                    {loading && (
                        <div
                            style={{
                                padding:
                                    "25px 0",
                                opacity: 0.6,
                            }}
                        >
                            Loading approvals...
                        </div>
                    )}

                    {!loading &&
                        approvals.length === 0 && (
                            <div
                                style={{
                                    padding:
                                        "30px 0",
                                    opacity: 0.6,
                                }}
                            >
                                No pending approvals.
                            </div>
                        )}

                    {!loading &&
                        approvals.map(
                            (approval) => {
                                const busy =
                                    busyId ===
                                    approval.id;

                                return (
                                    <article
                                        key={
                                            approval.id
                                        }
                                        style={{
                                            padding:
                                                "18px",
                                            marginBottom:
                                                "14px",
                                            borderRadius:
                                                "12px",
                                            border:
                                                "1px solid #242424",
                                            background:
                                                "#0f0f0f",
                                        }}
                                    >
                                        <div
                                            style={{
                                                fontSize:
                                                    "12px",
                                                opacity:
                                                    0.5,
                                                marginBottom:
                                                    "8px",
                                            }}
                                        >
                                            APPROVAL
                                        </div>

                                        <div
                                            style={{
                                                fontSize:
                                                    "18px",
                                                marginBottom:
                                                    "8px",
                                                wordBreak:
                                                    "break-word",
                                            }}
                                        >
                                            {approval.id}
                                        </div>

                                        <div
                                            style={{
                                                display:
                                                    "grid",
                                                gridTemplateColumns:
                                                    "repeat(auto-fit,minmax(220px,1fr))",
                                                gap:
                                                    "8px",
                                                fontSize:
                                                    "13px",
                                                opacity:
                                                    0.7,
                                                marginBottom:
                                                    "16px",
                                            }}
                                        >
                                            <div>
                                                Request:{" "}
                                                {approval.requestId ||
                                                    "—"}
                                            </div>

                                            <div>
                                                Plan:{" "}
                                                {approval.planId ||
                                                    "—"}
                                            </div>

                                            <div>
                                                Status:{" "}
                                                {approval.status ||
                                                    "—"}
                                            </div>

                                            <div>
                                                Created:{" "}
                                                {approval.createdAt}
                                            </div>
                                        </div>

                                        <div
                                            style={{
                                                display:
                                                    "flex",
                                                gap:
                                                    "10px",
                                                flexWrap:
                                                    "wrap",
                                            }}
                                        >
                                            <button
                                                type="button"
                                                disabled={busy}
                                                onClick={() =>
                                                    void decide(
                                                        approval.id,
                                                        "APPROVED",
                                                    )
                                                }
                                                style={{
                                                    padding:
                                                        "11px 18px",
                                                    borderRadius:
                                                        "9px",
                                                    border:
                                                        "1px solid #4b8",
                                                    background:
                                                        "#12351f",
                                                    color:
                                                        "#d9ffe5",
                                                    cursor:
                                                        busy
                                                            ? "default"
                                                            : "pointer",
                                                }}
                                            >
                                                {busy
                                                    ? "Processing..."
                                                    : "Approve"}
                                            </button>

                                            <button
                                                type="button"
                                                disabled={busy}
                                                onClick={() =>
                                                    void decide(
                                                        approval.id,
                                                        "REJECTED",
                                                    )
                                                }
                                                style={{
                                                    padding:
                                                        "11px 18px",
                                                    borderRadius:
                                                        "9px",
                                                    border:
                                                        "1px solid #844",
                                                    background:
                                                        "#351515",
                                                    color:
                                                        "#ffdcdc",
                                                    cursor:
                                                        busy
                                                            ? "default"
                                                            : "pointer",
                                                }}
                                            >
                                                {busy
                                                    ? "Processing..."
                                                    : "Reject"}
                                            </button>
                                        </div>
                                    </article>
                                );
                            },
                        )}
                </section>

                <div
                    style={{
                        marginTop: "24px",
                        padding: "14px 16px",
                        borderRadius: "10px",
                        background:
                            "#0b0b0b",
                        border:
                            "1px solid #1d1d1d",
                        fontSize: "12px",
                        opacity: 0.55,
                    }}
                >
                    Approval decisions are
                    authenticated and persisted to
                    HAPPY remote runtime state.
                    Execution resume is handled by
                    the separate continuation layer.
                </div>
            </div>
        </main>
    );
}
