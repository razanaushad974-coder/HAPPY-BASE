import type { SupabaseClient } from "@supabase/supabase-js";

import {
    createRuntimeScopeKey,
    SupabaseRuntimeSnapshotStore,
    type RuntimeSnapshotRecord,
    type RuntimeSnapshotScope,
    type SupabaseRuntimePersistenceStatus,
} from "../persistence/adapters/supabase-runtime-snapshot";

import type { HappyStateStore } from "../state/happy-state-store";

export interface RuntimePersistenceOutcome {
    status: SupabaseRuntimePersistenceStatus;
    scopeKey: string;
    version?: number;
    record?: RuntimeSnapshotRecord;
    error?: string;
}

export async function persistAuthenticatedRuntimeSnapshot(
    client: SupabaseClient | undefined,
    store: HappyStateStore,
    scope: RuntimeSnapshotScope,
    version: number = 1,
): Promise<RuntimePersistenceOutcome> {
    const scopeKey =
        createRuntimeScopeKey(scope);

    if (!client) {
        return {
            status: "NOT_YET_CONNECTED",
            scopeKey,
            error:
                "Authenticated Supabase client is not connected.",
        };
    }

    try {
        const state =
            await store.snapshot();

        const snapshotStore =
            new SupabaseRuntimeSnapshotStore(
                client,
            );

        const record =
            await snapshotStore.save(
                scope,
                state,
                version,
            );

        return {
            status: "AVAILABLE",
            scopeKey,
            version: record.version,
            record,
        };
    }
    catch (error) {
        const message =
            error instanceof Error
                ? error.message
                : "Supabase runtime snapshot persistence failed.";

        return {
            status: "ERROR",
            scopeKey,
            error: message,
        };
    }
}