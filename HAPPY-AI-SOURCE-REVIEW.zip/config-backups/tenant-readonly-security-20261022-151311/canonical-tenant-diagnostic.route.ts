import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { resolveCanonicalSupabaseTenant } from "@/core/workspace/supabase-tenant-resolver";

export const dynamic = "force-dynamic";

export async function GET() {
    try {
        const supabase =
            await createSupabaseServerClient();

        const sessionResult =
            await supabase.auth.getSession();

        if (
            sessionResult.error ||
            !sessionResult.data.session
        ) {
            return NextResponse.json(
                {
                    status: "UNAUTHENTICATED",
                    verified: false,
                    error:
                        sessionResult.error?.message ??
                        "No authenticated Supabase session.",
                },
                { status: 401 },
            );
        }

        const accessToken =
            sessionResult.data.session.access_token;

        const tenant =
            await resolveCanonicalSupabaseTenant(accessToken, { allowProvisioning: false });

        return NextResponse.json({
            status:
                "LIVE_CANONICAL_TENANT_RESOLVED",
            verified: true,
            organizationId:
                tenant.organizationId,
            organizationName:
                tenant.organizationName,
            organizationSlug:
                tenant.organizationSlug,
            workspaceId:
                tenant.workspaceId,
            workspaceName:
                tenant.workspaceName,
            workspaceSlug:
                tenant.workspaceSlug,
            userId:
                tenant.userId,
            organizationIdLooksUuid:
                /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
                    tenant.organizationId,
                ),
            workspaceIdLooksUuid:
                /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
                    tenant.workspaceId,
                ),
        });
    } catch (error: unknown) {
        return NextResponse.json(
            {
                status:
                    "LIVE_CANONICAL_TENANT_RESOLUTION_FAILED",
                verified: false,
                error:
                    error instanceof Error
                        ? error.message
                        : String(error),
            },
            { status: 500 },
        );
    }
}
