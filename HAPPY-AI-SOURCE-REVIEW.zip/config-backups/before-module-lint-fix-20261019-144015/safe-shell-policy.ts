import { resolve, relative, isAbsolute } from "node:path";
export type ShellSafetyStatus =
  | "ALLOWED"
  | "WAITING_APPROVAL"
  | "BLOCKED"
  | "NOT_YET_CONNECTED";

export interface SafeShellRequest {
  executable: string;
  args?: string[];
  cwd?: string;
  timeoutMs?: number;
  approved?: boolean;
  workspaceRoot: string;
}

export interface ShellSafetyDecision {
  status: ShellSafetyStatus;
  reason: string;
  executable?: string;
  normalizedArgs: string[];
  cwd: string;
  timeoutMs: number;
}

const DEFAULT_TIMEOUT_MS = 30_000;

const ALLOWED_EXECUTABLES = new Set([
  "node",
  "node.exe",
  "npm",
  "npm.cmd",
  "npx",
  "npx.cmd",
  "git",
  "git.exe",
]);

const READ_ONLY_PATTERNS = [
  /^node(\.exe)?\s+--version$/i,
  /^npm(\.cmd)?\s+--version$/i,
  /^npx(\.cmd)?\s+tsc\s+--noEmit$/i,
  /^git(\.exe)?\s+status$/i,
  /^git(\.exe)?\s+diff\s+--check$/i,
  /^git(\.exe)?\s+diff\s+--name-only$/i,
  /^git(\.exe)?\s+log\s+-1\s+--oneline$/i,
];

const FORBIDDEN_SHELL_SYNTAX =
  /[&|;<>\x60$(){}\[\]!*?^]/;

function normalizeExecutable(
  executable: string,
): string {
  return executable.trim();
}

function normalizeArgs(
  args: string[] | undefined,
): string[] {
  return (args ?? []).map((arg) => String(arg));
}

function normalizeTimeout(
  timeoutMs: number | undefined,
): number {
  if (!Number.isFinite(timeoutMs)) {
    return DEFAULT_TIMEOUT_MS;
  }

  return Math.min(
    DEFAULT_TIMEOUT_MS,
    Math.max(
      1000,
      Math.trunc(timeoutMs as number),
    ),
  );
}

function isWithinWorkspace(
  workspaceRoot: string,
  candidate: string,
): boolean {
const root = resolve(
    workspaceRoot,
  );

  const target = resolve(candidate);

  const relativePath = relative(
    root,
    target,
  );

  return (
    relativePath === "" ||
    (
      !relativePath.startsWith("..") &&
      !isAbsolute(relativePath)
    )
  );
}

function buildCommandString(
  executable: string,
  args: string[],
): string {
  return [
    executable,
    ...args,
  ].join(" ");
}

function isReadOnlyCommand(
  executable: string,
  args: string[],
): boolean {
  const command =
    buildCommandString(
      executable,
      args,
    );

  return READ_ONLY_PATTERNS.some(
    (pattern) =>
      pattern.test(command),
  );
}

export function evaluateSafeShellRequest(
  request: SafeShellRequest,
): ShellSafetyDecision {
  const executable =
    normalizeExecutable(
      request.executable,
    );

  const args =
    normalizeArgs(request.args);

  const workspaceRoot =
    request.workspaceRoot.trim();

  const cwd =
    request.cwd?.trim() ||
    workspaceRoot;

  const timeoutMs =
    normalizeTimeout(
      request.timeoutMs,
    );

  if (!workspaceRoot) {
    return {
      status: "BLOCKED",
      reason:
        "Workspace root is required.",
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  if (!executable) {
    return {
      status: "BLOCKED",
      reason:
        "Shell executable is required.",
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  if (
    !ALLOWED_EXECUTABLES.has(
      executable,
    )
  ) {
    return {
      status: "BLOCKED",
      reason:
        `Executable is not allowlisted: ${executable}`,
      executable,
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  if (
    FORBIDDEN_SHELL_SYNTAX.test(
      executable,
    )
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Forbidden shell syntax detected in executable.",
      executable,
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  for (const arg of args) {
    if (
      FORBIDDEN_SHELL_SYNTAX.test(arg)
    ) {
      return {
        status: "BLOCKED",
        reason:
          "Forbidden shell syntax detected in arguments.",
        executable,
        normalizedArgs: args,
        cwd,
        timeoutMs,
      };
    }
  }

  if (
    !isWithinWorkspace(
      workspaceRoot,
      cwd,
    )
  ) {
    return {
      status: "BLOCKED",
      reason:
        "Working directory must remain inside the HAPPY workspace root.",
      executable,
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  const readOnly =
    isReadOnlyCommand(
      executable,
      args,
    );

  if (!readOnly && !request.approved) {
    return {
      status: "WAITING_APPROVAL",
      reason:
        "Shell commands that are not explicitly classified read-only require approval.",
      executable,
      normalizedArgs: args,
      cwd,
      timeoutMs,
    };
  }

  return {
    status: "ALLOWED",
    reason:
      readOnly
        ? "Command matches the safe read-only allowlist."
        : "Command passed the safe-shell policy with explicit approval.",
    executable,
    normalizedArgs: args,
    cwd,
    timeoutMs,
  };
}

export function getSafeShellAllowlist(): readonly string[] {
  return [...ALLOWED_EXECUTABLES];
}

export function getSafeShellMaxTimeoutMs(): number {
  return DEFAULT_TIMEOUT_MS;
}
