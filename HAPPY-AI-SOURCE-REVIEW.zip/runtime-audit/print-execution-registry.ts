import { createDefaultExecutionRegistry } from "../src/core/execution/default-registry";

const registry = createDefaultExecutionRegistry();

for (const adapter of registry.list()) {
  console.log(`${adapter.capability} -> ${adapter.status()}`);
}
